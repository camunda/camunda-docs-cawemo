import { getBaseUrl, getUser, getIamBaseUrl } from '../../helpers';
import { ADMIN_USER } from '../../../scripts/prepare/fixtures';

describe('Sign up', function () {
  it.default('a user can sign up via token', function () {
    const user = getUser();

    cy.createSignupInvitationToken({ invitedEmail: user.email, inviter: ADMIN_USER }).then((tokenId) => {
      cy.visit(getBaseUrl(`signup?token=${tokenId}`));

      // Assert that the email input is already populated and disabled.
      cy.getByTestId('email').should('have.value', user.email).and('be.disabled');

      // Type the user's name, password, and submit the sign up form.
      cy.getByTestId('name')
        .type(user.name)
        .getByTestId('new-password')
        .type(user.password)
        .getByTestId('submit')
        .click();

      // Assert that the user has been redirected to Cawemo.
      cy.url().should('eq', getBaseUrl());

      // Assert that the avatar from the homepage is visible.
      cy.getByTestId(`avatar-${user.name}`).should('be.visible');

      // Remove the user.
      cy.removeUser(user);
    });
  });
});
