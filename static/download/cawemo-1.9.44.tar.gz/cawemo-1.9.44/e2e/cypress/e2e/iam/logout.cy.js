describe('Logout', function () {
  beforeEach(function () {
    cy.createUserAndLogin().as('user').visit('/');
  });

  afterEach(function () {
    cy.removeUser(this.user);
  });

  it('logs out a user', function () {
    // Open the user menu and press the logout link.
    cy.getByTestId('user-menu-button').click().getByTestId('logout-menu-item').click();

    // Assert that IAM's login page is shown.
    cy.getByTestId('submit').should('be.visible');

    // Assert that after log out, the user can't access Cawemo's homepage.
    cy.visit('/').getByTestId(`avatar-${this.user.name}`).should('not.exist');
  });
});
