import { getUser, getBaseUrl, getEmail } from '../../helpers';

describe('Project invitations', function () {
  beforeEach(function () {
    // Create a user and a project.
    cy.createUserAndLogin().as('user').then(cy.createProject).as('project');
    cy.deleteAllEmails();
  });

  afterEach(function () {
    cy.removeUser(this.user);
  });

  describe.default('Project invitations', function () {
    it('a project owner can invite an existing user', function () {
      cy.joinUserToOrganization(this.user).then((collaborator) => {
        // Visit the created project.
        cy.visit(`/projects/${this.project.id}`);

        // Expand the sidebar and click the "Add" button.
        cy.getByTestId('add-collaborator').click();

        cy.getByTestId('multi-select-input').type(collaborator.email.substr(0, 5));

        cy.getByTestId('user-suggestions')
          .should('be.visible')
          .getByTestId(`collaborator-${collaborator.name}`)
          .should('be.visible')
          .and('contain', collaborator.name)
          .and('contain', collaborator.email)
          .click();

        cy.getByTestId('multi-select-input').type(getEmail() + '{enter}');

        cy.getByTestId('empty-state').should('be.visible').and('contain', 'User not found!');

        cy.getByTestId('chip').should('be.visible').and('have.length', 1).and('have.text', collaborator.email);

        cy.getByTestId('invite-email-button').should('not.be.disabled').click();

        cy.getByTestId('entity-list')
          .should('be.visible')
          .getByTestId(`entity-${collaborator.name}`)
          .should('be.visible')
          .and('contain', collaborator.name);

        cy.login(collaborator);

        // Assert that the invitation email has arrived
        cy.getLinkFromEmail(collaborator.email, 'invite').as('invitation');
        cy.get('@invitation').should('include', `/projects/${this.project.id}`).then(cy.visit);

        cy.url().should('include', 'projects').should('include', this.project.id);

        cy.getByTestId('breadcrumb-project-menu').should('have.text', this.project.name);

        cy.removeUser(collaborator);
      });
    });
  });

  describe.ldap('Project invitations', function () {
    it('a project owner can invite an existing user', function () {
      cy.createUser().then((user) => {
        cy.createInvitation(user, this.project.id);

        // Change the session.
        cy.login(user);

        // Await the invitation email.
        cy.getLinkFromEmail(user.email, 'invite').as('invitation');

        // Assert that the invitation email has arrived and visit its URL.
        cy.get('@invitation').then(cy.visit);

        // Assert that the redirect goes to the right project.
        cy.url().should('include', 'projects').should('include', this.project.id);

        // Assert that the right project is displayed and that the joined user
        // is part of the collaborator list.
        cy.getByTestId('breadcrumb-project-menu')
          .should('have.text', this.project.name)
          .getByTestId(`entity-You`)
          .should('exist');

        // Remove the invited user.
        cy.removeUser(user);
      });
    });

    it('an invitation for an non-existing user can be cancelled', function () {
      // invite a non-existing to the project.
      const newUser = getUser();

      cy.createInvitation(newUser, this.project.id).as('invitation');

      // Open the project and remove the invitation.
      cy.visit(`/projects/${this.project.id}`)
        .getByTestId(`entity-${newUser.email}`)
        .find('[data-test="entity-context-dropdown"]')
        .click()
        .getByTestId('remove-collaborator')
        .click()
        .getByTestId('confirm-button')
        .click();

      // log out inviting user
      cy.logout();

      const expectedStatus = 401;
      // Get the invitation link and assert that it can't be accessed any longer,
      // instead returning a 404.
      cy.get('@invitation').then((url) => {
        cy.request({ url, failOnStatusCode: false }).its('status').should('eq', expectedStatus);
      });
    });

    it('a project collaborator can leave a project', function () {
      cy.createUser().then((collaborator) => {
        cy.createInvitation(collaborator, this.project.id).as('invitation');

        // Log the invited, existing user in.
        cy.login(collaborator);

        // Get the invitation link, open it and join the project.
        cy.get('@invitation').then(cy.visit);

        // Click the "Leave project" button.
        cy.getByTestId('entity-You')
          .find('[data-test="entity-context-dropdown"]')
          .first()
          .click()
          .getByTestId('leave-project')
          .click();

        // Assert that the confirmation modal is displayed and confirm.
        cy.contains('Leave project').should('be.visible').getByTestId('confirm-button').click();

        // Assert that the snackbar is visible and that the collaborator
        // has been redirected to the homepage.
        cy.getByTestId('snackbar')
          .should('be.visible')
          .and('have.text', 'You have left the project.')
          .url()
          .should('eq', getBaseUrl());

        // Open the same project again.
        cy.visit(`/projects/${this.project.id}`);

        // Assert that the user doesn't have access to the project anymore.
        cy.contains('Project not found!')
          .should('exist')
          .getByTestId('breadcrumb-project')
          .should('be.visible')
          .and('have.text', 'Project Not Found');

        // Remove the invited user.
        cy.removeUser(collaborator);
      });
    });
  });

  describe.ldap('Project invitations', function () {
    it('a project owner can add a new user', function () {
      cy.createUserInLdapOnly().then((newUser) => {
        // Visit the created project.
        cy.visit(`/projects/${this.project.id}`);

        // Expand the sidebar and click the "Add" button.
        cy.getByTestId('add-collaborator').click();

        // Assert that the submit button is disabled.
        cy.getByTestId('invite-email-button').should('be.disabled');

        // Assert that the invitation modal is visible and has the correct project name.
        cy.getByTestId('invitation-modal-title')
          .should('be.visible')
          .and('have.text', `Add collaborators to "${this.project.name}"`);

        // Type in the new user's email address and invite them
        cy.getByTestId('multi-select-input').type(newUser.email + '{enter}');
        cy.getByTestId('chip').should('be.visible').and('have.length', 1).and('have.text', newUser.email);
        cy.getByTestId('invite-email-button').should('not.be.disabled').click();

        // Assert that the snackbar is visible and has the right text.
        cy.getByTestId('snackbar').should('be.visible').and('have.text', 'The user has been added.');

        // Await the invitation email.
        cy.getLinkFromEmail(newUser.email, 'invite').as('invitation');

        cy.login(newUser);

        // Assert that the invitation email has arrived and visit its URL.
        cy.get('@invitation').should('include', `/projects/${this.project.id}`).then(cy.visit);

        // Assert that the right project is displayed and that the joined user
        // is part of the collaborator list.
        cy.getByTestId('breadcrumb-project-menu')
          .should('have.text', this.project.name)
          .getByTestId(`entity-${this.user.name}`)
          .should('exist');

        cy.removeUser(newUser);
      });
    });

    it('a new user implicitly joins all projects on log in', function () {
      cy.createUserInLdapOnly().then((newUser) => {
        cy.createInvitation(newUser, this.project.id).as('invitation');
        cy.createProject(this.user).then((project2) => {
          cy.createInvitation(newUser, project2.id).as('invitation2');
        });
        cy.login(newUser);

        cy.getByTestId('entity-list').first().find('li').should('have.length', 2);

        cy.removeUser(newUser);
      });
    });

    it("an invitation can't be resent", function () {
      const user = getUser();

      // Open the project.
      cy.visit(`/projects/${this.project.id}`);

      // Invite a collaborator manually.
      cy.getByTestId('add-collaborator')
        .click()
        .getByTestId('multi-select-input')
        .type(user.email + '{enter}')
        .getByTestId('invite-email-button')
        .click();

      // Open the dropdown and assert "Resend invitation" does not exist.
      cy.getByTestId(`entity-${user.email.toLowerCase()}`)
        .find('[data-test="entity-context-dropdown"]')
        .click()
        .getByTestId('resend-invitation')
        .should('not.exist');
    });

    it("the project owner can't copy the invitation link directly", function () {
      const user = getUser();

      // Open the project.
      cy.visit(`/projects/${this.project.id}`);

      // Invite a collaborator manually.
      cy.getByTestId('add-collaborator')
        .click()
        .getByTestId('multi-select-input')
        .type(user.email + '{enter}')
        .getByTestId('invite-email-button')
        .click();

      // Open the dropdown and click on "Copy invitation URL".
      cy.getByTestId(`entity-${user.email.toLowerCase()}`)
        .find('[data-test="entity-context-dropdown"]')
        .click()
        .getByTestId('copy-invitation')
        .should('not.exist');
    });
  });
});
