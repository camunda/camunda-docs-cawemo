describe('UI Form', function () {
  beforeEach(function () {
    // Create a new user, project and template.
    cy.createUserAndLogin()
      .as('user')
      .then((user) => {
        cy.createProject(user, 'CATALOG')
          .as('project')
          .then((project) => {
            cy.createTemplate(project, 'TEMPLATE_SERVICE_TASK').as('template');
          });
      });
  });

  afterEach(function () {
    cy.removeUser(this.user);
    cy.removeAllProjects();
  });

  it('only the owner can edit a service task template', function () {
    // Open the template.
    cy.visit(`/templates/${this.template.id}`);

    // Join a new user to the existing user's organization.
    cy.joinUserToOrganization(this.user).then((collaborator) => {
      // Login as the collaborator.
      cy.login(collaborator).visit(`/templates/${this.template.id}`);

      // Assert that a message is displayed for collaborators.
      cy.getByTestId('collaborator-info')
        .should('be.visible')
        .and('contain', 'Only the project owner is allowed to modify templates.');

      // Assert that the editor is read-only.
      cy.get('input').first().should('have.attr', 'disabled');

      cy.removeUser(collaborator);
    });
  });

  it('the owner can write values in the form', function () {
    // Open the template.
    cy.visit(`/templates/${this.template.id}`);

    // Assert that the form is visible.
    cy.getByTestId('form-editor').should('be.visible');

    // Fill in content for the template name, service task label,
    // package name, and description.
    cy.get('input[name="name"]')
      .clear()
      .type('Template #1')
      .get('input[name="service-task-label"]')
      .type('My Service Task')
      .get('textarea[name="description"]')
      .type('Template description')
      .get('input[name="implementation-name"]')
      .type('package.name');

    // Assert that the breadcrumb shows the edited template name
    // and that the status text is shown.
    cy.getByTestId('breadcrumb-template')
      .should('have.text', 'Template #1')
      .getByTestId('autosave')
      .should('contain', 'Autosaved');

    // Open the code editor and wait until it has loaded.
    cy.getByTestId('toggle-editor').click().getByTestId('json-editor').should('be.visible');

    // Wait for the editor to load.
    cy.waitForEditor();

    // Assert that the code editor contains the changed content.
    cy.contains('"name": "Template #1",').should('be.visible');
    cy.contains('"description": "Template description",').should('be.visible');
    // cy.contains('"value": "My Service Task",').should('be.visible');
    // cy.contains('"value": "package.name",').should('be.visible');

    // Assert that the user can go back to the form.
    cy.getByTestId('back-to-form').should('be.visible').click().getByTestId('form-editor').should('be.visible');
  });

  it('a user can manage the implementation', function () {
    // Increase the viewport so that the dropdown is visible.
    cy.viewport(1280, 720);

    // Prepare file downloads.
    cy.prepareDownload();

    // Open the template.
    cy.visit(`/templates/${this.template.id}`);

    // Assert that the implementation type is "UiPath" by default.
    cy.getByTestId('implementation-type').should('have.text', 'RPA Bridge Task - UiPath');

    // Assert that the implementation name is empty by default.
    cy.getByTestId('implementation-name').should('have.value', '');

    // Change the implementation type to "External Service Task".
    cy.getByTestId('implementation-type').click().getByTestId('external').click();

    // Assert that the diagram is saved.
    cy.getByTestId('autosave').should('be.visible').and('contain', 'Autosaved');

    // Change the implementation name.
    cy.getByTestId('implementation-name').type('123');

    // Assert that the correct properties are part of the JSON.
    cy.getTemplateJSON().then((json) => {
      expect(json.properties.length).to.equal(2);
      expect(json.properties[1].value).to.equal('123');
    });

    // Change the implementation type to "UiPath".
    cy.getByTestId('implementation-type').click().getByTestId('uipath').click();

    // Change the implementation name.
    cy.getByTestId('implementation-name').clear().type('456');

    // Assert that the correct properties are part of the JSON.
    cy.getTemplateJSON().then((json) => {
      expect(json.properties.length).to.equal(4);
      expect(json.properties[0].value).to.equal('456');
      expect(json.properties[0].label).to.equal('UiPath Package Name');
      expect(json.properties[3].value).to.equal('uipath');
    });

    // Change the implementation type to "Automation Anywhere".
    cy.getByTestId('implementation-type').click().getByTestId('automationanywhere').click();

    // Assert that the correct properties are part of the JSON.
    cy.getTemplateJSON().then((json) => {
      expect(json.properties.length).to.equal(4);
      expect(json.properties[0].value).to.equal('456');
      expect(json.properties[0].label).to.equal('Automation Anywhere Bot Name');
      expect(json.properties[3].value).to.equal('automationanywhere');
    });

    // Change the implementation type to "External Service Task".
    cy.getByTestId('implementation-type').click().getByTestId('external').click();

    // Assert that the correct properties are part of the JSON.
    cy.getTemplateJSON().then((json) => {
      expect(json.properties.length).to.equal(2);
      expect(json.properties[1].value).to.equal('456');
    });
  });

  it('a user can manage input/output parameters', function () {
    cy.prepareDownload();

    // Open the template.
    cy.visit(`/templates/${this.template.id}`);

    cy.get('input[name="parameter-label"]').should('not.exist');

    cy.getByTestId('add-input-parameter').should('have.attr', 'aria-label', 'Add input parameter').click();

    // Fill out the existing input parameter.
    cy.get('input[name="parameter-label-4"]')
      .type('in1')
      .get('input[name="parameter-description-4"]')
      .type('Input param description #1');

    cy.getByTestId('add-output-parameter').should('have.attr', 'aria-label', 'Add output parameter').click();

    // Fill out the existing output parameter.
    cy.get('input[name="parameter-label-5"]')
      .type('out1')
      .get('input[name="parameter-description-5"]')
      .type('Output param description #1');

    // Add another input parameter.
    cy.getByTestId('add-input-parameter')
      .click()
      .get('input[name="parameter-label-6"]')
      .type('in2')
      .get('input[name="parameter-description-6"]')
      .type('Input param description #2')
      .getByTestId('add-input-parameter')
      .click();

    // Add another output parameter.
    cy.getByTestId('add-output-parameter')
      .click()
      .get('input[name="parameter-label-8"]')
      .type('out2')
      .get('input[name="parameter-description-8"]')
      .type('Output param description #2')
      .getByTestId('add-output-parameter')
      .click();

    // Assert that the JSON has the right structure and parameters.
    cy.getTemplateJSON().then((json) => {
      expect(json.properties.length).to.equal(8);

      const [, , , , in1, in2, out1, out2] = json.properties;

      expect(in1.label).to.equal('in1');
      expect(in1.value).to.equal('${in1}');
      expect(in1.binding.type).to.equal('camunda:inputParameter');

      expect(in2.label).to.equal('in2');
      expect(in2.value).to.equal('${in2}');
      expect(in2.binding.type).to.equal('camunda:inputParameter');

      expect(out1.label).to.equal('out1');
      expect(out1.value).to.equal('out1');
      expect(out1.binding.type).to.equal('camunda:outputParameter');

      expect(out2.label).to.equal('out2');
      expect(out2.value).to.equal('out2');
      expect(out2.binding.type).to.equal('camunda:outputParameter');
    });

    // Delete the first input and first output parameter.
    cy.getByTestId('delete-parameter')
      .first()
      .click()
      .wait(500)
      .getByTestId('delete-parameter')
      .eq(2)
      .click()
      .wait(500);

    // Assert that the JSON has the right structure and parameters.
    cy.getTemplateJSON().then((json) => {
      expect(json.properties.length).to.equal(6);

      const [, , , , in2, out2] = json.properties;

      expect(in2.label).to.equal('in2');
      expect(in2.value).to.equal('${in2}');
      expect(in2.binding.type).to.equal('camunda:inputParameter');

      expect(out2.label).to.equal('out2');
      expect(out2.value).to.equal('out2');
      expect(out2.binding.type).to.equal('camunda:outputParameter');
    });
  });

  it('a user can manage BPMN errors', function () {
    cy.prepareDownload();

    // Open the template.
    cy.visit(`/templates/${this.template.id}`);

    // Write the package name to satisfy the validation.
    cy.getByTestId('implementation-name').type('package.name');

    // Assert no error group exists, yet.
    cy.get('input[name="error-name-4"]').should('not.exist');

    // Assert that the "Add Error" button exists and click it.
    cy.getByTestId('add-bpmn-error').should('have.attr', 'aria-label', 'Add BPMN error').click();

    // Fill out the newly created error.
    cy.get('input[name="error-name-4"]').type('Error #1').get('input[name="error-code-4"]').type('500');

    // Click the "Publish button".
    cy.getByTestId('publish-template').click();

    // Assert that the publish dialog has not been opened because there are still some errors
    // in the form.
    cy.getByTestId('dialog-title').should('not.exist');

    // Assert that the snackbar with an error message is visible.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .and('have.text', 'This template cannot be published. Please complete all required fields.');

    // Assert that the "Error expression" field has an error.
    cy.get('input[name="error-expression-4"]').next().should('be.visible').and('have.text', 'This field is required');

    // Fill out the "Error expression".
    cy.get('input[name="error-expression-4"]').type('${x == 1}', { parseSpecialCharSequences: false });

    // Click the "Publish button".
    cy.getByTestId('publish-template').click();

    // Assert that the publish dialog is visible this time and cancel it.
    cy.getByTestId('dialog-title').should('be.visible').getByTestId('cancel').click();

    // Assert that the "Error expression" field no longer has an error.
    cy.getByTestId('input-error').should('not.exist');

    // Assert that the JSON has the right structure and parameters.
    cy.getTemplateJSON().then((json) => {
      expect(json.properties.length).to.equal(5);

      const [, , , , error] = json.properties;

      expect(error.label).to.equal('Error #1');
      expect(error.value).to.equal('${x == 1}');
      expect(error.binding.type).to.equal('camunda:errorEventDefinition');

      expect(json.scopes[0].type).to.equal('bpmn:Error');
      expect(json.scopes[0].id).to.equal(error.binding.errorRef);
      expect(json.scopes[0].properties[0].value).to.equal('500');
      expect(json.scopes[0].properties[1].value).to.equal('');
      expect(json.scopes[0].properties[2].value).to.equal('Error #1');
    });

    // Clear the error name and error code.
    cy.get('input[name="error-name-4"]').clear().get('input[name="error-code-4"]').clear();

    // Assert that the error is still part of the JSON.
    cy.getTemplateJSON().then((json) => {
      expect(json.properties.length).to.equal(5);
      expect(json.scopes.length).to.equal(1);
    });

    cy.get('input[name="error-expression-4"]').clear();

    // Assert that the error is no longer part of the JSON.
    cy.getTemplateJSON().then((json) => {
      expect(json.properties.length).to.equal(4);
      expect(json.scopes).to.equal(undefined);
    });

    // Delete the first input and first output parameter.
    cy.getByTestId('delete-error').click();

    // Assert that the error group has been deleted.
    cy.get('input[name="error-name-4"]').should('not.exist');

    // Assert that the error is no longer part of the JSON.
    cy.getTemplateJSON().then((json) => {
      expect(json.properties.length).to.equal(4);
      expect(json.scopes).to.equal(undefined);
    });
  });
});

describe('JSON editor', function () {
  beforeEach(function () {
    // Create a new user, project and template.
    cy.createUserAndLogin()
      .as('user')
      .then((user) => {
        cy.createProject(user, 'CATALOG').as('project').then(cy.createTemplate).as('template');
      });
  });

  afterEach(function () {
    cy.removeUser(this.user);
  });

  it("a user can interact with the editor's controls", function () {
    // Open the template.
    cy.visit(`/templates/${this.template.id}`);

    // Wait for the editor to load.
    cy.waitForEditor();

    // Assert that the fullscreen button is visible.
    cy.getByTestId('toggle-fullscreen').should('be.visible');

    // Assert that the minimap or the toggle is not visible.
    cy.get('.minimap').should('not.be.visible').getByTestId('toggle-minimap').should('not.exist');

    // Get the zoom-in/out buttons and assert that they can change the font-size.
    cy.get('.view-lines')
      .should('have.css', 'font-size', '13px')
      .getByTestId('zoom-out')
      .should('be.visible')
      .click({ force: true })
      .get('.view-lines')
      .should('have.css', 'font-size', '12px')
      .getByTestId('zoom-in')
      .dblclick({ force: true })
      .get('.view-lines')
      .should('have.css', 'font-size', '14px');
  });
});
