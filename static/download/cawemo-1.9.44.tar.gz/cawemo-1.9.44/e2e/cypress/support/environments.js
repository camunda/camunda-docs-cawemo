import { isLdapEnabled } from '../helpers';

it.default = (description, fn) => {
  return isLdapEnabled()
    ? it.skip(`[default] ${description}`, fn)
    : it(`[default] ${description}`, fn);
};

it.ldap = (description, fn) => {
  return !isLdapEnabled()
    ? it.skip(`[LDAP] ${description}`, fn)
    : it(`[LDAP] ${description}`, fn);
};

describe.default = (description, fn) => {
  return isLdapEnabled()
    ? describe.skip(`[default] ${description}`, fn)
    : describe(`[default] ${description}`, fn);
};

describe.ldap = (description, fn) => {
  return !isLdapEnabled()
    ? describe.skip(`[LDAP] ${description}`, fn)
    : describe(`[LDAP] ${description}`, fn);
};
