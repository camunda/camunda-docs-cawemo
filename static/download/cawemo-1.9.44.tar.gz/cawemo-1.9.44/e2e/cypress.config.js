const { defineConfig } = require('cypress')

module.exports = defineConfig({
  env: {
    IAM_BASE_URL: "http://localhost:9000",
    EMAIL_URL: "http://localhost:8025",
    ENGINE_URL: "http://localhost:1234",

    DB_USER: "master",
    DB_HOST: "localhost",
    DB_PASSWORD: "master",
    DB_NAME: "cawemo",
    DB_PORT: "5432",

    IAM_DB_USER: "master",
    IAM_DB_HOST: "localhost",
    IAM_DB_PASSWORD: "master",
    IAM_DB_NAME: "iam",
    IAM_DB_PORT: "5432",

    FEATURE_LDAP_ENABLED: false,
    LDAP_SERVER_URL: "ldap://localhost",
    LDAP_MANAGER_DN: "cn=admin,dc=example,dc=com",
    LDAP_MANAGER_PASSWORD: "camunda123",

    engineApiKey: "d39cb67d504e19821bf3372a2c7addac33992325675301ddd3956a76df091964",
    engineApiKeySecret: "$2a$12$iVLjVsuuSbg7IGOG4SKzIO6LKLhGscOR7S.8MToeU5LISsaz22kQS",
    adminSignupToken: "16510354-c1c5-40e0-813c-cfb55bac372a"
  },
  viewportWidth: 1280,
  viewportHeight: 800,
  video: false,
  numTestsKeptInMemory: 10,
  defaultCommandTimeout: 8000,
  pageLoadTimeout: 120000,
  chromeWebSecurity: false,
  retries: 3,
  e2e: {
    setupNodeEvents(on, config) {
      return require('./cypress/plugins/index.js')(on, config)
    },
    baseUrl: 'http://localhost:8088',
  },
})
