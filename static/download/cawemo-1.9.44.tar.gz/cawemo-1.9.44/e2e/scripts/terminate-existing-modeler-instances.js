/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements. Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */

import fkill from 'fkill';

const terminateExistingModelerInstances = async () => {
  try {
    await fkill('Camunda Modeler');
  } catch (ex) {
    console.error(ex);
  }
};

module.exports = terminateExistingModelerInstances;
