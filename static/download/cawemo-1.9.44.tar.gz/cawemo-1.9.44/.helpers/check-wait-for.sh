#!/bin/sh

: ${SLEEP_LENGTH:=2}
: ${TIMEOUT_LENGTH:=300}

# Some images (e.g. iam-backend) ship without netcat; fall back to bash's /dev/tcp there
if command -v nc >/dev/null 2>&1; then
  PROBE='nc -zv $0 $1'
else
  PROBE='bash -c "exec 3<>/dev/tcp/$0/$1" 2>/dev/null'
fi

for var in "$@"
do
  HOST=${var%:*}
  PORT=${var#*:}
  timeout ${TIMEOUT_LENGTH} sh -c "until $PROBE; do echo '$HOST $PORT not online yet' >/dev/stderr; sleep $SLEEP_LENGTH; done" "$HOST" "$PORT" || exit 1
done
