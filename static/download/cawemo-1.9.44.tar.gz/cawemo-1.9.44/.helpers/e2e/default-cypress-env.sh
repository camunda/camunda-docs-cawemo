#!/bin/bash

source "$(dirname $0)/common-cypress-env.sh"

exec "$@"
