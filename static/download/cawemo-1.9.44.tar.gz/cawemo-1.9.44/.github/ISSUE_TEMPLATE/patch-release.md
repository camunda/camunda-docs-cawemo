---
name: Patch release
title: "Cawemo On-Premises Release `1.9.x`"
about: Epic for Cawemo patch releases
labels: on-premises, epic
---

### Description

All tasks related to the `1.9.x` patch release.

### Bugfixes
...

### CVE fixes

#### restapi
- [ ] ...

#### webapp
- [ ] ...

#### websockets
- [ ] ...

### Release checklist

(📋 see also the [detailed release documentation](https://reimagined-doodle-12d70320.pages.github.io/Product-Specific/Camunda-7-Cawemo/Releases/Cawemo-On-Premises-Release))
- [ ] Before building Docker images:
  - [ ] Trigger [`cron-snyk-import`](https://github.com/camunda/cawemo/actions/workflows/cron-snyk-import.yml) to import the latest vulnerabilities into Snyk
  - [ ] Assert that Snyk does not report any vulnerabilities: [link](https://app.snyk.io/org/team-web-modeler/projects?groupBy=targets&searchQuery=cawemo)
- [ ] **Update versions** in `cawemo` repository by running [`update-release-versions`](https://github.com/camunda/cawemo/actions/workflows/update-release-versions.yml)
- [ ] Merge newly created PR with `chore(release): update Cawemo version to ...`
- [ ] [Create a **GitHub release**](https://github.com/camunda/cawemo/releases/new) `1.9.x` to trigger release of the Docker images
- [ ] Perform **smoke test** with new Docker images
- [ ] **Update docs** in [camunda-docs-cawemo](https://github.com/camunda/camunda-docs-cawemo) repo:
  - [ ] Update Cawemo version in installation guide
  - [ ] Update download files
  - [ ] Update lists of third-party libraries
    - [ ] `cawemo-backend`
    - [ ] `cawemo-webapp`
    - [ ] `cawemo-websockets`
  - [ ] Update supported environments (if applicable)
  - [ ] Update theme
  - [ ] Apply the docs changes to the following branches:
    - [ ] `1.9`
- [ ] **Update docs** in [camunda-docs-static](https://github.com/camunda/camunda-docs-static) repo
  - [ ] Add security notice
  - [ ] Update Cawemo version on downloads page
- [ ] **Publish the docs**
- [ ] **Inform Support team** of new release on `#ask-support` ([example message](https://camunda.slack.com/archives/CHAC0L80M/p1725256737319179))
