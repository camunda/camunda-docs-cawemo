{{ define "shared.commonLabels" -}}
{{ printf "%s: %s" "branch" .Values.global.labels.branch }}
{{ printf "%s: %s" "change-trigger" ( quote .Values.global.changed ) }}
{{ toYaml .Values.global.commonLabels -}}
{{ end }}

{{ define "shared.commonAnnotations" -}}
{{ printf "camunda.cloud/created-by: %s/blob/%s/.ci/%s" .Values.global.git.repoUrl .Values.global.git.branch .Template.Name -}}
{{ end }}
