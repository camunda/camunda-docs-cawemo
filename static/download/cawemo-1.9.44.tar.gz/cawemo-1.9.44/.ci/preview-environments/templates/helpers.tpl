{{ define "domain.cawemo" }}{{ printf "%s.%s" .Release.Name .Values.global.ingress.domain | trimPrefix "cawemo-" }}{{ end }}
{{ define "domain.iam" }}{{ printf "%s-iam.%s" .Release.Name .Values.global.ingress.domain | trimPrefix "cawemo-" }}{{ end }}
{{ define "domain.camunda" }}{{ printf "%s-camunda.%s" .Release.Name .Values.global.ingress.domain | trimPrefix "cawemo-" }}{{ end }}
{{ define "domain.ws" }}{{ printf "%s-ws.%s" .Release.Name  .Values.global.ingress.domain | trimPrefix "cawemo-" }}{{ end }}
