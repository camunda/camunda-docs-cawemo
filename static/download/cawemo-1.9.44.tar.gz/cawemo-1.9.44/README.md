> Check out the project's [staging](https://stage.cawemo.camunda.cloud) and [staging with ldap integration](https://stage-ldap.cawemo.camunda.cloud) environments.

# Status Check

[![main](https://github.com/camunda/cawemo/actions/workflows/build-and-test.yml/badge.svg)](https://github.com/camunda/cawemo/actions/workflows/build-and-test.yml)
[![iam-it-test](https://github.com/camunda/cawemo/actions/workflows/cron-iam-it-test.yml/badge.svg)](https://github.com/camunda/cawemo/actions/workflows/cron-iam-it-test.yml)


# Cawemo

The sources of [Cawemo](https://docs.camunda.org/cawemo/1.9/technical-guide/installation/) can be found [here](https://github.com/camunda/cawemo/tree/main).

## How to Develop

Checkout [our development documentation](https://github.com/camunda/team-web-modeler) to learn how to set up Cawemo on your machine.

#### TLDR

Use the following `make` targets during development:

```
make env-up         # set up run-time environment
make env-up-ldap    # set up run-time environment with ldap

make env-down       # tear down run-time environment
make env-down-ldap  # tear down run-time environment with ldap

make local          # run in local development mode
make local-ldap     # run in local development mode with ldap

make all            # build application for production
```

## Additional Resources

* [Documentation](https://github.com/camunda/team-web-modeler)
* [Get started with development](https://reimagined-doodle-12d70320.pages.github.io/Product-Specific/Camunda-7-Cawemo/Development/Getting-Started-Development-Documentation)
* [Test Users](https://reimagined-doodle-12d70320.pages.github.io/Product-Specific/Camunda-7-Cawemo/Development/Getting-Started-Development-Documentation#test-data)

## License
This repository contains files subject to a [commercial license](./LICENSE.txt).
