#!/bin/bash

set -e

PROPERTIES_FILE="$(dirname "$0")/preferred-licenses.properties"
DEPENDENCIES_FILE="$1"

if [[ -z "$DEPENDENCIES_FILE" ]]; then
    echo "Error: Dependencies file not provided. Usage: $(basename "$0") <dependencies-file>"
    exit 1
fi
if [[ ! -f "$DEPENDENCIES_FILE" ]]; then
    echo "Error: Dependencies file '$DEPENDENCIES_FILE' does not exist."
    exit 1
fi

echo "Using properties file: $PROPERTIES_FILE"
echo "Removing unused licenses from: $DEPENDENCIES_FILE"

# process each line in the properties file
while IFS='=' read -r key value; do
    # convert the key format from "group.id_artifact-id" to "group.id:artifact-id"
    library_name="${key//_/:}"
    preferred_license="$value"

    echo "Processing: $library_name -> keeping '$preferred_license'"

    # escape special characters in the library name for use in regex
    escaped_library="${library_name//./\\.}"

    # find the line in the file that contains this library
    matching_line=$(grep "\[$escaped_library@" "$DEPENDENCIES_FILE" || echo "")

    if [[ -z "$matching_line" ]]; then
        echo "  Error: Library not found in dependencies file. Please update the properties file."
        exit 1
    fi

    # extract all license patterns and find the matching one
    preferred_license_entry=""
    while IFS= read -r license_entry; do
        if [[ "$license_entry" =~ ^\(\[([^\]]+)\] ]]; then
            license_name="${BASH_REMATCH[1]}"
            if [[ "$license_name" == "$preferred_license" ]]; then
                preferred_license_entry="$license_entry"
                break
            fi
        fi
    done < <(echo "$matching_line" | grep -oE '\(\[[^]]+\]\([^)]+\)\)')

    if [[ -z "$preferred_license_entry" ]]; then
        echo "  Error: Preferred license '$preferred_license' not found in line. Please update the properties file."
        exit 1
    fi

    # extract the part before the first license (library info and URL)
    line_prefix=$(echo "$matching_line" | sed -E 's/^(.*\)) \(\[.*$/\1/')

    # build the new line with only the preferred license
    new_line="$line_prefix $preferred_license_entry"

    # escape special characters (brackets, slash) for sed
    escaped_old="${matching_line//\\/\\\\}"
    escaped_old="${escaped_old//\[/\\[}"
    escaped_old="${escaped_old//\]/\\]}"
    escaped_old="${escaped_old//\//\\/}"
    escaped_new="${new_line//\\/\\\\}"
    escaped_new="${escaped_new//\[/\\[}"
    escaped_new="${escaped_new//\]/\\]}"
    escaped_new="${escaped_new//\//\\/}"

    # replace the old line with the new one; using `.tmp` to avoid issues on macOS
    sed -i.tmp "s|^${escaped_old}$|${escaped_new}|" "$DEPENDENCIES_FILE"
    rm "$DEPENDENCIES_FILE.tmp"

# read properties file, ignoring comments and empty lines
done < <(grep -Ev '^#|^[[:space:]]*$' "$PROPERTIES_FILE")
