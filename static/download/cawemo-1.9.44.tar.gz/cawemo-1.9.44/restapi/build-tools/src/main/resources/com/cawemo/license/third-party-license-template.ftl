<#--

    Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
    under one or more contributor license agreements.

    Licensed under a commercial license.
    You may not use this file except in compliance with the commercial license.

-->
<#macro artifactFormat project>
  <#if project.url?has_content>
    [${project.groupId}:${project.artifactId}@${project.version}](${project.url})<#rt>
  <#else>
    ${project.groupId}:${project.artifactId}@${project.version}<#rt>
  </#if>
</#macro>
<#macro licenseFormat project>
  <#if project.licenses?size gt 0>
    <#list project.licenses as license>
      <#if license.name?has_content && license.url?has_content>
        ([${license.name}](${license.url}))
      <#elseif license.name?has_content>
        (${license.name})
      </#if>
      <#if license.name?has_content && project.licenses?last != license>
        and
      </#if>
    </#list>
  <#else>
    <#--
      The property project.licenses is not set for projects with an overridden license. Instead, the license name is
      derived from the licenseMap (that contains a list of projects per license). The license URL is not available in
      this case.
    -->
    <#list licenseMap as e>
      <#list e.getValue() as p>
        <#if p.groupId == project.groupId && p.artifactId == project.artifactId && p.version == project.version>
          (${e.getKey()})
        </#if>
      </#list>
    </#list>
  </#if>
</#macro>
<#if dependencyMap?size == 0>
  The project has no dependencies.
<#else>
  <#list dependencyMap as e>
    <#assign project = e.getKey()/>
    <@compress single_line=true>
      - <@artifactFormat project/>
        <@licenseFormat project/>
    </@compress>

  </#list>
</#if>
