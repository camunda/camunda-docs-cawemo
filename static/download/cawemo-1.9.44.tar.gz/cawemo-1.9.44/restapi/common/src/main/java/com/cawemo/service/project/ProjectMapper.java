/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.dto.base.request.ProjectUpdateDto;
import com.cawemo.data.dto.base.response.ProjectDto;
import com.cawemo.data.dto.base.response.ProjectWithInvitationsDto;
import com.cawemo.data.dto.publicapi.response.CatalogDto;
import com.cawemo.data.dto.publicapi.response.PublicApiEngineProjectDto;
import com.cawemo.data.dto.publicapi.response.PublicApiProjectMetadataDto;
import com.cawemo.data.entity.Folder;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.ProjectPermission;
import com.cawemo.data.entity.view.InvitedCollaboratorView;
import com.cawemo.data.entity.view.ProjectCollaboratorView;
import com.cawemo.data.entity.view.ProjectPermissionWithStatisticsView;
import com.cawemo.data.projection.FileWithoutContent;
import com.cawemo.service.file.FileMapper;
import com.cawemo.service.folder.FolderMapper;
import com.cawemo.util.UrlSlug;
import java.time.ZonedDateTime;
import java.util.List;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.NullValueMappingStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring", uses = {FileMapper.class, FolderMapper.class, ProjectCollaboratorMapper.class})
public interface ProjectMapper {

  @Mapping(target = "id", source = "project.id")
  @Mapping(target = "name", source = "project.name")
  @Mapping(target = "slug", source = "project", qualifiedByName = "projectSlug")
  @Mapping(target = "created", source = "project.created")
  @Mapping(target = "organizationId", source = "project.organization.id")
  @Mapping(target = "permissionAccess", source = "permissionAccess")
  @Mapping(target = "collaborators", source = "collaborators") // uses ProjectCollaboratorMapper
  @Mapping(target = "files", source = "files") // uses FileMapper
  @Mapping(target = "filesCount", source = "fileCount")
  @Mapping(target = "folders", source = "folders") // uses FolderMapper
  @Mapping(target = "lastModified", source = "lastModified")
  @Mapping(target = "admins", ignore = true)
  ProjectDto asProjectDto(Project project,
                          List<ProjectPermission> collaborators,
                          List<Folder> folders,
                          List<FileWithoutContent> files,
                          int fileCount,
                          ProjectPermissionLevel permissionAccess,
                          ZonedDateTime lastModified);

  @Mapping(target = "id", source = "view.project.id")
  @Mapping(target = "name", source = "view.project.name")
  @Mapping(target = "slug", source = "view.project", qualifiedByName = "projectSlug")
  @Mapping(target = "created", source = "view.project.created")
  @Mapping(target = "organizationId", source = "view.project.organization.id")
  @Mapping(target = "permissionAccess", source = "permissionAccess")
  @Mapping(target = "type", source = "view.project.type")
  @Mapping(target = "collaborators", source = "collaborators") // uses ProjectCollaboratorMapper
  @Mapping(target = "files", ignore = true)
  @Mapping(target = "folders", ignore = true)
  @Mapping(target = "filesCount", source = "view.fileCount")
  @Mapping(target = "admins", ignore = true)
  ProjectDto asProjectDto(ProjectPermissionWithStatisticsView view,
                          List<ProjectCollaboratorView> collaborators,
                          ProjectPermissionLevel permissionAccess);

  @BeanMapping(ignoreByDefault = true)
  @Mapping(target = "id", source = "project.id")
  @Mapping(target = "name", source = "project.name")
  @Mapping(target = "type", source = "project.type")
  @Mapping(target = "admins", source = "admins") // uses ProjectCollaboratorMapper
  ProjectDto asProjectDto(ProjectWithAdmins view);

  List<ProjectDto> asProjectDtoList(List<ProjectWithAdmins> projects);

  ProjectWithInvitationsDto asProjectWithInvitationsDto(ProjectDto projectDto,
                                                        List<InvitedCollaboratorView> invitations);

  @Mapping(target = "name", source = "dto.name")
  @BeanMapping(
    ignoreByDefault = true,
    nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
  )
  Project updateFromDto(@MappingTarget Project project, ProjectUpdateDto dto);

  @Named("projectSlug")
  default String projectSlug(Project project) {
    return UrlSlug.buildSlug(project.getId(), project.getName());
  }

  CatalogDto asCatalogDto(Project catalog);

  List<CatalogDto> asCatalogDtoList(List<Project> catalogs);

  PublicApiEngineProjectDto asPublicApiEngineProjectDto(Project project);

  List<PublicApiEngineProjectDto> asPublicApiEngineProjectDtoList(List<Project> projects);

  @Mapping(target = "created", source = "created", qualifiedByName = "asZuluTime")
  @Mapping(target = "updated", source = "updated", qualifiedByName = "asZuluTime")
  PublicApiProjectMetadataDto asPublicApiProjectDto(Project project);

  List<PublicApiProjectMetadataDto> asPublicApiProjectDtoList(List<Project> projects);
}
