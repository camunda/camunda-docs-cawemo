/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.pusher;

import com.cawemo.data.dto.base.request.AttentionGrabberDto;
import com.cawemo.data.entity.Comment;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.User;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PusherService {

  private final PusherClient pusherClient;
  private final PusherMapper pusherMapper;

  public void updateFileNotification(File file, User user, String originAppInstanceId) {
    var event = PusherEventImpl.DIAGRAM_UPDATE;
    var payload = pusherMapper.asPusherFileDto(file, user, originAppInstanceId);
    pusherClient.trigger(event, file.getId(), payload);
  }

  public void attentionGrabberCreationNotification(User user, String fileId,
                                                   AttentionGrabberDto attentionGrabberDto) {
    var event = PusherEventImpl.DIAGRAM_ATTENTION_CREATION;
    var payload = pusherMapper.asPusherAttentionGrabberDto(attentionGrabberDto, user);
    pusherClient.trigger(event, fileId, payload);
  }

  public void attentionGrabberDeletionNotification(User user, String fileId) {
    var event = PusherEventImpl.DIAGRAM_ATTENTION_DELETION;
    var payload = pusherMapper.asPusherAttentionGrabberDto(user);
    pusherClient.trigger(event, fileId, payload);
  }

  public void addDiagramCommentNotification(Comment comment, String originAppInstanceId) {
    commentNotification(PusherEventImpl.COMMENT_ADD, comment, originAppInstanceId);
  }

  public void editDiagramCommentNotification(Comment comment, String originAppInstanceId) {
    commentNotification(PusherEventImpl.COMMENT_EDIT, comment, originAppInstanceId);
  }

  public void removeDiagramCommentNotification(Comment comment, String originAppInstanceId) {
    commentNotification(PusherEventImpl.COMMENT_REMOVE, comment, originAppInstanceId);
  }

  public void addPermissionNotification(User user, Project project) {
    permissionNotification(PusherEventImpl.PERMISSION_ADD, user, project);
  }

  public void editPermissionNotification(User user, Project project) {
    permissionNotification(PusherEventImpl.PERMISSION_EDIT, user, project);
  }

  public void removePermissionNotification(User user, List<Project> projects, PusherIntent intent) {
    var event = PusherEventImpl.PERMISSION_REMOVE;
    var payload = pusherMapper.asPusherMultiProjectPermissionDto(intent, projects);
    pusherClient.trigger(event, user.getId(), payload);
  }

  private void commentNotification(PusherEvent event, Comment comment, String originAppInstanceId) {
    var payload = pusherMapper.asPusherCommentDto(comment, originAppInstanceId);
    pusherClient.trigger(event, comment.getFile().getId(), payload);
  }

  private void permissionNotification(PusherEvent event, User user, Project project) {
    var payload = pusherMapper.asPusherProjectPermissionDto(project);
    pusherClient.trigger(event, user.getId(), payload);
  }
}
