/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.publicapi.response;

public record PublicApiMilestoneMetadataDto(
        String id,
        String name,
        String fileId,
        String created,
        PublicApiUserDto createdBy,
        String updated,
        PublicApiUserDto updatedBy) { }
