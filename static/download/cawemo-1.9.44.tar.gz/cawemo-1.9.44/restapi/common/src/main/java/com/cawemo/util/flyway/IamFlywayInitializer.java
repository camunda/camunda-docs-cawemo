/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util.flyway;

import javax.sql.DataSource;
import lombok.RequiredArgsConstructor;
import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@ConditionalOnProperty(value = "iam.flyway.enabled", havingValue = "true")
public class IamFlywayInitializer implements InitializingBean {

  private final IamFlywayProperties properties;

  @Override
  public void afterPropertiesSet() {
    var dataSource = createDataSource();
    var flyway = configureFlyway(dataSource);
    flyway.migrate();
  }

  private DataSource createDataSource() {
    return new SingleConnectionDataSource(
      properties.dataSource().url(),
      properties.dataSource().username(),
      properties.dataSource().password(),
      true
    );
  }

  private Flyway configureFlyway(DataSource dataSource) {
    return Flyway.configure()
      .dataSource(dataSource)
      .baselineOnMigrate(true)
      .table(properties.flyway().tableName())
      .locations(properties.flyway().locations())
      .load();
  }
}
