/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.admin;

import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/adminApi")
public interface AdminApiController {
}
