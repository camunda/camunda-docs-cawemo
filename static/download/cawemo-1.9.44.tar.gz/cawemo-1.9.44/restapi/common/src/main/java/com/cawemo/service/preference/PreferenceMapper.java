/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.preference;

import com.cawemo.data.entity.Preference;
import com.cawemo.data.entity.User;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PreferenceMapper {

  @Mapping(source = "user", target = "id.user")
  @Mapping(source = "key", target = "id.key")
  Preference asPreference(User user, PreferenceKey key, boolean value);
}
