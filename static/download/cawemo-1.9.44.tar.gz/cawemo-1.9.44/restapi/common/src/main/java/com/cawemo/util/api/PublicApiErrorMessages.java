/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util.api;

import lombok.experimental.UtilityClass;

@UtilityClass
public class PublicApiErrorMessages {

  public static final String RESOURCE_NOT_FOUND = "Could not find the requested resource.";
  public static final String TEMPLATE_HAS_NO_PUBLISHED_VERSIONS =
    "There are no published versions for the requested template.";
}
