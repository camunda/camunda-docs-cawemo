/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity;

import com.cawemo.service.project.ProjectPermissionLevel;
import com.cawemo.util.Constants;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;
import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(
  name = "project_invitations",
  indexes = {
    @Index(columnList = "created_by"),
    @Index(columnList = "project_id"),
    @Index(columnList = "token_id"),
    @Index(columnList = "updated_by")
  },
  uniqueConstraints = @UniqueConstraint(columnNames = {"project_id", "invited_email"})
)
@EntityListeners(AuditingEntityListener.class)
@Data
@Accessors(chain = true)
public class ProjectInvitation implements Serializable {

  @Id
  @GeneratedValue(generator = "uuid")
  @GenericGenerator(name = "uuid", strategy = "uuid2")
  private String id;

  @ManyToOne
  @JoinColumn(name = "project_id", nullable = false)
  @OnDelete(action = OnDeleteAction.CASCADE)
  private Project project;

  // length attribute is not considered when Flyway creates the schema on Postgres (there, "citext" is used as type with
  // basically unlimited length), but only when running tests on H2 (in this case Hibernate creates the schema)
  @Column(name = "invited_email", nullable = false, length = Constants.EMAIL_MAX_LENGTH)
  private String invitedEmail;

  @OneToOne
  @JoinColumn(name = "token_id", nullable = false)
  @OnDelete(action = OnDeleteAction.CASCADE)
  private Token token;

  @Column(length = Constants.INVITE_MESSAGE_MAX_LENGTH)
  private String customMessage;

  @Enumerated(EnumType.STRING)
  @Column(nullable = false)
  private ProjectPermissionLevel access;

  @CreatedDate
  @Column(nullable = false, updatable = false)
  private ZonedDateTime created;

  @CreatedBy
  @ManyToOne
  @JoinColumn(name = "created_by", nullable = false)
  @OnDelete(action = OnDeleteAction.CASCADE)
  private User createdBy;

  @LastModifiedDate
  @Column(nullable = false)
  private ZonedDateTime updated;

  @LastModifiedBy
  @ManyToOne
  @JoinColumn(name = "updated_by", nullable = false)
  private User updatedBy;

  @Override
  public boolean equals(Object object) {
    if (object == null) {
      return false;
    } else if (object == this) {
      return true;
    } else if (!(object instanceof ProjectInvitation)) {
      return false;
    } else {
      return Objects.equals(this.id, ((ProjectInvitation) object).getId());
    }
  }

  @Override
  public int hashCode() {
    return Constants.ENTITY_HASHCODE;
  }
}
