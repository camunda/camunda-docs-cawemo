/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util;

import java.text.Normalizer;

public class UrlSlug {

  private static final String DELIMITER = "--";

  public static String buildSlug(String id, String name) {
    String readableName =
      Normalizer.normalize(name, Normalizer.Form.NFD)
        // If you change this transformations, make sure to update UrlSlug.js accordingly!
        // replace any non letter/number characters
        .replaceAll("[^a-zA-Z0-9]", "-")
        // replace consecutive dashes with a single one
        .replaceAll("(-)\\1+", "-")
        // remove leading and trailing dashes
        .replaceAll("(^-|-$)", "")
        .toLowerCase();

    return (!readableName.isEmpty()) ? id + DELIMITER + readableName : id;
  }

  public static String getId(String slugString) {
    if (slugString == null || slugString.isEmpty()) {
      return null;
    } else if (isSlug(slugString)) {
      return slugString.split(DELIMITER, 2)[0];
    } else {
      return slugString;
    }
  }

  private static boolean isSlug(String slugString) {
    return slugString.contains(DELIMITER);
  }
}


