/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.user;

import com.cawemo.data.dto.base.request.UserLoginDto;
import com.cawemo.data.dto.base.request.UserUpdateDto;
import com.cawemo.data.dto.base.response.UserDto;
import com.cawemo.data.entity.User;
import java.util.List;
import java.util.stream.Collectors;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.NullValueMappingStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring")
public interface UserMapper {

  @Mapping(source = "dto.name", target = "name")
  @Mapping(source = "dto.email", target = "email")
  @Mapping(source = "dto.verified", target = "verified")
  @BeanMapping(
    ignoreByDefault = true,
    nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
  )
  User updateFromDto(@MappingTarget User user, UserLoginDto dto);

  @Mapping(source = "dto.name", target = "name")
  @Mapping(source = "dto.email", target = "email")
  @Mapping(source = "dto.verified", target = "verified")
  @BeanMapping(
    ignoreByDefault = true,
    nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
  )
  User updateFromDto(@MappingTarget User user, UserUpdateDto dto);

  UserDto asUserDto(User user);

  @Named("idAsUserDto")
  @BeanMapping(ignoreByDefault = true)
  @Mapping(source = "id", target = "id")
  UserDto idAsUserDto(String id);

  @Named("idsAsUserDtoList")
  default List<UserDto> idsAsUserDtoList(List<User> users) {
    return users.stream()
      .map(User::getId)
      .map(this::idAsUserDto)
      .collect(Collectors.toList());
  }
}
