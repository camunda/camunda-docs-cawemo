/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.dto.base.response.ProjectDto;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.ProjectPermission;
import com.cawemo.data.entity.User;
import com.cawemo.data.entity.view.ProjectStatisticsView;
import com.cawemo.data.projection.FileWithoutContent;
import com.cawemo.data.repository.FolderRepository;
import com.cawemo.data.repository.ProjectRepository;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.util.Assert;

@RequiredArgsConstructor
public abstract class AbstractProjectInfoBuilder {

  private final FolderRepository folderRepository;
  private final ProjectPermissionService projectPermissionService;
  private final ProjectMapper projectMapper;
  private final ProjectRepository projectRepository;

  public ProjectDto buildProjectInfoExcludingFoldersAndFiles(Project project, User user) {
    return getProjectDto(project, null, user);
  }

  public ProjectDto buildProjectInfoIncludingFoldersAndFiles(Project project, List<FileWithoutContent> files,
                                                             User user) {
    Assert.notNull(files, "files cannot be null when building project info with files");
    return getProjectDto(project, files, user);
  }

  protected ProjectDto getProjectDto(Project project, List<FileWithoutContent> files, User user) {
    var userPermission = projectPermissionService.getUserPermission(project, user);
    var visibleCollaborators = getCollaborators(project, user, userPermission);
    // only include folders when files are requested
    var folders = (files == null) ? null : folderRepository.findByParentIsNullAndProject(project);
    var stats = projectRepository.getProjectStatistics(project);
    var lastModified = getLastModifiedDate(project, stats);

    return projectMapper.asProjectDto(project, visibleCollaborators, folders, files, (int) stats.getFileCount(),
      userPermission, lastModified);
  }

  private List<ProjectPermission> getCollaborators(Project project, User user, ProjectPermissionLevel userPermission) {
    var allCollaborators = project.getProjectPermissions();
    return projectPermissionService.getVisibleCollaborators(project.getType(), allCollaborators, user, userPermission);
  }

  private ZonedDateTime getLastModifiedDate(Project project, ProjectStatisticsView statisticsView) {
    var lastModifiedProjectContent = ObjectUtils
      .max(statisticsView.getFilesLastUpdated(), statisticsView.getFoldersLastUpdated());
    return Objects.requireNonNullElse(lastModifiedProjectContent, project.getCreated());
  }
}
