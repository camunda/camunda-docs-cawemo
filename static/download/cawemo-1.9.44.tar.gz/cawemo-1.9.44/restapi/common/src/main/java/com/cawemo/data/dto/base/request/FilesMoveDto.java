/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import com.cawemo.data.validation.constraint.NullOrNotBlank;
import com.cawemo.util.Constants;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import java.util.List;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class FilesMoveDto {

  @Size(max = Constants.VARCHAR_MAX)
  @NotBlank
  private String targetProjectId;

  @Size(max = Constants.VARCHAR_MAX)
  @NullOrNotBlank
  private String targetFolderId;

  @NotEmpty
  private List<@NotBlank @Size(max = Constants.VARCHAR_MAX) String> fileIds;
}
