/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import com.cawemo.data.validation.constraint.NullOrNotBlank;
import com.cawemo.data.validation.constraint.ValidBpmn;
import com.cawemo.util.Constants;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class DiagramModelerPluginDto {

  @Size(max = Constants.VARCHAR_MAX)
  @NullOrNotBlank
  private String relationId;

  @ValidBpmn
  private String content;

  @Size(max = Constants.VARCHAR_MAX)
  @NotBlank
  private String name;
}
