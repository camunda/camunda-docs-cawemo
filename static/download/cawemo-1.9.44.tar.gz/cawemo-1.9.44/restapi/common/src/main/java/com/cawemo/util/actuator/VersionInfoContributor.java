/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util.actuator;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.actuate.info.Info;
import org.springframework.boot.actuate.info.InfoContributor;
import org.springframework.boot.info.GitProperties;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class VersionInfoContributor implements InfoContributor {

  private final GitProperties gitProperties;

  @Override
  public void contribute(Info.Builder builder) {
    builder.withDetail("version", gitProperties.getCommitId());
  }
}
