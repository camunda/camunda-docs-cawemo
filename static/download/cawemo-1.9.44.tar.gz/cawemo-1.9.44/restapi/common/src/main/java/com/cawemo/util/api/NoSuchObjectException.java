/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util.api;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class NoSuchObjectException extends NotFoundException {

  public NoSuchObjectException(String message) {
    super(null, message);
  }
}
