/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util;

import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

public class SetUtil {

  public static Set<String> toLowerCaseIgnoringDuplicates(Set<String> set) {
    return set.stream()
      .map(s -> s.toLowerCase(Locale.US))
      .collect(Collectors.toSet());
  }
}
