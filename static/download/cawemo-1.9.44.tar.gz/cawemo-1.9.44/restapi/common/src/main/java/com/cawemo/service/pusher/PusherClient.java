/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.pusher;

import com.cawemo.data.dto.pusher.PusherMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pusher.rest.PusherAsync;
import com.pusher.rest.data.Result;
import java.util.Optional;
import java.util.concurrent.CompletionException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class PusherClient {

  private static final String CREATION_FAILED_MESSAGE = "Pusher message creation failed: ";
  private final PusherAsync pusher;
  private final ObjectMapper objectMapper;

  public void trigger(PusherEvent event, String channelSuffix, Object payload) {
    createPusherMessage(event, payload)
      .ifPresent(message -> trigger(event, channelSuffix, message));
  }

  private void trigger(PusherEvent event, String channelSuffix, PusherMessage data) {
    pusher
      .trigger(event.getChannelPrefix() + channelSuffix, event.getEventName(), data)
      .thenAccept(result -> {
        if (result.getStatus() != Result.Status.SUCCESS) {
          log.error("Pusher message creation failed with status '{}': {}", result.getStatus(), result.getMessage());
        }
      })
      .exceptionally(e -> {
        if (e instanceof CompletionException completionException &&
          completionException.getCause() instanceof PusherMessageCreationException pusherMessageCreationException) {
          log.error(CREATION_FAILED_MESSAGE, pusherMessageCreationException);
        }

        return null;
      });
  }

  private Optional<PusherMessage> createPusherMessage(PusherEvent event, Object payload) {
    try {
      var message = new PusherMessage()
        .setType(event)
        .setPayload(objectMapper.writeValueAsString(payload));
      return Optional.of(message);
    } catch (JsonProcessingException e) {
      log.error(CREATION_FAILED_MESSAGE, e);
      return Optional.empty();
    }
  }
}
