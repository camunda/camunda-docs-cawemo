/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util;

import java.time.ZonedDateTime;

public class DateUtil {

  public static long asTimestamp(ZonedDateTime date) {
    return date.toInstant().toEpochMilli();
  }
}
