/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util.api;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class ServerException extends RuntimeException {

  public ServerException(Throwable cause) {
    super(cause);
  }

  public ServerException(String message) {
    super(message);
  }

  public ServerException(String message, Throwable cause) {
    super(message, cause);
  }
}
