/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.dto.base.response.InvitedProjectCollaboratorDto;
import com.cawemo.data.dto.base.response.ProjectCollaboratorDto;
import com.cawemo.data.entity.ProjectPermission;
import com.cawemo.data.entity.User;
import com.cawemo.data.entity.view.InvitedCollaboratorView;
import com.cawemo.data.entity.view.ProjectCollaboratorView;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ProjectCollaboratorMapper {

  @Mapping(target = "id", source = "id.user.id")
  @Mapping(target = "name", source = "id.user.name")
  @Mapping(target = "email", source = "id.user.email")
  @Mapping(target = "username", source = "id.user.username")
  @Mapping(target = "permissionAccess", source = "access")
  ProjectCollaboratorDto asCollaboratorDto(ProjectPermission projectPermission);

  List<ProjectCollaboratorDto> asCollaboratorDtoList(List<ProjectPermission> projectPermissions);

  @Mapping(target = "status", expression = "java( com.cawemo.service.user.InviteeStatus.SENT )")
  @Mapping(source = "token.id", target = "tokenId")
  @Mapping(target = "username", ignore = true)
  InvitedProjectCollaboratorDto asInvitedProjectCollaboratorDto(InvitedCollaboratorView invitedCollaborator);

  List<InvitedProjectCollaboratorDto> asInvitedProjectCollaboratorDtoList(
    List<InvitedCollaboratorView> invitedCollaborators);

  @Mapping(target = "username", ignore = true)
  @Mapping(target = "permissionAccess", ignore = true)
  ProjectCollaboratorDto asCollaboratorDto(User user);

  List<ProjectCollaboratorDto> fromUsers(List<User> users);

  ProjectCollaboratorDto asProjectCollaboratorDto(ProjectCollaboratorView collaborator);

  List<ProjectCollaboratorDto> asProjectCollaboratorDtoList(List<ProjectCollaboratorView> collaborators);
}
