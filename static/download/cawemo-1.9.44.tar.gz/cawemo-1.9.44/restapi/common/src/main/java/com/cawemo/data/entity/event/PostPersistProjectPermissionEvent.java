/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity.event;

import com.cawemo.data.entity.ProjectPermission;

public class PostPersistProjectPermissionEvent extends EntityEvent<ProjectPermission> {

  public PostPersistProjectPermissionEvent(ProjectPermission source) {
    super(source);
  }
}
