/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.token;

import com.cawemo.data.dto.base.response.TokenDto;
import com.cawemo.data.entity.Token;
import java.util.List;
import java.util.stream.Collectors;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring")
public interface TokenMapper {

  @BeanMapping(ignoreByDefault = true)
  @Mapping(source = "type", target = "type")
  TokenDto asDtoWithTypeOnly(Token token);

  @Named("asDto") // used in SignUpInvitationMapper
  TokenDto asDto(Token token);

  default List<TokenDto> asDtoList(List<Token> tokens) {
    return tokens.stream()
      .map(this::asDto)
      .collect(Collectors.toList());
  }
}
