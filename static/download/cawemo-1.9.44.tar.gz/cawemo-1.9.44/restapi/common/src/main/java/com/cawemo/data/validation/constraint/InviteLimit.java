/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.validation.constraint;

import com.cawemo.util.Constants;
import com.cawemo.util.api.ApiError;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import jakarta.validation.ReportAsSingleViolation;
import jakarta.validation.constraints.Size;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {})
@Size(max = Constants.BATCH_INVITE_LIMIT)
@ReportAsSingleViolation
@CustomApiErrorResponse(reason = ApiError.INVITE_LIMIT_EXCEEDED)
public @interface InviteLimit {

  String message() default "Limit exceeded";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}
