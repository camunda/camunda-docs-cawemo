/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.mail.template.view;

import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.User;
import lombok.Getter;

@Getter
public class OrganizationAdminPermissionGrantedMail extends OrganizationPermissionChangedMail {

  private final String settingsLink;

  public OrganizationAdminPermissionGrantedMail(User user, Organization organization, String settingsLink) {
    super("organization_admin_permission_granted", user, organization);
    this.settingsLink = settingsLink;
  }
}
