/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity;

import com.cawemo.data.entity.listener.FileEntityListener;
import com.cawemo.service.file.FileType;
import com.cawemo.util.Constants;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Objects;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.hibernate.annotations.JdbcType;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.hibernate.annotations.Where;
import org.hibernate.type.descriptor.jdbc.LongVarcharJdbcType;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(
  name = "files",
  indexes = {
    @Index(columnList = "created_by"),
    @Index(columnList = "folder_id"),
    @Index(columnList = "project_id"),
    @Index(columnList = "updated_by")
  }
)
@EntityListeners({AuditingEntityListener.class, FileEntityListener.class})
@Data
@Accessors(chain = true)
public class File implements Serializable {

  @Id
  private String id;

  @Column(nullable = false)
  private String name;

  @ManyToOne
  @JoinColumn(name = "project_id", nullable = false)
  @OnDelete(action = OnDeleteAction.CASCADE)
  private Project project;

  @ManyToOne
  @JoinColumn(name = "folder_id")
  @OnDelete(action = OnDeleteAction.CASCADE)
  private Folder folder;

  @JdbcType(LongVarcharJdbcType.class)
  private String content;

  @Version
  @Column(nullable = false)
  private Integer revision;

  @Column(nullable = false)
  private String relationId;

  private String processId;

  @Column(nullable = false)
  @Enumerated(EnumType.STRING)
  private FileType type;

  @CreatedDate
  @Column(updatable = false, nullable = false)
  private ZonedDateTime created;

  @CreatedBy
  @ManyToOne
  @JoinColumn(name = "created_by", nullable = false)
  private User createdBy;

  @LastModifiedDate
  @Column(nullable = false)
  private ZonedDateTime updated;

  @LastModifiedBy
  @ManyToOne
  @JoinColumn(name = "updated_by", nullable = false)
  private User updatedBy;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "file", fetch = FetchType.LAZY)
  private List<Comment> comments;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "sourceFile", fetch = FetchType.LAZY, orphanRemoval = true)
  @Where(clause = "source_element_id IS NULL")
  private List<FileLink> linksOutgoing;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "targetFile", fetch = FetchType.LAZY)
  private List<FileLink> legacyLinksIncoming;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "file", fetch = FetchType.LAZY)
  private List<Milestone> milestones;

  @ToString.Exclude
  @OneToOne(cascade = CascadeType.ALL, mappedBy = "file")
  private FileShare share;

  @Override
  public boolean equals(Object object) {
    if (object == null) {
      return false;
    } else if (object == this) {
      return true;
    } else if (!(object instanceof File)) {
      return false;
    } else {
      return Objects.equals(this.id, ((File) object).getId());
    }
  }

  @Override
  public int hashCode() {
    return Constants.ENTITY_HASHCODE;
  }
}
