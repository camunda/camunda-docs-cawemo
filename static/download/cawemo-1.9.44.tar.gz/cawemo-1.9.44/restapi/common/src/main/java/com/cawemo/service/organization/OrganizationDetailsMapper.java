/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.organization;

import com.cawemo.data.dto.base.response.OrganizationDetailsDto;

public interface OrganizationDetailsMapper {

  OrganizationDetailsDto asDto(OrganizationDetails organizationDetails);
}
