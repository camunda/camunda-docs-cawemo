/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.user;

import com.cawemo.data.dto.base.request.UserLoginDto;
import com.cawemo.data.entity.User;
import com.cawemo.data.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.transaction.annotation.Transactional;

@RequiredArgsConstructor
public abstract class AbstractLoginUserHandler {

  private final UserMapper userMapper;
  private final UserRepository userRepository;

  @Transactional
  public User createOrUpdateUser(UserLoginDto dto) {
    return userRepository.findByIamId(dto.getIamId())
      .map(user -> updateUser(user, dto))
      .orElseGet(() -> createUser(dto));
  }

  protected abstract User createUser(UserLoginDto dto);

  protected User updateUser(User user, UserLoginDto dto) {
    return userDataHasChanged(user, dto) ? updateChangedUser(user, dto) : user;
  }

  private User updateChangedUser(User user, UserLoginDto dto) {
    return userRepository.save(userMapper.updateFromDto(user, dto));
  }

  private boolean userDataHasChanged(User user, UserLoginDto dto) {
    return !user.getName().equals(dto.getName())
      || !user.getEmail().equalsIgnoreCase(dto.getEmail())
      || user.isVerified() != dto.isVerified();
  }
}
