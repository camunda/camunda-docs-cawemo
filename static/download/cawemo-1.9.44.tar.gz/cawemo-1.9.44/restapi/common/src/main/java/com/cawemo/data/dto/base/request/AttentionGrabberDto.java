/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class AttentionGrabberDto {

  @NotNull
  private Coordinates coordinates;

  @NotBlank
  private String color;

  @Data
  @Accessors(chain = true)
  public static class Coordinates {

    private double x;

    private double y;
  }
}
