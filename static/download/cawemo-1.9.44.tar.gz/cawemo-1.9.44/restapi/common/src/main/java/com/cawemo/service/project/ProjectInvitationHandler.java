/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.dto.base.request.ProjectInvitationDto;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.User;
import com.cawemo.util.InvitationResult;
import java.util.List;

public interface ProjectInvitationHandler {

  List<InvitationResult> inviteCollaborators(User inviter, Project project, ProjectInvitationDto dto);
}
