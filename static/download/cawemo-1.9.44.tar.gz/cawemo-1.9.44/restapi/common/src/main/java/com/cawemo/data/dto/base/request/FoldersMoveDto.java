/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import com.cawemo.data.validation.constraint.ValidFolderProjectAndParent;
import com.cawemo.data.validation.constraint.ValidFoldersMoveData;
import com.cawemo.util.Constants;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ValidFolderProjectAndParent
@ValidFoldersMoveData
public class FoldersMoveDto extends AbstractFolderDto {

  @NotEmpty
  private List<@NotBlank @Size(max = Constants.VARCHAR_MAX) String> folderIds;
}
