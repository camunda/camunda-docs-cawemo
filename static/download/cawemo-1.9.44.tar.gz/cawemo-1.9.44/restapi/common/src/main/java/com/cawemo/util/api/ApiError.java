/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util.api;

public enum ApiError {

  // 400 Bad Request
  INVALID_INPUT,
  TOKEN_EXPIRED,
  INVITE_LIMIT_EXCEEDED,
  SEATS_LIMIT_EXCEEDED,
  DOWNLOAD_LIMIT_EXCEEDED,
  OWN_ORGANIZATION_EXISTS,

  // 401 Unauthorized
  INVALID_PASSWORD,
  NOT_VERIFIED,

  // 403 Forbidden
  INVALID_OPERATION,
  ENTERPRISE_ONLY,

  // 404 Not Found
  TOKEN_NOT_FOUND,

  // 409 Conflict
  REVISION_CONFLICT,

  // 503 Service Unavailable
  MAINTENANCE_MODE,

  // not returned as error
  ALREADY_COLLABORATING,
  ALREADY_INVITED
}
