/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.dto.base.request.ProjectCollaboratorUpdateDto;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.ProjectPermission;
import com.cawemo.data.entity.User;
import com.cawemo.data.repository.ProjectPermissionRepository;
import java.util.Optional;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public abstract class AbstractProjectCollaboratorModifier {

  private final ProjectPermissionService projectPermissionService;
  private final ProjectPermissionRepository projectPermissionRepository;

  public void updateProjectPermission(Project project, ProjectCollaboratorUpdateDto dto) {
    projectPermissionService.getProjectPermissionForProjectUserEmail(project, dto.getEmail())
      .ifPresentOrElse(permission -> {
        ensurePermissionIsUpdatable(permission, dto.getPermissionAccess());
        if (permission.getAccess() != dto.getPermissionAccess()) {
          permission.setAccess(dto.getPermissionAccess());
          projectPermissionRepository.save(permission);
        }
      }, () -> updateProjectPermissionNotFoundAction(project, dto));
  }

  abstract void updateProjectPermissionNotFoundAction(Project project, ProjectCollaboratorUpdateDto dto);

  public void deleteProjectPermission(User authenticatedUser, Project project, String email) {

    var isSelfDeletion = authenticatedUser.getEmail().equalsIgnoreCase(email);
    ensurePermissionIsDeletable(authenticatedUser, project, isSelfDeletion);

    // only fetch the permission by email if an admin removes someone else, otherwise we can just delete the
    // authenticated user's permission
    var optionalPermission = isSelfDeletion ?
      Optional.of(projectPermissionService.buildProjectPermission(project, authenticatedUser)) :
      projectPermissionService.getProjectPermissionForProjectUserEmail(project, email);

    optionalPermission
      .ifPresentOrElse(projectPermissionRepository::delete,
        () -> deleteProjectPermissionNotFoundAction(authenticatedUser, project, email));
  }

  abstract void deleteProjectPermissionNotFoundAction(User authenticatedUser, Project project, String email);

  private void ensurePermissionIsUpdatable(ProjectPermission permission, ProjectPermissionLevel newAccess) {
    // An admin permission is not allowed to be downgraded if it's the only one for the project
    if (permission.getAccess() == ProjectPermissionLevel.OWNER && newAccess != ProjectPermissionLevel.OWNER) {
      var project = permission.getId().getProject();
      if (!projectPermissionRepository
        .existsByIdProjectAndAccessAndIdUserNot(project, ProjectPermissionLevel.OWNER, permission.getId().getUser())) {
        throw new ProjectPermissionNotChangeableException(project);
      }
    }
  }

  private void ensurePermissionIsDeletable(User authenticatedUser, Project project, boolean isSelfDeletion) {
    var projectAdmins = projectPermissionService.getProjectAdmins(project);
    var isAuthenticatedUserProjectAdmin = projectAdmins.stream().anyMatch(admin -> admin.equals(authenticatedUser));
    var isAttemptToDeleteOnlyAdmin = isAuthenticatedUserProjectAdmin && isSelfDeletion && projectAdmins.size() == 1;
    var isAttemptToDeleteOtherUserAsNonAdmin = !isAuthenticatedUserProjectAdmin && !isSelfDeletion;
    if (isAttemptToDeleteOnlyAdmin || isAttemptToDeleteOtherUserAsNonAdmin) {
      throw new ProjectPermissionNotChangeableException(project);
    }
  }
}
