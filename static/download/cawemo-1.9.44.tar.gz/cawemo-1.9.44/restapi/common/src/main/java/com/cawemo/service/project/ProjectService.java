/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.dto.base.request.ProjectCreateDto;
import com.cawemo.data.dto.base.request.ProjectUpdateDto;
import com.cawemo.data.dto.base.response.ProjectDto;
import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.ProjectPermission;
import com.cawemo.data.entity.ProjectPermissionId;
import com.cawemo.data.entity.User;
import com.cawemo.data.entity.view.ProjectAdminView;
import com.cawemo.data.entity.view.ProjectCollaboratorView;
import com.cawemo.data.entity.view.ProjectPermissionView;
import com.cawemo.data.entity.view.ProjectPermissionWithStatisticsView;
import com.cawemo.data.repository.FileRepository;
import com.cawemo.data.repository.OrganizationRepository;
import com.cawemo.data.repository.ProjectRepository;
import com.cawemo.util.api.NoSuchObjectException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ProjectService {

  public static final String ENGINE_PROJECT_NAME = "%s Deployments";
  public static final String MODELER_PROJECT_NAME = "%s's diagrams";

  private final ProjectMapper projectMapper;
  private final ProjectRepository projectRepository;
  private final OrganizationRepository organizationRepository;
  private final FileRepository fileRepository;
  private final AbstractProjectInfoBuilder projectInfoBuilder;
  private final ProjectPermissionService projectPermissionService;

  public static String engineDeploymentProjectName(String projectName) {
    return String.format(ENGINE_PROJECT_NAME, projectName);
  }

  public static String modelerProjectName(String userName) {
    return String.format(MODELER_PROJECT_NAME, userName);
  }

  public Project createProject(ProjectCreateDto dto, User user) {
    var organization = organizationRepository.findById(dto.getOrganizationId())
      // should actually not be empty here as permission check already fails if organization does not exist
      .orElseThrow(NoSuchObjectException::new);
    return createProjectForUser(organization, dto.getName(), user, dto.getType());
  }

  public Project createProjectForUser(Organization organization, String name, User user, ProjectType type) {
    var project = new Project()
      .setOrganization(organization)
      .setName(name)
      .setType(type);
    var permissionId = new ProjectPermissionId()
      .setUser(user)
      .setProject(project);
    var projectPermission = new ProjectPermission()
      .setId(permissionId)
      .setAccess(ProjectPermissionLevel.OWNER);
    project.setProjectPermissions(List.of(projectPermission));
    return projectRepository.save(project);
  }

  public List<Project> getEngineProjects(Organization organization, String projectName) {
    return StringUtils.isNotBlank(projectName) ?
      projectRepository.findByNameAndOrganizationAndType(projectName, organization, ProjectType.ENGINE) :
      projectRepository.findByOrganizationAndType(organization, ProjectType.ENGINE);
  }

  public Project getOrCreateEngineProject(Organization organization, User user, String projectName) {
    var engineProjectName = engineDeploymentProjectName(projectName);
    return projectRepository
      .findFirstByNameAndOrganizationAndTypeAndProjectPermissionsAccessAndProjectPermissionsIdUserOrderByCreatedDesc(
        engineProjectName, organization, ProjectType.ENGINE, ProjectPermissionLevel.OWNER, user)
      .orElseGet(() -> createProjectForUser(organization, engineProjectName, user, ProjectType.ENGINE));
  }

  public Project getOrCreateModelerProject(Organization organization, User user) {
    return projectRepository
      .findFirstByOrganizationAndTypeAndProjectPermissionsAccessAndProjectPermissionsIdUserOrderByCreatedDesc
        (organization, ProjectType.MODELER, ProjectPermissionLevel.OWNER, user)
      .orElseGet(() ->
        createProjectForUser(organization, modelerProjectName(user.getName()), user, ProjectType.MODELER));
  }

  public List<ProjectDto> getAllAccessibleProjects(Organization organization, User user) {
    var projects = findAccessibleProjectsWithStatisticsByUserAndOrganization(user, organization);
    var collaborators = getCollaboratorsPerProject(projects);
    return projects
      .stream()
      .map(project -> getProjectInfo(project, user, collaborators.get(project.getProject().getId())))
      .toList();
  }

  public ProjectDto getProjectInfo(ProjectPermissionWithStatisticsView view, User user,
                                   List<ProjectCollaboratorView> collaboratorsViews) {
    var userPermission = ProjectPermissionService.getEffectiveProjectPermissionLevel(view);
    var visibleCollaboratorsViews =
      projectPermissionService.getVisibleCollaborators(view, collaboratorsViews, user, userPermission);

    return projectMapper.asProjectDto(view, visibleCollaboratorsViews, userPermission);
  }

  private Map<String, List<ProjectCollaboratorView>> getCollaboratorsPerProject(
    List<ProjectPermissionWithStatisticsView> views) {
    var projectIds = views.stream().map(view -> view.getProject().getId()).toList();
    return projectPermissionService.getCollaborators(projectIds).stream()
      .collect(Collectors.groupingBy(ProjectCollaboratorView::getProjectId, Collectors.toList()));
  }

  public ProjectDto getProjectInfoIncludingFoldersAndFiles(Project project, User user) {
    var files = fileRepository.findByProjectAndFolderIsNullOrderByUpdatedDesc(project);
    return projectInfoBuilder.buildProjectInfoIncludingFoldersAndFiles(project, files, user);
  }

  public ProjectDto getProjectInfoExcludingFoldersAndFiles(Project project, User user) {
    return projectInfoBuilder.buildProjectInfoExcludingFoldersAndFiles(project, user);
  }

  public List<ProjectWithAdmins> findProjectsWithAdminsByOrganization(Organization organization) {
    return projectRepository.findAdminViewsByOrganization(organization)
      .stream()
      .collect(Collectors.groupingBy(ProjectAdminView::getProject,
        Collectors.mapping(ProjectAdminView::getAdmin, Collectors.toList())))
      .entrySet()
      .stream()
      .map(entry -> new ProjectWithAdmins(entry.getKey(), entry.getValue()))
      .toList();
  }

  public List<Project> findAccessibleProjectsByUserAndOrganization(User user, Organization organization) {
    return projectRepository.findPermissionViewByUserAndOrganization(user, organization)
      .stream()
      .filter(view -> ProjectPermissionService.getEffectiveProjectPermissionLevel(view) != ProjectPermissionLevel.NONE)
      .map(ProjectPermissionView::getProject)
      .toList();
  }

  private List<ProjectPermissionWithStatisticsView> findAccessibleProjectsWithStatisticsByUserAndOrganization(
    User user, Organization organization) {
    return projectRepository.findPermissionWithStatisticsByUserAndOrganization(user, organization)
      .stream()
      .filter(view -> ProjectPermissionService.getEffectiveProjectPermissionLevel(view) != ProjectPermissionLevel.NONE)
      .toList();
  }

  public void updateProject(Project project, ProjectUpdateDto dto) {
    projectRepository.save(projectMapper.updateFromDto(project, dto));
  }

  public void deleteProject(Project project) {
    projectRepository.delete(project);
  }

  public void deleteProjects(List<String> projectIds) {
    var projects = projectRepository.findAllById(projectIds);
    projectRepository.deleteAll(projects);
  }
}
