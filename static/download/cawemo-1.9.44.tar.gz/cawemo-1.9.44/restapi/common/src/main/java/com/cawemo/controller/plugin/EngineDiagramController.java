/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.plugin;

import com.cawemo.data.dto.base.request.DiagramEnginePluginDto;
import com.cawemo.security.authentication.ApiKeyAwareUserDetails;
import com.cawemo.service.file.PluginFileService;
import com.cawemo.util.Constants;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Engine")
@RequiredArgsConstructor
@RestController
@Validated
@PreAuthorize(
  "isFeatureEnabled(T(com.cawemo.service.authentication.AuthenticationService).authenticatedApiKey.organization" +
    ", T(Feature).ENGINE_PLUGIN)")
public class EngineDiagramController implements PluginApiController {

  private final PluginFileService pluginFileService;

  @GetMapping(value = "/engine/v1/project/{projectName}/diagrams/{processId}/missing_versions",
    produces = MediaType.APPLICATION_JSON_VALUE)
  public int[] getMissingVersions(@PathVariable("projectName") String projectName,
                                  @PathVariable("processId") String processId,
                                  @AuthenticationPrincipal ApiKeyAwareUserDetails userDetails) {
    return pluginFileService.getMissingEngineDiagramVersions(projectName, processId, userDetails.getUser());
  }

  @PutMapping(value = "/engine/v1/project/{projectName}/diagrams/{processId}",
    consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<String> putEngineDiagram(
    @PathVariable("projectName") @NotBlank @Size(max = Constants.VARCHAR_MAX) String projectName,
    @PathVariable("processId") @NotBlank @Size(max = Constants.VARCHAR_MAX) String processId,
    @Valid @RequestBody DiagramEnginePluginDto dto,
    @AuthenticationPrincipal ApiKeyAwareUserDetails userDetails) {
    pluginFileService.putEngineDiagram(projectName, processId, userDetails.getApiKey(), dto);

    // fix for #8142 - explicitly return OK with empty contents to not break the engine integration
    return ResponseEntity.ok(StringUtils.EMPTY);
  }
}
