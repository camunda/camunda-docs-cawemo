/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util.api;

import com.cawemo.data.dto.base.response.ApiErrorDto;
import com.cawemo.data.dto.base.response.ApiResponseWrapperDto;
import java.util.Set;
import lombok.experimental.UtilityClass;

@UtilityClass
public class ApiResponseUtil {

  public static ApiResponseWrapperDto createErrorResponse(ApiError reason) {
    return createErrorResponse(reason, null);
  }

  public static ApiResponseWrapperDto createErrorResponse(ApiError reason, String detail) {
    var errorDto = new ApiErrorDto()
      .setReason(reason)
      .setDetail(detail);
    return new ApiResponseWrapperDto()
      .setErrors(Set.of(errorDto));
  }
}
