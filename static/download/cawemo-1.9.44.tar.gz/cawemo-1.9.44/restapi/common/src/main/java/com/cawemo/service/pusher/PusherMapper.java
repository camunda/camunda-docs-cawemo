/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.pusher;

import com.cawemo.data.dto.base.request.AttentionGrabberDto;
import com.cawemo.data.dto.pusher.PusherAttentionGrabberDto;
import com.cawemo.data.dto.pusher.PusherCommentDto;
import com.cawemo.data.dto.pusher.PusherFileDto;
import com.cawemo.data.dto.pusher.PusherMultiProjectPermissionDto;
import com.cawemo.data.dto.pusher.PusherProjectPermissionDto;
import com.cawemo.data.entity.Comment;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.User;
import java.util.List;
import java.util.Set;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PusherMapper {

  @Mapping(source = "file.id", target = "fileId")
  @Mapping(source = "file.updated", target = "timestamp")
  @Mapping(source = "file.revision", target = "revision")
  @Mapping(source = "user.username", target = "user.username")
  @Mapping(source = "user.name", target = "user.name")
  @Mapping(source = "user.id", target = "user.id")
  @Mapping(source = "originAppInstanceId", target = "originAppInstanceId")
  PusherFileDto asPusherFileDto(File file, User user, String originAppInstanceId);

  @Mapping(source = "user.id", target = "authorUserId")
  PusherAttentionGrabberDto asPusherAttentionGrabberDto(AttentionGrabberDto attentionGrabberDto, User user);

  @Mapping(source = "user.id", target = "authorUserId")
  @Mapping(target = "coordinates", ignore = true)
  @Mapping(target = "color", ignore = true)
  PusherAttentionGrabberDto asPusherAttentionGrabberDto(User user);

  @Mapping(source = "comment.id", target = "id")
  @Mapping(source = "comment.file.id", target = "fileId")
  @Mapping(source = "comment.content", target = "content")
  @Mapping(source = "comment.created", target = "created")
  @Mapping(source = "comment.createdBy", target = "author")
  @Mapping(source = "comment.reference", target = "reference")
  @Mapping(source = "comment.updated", target = "lastChanged")
  @Mapping(source = "originAppInstanceId", target = "originAppInstanceId")
  PusherCommentDto asPusherCommentDto(Comment comment, String originAppInstanceId);

  @Mapping(source = "project.id", target = "projectId")
  PusherProjectPermissionDto asPusherProjectPermissionDto(Project project);

  @Mapping(source = "projects", target = "projectIds")
  PusherMultiProjectPermissionDto asPusherMultiProjectPermissionDto(PusherIntent intent, List<Project> projects);

  default String asProjectId(Project project) {
    return project.getId();
  }

  Set<String> asProjectIds(List<Project> projects);
}
