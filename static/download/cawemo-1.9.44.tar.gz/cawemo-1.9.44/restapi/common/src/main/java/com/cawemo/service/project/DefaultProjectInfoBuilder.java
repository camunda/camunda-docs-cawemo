/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.dto.base.response.ProjectDto;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.User;
import com.cawemo.data.entity.view.InvitedCollaboratorView;
import com.cawemo.data.projection.FileWithoutContent;
import com.cawemo.data.repository.FolderRepository;
import com.cawemo.data.repository.ProjectInvitationRepository;
import com.cawemo.data.repository.ProjectRepository;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class DefaultProjectInfoBuilder extends AbstractProjectInfoBuilder {

  private final ProjectMapper projectMapper;
  private final ProjectInvitationRepository projectInvitationRepository;

  public DefaultProjectInfoBuilder(FolderRepository folderRepository,
                                   ProjectPermissionService projectPermissionService,
                                   ProjectMapper projectMapper,
                                   ProjectInvitationRepository projectInvitationRepository,
                                   ProjectRepository projectRepository) {
    super(folderRepository, projectPermissionService, projectMapper, projectRepository);
    this.projectMapper = projectMapper;
    this.projectInvitationRepository = projectInvitationRepository;
  }

  @Override
  protected ProjectDto getProjectDto(Project project, List<FileWithoutContent> files, User user) {
    var dto = super.getProjectDto(project, files, user);

    var invitations = getInvitationsIfAllowedToSee(project, dto.getPermissionAccess());
    return projectMapper.asProjectWithInvitationsDto(dto, invitations);
  }

  private List<InvitedCollaboratorView> getInvitationsIfAllowedToSee(Project project,
                                                                     ProjectPermissionLevel userPermission) {
    return allowedToSeeInvitations(userPermission) ?
      projectInvitationRepository.getInvitedCollaboratorsForProject(project) :
      null;
  }

  private boolean allowedToSeeInvitations(ProjectPermissionLevel permissionLevel) {
    return permissionLevel == ProjectPermissionLevel.OWNER || permissionLevel == ProjectPermissionLevel.WRITE;
  }
}
