/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util.api;

import lombok.Getter;

@Getter
public class ClientException extends RuntimeException {

  private final ApiError apiError;

  protected ClientException() {
    this(null);
  }

  protected ClientException(ApiError apiError) {
    this(apiError, null);
  }

  protected ClientException(ApiError apiError, String message) {
    super(message);
    this.apiError = apiError;
  }
}
