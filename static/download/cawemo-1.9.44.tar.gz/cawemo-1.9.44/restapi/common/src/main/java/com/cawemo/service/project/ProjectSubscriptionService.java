/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.ProjectSubscription;
import com.cawemo.data.entity.ProjectSubscriptionId;
import com.cawemo.data.entity.User;
import com.cawemo.data.entity.view.ProjectSubscriptionView;
import com.cawemo.data.repository.ProjectSubscriptionRepository;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ProjectSubscriptionService {

  private final ProjectSubscriptionRepository projectSubscriptionRepository;

  public void createSubscription(String projectId, User user) {
    persistSubscription(projectId, user, true);
  }

  public List<ProjectSubscriptionView> getSubscriptions(Organization organization, User user) {
    return projectSubscriptionRepository
      .findByIdProjectOrganizationAndIdUser(organization, user)
      .stream()
      .filter(view -> {
        var projectType = view.getProjectPermission().getId().getProject().getType();
        var permissionLevel = view.getProjectPermission().getAccess();
        return ProjectPermissionMatcher.isAllowed(projectType, permissionLevel, ProjectOperation.COMMENT_AND_MENTION);
      })
      .collect(Collectors.toList());
  }

  public void deleteSubscription(String projectId, User user) {
    persistSubscription(projectId, user, false);
  }

  private void persistSubscription(String projectId, User user, boolean isActive) {
    var id = new ProjectSubscriptionId()
      .setProject(new Project().setId(projectId))
      .setUser(user);
    var subscription = new ProjectSubscription()
      .setId(id)
      .setActive(isActive);

    projectSubscriptionRepository.save(subscription);
  }
}
