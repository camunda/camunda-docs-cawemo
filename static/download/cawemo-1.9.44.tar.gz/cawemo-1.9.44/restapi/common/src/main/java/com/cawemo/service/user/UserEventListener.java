/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.user;

import com.cawemo.data.entity.User;
import com.cawemo.data.entity.event.PreRemoveUserEvent;
import com.cawemo.util.Constants;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@RequiredArgsConstructor
public class UserEventListener {

  private static final User DUMMY_USER = new User().setId(Constants.DUMMY_USER_ID);

  @EventListener
  @Transactional
  public void preRemoveUser(PreRemoveUserEvent event) {
    setCreatedByToDummyUserForObjectsCreatedByUser(event.getSource());
    setUpdatedByToDummyUserForObjectsUpdatedByUser(event.getSource());
  }

  private void setCreatedByToDummyUserForObjectsCreatedByUser(User user) {
    user.getCommentsCreated().forEach(comment -> comment.setCreatedBy(DUMMY_USER));
    user.getFileLinksCreated().forEach(fileLink -> fileLink.setCreatedBy(DUMMY_USER));
    user.getFilesCreated().forEach(file -> file.setCreatedBy(DUMMY_USER));
    user.getFileSharesCreated().forEach(share -> share.setCreatedBy(DUMMY_USER));
    user.getFoldersCreated().forEach(folder -> folder.setCreatedBy(DUMMY_USER));
    user.getMilestonesCreated().forEach(milestone -> milestone.setCreatedBy(DUMMY_USER));
    user.getOrganizationsCreated().forEach(organization -> organization.setCreatedBy(DUMMY_USER));
    user.getOrganizationPermissionsCreated().forEach(permission -> permission.setCreatedBy(DUMMY_USER));
    user.getProjectsCreated().forEach(project -> project.setCreatedBy(DUMMY_USER));
    user.getProjectPermissionsCreated().forEach(permission -> permission.setCreatedBy(DUMMY_USER));
  }

  private void setUpdatedByToDummyUserForObjectsUpdatedByUser(User user) {
    user.getFileLinksUpdated().forEach(fileLink -> fileLink.setUpdatedBy(DUMMY_USER));
    user.getFilesUpdated().forEach(file -> file.setUpdatedBy(DUMMY_USER));
    user.getFileSharesUpdated().forEach(share -> share.setUpdatedBy(DUMMY_USER));
    user.getFoldersUpdated().forEach(folder -> folder.setUpdatedBy(DUMMY_USER));
    user.getMilestonesUpdated().forEach(milestone -> milestone.setUpdatedBy(DUMMY_USER));
    user.getOrganizationsUpdated().forEach(organization -> organization.setUpdatedBy(DUMMY_USER));
    user.getOrganizationPermissionsUpdated().forEach(permission -> permission.setUpdatedBy(DUMMY_USER));
    user.getProjectsUpdated().forEach(project -> project.setUpdatedBy(DUMMY_USER));
    user.getProjectInvitationsUpdated().forEach(invitation -> invitation.setUpdatedBy(DUMMY_USER));
    user.getProjectPermissionsUpdated().forEach(permission -> permission.setUpdatedBy(DUMMY_USER));
    user.getTokensUpdated().forEach(token -> token.setUpdatedBy(DUMMY_USER));
  }
}
