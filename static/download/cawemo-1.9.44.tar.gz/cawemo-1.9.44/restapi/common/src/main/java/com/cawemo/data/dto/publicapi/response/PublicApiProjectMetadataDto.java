/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.publicapi.response;

public record PublicApiProjectMetadataDto(
  String id,
  String name,
  String created,
  String type,
  PublicApiUserDto createdBy,
  String updated,
  PublicApiUserDto updatedBy) { }
