/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.publicapi.request;

import com.cawemo.data.validation.constraint.NullOrNotBlank;
import com.cawemo.util.Constants;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class TemplateCreateDto {

  @JsonProperty("$schema")
  private String schema;

  @Size(min = 1, max = Constants.VARCHAR_MAX)
  @NotBlank
  private String name;

  private String description;

  private String id;

  @NotEmpty
  private List<@NotBlank String> appliesTo;

  private List<Object> properties;

  private Long version;

  @NotNull
  @Valid
  private Metadata metadata;

  @JsonAnySetter
  @JsonAnyGetter
  @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
  private Map<String, Object> additionalProperties = new HashMap<>();

  @Data
  @Accessors(chain = true)
  public static class Metadata {

    @Size(min = 1, max = Constants.VARCHAR_MAX)
    @NotBlank
    private String catalogId;

    @Size(min = 1, max = Constants.VARCHAR_MAX)
    @NullOrNotBlank
    private String templateVersionName;

    private boolean published;
  }
}
