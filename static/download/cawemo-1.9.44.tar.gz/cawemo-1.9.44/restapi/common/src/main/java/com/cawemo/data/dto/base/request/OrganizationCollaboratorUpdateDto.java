/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import com.cawemo.data.validation.constraint.EnumStringValue;
import com.cawemo.service.organization.OrganizationPermissionLevel;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class OrganizationCollaboratorUpdateDto {

  @NotBlank
  private String email;

  @EnumStringValue(noneOf = "NONE")
  private OrganizationPermissionLevel permissionAccess;
}
