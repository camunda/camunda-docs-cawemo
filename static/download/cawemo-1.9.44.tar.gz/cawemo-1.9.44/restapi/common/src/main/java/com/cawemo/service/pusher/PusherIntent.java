/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.pusher;

import com.fasterxml.jackson.annotation.JsonValue;
import java.util.Locale;

public enum PusherIntent {

  LEAVE,
  REMOVE;

  @JsonValue
  public String toLowerCase() {
    return super.toString().toLowerCase(Locale.US);
  }
}
