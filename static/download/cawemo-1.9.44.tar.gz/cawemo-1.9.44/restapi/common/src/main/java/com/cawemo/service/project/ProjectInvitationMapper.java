/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.dto.base.response.ProjectDto;
import com.cawemo.data.dto.base.response.ProjectInvitationResponseDto;
import com.cawemo.data.dto.base.response.ProjectInvitationResultDto;
import com.cawemo.data.dto.base.response.ProjectInvitationResultListWrapperDto;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.ProjectInvitation;
import com.cawemo.util.InvitationResult;
import java.util.List;
import org.apache.commons.lang3.ObjectUtils;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring")
public interface ProjectInvitationMapper {

  @Mapping(target = "user.id", source = "createdBy.id")
  @Mapping(target = "user.name", source = "createdBy.name")
  @Mapping(target = "user.username", ignore = true)
  @Mapping(target = "user.email", ignore = true)
  @Mapping(target = "project", source = "project")
  @Mapping(target = "email", source = "invitedEmail")
  @BeanMapping(ignoreByDefault = true)
  ProjectInvitationResponseDto asDto(ProjectInvitation projectInvitation);

  @Mapping(target = "id", source = "id")
  @Mapping(target = "name", source = "name")
  @BeanMapping(ignoreByDefault = true)
  ProjectDto asDto(Project project);

  @Mapping(source = "result", target = "status", qualifiedByName = "getStatus")
  @Mapping(source = "token.id", target = "tokenId")
  ProjectInvitationResultDto asDto(InvitationResult result);

  List<ProjectInvitationResultDto> asDtoList(List<InvitationResult> results);

  default ProjectInvitationResultListWrapperDto asListWrapperDto(List<InvitationResult> results) {
    return new ProjectInvitationResultListWrapperDto().setInvitationResults(asDtoList(results));
  }

  @Named("getStatus")
  default Enum<?> getStatus(InvitationResult result) {
    return ObjectUtils.getIfNull(result.getStatus(), result.getError());
  }
}
