/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.publicapi.response;

import java.util.List;
import lombok.Data;

@Data
public class PublicApiTemplateMetadataDto {

  private String catalogId;

  private String templateVersionName;

  private boolean published;

  private long created;

  private long updated;

  private List<String> tags;
}
