/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.preference;

import com.cawemo.data.entity.User;
import java.util.Map;

public interface PreferenceService {

  Map<PreferenceKey, Boolean> getUserPreferences(User user);

  void updateUserPreferences(User user, Map<PreferenceKey, Boolean> preferences);
}
