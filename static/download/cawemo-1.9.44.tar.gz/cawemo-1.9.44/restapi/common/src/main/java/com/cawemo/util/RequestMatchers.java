/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util;

import java.util.Arrays;
import java.util.stream.Collectors;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.AnyRequestMatcher;
import org.springframework.security.web.util.matcher.NegatedRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

public class RequestMatchers {

  public static RequestMatcher excludePaths(String... excludedPathPatterns) {
    if (ArrayUtils.isEmpty(excludedPathPatterns)) {
      return AnyRequestMatcher.INSTANCE;
    }
    var pathMatchers = Arrays.stream(excludedPathPatterns)
      .map(pattern -> (RequestMatcher) new AntPathRequestMatcher(pattern))
      .collect(Collectors.toList());
    return new NegatedRequestMatcher(new OrRequestMatcher(pathMatchers));
  }
}
