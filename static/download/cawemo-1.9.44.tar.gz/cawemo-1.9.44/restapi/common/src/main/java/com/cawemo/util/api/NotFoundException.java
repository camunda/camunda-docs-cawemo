/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util.api;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class NotFoundException extends ClientException {

  protected NotFoundException(ApiError apiError, String message) {
    super(apiError, message);
  }
}
