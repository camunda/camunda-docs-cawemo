/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.dto.base.request.ProjectCollaboratorUpdateDto;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.User;
import com.cawemo.data.repository.ProjectPermissionRepository;
import com.cawemo.util.api.NoSuchObjectException;
import org.springframework.stereotype.Service;

@Service
public class DefaultProjectCollaboratorModifier extends AbstractProjectCollaboratorModifier {

  private final ProjectInvitationService projectInvitationService;

  public DefaultProjectCollaboratorModifier(ProjectPermissionService projectPermissionService,
                                            ProjectPermissionRepository projectPermissionRepository,
                                            ProjectInvitationService projectInvitationService) {
    super(projectPermissionService, projectPermissionRepository);
    this.projectInvitationService = projectInvitationService;
  }

  @Override
  void updateProjectPermissionNotFoundAction(Project project, ProjectCollaboratorUpdateDto dto) {
    projectInvitationService.findByProjectAndInvitedEmail(project, dto.getEmail())
      .ifPresentOrElse(invitation -> {
        invitation.setAccess(dto.getPermissionAccess());
        projectInvitationService.updateInvitation(invitation);
      }, () -> {
        throw new NoSuchObjectException();
      });
  }

  @Override
  void deleteProjectPermissionNotFoundAction(User authenticatedUser, Project project, String email) {
    if (!projectInvitationService.deleteByProjectAndInvitedEmail(project, email)) {
      throw new NoSuchObjectException();
    }
  }
}
