/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.preference;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.Arrays;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum PreferenceKey {

  NEWSLETTER_CONSENT_GIVEN("newsletterConsentGiven"),
  ONBOARDING_FLOW_SEEN("onboardingFlowSeen"),
  SHOW_NEWSLETTER_CONSENT_REQUEST("showNewsletterConsentRequest");

  @JsonValue
  private final String key;

  @JsonCreator
  public static PreferenceKey fromString(String string) {
    return Arrays.stream(values())
      .filter(preferenceKey -> preferenceKey.key.equals(string))
      .findFirst()
      .orElseThrow();
  }
}
