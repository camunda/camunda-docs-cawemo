/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.ProjectInvitation;
import com.cawemo.data.entity.ProjectPermission;
import com.cawemo.data.entity.ProjectPermissionId;
import com.cawemo.data.entity.User;
import com.cawemo.data.entity.view.ProjectCollaboratorView;
import com.cawemo.data.entity.view.ProjectPermissionAdminView;
import com.cawemo.data.entity.view.ProjectPermissionView;
import com.cawemo.data.entity.view.ProjectPermissionWithStatisticsView;
import com.cawemo.data.repository.ProjectPermissionRepository;
import com.cawemo.data.repository.ProjectRepository;
import com.cawemo.service.organization.OrganizationPermissionService;
import com.cawemo.service.pusher.PusherService;
import com.cawemo.util.api.NoSuchObjectException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProjectPermissionService {

  private final OrganizationPermissionService organizationPermissionService;
  private final ProjectPermissionRepository projectPermissionRepository;
  private final ProjectRepository projectRepository;
  private final ProjectService projectService;
  private final PusherService pusherService;

  public ProjectPermissionService(@Lazy OrganizationPermissionService organizationPermissionService,
                                  ProjectPermissionRepository projectPermissionRepository,
                                  ProjectRepository projectRepository,
                                  @Lazy ProjectService projectService,
                                  PusherService pusherService) {
    this.organizationPermissionService = organizationPermissionService;
    this.projectPermissionRepository = projectPermissionRepository;
    this.projectRepository = projectRepository;
    this.projectService = projectService;
    this.pusherService = pusherService;
  }

  public static ProjectPermissionLevel getEffectiveProjectPermissionLevel(ProjectPermissionView view) {
    return Optional.ofNullable(view.getProjectPermission())
      .orElse(view.getProjectType().isOrganizationPublic() ? ProjectPermissionLevel.READ : ProjectPermissionLevel.NONE);
  }

  public void createProjectPermission(Project project, User user, ProjectPermissionLevel accessLevel, User createdBy) {
    var permission = buildProjectPermission(project, user, accessLevel, createdBy, createdBy);
    projectPermissionRepository.save(permission);
  }

  public void createProjectPermission(Project project, User user, ProjectInvitation invitation) {
    var permission = buildProjectPermission(project, user, invitation.getAccess(), invitation.getCreatedBy(),
      invitation.getUpdatedBy());
    projectPermissionRepository.save(permission);
  }

  public void createOrUpdateProjectPermission(Project project, User user, ProjectPermissionLevel accessLevel) {
    projectPermissionRepository.findById(new ProjectPermissionId().setProject(project).setUser(user))
      .ifPresentOrElse(permission -> {
        permission
          .setAccess(accessLevel)
          .setUpdatedBy(user);
        projectPermissionRepository.save(permission);
      }, () -> createProjectPermission(project, user, accessLevel, user));
  }

  /**
   * This method will delete project permissions in batch ignoring any entity lifecycle callbacks like
   * {@link jakarta.persistence.PreUpdate}.
   */
  public void deleteProjectPermissionsInBatch(User user, Organization organization) {
    var projects = projectService.findAccessibleProjectsByUserAndOrganization(user, organization);
    projectPermissionRepository.deleteInBatchByIdUserAndIdProjectIn(user, projects);
    pusherService.removePermissionNotification(user, projects, null);
  }

  public List<ProjectPermission> findPermissionsForSubscribedUsersExcludingReadAccess(List<String> usernames,
                                                                                      Project project) {
    var lowerCaseUsernames = usernames.stream()
      .map(String::toLowerCase)
      .toList();
    return projectPermissionRepository
      .findPermissionsForSubscribedUsersExcludingReadAccess(lowerCaseUsernames, project);
  }

  public boolean projectPermissionExists(Project project, User user) {
    var id = new ProjectPermissionId()
      .setProject(project)
      .setUser(user);
    return projectPermissionRepository.existsById(id);
  }

  public boolean projectPermissionExists(Project project, String userEmail) {
    return projectPermissionRepository.existsByIdProjectAndIdUserEmailIgnoreCase(project, userEmail);
  }

  public List<User> getProjectAdmins(Project project) {
    return projectPermissionRepository
      .findByIdProjectAndAccess(project, ProjectPermissionLevel.OWNER)
      .stream()
      .map(ProjectPermission::getId)
      .map(ProjectPermissionId::getUser)
      .toList();
  }

  public List<ProjectPermission> getCollaborators(Project project, User user) {
    var userPermission = getUserPermission(project, user);
    var allCollaborators = project.getProjectPermissions();
    return getVisibleCollaborators(project.getType(), allCollaborators, user, userPermission);
  }

  public ProjectPermissionLevel getUserPermission(Project project, User user) {
    return projectRepository.findPermissionByUserAndProject(user, project)
      .map(ProjectPermissionService::getEffectiveProjectPermissionLevel)
      .orElseThrow(NoSuchObjectException::new);
  }

  public List<ProjectPermission> getVisibleCollaborators(ProjectType type,
                                                         List<ProjectPermission> allCollaborators,
                                                         User user,
                                                         ProjectPermissionLevel userPermissionLevel) {
    return !ProjectPermissionMatcher.isAllowed(type, userPermissionLevel, ProjectOperation.VIEW_COLLABORATORS) ?
      // read-only collaborators should not see other people in the project but only themselves
      allCollaborators
        .stream()
        .filter(permission -> permission.getId().getUser().equals(user))
        .toList() :
      allCollaborators;
  }

  public List<ProjectCollaboratorView> getVisibleCollaborators(ProjectPermissionWithStatisticsView view,
                                                               List<ProjectCollaboratorView> allCollaborators,
                                                               User user,
                                                               ProjectPermissionLevel userPermissionLevel) {
    return !ProjectPermissionMatcher.isAllowed(view.getProjectType(), userPermissionLevel,
      ProjectOperation.VIEW_COLLABORATORS) ?
      // read-only collaborators should not see other people in the project but only themselves
      allCollaborators
        .stream()
        .filter(collaboratorView -> collaboratorView.getId().equals(user.getId()))
        .toList() :
      allCollaborators;
  }

  public List<ProjectCollaboratorView> getCollaborators(List<String> projectIds) {
    return projectPermissionRepository.findByProjectIdIn(projectIds);
  }

  public List<ProjectPermissionWithAdmins> getPermissionsWithProjectAdminsForOrganizationAndUser(
    Organization organization, String userId) {
    return projectPermissionRepository.getPermissionsWithProjectAdminsForOrganizationAndUser(organization, userId)
      .stream()
      .collect(Collectors.groupingBy(ProjectPermissionAdminView::getPermission,
        Collectors.mapping(ProjectPermissionAdminView::getAdmin, Collectors.toList())))
      .entrySet()
      .stream()
      .map(entry -> new ProjectPermissionWithAdmins(entry.getKey(), entry.getValue()))
      .toList();
  }

  public boolean existsByIdProjectOrganizationAndIdUserNot(Organization organization, User user) {
    return projectPermissionRepository.existsByIdProjectOrganizationAndIdUserNot(organization, user);
  }

  @Transactional
  public void transferProjectAdminPermissionsToOrganizationAdmin(User user, List<Organization> organizations) {
    transferProjectAdminPermissions(user, organizations,
      organization -> organizationPermissionService.getMostSeniorOrganizationAdminExcludingUser(organization, user));
  }

  @Transactional
  public void transferProjectAdminPermissionsToOrganizationAdmin(User authenticatedUser,
                                                                 User permissionUser,
                                                                 Organization organization) {
    transferProjectAdminPermissions(permissionUser, List.of(organization),
      org -> getTargetOrganizationAdmin(authenticatedUser, permissionUser, org));
  }

  @Transactional
  public void transferProjectAdminPermissionsForEngineProjectsToOtherOrganizationAdmin(User authenticatedUser,
                                                                                       User currentAdmin,
                                                                                       Organization organization) {
    var adminPermissions = getEngineProjectAdminPermissions(organization, currentAdmin);
    if (!adminPermissions.isEmpty()) {
      projectPermissionRepository.deleteAll(adminPermissions);
      var newAdmin = getTargetOrganizationAdmin(authenticatedUser, currentAdmin, organization);
      createNewAdminPermissions(adminPermissions, newAdmin);
    }
  }

  public Optional<ProjectPermission> getProjectPermissionForProjectUserEmail(Project project, String email) {
    return projectPermissionRepository.findByIdProjectAndIdUserEmailIgnoreCase(project, email);
  }

  public ProjectPermission buildProjectPermission(Project project, User user) {
    var projectPermissionId = new ProjectPermissionId()
      .setProject(project)
      .setUser(user);
    return new ProjectPermission().setId(projectPermissionId);
  }

  private ProjectPermission buildProjectPermission(Project project,
                                                   User user,
                                                   ProjectPermissionLevel accessLevel,
                                                   User createdBy,
                                                   User updatedBy) {
    return buildProjectPermission(project, user)
      .setAccess(accessLevel)
      .setCreatedBy(createdBy)
      .setUpdatedBy(updatedBy);
  }

  private void transferProjectAdminPermissions(User user,
                                               List<Organization> organizations,
                                               Function<Organization, User> targetAdminProvider) {
    findAllAdminPermissionsForProjectsUserIsAdminOf(organizations, user).forEach((project, adminPermissions) ->
      filterByUser(adminPermissions, user).ifPresent(permission -> {
        projectPermissionRepository.delete(permission);
        // assign new project admin only if the user has been the only one
        if (adminPermissions.size() == 1) {
          var targetAdmin = targetAdminProvider.apply(project.getOrganization());
          createOrUpdateProjectPermission(project, targetAdmin, ProjectPermissionLevel.OWNER);
        }
      })
    );
  }

  private User getTargetOrganizationAdmin(User authenticatedUser, User permissionUser, Organization organization) {
    return authenticatedUser.equals(permissionUser) ?
      organizationPermissionService.getMostSeniorOrganizationAdminExcludingUser(organization, permissionUser) :
      authenticatedUser;
  }

  private Map<Project, List<ProjectPermission>> findAllAdminPermissionsForProjectsUserIsAdminOf(
    List<Organization> organizations, User user) {
    return projectPermissionRepository.findAllAdminPermissionsForProjectsUserIsAdminOf(organizations, user)
      .stream()
      .collect(Collectors.groupingBy(permission -> permission.getId().getProject()));
  }

  private Optional<ProjectPermission> filterByUser(List<ProjectPermission> permissions, User user) {
    return permissions.stream()
      .filter(permission -> permission.getId().getUser().equals(user))
      .findFirst();
  }

  private List<ProjectPermission> getEngineProjectAdminPermissions(Organization organization, User user) {
    return projectPermissionRepository.findByIdProjectOrganizationAndIdProjectTypeAndIdUserAndAccess(
      organization, ProjectType.ENGINE, user, ProjectPermissionLevel.OWNER);
  }

  private void createNewAdminPermissions(List<ProjectPermission> currentAdminPermissions, User newAdmin) {
    var newAdminPermissions = currentAdminPermissions
      .stream()
      .map(permission -> createProjectAdminPermission(permission.getId().getProject(), newAdmin))
      .toList();
    projectPermissionRepository.saveAll(newAdminPermissions);
  }

  private ProjectPermission createProjectAdminPermission(Project project, User admin) {
    return buildProjectPermission(project, admin).setAccess(ProjectPermissionLevel.OWNER);
  }
}
