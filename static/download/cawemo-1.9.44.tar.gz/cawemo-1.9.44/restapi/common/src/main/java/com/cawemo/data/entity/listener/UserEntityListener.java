/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity.listener;

import com.cawemo.data.entity.User;
import com.cawemo.data.entity.event.PreRemoveUserEvent;
import jakarta.persistence.PreRemove;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class UserEntityListener {

  private final ApplicationEventPublisher publisher;

  @PreRemove
  public void preRemove(User user) {
    publisher.publishEvent(new PreRemoveUserEvent(user));
  }
}
