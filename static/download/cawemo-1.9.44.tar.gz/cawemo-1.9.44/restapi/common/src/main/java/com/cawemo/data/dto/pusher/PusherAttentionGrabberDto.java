/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.pusher;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class PusherAttentionGrabberDto {

  private Coordinates coordinates;

  private String color;

  private String authorUserId;

  @Data
  @Accessors(chain = true)
  public static class Coordinates {

    private double x;

    private double y;
  }
}
