/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util;

public enum Feature {

  DIAGRAM_LINKS,
  DIFFING,
  ENGINE_PLUGIN,
  MODELER_PLUGIN,
  RELATED_DIAGRAMS,
  RPA
}
