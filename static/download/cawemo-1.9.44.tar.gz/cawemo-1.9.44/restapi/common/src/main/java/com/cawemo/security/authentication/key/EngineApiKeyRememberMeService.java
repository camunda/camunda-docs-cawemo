/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.authentication.key;

import com.cawemo.data.entity.ApiKey;
import com.cawemo.data.repository.ApiKeyRepository;
import com.cawemo.security.authentication.ApiKeyAwareUserDetails;
import java.util.List;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.authentication.AuthenticationDetailsSource;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class EngineApiKeyRememberMeService extends AbstractApiKeyRememberMeService {

  public static final String ORGANIZATION_ID_PARAM = "organizationId";
  private final ApiKeyRepository apiKeyRepository;

  protected EngineApiKeyRememberMeService(UserDetailsService userDetailsService,
                                          ApiKeyRepository apiKeyRepository,
                                          @Lazy PasswordEncoder passwordEncoder,
                                          AuthenticationDetailsSource<ApiKey, ApiKeyAwareUserDetails> detailsSource) {
    super(userDetailsService, passwordEncoder, detailsSource);
    this.apiKeyRepository = apiKeyRepository;
  }

  @Override
  String principalParameter() {
    return ORGANIZATION_ID_PARAM;
  }

  @Override
  List<ApiKey> getApiKeys(String organizationId) {
    return apiKeyRepository.findByOrganizationId(organizationId);
  }
}
