/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import com.cawemo.data.validation.constraint.NullOrNotBlank;
import com.cawemo.util.Constants;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.util.Set;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class FileCreateFromMilestoneDto {

  @Size(max = Constants.VARCHAR_MAX)
  @NullOrNotBlank
  private String targetProjectId;

  @Size(max = Constants.VARCHAR_MAX)
  @NullOrNotBlank
  private String targetFolderId;

  @Size(max = Constants.VARCHAR_MAX)
  @NullOrNotBlank // only required for BPMN diagrams (checked in FileService)
  private String processId;

  private Set<@NotBlank @Size(max = Constants.VARCHAR_MAX) String> callActivityLinks;
}
