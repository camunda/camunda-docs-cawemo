/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import com.cawemo.data.validation.constraint.EnumStringValue;
import com.cawemo.service.project.ProjectPermissionLevel;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class ProjectCollaboratorUpdateDto {

  @NotBlank
  @Email
  private String email;

  @EnumStringValue(noneOf = "NONE")
  private ProjectPermissionLevel permissionAccess;
}
