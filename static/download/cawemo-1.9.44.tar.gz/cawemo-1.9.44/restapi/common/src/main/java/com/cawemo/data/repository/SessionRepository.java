/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.Session;
import java.time.ZonedDateTime;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface SessionRepository extends JpaRepository<Session, String> {

  Optional<Session> findByIdAndValidUntilAfter(String id, ZonedDateTime date);

  @Transactional
  void deleteByValidUntilBefore(ZonedDateTime sessionExpiryDate);

  @Transactional
  @Modifying
  @Query("""
    UPDATE Session s
    SET s.updated = :updated
    WHERE s = :session
    """)
  void setUpdated(@Param("session") Session session, @Param("updated") ZonedDateTime updated);
}
