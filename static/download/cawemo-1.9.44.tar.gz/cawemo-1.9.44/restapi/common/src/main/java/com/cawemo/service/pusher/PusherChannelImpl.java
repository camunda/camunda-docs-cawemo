/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.pusher;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum PusherChannelImpl implements PusherChannel {

  DIAGRAM_UPDATE("private-diagram-update-"),
  DIAGRAM_ATTENTION("private-diagram-attention-"),
  PERMISSION("private-user-"),
  COMMENT("private-comments-");

  private final String prefix;
}
