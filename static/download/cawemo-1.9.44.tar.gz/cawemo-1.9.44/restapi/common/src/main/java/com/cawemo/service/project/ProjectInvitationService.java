/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.ProjectInvitation;
import com.cawemo.data.entity.User;
import com.cawemo.data.entity.view.InvitedCollaboratorView;
import com.cawemo.data.entity.view.ProjectInvitationAdminView;
import com.cawemo.data.repository.ProjectInvitationRepository;
import com.cawemo.service.organization.OrganizationPermissionService;
import com.cawemo.service.token.TokenService;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ProjectInvitationService {

  private final OrganizationPermissionService organizationPermissionService;
  private final ProjectInvitationRepository projectInvitationRepository;
  private final ProjectPermissionService projectPermissionService;
  private final TokenService tokenService;

  @Transactional
  public void joinProject(ProjectInvitation invitation, User user) {
    var project = invitation.getProject();
    organizationPermissionService
      .getOrCreateCollaboratorPermission(project.getOrganization(), user, invitation.getCreatedBy());
    projectPermissionService.createProjectPermission(project, user, invitation);
    tokenService.deleteToken(invitation.getToken());
  }

  public boolean joinProjectIsAllowed(ProjectInvitation invitation) {
    return ProjectPermissionMatcher.isAllowed(invitation.getProject().getType(), invitation.getAccess(),
      ProjectOperation.JOIN_PROJECT);
  }

  public List<ProjectInvitation> findByOrganizationAndEmail(Organization organization, String email) {
    return projectInvitationRepository.findByProjectOrganizationAndInvitedEmailIgnoreCase(organization, email);
  }

  public Optional<ProjectInvitation> findByProjectAndInvitedEmail(Project project, String email) {
    return projectInvitationRepository.findByProjectAndInvitedEmailIgnoreCase(project, email);
  }

  public void updateInvitation(ProjectInvitation invitation) {
    projectInvitationRepository.save(invitation);
  }

  public void deleteInvitations(List<ProjectInvitation> invitations) {
    var tokens = invitations
      .stream()
      .map(ProjectInvitation::getToken)
      .toList();

    // deletion will be cascaded to project invitations
    tokenService.deleteTokens(tokens);
  }

  public boolean deleteByProjectAndInvitedEmail(Project project, String email) {
    return tokenService.deleteByProjectInvitationProjectAndInvitedEmail(project, email) > 0;
  }

  public List<InvitedCollaboratorView> getInvitedUsersWithoutOrganizationPermission(Organization organization) {
    return projectInvitationRepository.getInvitedUsersWithoutOrganizationPermission(organization);
  }

  public List<ProjectInvitationWithAdmins> getInvitationsWithProjectAdminsForOrganizationAndInvitedEmail(
    Organization organization, String email) {
    return projectInvitationRepository
      .getInvitationsWithProjectAdminsForOrganizationAndInvitedEmail(organization, email)
      .stream()
      .collect(Collectors.groupingBy(ProjectInvitationAdminView::getInvitation,
        Collectors.mapping(ProjectInvitationAdminView::getAdmin, Collectors.toList())))
      .entrySet()
      .stream()
      .map(entry -> new ProjectInvitationWithAdmins(entry.getKey(), entry.getValue()))
      .toList();
  }
}
