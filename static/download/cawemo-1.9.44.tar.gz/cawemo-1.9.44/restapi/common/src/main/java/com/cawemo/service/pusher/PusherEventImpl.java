/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.pusher;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum PusherEventImpl implements PusherEvent {

  PERMISSION_ADD("permission:add", "PERMISSION_ADDED", PusherChannelImpl.PERMISSION),
  PERMISSION_EDIT("permission:edit", "PERMISSION_EDITED", PusherChannelImpl.PERMISSION),
  PERMISSION_REMOVE("permission:remove", "PERMISSION_REMOVED", PusherChannelImpl.PERMISSION),

  COMMENT_ADD("comment:add", "COMMENT_ADDED", PusherChannelImpl.COMMENT),
  COMMENT_EDIT("comment:edit", "COMMENT_EDITED", PusherChannelImpl.COMMENT),
  COMMENT_REMOVE("comment:remove", "COMMENT_REMOVED", PusherChannelImpl.COMMENT),

  DIAGRAM_UPDATE("diagram:update", "DIAGRAM_LAST_MODIFIED", PusherChannelImpl.DIAGRAM_UPDATE),
  DIAGRAM_ATTENTION_CREATION("diagram:attention:create", "DIAGRAM_ATTENTION", PusherChannelImpl.DIAGRAM_ATTENTION),
  DIAGRAM_ATTENTION_DELETION("diagram:attention:delete", "DIAGRAM_ATTENTION", PusherChannelImpl.DIAGRAM_ATTENTION);

  private final String eventName;
  private final String messageType;
  private final PusherChannel channel;
}
