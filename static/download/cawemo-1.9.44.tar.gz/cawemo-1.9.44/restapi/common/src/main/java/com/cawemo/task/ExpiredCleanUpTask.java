/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.task;

import com.cawemo.configuration.data.ZonedDateTimeProvider;
import com.cawemo.data.repository.SessionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "scheduling.expired-clean-up.enabled", havingValue = "true", matchIfMissing = true)
@RequiredArgsConstructor
public class ExpiredCleanUpTask {

  private final SessionRepository sessionRepository;
  private final ZonedDateTimeProvider zonedDateTimeProvider;

  @Scheduled(
    initialDelayString = "${scheduling.expired-clean-up.initial-delay-millis}",
    fixedDelayString = "${scheduling.expired-clean-up.fixed-delay-millis}"
  )
  public void cleanUp() {
    sessionRepository.deleteByValidUntilBefore(zonedDateTimeProvider.now());
  }
}
