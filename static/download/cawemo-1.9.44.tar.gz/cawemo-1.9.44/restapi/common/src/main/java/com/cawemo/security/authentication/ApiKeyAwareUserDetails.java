/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.authentication;

import com.cawemo.data.entity.ApiKey;
import lombok.Getter;
import org.springframework.util.Assert;

public class ApiKeyAwareUserDetails extends UserAwareUserDetails {

  @Getter
  private final ApiKey apiKey;

  public ApiKeyAwareUserDetails(ApiKey apiKey) {
    super(apiKey.getUser());
    Assert.isNull(apiKey.getSecret(), "apiKey secret must be erased before creating ApiKeyAwareUserDetails");
    this.apiKey = apiKey;
  }
}
