/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.configuration.data;

import java.time.ZonedDateTime;
import java.time.temporal.TemporalAccessor;
import java.util.Optional;
import org.springframework.data.auditing.DateTimeProvider;

public interface ZonedDateTimeProvider extends DateTimeProvider {

  ZonedDateTime now();

  @Override
  default Optional<TemporalAccessor> getNow() {
    return Optional.of(now());
  }
}
