/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.Set;
import lombok.experimental.UtilityClass;

@UtilityClass
public class ProjectPermissionMatcher {

  private static final Map<ProjectOperation, Map<ProjectType, Set<ProjectPermissionLevel>>> PERMISSIONS =
    new EnumMap<>(ProjectOperation.class);

  static {
    PERMISSIONS.put(ProjectOperation.VIEW_PROJECT,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.READ, ProjectPermissionLevel.COMMENT,
          ProjectPermissionLevel.WRITE, ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Set.of(ProjectPermissionLevel.READ, ProjectPermissionLevel.OWNER),
        ProjectType.MODELER, Set.of(ProjectPermissionLevel.READ, ProjectPermissionLevel.OWNER),
        ProjectType.CATALOG, Set.of(ProjectPermissionLevel.READ, ProjectPermissionLevel.OWNER))
    );

    PERMISSIONS.put(ProjectOperation.MODIFY_PROJECT,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Collections.emptySet(),
        ProjectType.MODELER, Collections.emptySet(),
        ProjectType.CATALOG, Set.of(ProjectPermissionLevel.OWNER))
    );

    PERMISSIONS.put(ProjectOperation.DELETE_PROJECT,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Set.of(ProjectPermissionLevel.OWNER),
        ProjectType.MODELER, Set.of(ProjectPermissionLevel.OWNER),
        ProjectType.CATALOG, Set.of(ProjectPermissionLevel.OWNER))
    );

    PERMISSIONS.put(ProjectOperation.LEAVE_PROJECT,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.READ, ProjectPermissionLevel.COMMENT,
          ProjectPermissionLevel.WRITE),
        ProjectType.ENGINE, Collections.emptySet(),
        ProjectType.MODELER, Collections.emptySet(),
        ProjectType.CATALOG, Collections.emptySet())
    );

    PERMISSIONS.put(ProjectOperation.JOIN_PROJECT,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.READ, ProjectPermissionLevel.COMMENT,
          ProjectPermissionLevel.WRITE, ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Collections.emptySet(),
        ProjectType.MODELER, Collections.emptySet(),
        ProjectType.CATALOG, Collections.emptySet())
    );

    PERMISSIONS.put(ProjectOperation.VIEW_COLLABORATORS,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.COMMENT, ProjectPermissionLevel.WRITE,
          ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Collections.emptySet(),
        ProjectType.MODELER, Collections.emptySet(),
        ProjectType.CATALOG, Collections.emptySet())
    );

    PERMISSIONS.put(ProjectOperation.INVITE_COLLABORATOR,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Collections.emptySet(),
        ProjectType.MODELER, Collections.emptySet(),
        ProjectType.CATALOG, Collections.emptySet())
    );

    PERMISSIONS.put(ProjectOperation.MODIFY_FOLDER,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.WRITE, ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Collections.emptySet(),
        ProjectType.MODELER, Collections.emptySet(),
        ProjectType.CATALOG, Collections.emptySet())
    );

    PERMISSIONS.put(ProjectOperation.DELETE_FOLDER,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.WRITE, ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Collections.emptySet(),
        ProjectType.MODELER, Collections.emptySet(),
        ProjectType.CATALOG, Collections.emptySet())
    );

    PERMISSIONS.put(ProjectOperation.VIEW_FILE,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.READ, ProjectPermissionLevel.COMMENT,
          ProjectPermissionLevel.WRITE, ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Set.of(ProjectPermissionLevel.READ, ProjectPermissionLevel.OWNER),
        ProjectType.MODELER, Set.of(ProjectPermissionLevel.READ, ProjectPermissionLevel.OWNER),
        ProjectType.CATALOG, Set.of(ProjectPermissionLevel.READ, ProjectPermissionLevel.OWNER))
    );

    PERMISSIONS.put(ProjectOperation.SHARE_FILE,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.WRITE, ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Set.of(ProjectPermissionLevel.READ, ProjectPermissionLevel.OWNER),
        ProjectType.MODELER, Set.of(ProjectPermissionLevel.READ, ProjectPermissionLevel.OWNER),
        ProjectType.CATALOG, Collections.emptySet()
      )
    );

    PERMISSIONS.put(ProjectOperation.MODIFY_FILE,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.WRITE, ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Collections.emptySet(),
        ProjectType.MODELER, Collections.emptySet(),
        ProjectType.CATALOG, Set.of(ProjectPermissionLevel.OWNER)
      )
    );

    PERMISSIONS.put(ProjectOperation.DELETE_FILE,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.WRITE, ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Set.of(ProjectPermissionLevel.OWNER),
        ProjectType.MODELER, Set.of(ProjectPermissionLevel.OWNER),
        ProjectType.CATALOG, Set.of(ProjectPermissionLevel.OWNER))
    );

    PERMISSIONS.put(ProjectOperation.VIEW_MILESTONE,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.WRITE, ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Set.of(ProjectPermissionLevel.READ, ProjectPermissionLevel.OWNER),
        ProjectType.MODELER, Set.of(ProjectPermissionLevel.READ, ProjectPermissionLevel.OWNER),
        ProjectType.CATALOG, Set.of(ProjectPermissionLevel.READ, ProjectPermissionLevel.OWNER)
      )
    );

    PERMISSIONS.put(ProjectOperation.MODIFY_MILESTONE,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.WRITE, ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Collections.emptySet(),
        ProjectType.MODELER, Collections.emptySet(),
        ProjectType.CATALOG, Set.of(ProjectPermissionLevel.OWNER)
      )
    );

    PERMISSIONS.put(ProjectOperation.DELETE_MILESTONE,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.WRITE, ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Set.of(ProjectPermissionLevel.OWNER),
        ProjectType.MODELER, Set.of(ProjectPermissionLevel.OWNER),
        ProjectType.CATALOG, Set.of(ProjectPermissionLevel.OWNER)
      )
    );

    PERMISSIONS.put(ProjectOperation.COMMENT_AND_MENTION,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.COMMENT, ProjectPermissionLevel.WRITE,
          ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Collections.emptySet(),
        ProjectType.MODELER, Collections.emptySet(),
        ProjectType.CATALOG, Collections.emptySet()
      )
    );

    PERMISSIONS.put(ProjectOperation.MODIFY_PERMISSIONS,
      Map.of(
        ProjectType.DEFAULT, Set.of(ProjectPermissionLevel.OWNER),
        ProjectType.ENGINE, Collections.emptySet(),
        ProjectType.MODELER, Collections.emptySet(),
        ProjectType.CATALOG, Collections.emptySet()
      )
    );
  }

  public static boolean isAllowed(ProjectType projectType,
                                  ProjectPermissionLevel projectPermissionLevel,
                                  ProjectOperation operation) {
    var permissionsForOperation = PERMISSIONS.get(operation);
    return permissionsForOperation.containsKey(projectType) &&
      permissionsForOperation.get(projectType).contains(projectPermissionLevel);
  }

  public static Map<ProjectOperation, Map<ProjectType, Set<ProjectPermissionLevel>>> getPermissions() {
    return Collections.unmodifiableMap(PERMISSIONS);
  }
}
