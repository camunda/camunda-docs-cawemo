/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util;

import java.nio.charset.StandardCharsets;
import lombok.experimental.UtilityClass;

@UtilityClass
public class Constants {

  /**
   * Number of characters; must not be > {@link #PASSWORD_BYTES_MAX_LENGTH} (one byte per alphanumeric character).
   */
  public static final int API_KEY_LENGTH = 72;

  /**
   * Maximum allowed length of an email address according to https://tools.ietf.org/html/rfc3696#section-3.
   */
  public static final int EMAIL_MAX_LENGTH = 320;

  public static final int VARCHAR_MAX = 255;
  public static final int BATCH_INVITE_LIMIT = 20;
  public static final int INVITE_MESSAGE_MAX_LENGTH = 500;
  public static final int PASSWORD_BYTES_MAX_LENGTH = 72; // BCrypt only uses the first 72 bytes
  public static final int MAX_SEATS_PER_ORGANIZATION = 10_000;
  public static final int NON_VERIFIED_ALLOWED_PERIOD_IN_HOURS = 24; // non-verified users may use Cawemo for 24 hours
  public static final int SESSION_EXPIRATION_TIME_IN_DAYS = 30;
  public static final int FILE_DOWNLOAD_LIMIT = 100;
  public static final int FOLDER_DOWNLOAD_LIMIT = 20;

  /**
   * Validation uses a more practical implementation of RFC 5322 (https://tools.ietf.org/html/rfc5322#section-3.4) with
   * omitted IP addresses, domain-specific addresses, the syntax using double quotes and square brackets. Includes
   * checking TLD (top-level-domain) ending.
   * Source: https://www.regular-expressions.info/email.html
   */
  public static final String CONTAINS_EMAIL_PATTERN = """
    ([a-zA-Z0-9!#$%&'*+/=?^_‘{|}~-]+(\\.[a-zA-Z0-9!#$%&'*+/=?^_‘{|}~-]+)*\
    @\
    ([a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?\\.)+\
    [a-zA-Z]([a-zA-Z0-9-]*[a-zA-Z0-9])?)""";

  public static final String EMAIL_PATTERN = "^" + CONTAINS_EMAIL_PATTERN + "$";

  public static final String URL_PATTERN = """
    ([a-zA-Z0-9.+-]+://|www\\.)\
    ([-a-zA-Z0-9+$&@#/%?=~_|!:,;'*()]{0,63}\\.)+\
    ([a-zA-Z0-9-:]{1,63})+\
    |\
    ([-a-zA-Z0-9+$&@#/%?=~_|!:,;'*()]{1,63}\\.)+\
    ([a-zA-Z0-9-:]{1,63})/""";

  public static final String DOES_NOT_CONTAIN_URL_PATTERN = "^((?!(" + URL_PATTERN + ")).)*$";

  public static final String DUMMY_USER_ID = "99999999-9999-9999-9999-999999999999";

  public static final String CHARSET_UTF_8 = StandardCharsets.UTF_8.toString();

  public static final int ENTITY_HASHCODE = 31;

  public static final String CORRELATION_ID_HEADER_NAME = "X-Correlation-Id";
  public static final String CORRELATION_ID_LOGGING_KEY = "correlationId";
}
