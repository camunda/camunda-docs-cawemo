/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.user;

import com.cawemo.util.api.ServerException;

public class UsernameGenerationFailedException extends ServerException {

  UsernameGenerationFailedException(String name) {
    super("Failed to generate a unique username for name: " + name);
  }
}
