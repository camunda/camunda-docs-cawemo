/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util.api;

public class BadRequestException extends ClientException {

  public BadRequestException(ApiError apiError) {
    super(apiError);
  }

  public BadRequestException(ApiError apiError, String message) {
    super(apiError, message);
  }
}
