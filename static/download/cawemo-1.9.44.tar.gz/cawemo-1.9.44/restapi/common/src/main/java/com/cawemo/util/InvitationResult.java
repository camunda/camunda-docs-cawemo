/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util;

import com.cawemo.data.entity.Token;
import com.cawemo.service.user.InviteeStatus;
import com.cawemo.util.api.ApiError;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class InvitationResult {

  private final String email;
  private final Token token;
  private final InviteeStatus status;
  private final ApiError error;

  public InvitationResult(String email, InviteeStatus status) {
    this(email, null, status, null);
  }

  public InvitationResult(String email, Token token, InviteeStatus status) {
    this(email, token, status, null);
  }

  public InvitationResult(String email, ApiError error) {
    this(email, null, null, error);
  }
}
