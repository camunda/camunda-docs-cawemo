/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.validation;

import com.cawemo.data.validation.constraint.EnumStringValue;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.Arrays;

public class EnumStringValueValidator implements ConstraintValidator<EnumStringValue, Enum<?>> {

  private String[] noneOf;

  @Override
  public void initialize(EnumStringValue enumStringValue) {
    noneOf = enumStringValue.noneOf();
  }

  @Override
  public boolean isValid(Enum<?> value, ConstraintValidatorContext context) {
    return value != null && Arrays
      .stream(noneOf)
      .noneMatch(forbiddenValues -> forbiddenValues.equals(value.toString()));
  }
}
