/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.authentication;

import com.cawemo.util.api.ServerException;

public class NoAuthenticatedApiKeyException extends ServerException {

  NoAuthenticatedApiKeyException() {
    super("Cannot get authenticated apiKey as principal is null or not an instance of ApiKeyAwareUserDetails");
  }
}
