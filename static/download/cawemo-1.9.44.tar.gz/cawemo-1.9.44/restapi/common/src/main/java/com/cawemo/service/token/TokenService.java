/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.token;

import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.Token;
import com.cawemo.data.repository.TokenRepository;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class TokenService {

  private final TokenRepository tokenRepository;

  public Token createToken(TokenType type) {
    var token = new Token().setType(type);
    return tokenRepository.save(token);
  }

  public void deleteToken(Token token) {
    tokenRepository.delete(token);
  }

  public void deleteTokens(List<Token> tokens) {
    tokenRepository.deleteAll(tokens);
  }

  public int deleteByProjectInvitationProjectAndInvitedEmail(Project project, String email) {
    return tokenRepository.deleteByProjectInvitationProjectAndEmail(project, email);
  }
}
