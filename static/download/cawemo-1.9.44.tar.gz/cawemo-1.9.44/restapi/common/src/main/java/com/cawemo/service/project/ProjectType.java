/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum ProjectType {

  DEFAULT(false, false),
  ENGINE(true, true),
  MODELER(true, true),
  CATALOG(true, false);

  private final boolean isOrganizationPublic;
  private final boolean isPluginType;
}
