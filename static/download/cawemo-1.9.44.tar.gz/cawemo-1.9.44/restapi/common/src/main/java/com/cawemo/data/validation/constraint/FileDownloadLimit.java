/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.validation.constraint;

import com.cawemo.util.Constants;
import com.cawemo.util.api.ApiError;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import jakarta.validation.ReportAsSingleViolation;
import jakarta.validation.constraints.Size;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {})
@Size(max = Constants.FILE_DOWNLOAD_LIMIT)
@ReportAsSingleViolation
@CustomApiErrorResponse(reason = ApiError.DOWNLOAD_LIMIT_EXCEEDED, useMessageAsDetail = true)
public @interface FileDownloadLimit {

  String DOWNLOAD_LIMIT_EXCEEDED_MESSAGE = "Download limit exceeded. You can select a maximum of "
    + Constants.FILE_DOWNLOAD_LIMIT + " files and " + Constants.FOLDER_DOWNLOAD_LIMIT + " folders.";

  String message() default DOWNLOAD_LIMIT_EXCEEDED_MESSAGE;

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}
