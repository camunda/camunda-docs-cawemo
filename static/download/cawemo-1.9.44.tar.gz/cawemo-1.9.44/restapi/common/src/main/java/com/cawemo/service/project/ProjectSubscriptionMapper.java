/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.dto.base.response.ProjectSubscriptionDto;
import com.cawemo.data.entity.view.ProjectSubscriptionView;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ProjectSubscriptionMapper {

  @Mapping(source = "projectPermission.id.project.id", target = "id")
  @Mapping(source = "projectPermission.id.project.name", target = "name")
  @Mapping(source = "projectPermission.id.project.organization.id", target = "organizationId")
  @Mapping(source = "view.active", target = "subscribed")
  ProjectSubscriptionDto asSubscriptionDto(ProjectSubscriptionView view);

  List<ProjectSubscriptionDto> asSubscriptionDtoList(List<ProjectSubscriptionView> subscriptions);
}
