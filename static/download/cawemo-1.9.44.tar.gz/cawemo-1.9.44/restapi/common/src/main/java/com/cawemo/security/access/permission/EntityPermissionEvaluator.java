/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.access.permission;

import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.util.Permission;

@FunctionalInterface
public interface EntityPermissionEvaluator<T, P extends Permission> {

  boolean hasPermission(UserAwareUserDetails userDetails, T targetDomainObject, P permission);
}
