/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util.api;

public class UnauthorizedException extends ClientException {

  public UnauthorizedException(ApiError apiError) {
    super(apiError);
  }

  protected UnauthorizedException(ApiError apiError, String message) {
    super(apiError, message);
  }
}
