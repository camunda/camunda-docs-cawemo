/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.organization;

import com.cawemo.data.dto.base.request.OrganizationUpdateDto;
import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.User;
import com.cawemo.data.entity.view.OrganizationAdminView;
import com.cawemo.data.repository.OrganizationRepository;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class OrganizationService {

  private final OrganizationPermissionService permissionService;
  private final OrganizationMapper organizationMapper;
  private final OrganizationRepository organizationRepository;

  public Organization createOrganization(String name) {
    return createOrganization(name, null);
  }

  @Transactional
  public Organization createInitialOrganization(User user) {
    var name = getInitialOrganizationName(user.getName());
    var organization = createOrganization(name, user);
    permissionService.createOwnerOrganizationPermission(organization, user);
    return organization;
  }

  public Organization updateOrganization(Organization organization, OrganizationUpdateDto dto) {
    return organizationRepository.save(organizationMapper.updateFromDto(organization, dto));
  }

  public String getInitialOrganizationName(String userName) {
    return userName + "'s Organization";
  }

  public List<OrganizationDetails> findOrganizationDetailsByUser(User user) {
    return organizationRepository.findOrganizationsWithAdminByUser(user)
      .stream()
      .collect(Collectors.groupingBy(OrganizationAdminView::getOrganization,
        Collectors.mapping(OrganizationAdminView::getAdmin, Collectors.toList())))
      .entrySet()
      .stream()
      .map(entry -> new OrganizationDetails(entry.getKey(), entry.getValue()))
      .collect(Collectors.toList());
  }

  private Organization createOrganization(String name, User createdBy) {
    var organization = new Organization()
      .setName(name)
      .setCreatedBy(createdBy)
      .setUpdatedBy(createdBy);
    return organizationRepository.save(organization);
  }
}
