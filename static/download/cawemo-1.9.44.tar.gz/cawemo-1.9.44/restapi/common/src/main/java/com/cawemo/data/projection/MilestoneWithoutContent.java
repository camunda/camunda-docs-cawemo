/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.projection;

import com.cawemo.data.entity.File;
import com.cawemo.data.entity.User;
import java.time.ZonedDateTime;
import lombok.Value;

@Value
public class MilestoneWithoutContent {

  String id;
  File file;
  String name;
  User createdBy;
  ZonedDateTime created;
  User updatedBy;
  ZonedDateTime updated;
}
