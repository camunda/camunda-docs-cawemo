/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.user;

import com.cawemo.data.dto.base.request.UserUpdateDto;
import com.cawemo.data.entity.User;
import com.cawemo.data.repository.UserRepository;
import com.cawemo.util.api.NoSuchObjectException;
import java.text.Normalizer;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {

  private static final int USERNAME_MAX_RANDOM_NUMBER = 1000000;

  private final UserMapper userMapper;
  private final UserRepository userRepository;

  public Optional<User> findUserByEmailAddress(String email) {
    return userRepository.findByEmailIgnoreCase(email);
  }

  public String generateUsername(String name) {
    var normalizedName = Normalizer
      .normalize(name, Normalizer.Form.NFD)
      // keep this in sync with MailService.MENTION_COLLABORATOR_PATTERN
      .replaceAll("[^0-9a-zA-Z._-]", "");

    var username = normalizedName;

    for (int i = 0; i < 100; i++) {
      if (userRepository.existsByUsernameIgnoreCase(username)) {
        username = normalizedName + (ThreadLocalRandom.current().nextInt(USERNAME_MAX_RANDOM_NUMBER) + 1);
      } else {
        return username;
      }
    }

    throw new UsernameGenerationFailedException(name);
  }

  public void updateUser(String iamId, UserUpdateDto dto) {
    var user = userRepository
      .findByIamId(iamId)
      .orElseThrow(NoSuchObjectException::new);

    userRepository.save(userMapper.updateFromDto(user, dto));
  }
}
