/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.util.Permission;

public enum ProjectOperation implements Permission {

  VIEW_PROJECT,
  MODIFY_PROJECT,
  DELETE_PROJECT,
  LEAVE_PROJECT,
  JOIN_PROJECT,

  VIEW_COLLABORATORS,
  INVITE_COLLABORATOR,

  MODIFY_FOLDER,
  DELETE_FOLDER,

  DELETE_FILE,
  VIEW_FILE,
  MODIFY_FILE,
  SHARE_FILE,

  VIEW_MILESTONE,
  MODIFY_MILESTONE,
  DELETE_MILESTONE,

  COMMENT_AND_MENTION,

  MODIFY_PERMISSIONS
}
