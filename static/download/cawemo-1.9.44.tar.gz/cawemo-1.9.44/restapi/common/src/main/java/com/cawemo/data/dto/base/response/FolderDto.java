/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.response;

import java.util.List;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class FolderDto {

  private String id;

  private String name;

  private String slug;

  private String projectId;

  private String parentId;

  private UserDto createdBy;

  private List<FolderChildDto> children;

  private List<FileWithoutContentDto> files;
}
