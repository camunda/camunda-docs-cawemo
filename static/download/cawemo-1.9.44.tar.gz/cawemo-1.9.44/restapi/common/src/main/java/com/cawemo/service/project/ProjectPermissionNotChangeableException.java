/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.entity.Project;
import com.cawemo.util.api.ApiError;
import com.cawemo.util.api.ForbiddenException;

public class ProjectPermissionNotChangeableException extends ForbiddenException {

  ProjectPermissionNotChangeableException(Project project) {
    super(ApiError.INVALID_OPERATION, "Permission for project " + project.getId() + " cannot be changed");
  }
}
