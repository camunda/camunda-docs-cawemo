/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.entity.ProjectPermissionId;
import com.cawemo.data.entity.event.PostPersistProjectPermissionEvent;
import com.cawemo.data.entity.event.PostRemoveProjectPermissionEvent;
import com.cawemo.data.entity.event.PostUpdateProjectPermissionEvent;
import com.cawemo.data.repository.ProjectPermissionRepository;
import com.cawemo.service.authentication.AuthenticationService;
import com.cawemo.service.pusher.PusherIntent;
import com.cawemo.service.pusher.PusherService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

@Component
@RequiredArgsConstructor
public class ProjectPermissionEventListener {

  private final PusherService pusherService;
  private final ProjectPermissionRepository projectPermissionRepository;

  @TransactionalEventListener
  public void postRemoveProjectPermission(PostRemoveProjectPermissionEvent event) {
    var permissionId = event.getSource().getId();
    pusherService.
      removePermissionNotification(permissionId.getUser(), List.of(permissionId.getProject()), getIntent(permissionId));
  }

  @TransactionalEventListener
  public void postUpdateProjectPermission(PostUpdateProjectPermissionEvent event) {
    var permissionId = event.getSource().getId();
    pusherService.editPermissionNotification(permissionId.getUser(), permissionId.getProject());
  }

  @TransactionalEventListener
  public void postPersistProjectPermission(PostPersistProjectPermissionEvent event) {
    if (shouldCreateAddPermissionNotification(event)) {
      var permissionId = event.getSource().getId();
      pusherService.addPermissionNotification(permissionId.getUser(), permissionId.getProject());
    }
  }

  private PusherIntent getIntent(ProjectPermissionId permissionId) {
    var isAuthenticatedUser = AuthenticationService.getOptionalAuthenticatedUser()
      .map(user -> user.equals(permissionId.getUser()))
      .orElse(false);
    return isAuthenticatedUser ? PusherIntent.LEAVE : PusherIntent.REMOVE;
  }

  private boolean shouldCreateAddPermissionNotification(PostPersistProjectPermissionEvent event) {
    var id = event.getSource().getId();
    return event.getSource().getAccess() != ProjectPermissionLevel.OWNER ||
      // create Pusher notification only for additional OWNER permissions (not when project is initially created)
      projectPermissionRepository
        .existsByIdProjectAndAccessAndIdUserNot(id.getProject(), ProjectPermissionLevel.OWNER, id.getUser());
  }
}
