/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.authentication;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.web.authentication.RememberMeServices;
import org.springframework.security.web.authentication.rememberme.RememberMeAuthenticationFilter;
import org.springframework.security.web.util.matcher.RequestMatcher;

public class PathAwareRememberMeAuthenticationFilter extends RememberMeAuthenticationFilter {

  private final RequestMatcher matcher;

  public PathAwareRememberMeAuthenticationFilter(RequestMatcher requestMatcher,
                                                 AuthenticationManager authenticationManager,
                                                 RememberMeServices rememberMeServices) {
    super(authenticationManager, rememberMeServices);
    this.matcher = requestMatcher;
  }

  /**
   * Applies {@link RememberMeAuthenticationFilter#doFilter(ServletRequest, ServletResponse, FilterChain)} when the
   * given path matches, otherwise proceeds with the given chain.
   */
  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException {
    if (matcher.matches((HttpServletRequest) request)) {
      super.doFilter(request, response, chain);
    } else {
      chain.doFilter(request, response);
    }
  }
}
