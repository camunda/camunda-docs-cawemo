/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.dto.base.request.ProjectInvitationDto;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.ProjectInvitation;
import com.cawemo.data.entity.User;
import com.cawemo.data.repository.ProjectInvitationRepository;
import com.cawemo.service.token.TokenService;
import com.cawemo.service.token.TokenType;
import com.cawemo.service.user.InviteeStatus;
import com.cawemo.util.InvitationResult;
import com.cawemo.util.SetUtil;
import com.cawemo.util.api.ApiError;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.transaction.support.TransactionTemplate;

@RequiredArgsConstructor
public abstract class AbstractProjectInvitationHandler implements ProjectInvitationHandler {

  private final ProjectPermissionService projectPermissionService;
  private final TokenService tokenService;
  private final TransactionTemplate transactionTemplate;
  private final ProjectInvitationRepository projectInvitationRepository;

  @Override
  public List<InvitationResult> inviteCollaborators(User inviter, Project project, ProjectInvitationDto dto) {
    var emails = SetUtil.toLowerCaseIgnoringDuplicates(dto.getEmails());
    var alreadyInvited = getAlreadySentInvitationEmails(project, emails);
    return emails
      .stream()
      .map(email ->
        alreadyInvited.contains(email) ?
          new InvitationResult(email, ApiError.ALREADY_INVITED) :
          handleInvitation(inviter, email, project, dto))
      .collect(Collectors.toList());
  }

  abstract void sendProjectInvitationMail(User inviter, ProjectInvitation invitation, Project project);

  protected InvitationResult handleInvitation(User inviter, String email, Project project, ProjectInvitationDto dto) {
    if (projectPermissionService.projectPermissionExists(project, email)) {
      return new InvitationResult(email, ApiError.ALREADY_COLLABORATING);
    }
    var invitation = createProjectInvitation(email, project, dto);
    sendProjectInvitationMail(inviter, invitation, project);
    return new InvitationResult(email, invitation.getToken(), InviteeStatus.SENT);
  }

  private Set<String> getAlreadySentInvitationEmails(Project project, Set<String> emails) {
    return projectInvitationRepository.findByProjectAndInvitedEmailIgnoreCaseIn(project, emails)
      .stream()
      .map(ProjectInvitation::getInvitedEmail)
      .map(email -> email.toLowerCase(Locale.US))
      .collect(Collectors.toSet());
  }

  private ProjectInvitation createProjectInvitation(String email, Project project, ProjectInvitationDto dto) {
    return transactionTemplate.execute(status -> {
      var token = tokenService.createToken(TokenType.PROJECT_INVITE);
      var invitation = new ProjectInvitation()
        .setProject(project)
        .setInvitedEmail(email)
        .setToken(token)
        .setCustomMessage(dto.getText())
        .setAccess(dto.getProjectAccess());
      return projectInvitationRepository.save(invitation);
    });
  }
}
