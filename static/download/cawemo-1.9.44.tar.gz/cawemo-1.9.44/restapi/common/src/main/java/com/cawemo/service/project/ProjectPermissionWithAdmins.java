/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.project;

import com.cawemo.data.entity.ProjectPermission;
import com.cawemo.data.entity.User;
import java.util.List;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class ProjectPermissionWithAdmins {

  private final ProjectPermission permission;
  private final List<User> admins;
}
