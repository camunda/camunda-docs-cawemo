/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.preference;

import com.cawemo.data.entity.Preference;
import com.cawemo.data.entity.User;
import com.cawemo.data.repository.PreferenceRepository;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PreferenceServiceImpl implements PreferenceService {

  protected final PreferenceRepository preferenceRepository;
  protected final PreferenceMapper preferenceMapper;
  private final PreferenceProperties preferenceProperties;

  @Override
  public Map<PreferenceKey, Boolean> getUserPreferences(User user) {
    var preferences = new EnumMap<>(preferenceProperties.defaultValues());
    preferences.putAll(getDatabaseUserPreferences(user));
    return preferences;
  }

  @Override
  public void updateUserPreferences(User user, Map<PreferenceKey, Boolean> preferences) {
    if (!preferences.isEmpty()) {
      preferenceRepository.saveAll(asPreferenceList(preferences, user));
    }
  }

  public Map<PreferenceKey, Boolean> getDatabaseUserPreferences(User user) {
    return preferenceRepository.findByIdUser(user)
      .stream()
      .collect(Collectors.toUnmodifiableMap(p -> p.getId().getKey(), Preference::isValue));
  }

  private List<Preference> asPreferenceList(Map<PreferenceKey, Boolean> preferences, User user) {
    return preferences.entrySet()
      .stream()
      .map(entry -> preferenceMapper.asPreference(user, entry.getKey(), entry.getValue()))
      .collect(Collectors.toList());
  }
}
