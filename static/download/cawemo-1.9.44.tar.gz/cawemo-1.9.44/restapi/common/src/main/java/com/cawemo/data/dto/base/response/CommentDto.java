/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.response;

import java.time.ZonedDateTime;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class CommentDto {

  private String id;
  private String fileId;
  private String content;
  private ZonedDateTime created;
  private ZonedDateTime lastChanged;
  private String reference;
  private CommentAuthorDto author;

  @Data
  @Accessors(chain = true)
  public static class CommentAuthorDto {

    private String id;
    private String name;
  }
}
