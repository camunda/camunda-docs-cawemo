/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.util;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import lombok.experimental.UtilityClass;
import org.camunda.bpm.model.bpmn.BpmnModelInstance;
import org.camunda.bpm.model.bpmn.impl.BpmnParser;
import org.camunda.bpm.model.bpmn.instance.Process;

@UtilityClass
public class BpmnUtil {

  private static final BpmnParser BPMN_PARSER = new BpmnParser();
  private static final String CAMUNDA_BPMN_EXTENSIONS_NS = "http://camunda.org/schema/1.0/bpmn";
  private static final String CAMUNDA_XML_RELATION_ID_ATTR = "diagramRelationId";

  public static BpmnModelInstance getBpmnModelInstance(String bpmn) {
    return BPMN_PARSER.parseModelFromStream(new ByteArrayInputStream(bpmn.getBytes(StandardCharsets.UTF_8)));
  }

  public static Optional<Process> getFirstExecutableProcess(BpmnModelInstance modelInstance) {
    return modelInstance
      .getModelElementsByType(Process.class)
      .stream()
      .filter(Process::isExecutable)
      .findFirst();
  }

  public static Optional<String> getRelationId(BpmnModelInstance modelInstance) {
    var relationId = modelInstance.getDefinitions()
      .getAttributeValueNs(CAMUNDA_BPMN_EXTENSIONS_NS, CAMUNDA_XML_RELATION_ID_ATTR);
    return Optional.ofNullable(relationId);
  }
}
