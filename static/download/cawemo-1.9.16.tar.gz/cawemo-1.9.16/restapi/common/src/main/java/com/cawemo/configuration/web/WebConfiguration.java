/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.configuration.web;

import com.cawemo.configuration.executor.ExecutorConfiguration;
import com.cawemo.controller.ResponseStatusCodeInterceptor;
import com.cawemo.controller.converter.BatchIdCollectionToEntityCollectionConverter;
import java.util.Collection;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.format.FormatterRegistry;
import org.springframework.web.servlet.config.annotation.AsyncSupportConfigurer;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfiguration implements WebMvcConfigurer {

  private final BatchIdCollectionToEntityCollectionConverter batchIdCollectionToEntityCollectionConverter;
  private final ResponseStatusCodeInterceptor responseStatusCodeInterceptor;
  private final AsyncTaskExecutor taskExecutor;

  public WebConfiguration(
    BatchIdCollectionToEntityCollectionConverter batchIdCollectionToEntityCollectionConverter,
    ResponseStatusCodeInterceptor responseStatusCodeInterceptor,
    @Qualifier(ExecutorConfiguration.FILE_DOWNLOAD_EXECUTOR) AsyncTaskExecutor taskExecutor) {
    this.batchIdCollectionToEntityCollectionConverter = batchIdCollectionToEntityCollectionConverter;
    this.responseStatusCodeInterceptor = responseStatusCodeInterceptor;
    this.taskExecutor = taskExecutor;
  }

  /**
   * Remove Spring's CollectionToCollectionConverter in favour of our own
   * {@link BatchIdCollectionToEntityCollectionConverter}.
   */
  @Override
  public void addFormatters(FormatterRegistry registry) {
    registry.removeConvertible(Collection.class, Collection.class);
    registry.addConverter(batchIdCollectionToEntityCollectionConverter);
  }

  @Override
  public void addInterceptors(InterceptorRegistry registry) {
    registry.addInterceptor(responseStatusCodeInterceptor);
  }

  @Override
  public void configureAsyncSupport(AsyncSupportConfigurer configurer) {
    configurer.setTaskExecutor(taskExecutor);
  }
}
