/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.validation;

import com.cawemo.data.dto.base.request.FileCreateDto;
import com.cawemo.data.validation.constraint.ValidFileCreateData;
import com.cawemo.service.file.FileType;
import java.util.Map;
import java.util.function.Function;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;

public class ValidFileCreateDataValidator implements ConstraintValidator<ValidFileCreateData, FileCreateDto> {

  private final Map<FileType, Function<FileCreateDto, Boolean>> validatorsByType = Map.of(
    FileType.BPMN, this::validateTypeBpmn,
    FileType.DMN, dto -> true, // currently no extra validation for DMN
    FileType.TEMPLATE_GENERIC, this::validateTypeTemplate,
    FileType.TEMPLATE_SERVICE_TASK, this::validateTypeTemplate
  );

  @Override
  public boolean isValid(FileCreateDto dto, ConstraintValidatorContext context) {
    var type = dto.getType();
    return type != null && validatorsByType.getOrDefault(type, d -> false).apply(dto);
  }

  private boolean validateTypeBpmn(FileCreateDto dto) {
    return !StringUtils.isBlank(dto.getProcessId());
    // TODO #6541 BPMN validation temporarily disabled
    // return ValidBpmnValidator.isValid(dto.getContent());
  }

  private boolean validateTypeTemplate(FileCreateDto dto) {
    return ValidJsonTemplateValidator.isValid(dto.getContent());
  }
}
