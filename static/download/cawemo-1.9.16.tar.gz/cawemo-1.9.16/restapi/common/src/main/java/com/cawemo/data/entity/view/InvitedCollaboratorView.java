/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity.view;

import com.cawemo.data.entity.Token;
import com.cawemo.service.project.ProjectPermissionLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class InvitedCollaboratorView {

  private final String id;
  private final String name;
  private final String email;
  private final Token token;
  private final ProjectPermissionLevel permissionAccess;

  public InvitedCollaboratorView(String id, String name, String email) {
    this(id, name, email, null, null);
  }
}
