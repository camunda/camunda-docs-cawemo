/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.authentication;

import com.cawemo.data.dto.base.request.UserLoginDto;
import com.cawemo.service.user.AbstractLoginUserHandler;
import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

public class PreAuthenticatedLoginFilter extends AbstractPreAuthenticatedProcessingFilter {

  private static final String DUMMY_CREDENTIALS = "N/A";
  private final RequestMatcher requestMatcher;

  // setter injection as constructor injection was not possible in a nice way
  // (due to circular dependencies with WebSecurityConfiguration)

  @Setter(onMethod_ = {@Autowired})
  private LoginRequestDeserializer loginRequestDeserializer;

  @Setter(onMethod_ = {@Autowired})
  private AbstractLoginUserHandler loginUserHandler;

  @Setter(onMethod_ = {@Autowired})
  private UserAwareUserDetailsSource userDetailsSource;

  @Setter(onMethod_ = {@Autowired})
  private Validator validator;

  public PreAuthenticatedLoginFilter(String loginUrl) {
    this.requestMatcher = new AntPathRequestMatcher(loginUrl);
  }

  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException {
    // execute filter logic for login endpoint only
    if (requestMatcher.matches((HttpServletRequest) request)) {
      super.doFilter(request, response, chain);
    } else {
      chain.doFilter(request, response);
    }
  }

  @Override
  protected Object getPreAuthenticatedPrincipal(HttpServletRequest request) {
    var dto = loginRequestDeserializer.deserializeBody(request);
    ensureValidInput(dto);
    var user = loginUserHandler.createOrUpdateUser(dto);

    return userDetailsSource.buildDetails(user);
  }

  /**
   * Returns a dummy value as Cawemo does not know about the user's password which is stored in IAM only.
   *
   * @return {@value #DUMMY_CREDENTIALS}
   */
  @Override
  protected Object getPreAuthenticatedCredentials(HttpServletRequest request) {
    return DUMMY_CREDENTIALS;
  }

  private void ensureValidInput(UserLoginDto dto) {
    var result = validator.validate(dto);
    if (!result.isEmpty()) {
      throw new ConstraintViolationException(result);
    }
  }
}
