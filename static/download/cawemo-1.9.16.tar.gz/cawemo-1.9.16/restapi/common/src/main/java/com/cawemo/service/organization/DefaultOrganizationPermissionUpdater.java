/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.organization;

import com.cawemo.data.entity.OrganizationPermission;
import com.cawemo.data.entity.User;
import com.cawemo.data.repository.OrganizationPermissionRepository;
import com.cawemo.service.project.ProjectPermissionService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class DefaultOrganizationPermissionUpdater implements OrganizationPermissionUpdater {

  private final OrganizationPermissionRepository organizationPermissionRepository;
  private final ProjectPermissionService projectPermissionService;

  @Override
  @Transactional
  public void updatePermissionAccess(OrganizationPermission permission, OrganizationPermissionLevel newAccess,
                                     User authenticatedUser) {
    ensurePermissionIsUpdatable(permission);
    transferEngineProjectsIfAdminIsDowngraded(permission, authenticatedUser);
    organizationPermissionRepository.save(permission.setAccess(newAccess));
  }

  private void ensurePermissionIsUpdatable(OrganizationPermission permission) {
    if (permission.getAccess() == OrganizationPermissionLevel.ADMIN && !otherOrganizationAdminExists(permission)) {
      throw new OrganizationPermissionNotChangeableException(permission.getId().getOrganization());
    }
  }

  private boolean otherOrganizationAdminExists(OrganizationPermission permission) {
    var id = permission.getId();
    return organizationPermissionRepository.existsByIdOrganizationAndIdUserNotAndAccess(
      id.getOrganization(), id.getUser(), OrganizationPermissionLevel.ADMIN);
  }

  private void transferEngineProjectsIfAdminIsDowngraded(OrganizationPermission permission, User authenticatedUser) {
    if (permission.getAccess() == OrganizationPermissionLevel.ADMIN) {
      projectPermissionService.transferProjectAdminPermissionsForEngineProjectsToOtherOrganizationAdmin(
        authenticatedUser, permission.getId().getUser(), permission.getId().getOrganization());
    }
  }
}
