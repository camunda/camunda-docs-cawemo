/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.data.dto.base.request.FileShareCreateDto;
import com.cawemo.data.entity.FileShare;
import com.cawemo.data.repository.FileShareRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class FileShareService {

  private final FileService fileService;
  private final FileShareRepository fileShareRepository;
  private final PasswordEncoder passwordEncoder;

  public FileShare createShare(FileShareCreateDto dto) {
    var file = fileService.getFile(dto.getFileId());
    if (file.getShare() != null) {
      return file.getShare();
    }

    var share = new FileShare().setFile(file);
    file.setShare(share);
    return fileShareRepository.save(share);
  }

  public void createPassword(FileShare fileShare, String password) {
    fileShare.setPassword(passwordEncoder.encode(password));
    fileShareRepository.save(fileShare);
  }

  public void deletePassword(FileShare fileShare) {
    fileShareRepository.save(fileShare.setPassword(null));
  }

  public void delete(FileShare fileShare) {
    fileShare.getFile().setShare(null);
    fileShareRepository.delete(fileShare);
  }

  public void checkPassword(FileShare fileShare, String password) {
    if (!passwordEncoder.matches(password, fileShare.getPassword())) {
      throw new InvalidFileSharePasswordException();
    }
  }

  public void ensureShareUnprotected(FileShare fileShare) {
    if (fileShare.getPassword() != null) {
      throw new InvalidFileSharePasswordException();
    }
  }
}
