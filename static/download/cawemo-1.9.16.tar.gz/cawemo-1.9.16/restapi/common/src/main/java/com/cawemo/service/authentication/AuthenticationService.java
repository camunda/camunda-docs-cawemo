/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.authentication;

import com.cawemo.data.entity.ApiKey;
import com.cawemo.data.entity.Session;
import com.cawemo.data.entity.User;
import com.cawemo.data.repository.SessionRepository;
import com.cawemo.security.authentication.ApiKeyAwareUserDetails;
import com.cawemo.security.authentication.UserAwareUserDetails;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthenticationService {

  private final SessionRepository sessionRepository;

  public static User getAuthenticatedUser() {
    return getOptionalAuthenticatedUser()
      .orElseThrow(NoAuthenticatedUserException::new);
  }

  public static Optional<User> getOptionalAuthenticatedUser() {
    return Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication())
      .map(Authentication::getPrincipal)
      .filter(UserAwareUserDetails.class::isInstance)
      .map(principal -> ((UserAwareUserDetails) principal).getUser());
  }

  public static UserAwareUserDetails getUserDetails(Authentication authentication) {
    var principal = authentication.getPrincipal();
    if (principal instanceof UserAwareUserDetails) {
      return (UserAwareUserDetails) principal;
    }

    throw new NoAuthenticatedUserException();
  }

  public static ApiKey getAuthenticatedApiKey() {
    var principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    if (!(principal instanceof ApiKeyAwareUserDetails)) {
      throw new NoAuthenticatedApiKeyException();
    }

    var userDetails = (ApiKeyAwareUserDetails) principal;
    return userDetails.getApiKey();
  }

  public Session createSession(User user) {
    return sessionRepository.save(new Session().setUser(user));
  }
}
