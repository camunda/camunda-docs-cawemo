/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.access.permission;

import com.cawemo.data.entity.Project;
import com.cawemo.data.repository.FileRepository;
import com.cawemo.data.repository.FolderRepository;
import com.cawemo.data.repository.ProjectRepository;
import com.cawemo.service.file.FileTypeCategory;
import java.util.Collection;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
public class FileTypeEvaluator {

  private final FileRepository fileRepository;
  private final FolderRepository folderRepository;
  private final ProjectRepository projectRepository;

  public FileTypeEvaluator(@Lazy FileRepository fileRepository,
                           @Lazy FolderRepository folderRepository,
                           @Lazy ProjectRepository projectRepository) {
    this.fileRepository = fileRepository;
    this.folderRepository = folderRepository;
    this.projectRepository = projectRepository;
  }

  public boolean isFileTypeCategoryAllowed(String projectId, FileTypeCategory category) {
    return projectRepository.findById(projectId)
      .map(project -> isAllowed(category, project))
      .orElse(false);
  }

  public boolean isFileTypeCategoryAllowedForFolder(String folderId, FileTypeCategory category) {
    return folderRepository.findById(folderId)
      .map(folder -> isAllowed(category, folder.getProject()))
      .orElse(false);
  }

  public boolean areFileTypeCategoriesAllowed(String projectId, Collection<String> fileIds) {
    return projectRepository.findById(projectId)
      .map(project -> areFileTypeCategoriesAllowed(project, fileIds))
      .orElse(false);
  }

  private boolean areFileTypeCategoriesAllowed(Project project, Collection<String> fileIds) {
    return fileRepository.findAllById(fileIds)
      .stream()
      .map(file -> file.getType().getCategory())
      .allMatch(category -> isAllowed(category, project));
  }

  private boolean isAllowed(FileTypeCategory category, Project project) {
    return category.isAllowed(project.getType());
  }
}
