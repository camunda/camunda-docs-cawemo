/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.converter;

import com.cawemo.data.projection.FileWithoutContent;
import com.cawemo.data.repository.FileRepository;
import java.util.Collection;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Dedicated converter for {@link com.cawemo.data.projection.FileWithoutContent}, since it is not an actual JPA entity
 * class, but a projection ({@link GenericEntityIdCollectionConverter} wouldn't work in this case).
 */
@Component
@RequiredArgsConstructor
public class FileIdToFileWithoutContentCollectionConverter implements EntityIdCollectionConverter<FileWithoutContent> {

  private final FileRepository fileRepository;

  @Override
  public Class<FileWithoutContent> getEntityType() {
    return FileWithoutContent.class;
  }

  @Override
  public Collection<FileWithoutContent> convert(Collection<String> fileIds) {
    return fileRepository.findByIdIn(fileIds);
  }
}
