/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.mail.template;

import com.cawemo.service.mail.CustomServerProperties;
import com.cawemo.service.mail.ThemeProperties;
import com.cawemo.service.mail.template.view.View;
import freemarker.template.Configuration;
import freemarker.template.TemplateException;
import java.io.IOException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

@Service
@RequiredArgsConstructor
public class MailTemplateService {

  private static final String FREEMARKER_EXTENSION = ".ftl";

  private final Configuration configuration;
  private final CustomServerProperties customServerProperties;
  private final ThemeProperties themeProperties;

  public String render(View view) {
    setAdditionalProperties(view);
    try {
      var template = configuration.getTemplate(getTemplatePath(view));
      return FreeMarkerTemplateUtils.processTemplateIntoString(template, view.toModel());
    } catch (IOException | TemplateException e) {
      throw new TemplateRenderingFailedException(e);
    }
  }

  private void setAdditionalProperties(View view) {
    view.setHostUrl(customServerProperties.url());
    view.setTheme(themeProperties);
  }

  private String getTemplatePath(View view) {
    var path = view.getTemplatePath();
    return path.endsWith(FREEMARKER_EXTENSION) ? path : path + FREEMARKER_EXTENSION;
  }
}
