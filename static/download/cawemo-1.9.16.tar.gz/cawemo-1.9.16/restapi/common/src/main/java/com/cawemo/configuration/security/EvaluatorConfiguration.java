/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.configuration.security;

import com.cawemo.security.access.permission.CawemoPermissionEvaluator;
import com.cawemo.security.access.permission.EntityCollectionPermissionEvaluator;
import com.cawemo.security.access.permission.EntityPermissionEvaluator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.ResolvableType;
import org.springframework.core.convert.ConversionService;

@Configuration
public class EvaluatorConfiguration {

  private final ConversionService conversionService;
  private final Map<Class<?>, EntityPermissionEvaluator> entityEvaluatorsByClass = new HashMap<>();
  private final Map<Class<?>, EntityCollectionPermissionEvaluator> entityCollectionEvaluatorsByClass = new HashMap<>();

  public EvaluatorConfiguration(@Lazy ConversionService conversionService,
                                List<EntityPermissionEvaluator> entityEvaluators,
                                List<EntityCollectionPermissionEvaluator> entityCollectionEvaluators) {
    this.conversionService = conversionService;

    for (var evaluator : entityEvaluators) {
      var resolvableType = ResolvableType.forClass(EntityPermissionEvaluator.class, evaluator.getClass());
      var generics = resolvableType.getGenerics();
      if (generics.length < 1) {
        return;
      }

      entityEvaluatorsByClass.put(generics[0].getRawClass(), evaluator);
    }

    for (var evaluator : entityCollectionEvaluators) {
      var resolvableType = ResolvableType.forClass(EntityCollectionPermissionEvaluator.class, evaluator.getClass());
      var generics = resolvableType.getGenerics();
      if (generics.length < 1) {
        return;
      }

      entityCollectionEvaluatorsByClass.put(generics[0].getRawClass(), evaluator);
    }
  }

  @Bean
  public CawemoPermissionEvaluator cawemoPermissionEvaluator() {
    var evaluator = new CawemoPermissionEvaluator(conversionService);
    entityEvaluatorsByClass.forEach(evaluator::addEvaluator);
    entityCollectionEvaluatorsByClass.forEach(evaluator::addEvaluator);
    return evaluator;
  }
}
