/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.plugin;

import com.cawemo.data.dto.base.request.DiagramModelerPluginDto;
import com.cawemo.data.dto.base.response.FileDto;
import com.cawemo.security.authentication.ApiKeyAwareUserDetails;
import com.cawemo.service.file.PluginFileService;
import com.cawemo.util.api.ServerException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.tags.Tag;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Modeler")
@RequiredArgsConstructor
@RestController
@PreAuthorize(
  "isFeatureEnabled(T(com.cawemo.service.authentication.AuthenticationService).authenticatedApiKey.organization" +
    ", T(Feature).MODELER_PLUGIN)")
public class ModelerFileController implements PluginApiController {

  private final ObjectMapper objectMapper;
  private final PluginFileService pluginFileService;

  @PutMapping(value = "/modeler/v2/diagrams",
    consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public FileDto putModelerDiagram(@Valid @RequestBody DiagramModelerPluginDto dto,
                                   @AuthenticationPrincipal ApiKeyAwareUserDetails apiKeyDetails) {
    return pluginFileService.putModelerDiagram(apiKeyDetails.getApiKey(), dto);
  }

  @PreAuthorize(
    "isFeatureEnabled(T(com.cawemo.service.authentication.AuthenticationService).authenticatedApiKey.organization" +
      ", T(Feature).RPA)")
  @GetMapping(value = "/modeler/v1/templates", produces = MediaType.APPLICATION_JSON_VALUE)
  public String getCatalogTemplates(@AuthenticationPrincipal ApiKeyAwareUserDetails apiKeyDetails,
                                    @RequestParam(required = false, defaultValue = "latest")
                                      VersionsParameter versions) {
    var apiKey = apiKeyDetails.getApiKey();
    var includeAllVersions = versions == VersionsParameter.all;
    var templates = pluginFileService.getCatalogTemplatesWithMetadata(apiKey, includeAllVersions);

    try {
      // workaround to not let ResponseBodyWrapperAdvice wrap the response in a ApiResponseWrapperDto
      return objectMapper.writeValueAsString(templates);
    } catch (JsonProcessingException e) {
      throw new ServerException("Could not serialize response as String", e);
    }
  }

  private enum VersionsParameter {
    all,
    latest
  }
}
