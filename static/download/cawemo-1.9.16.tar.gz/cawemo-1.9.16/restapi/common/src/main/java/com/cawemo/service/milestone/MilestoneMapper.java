/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.milestone;

import com.cawemo.data.dto.base.request.DiagramEnginePluginDto;
import com.cawemo.data.dto.base.request.MilestoneUpdateDto;
import com.cawemo.data.dto.base.response.MilestoneDto;
import com.cawemo.data.dto.base.response.MilestoneWithoutContentDto;
import com.cawemo.data.dto.base.response.MilestoneWrapperDto;
import com.cawemo.data.dto.base.response.TemplateMetadataDto;
import com.cawemo.data.dto.publicapi.request.PublicApiMilestoneCreateDto;
import com.cawemo.data.dto.publicapi.response.PublicApiMilestoneDto;
import com.cawemo.data.dto.publicapi.response.PublicApiMilestoneMetadataDto;
import com.cawemo.data.dto.publicapi.response.PublicApiProcessDefinitionVersionDto;
import com.cawemo.data.dto.publicapi.response.PublicApiTemplateMetadataDto;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.Milestone;
import com.cawemo.data.projection.MilestoneWithoutContent;
import com.cawemo.service.file.FileMapper;
import com.cawemo.util.DateUtil;
import java.time.ZonedDateTime;
import java.util.List;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.NullValueMappingStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring", uses = FileMapper.class)
public interface MilestoneMapper {

  @Mapping(source = "createdBy.id", target = "authorId")
  @Mapping(source = "createdBy.name", target = "authorName")
  @Mapping(source = "file.id", target = "fileId")
  MilestoneDto asMilestoneDto(Milestone milestone);

  @Mapping(source = "file.id", target = "fileId")
  @Mapping(source = "createdBy.id", target = "authorId")
  @Mapping(source = "createdBy.name", target = "authorName")
  MilestoneWithoutContentDto asMilestoneWithoutContentDto(MilestoneWithoutContent milestone);

  List<MilestoneWithoutContentDto> asMilestoneWithoutContentDtoList(List<MilestoneWithoutContent> milestones);

  @Mapping(source = "created", target = "created", qualifiedByName = "asZuluTime")
  @Mapping(source = "file.id", target = "fileId")
  @Mapping(source = "updated", target = "updated", qualifiedByName = "asZuluTime")
  PublicApiMilestoneMetadataDto asPublicApiMilestoneMetadataDto(MilestoneWithoutContent milestone);

  @Mapping(source = "created", target = "created", qualifiedByName = "asZuluTime")
  @Mapping(source = "file.id", target = "fileId")
  @Mapping(source = "updated", target = "updated", qualifiedByName = "asZuluTime")
  PublicApiMilestoneMetadataDto asPublicApiMilestoneMetadataDto(Milestone milestone);

  List<PublicApiMilestoneMetadataDto> asPublicApiMilestoneMetadataDtoList(List<MilestoneWithoutContent> files);

  PublicApiMilestoneDto asPublicApiMilestoneDto(Milestone milestone, PublicApiMilestoneMetadataDto metadata);

  @Mapping(target = "created", ignore = true)
  @Mapping(target = "createdBy", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "updated", ignore = true)
  @Mapping(target = "updatedBy", ignore = true)
  @Mapping(target = "file", expression = "java(file)")
  @Mapping(source = "dto.name", target = "name")
  Milestone asMilestone(File file, PublicApiMilestoneCreateDto dto);

  MilestoneWrapperDto asMilestoneWrapperDto(Milestone milestone);

  @Mapping(source = "name", target = "name")
  @BeanMapping(
    ignoreByDefault = true,
    nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
  )
  Milestone updateFromDto(@MappingTarget Milestone milestone, MilestoneUpdateDto dto);

  @Mapping(source = "processDefinition.content", target = "content")
  @Mapping(target = "created", ignore = true)
  @Mapping(target = "createdBy", ignore = true)
  @Mapping(target = "file", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "name", ignore = true)
  @Mapping(target = "updated", ignore = true)
  @Mapping(target = "updatedBy", ignore = true)
  @BeanMapping(nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
  Milestone updateFromDto(@MappingTarget Milestone milestone, DiagramEnginePluginDto dto);

  @Mapping(source = "created", target = "created", qualifiedByName = "asTimestamp")
  @Mapping(source = "updated", target = "updated", qualifiedByName = "asTimestamp")
  @Mapping(source = "file.project.name", target = "tags", qualifiedByName = "asList")
  @Mapping(source = "file.project.organization.id", target = "catalogOrganizationId")
  @Mapping(source = "id", target = "templateVersionId")
  TemplateMetadataDto asTemplateMetadataDto(Milestone version);

  @Mapping(source = "created", target = "created", qualifiedByName = "asTimestamp")
  @Mapping(source = "updated", target = "updated", qualifiedByName = "asTimestamp")
  @Mapping(source = "file.project.id", target = "catalogId")
  @Mapping(source = "file.project.name", target = "tags", qualifiedByName = "asList")
  @Mapping(source = "name", target = "templateVersionName")
  @Mapping(target = "published", constant = "true")
  PublicApiTemplateMetadataDto asPublicApiTemplateMetadataDto(Milestone version);

  @Mapping(source = "name", target = "templateVersionName")
  @Mapping(source = "project.id", target = "catalogId")
  @Mapping(source = "project.name", target = "tags", qualifiedByName = "asList")
  @Mapping(source = "created", target = "created", qualifiedByName = "asTimestamp")
  @Mapping(source = "updated", target = "updated", qualifiedByName = "asTimestamp")
  @Mapping(target = "published", constant = "false")
  PublicApiTemplateMetadataDto asPublicApiTemplateMetadataDto(File template);

  @Mapping(target = "key", source = "file.processId")
  @Mapping(target = "name", source = "file.name")
  @Mapping(target = "version", source = "name", qualifiedByName = "asProcessDefinitionVersion")
  PublicApiProcessDefinitionVersionDto asPublicApiProcessDefinitionDto(Milestone processDefinition);

  @Mapping(target = "key", source = "file.processId")
  @Mapping(target = "name", source = "file.name")
  @Mapping(target = "version", source = "name", qualifiedByName = "asProcessDefinitionVersion")
  PublicApiProcessDefinitionVersionDto asPublicApiProcessDefinitionDto(MilestoneWithoutContent processDefinition);

  List<PublicApiProcessDefinitionVersionDto> asPublicApiProcessDefinitionDtoList(
    List<MilestoneWithoutContent> processDefinitions);

  @Named("asTimestamp")
  default long asTimestamp(ZonedDateTime date) {
    return DateUtil.asTimestamp(date);
  }

  @Named("asList")
  default List<String> asList(String string) {
    return List.of(string);
  }

  @Named("asProcessDefinitionVersion")
  default int asProcessDefinitionVersion(String name) {
    return Integer.parseInt(name.replace(MilestoneService.ENGINE_VERSION_PREFIX, ""));
  }
}
