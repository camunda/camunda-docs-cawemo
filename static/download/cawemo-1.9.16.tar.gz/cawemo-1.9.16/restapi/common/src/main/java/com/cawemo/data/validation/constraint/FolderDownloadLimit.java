/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.validation.constraint;

import com.cawemo.util.Constants;
import com.cawemo.util.api.ApiError;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;
import javax.validation.constraints.Size;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {})
@Size(max = Constants.FOLDER_DOWNLOAD_LIMIT)
@ReportAsSingleViolation
@CustomApiErrorResponse(reason = ApiError.DOWNLOAD_LIMIT_EXCEEDED, useMessageAsDetail = true)
public @interface FolderDownloadLimit {

  String message() default FileDownloadLimit.DOWNLOAD_LIMIT_EXCEEDED_MESSAGE;

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}
