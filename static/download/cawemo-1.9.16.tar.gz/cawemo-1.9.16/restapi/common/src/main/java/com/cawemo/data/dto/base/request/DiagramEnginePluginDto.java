/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import com.cawemo.data.validation.constraint.NullOrNotBlank;
import com.cawemo.data.validation.constraint.ValidBpmnWithExecutableProcess;
import com.cawemo.util.Constants;
import java.time.LocalDateTime;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class DiagramEnginePluginDto {

  @NotNull
  private LocalDateTime deploymentTime;

  @Size(max = Constants.VARCHAR_MAX)
  @NullOrNotBlank
  private String relationId;

  @Valid
  private DiagramEnginePluginDto.PluginDiagramProcessDefinition processDefinition =
    new PluginDiagramProcessDefinition();

  @Data
  @Accessors(chain = true)
  public static class PluginDiagramProcessDefinition {

    @Positive
    private int version;

    @Size(max = Constants.VARCHAR_MAX)
    @NullOrNotBlank
    private String name;

    @ValidBpmnWithExecutableProcess
    private String content;
  }
}
