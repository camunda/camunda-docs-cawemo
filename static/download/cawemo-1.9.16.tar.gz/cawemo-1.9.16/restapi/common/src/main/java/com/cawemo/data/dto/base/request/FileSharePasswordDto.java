/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import com.cawemo.data.validation.constraint.Utf8ByteLength;
import com.cawemo.util.Constants;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class FileSharePasswordDto {

  @Utf8ByteLength(max = Constants.PASSWORD_BYTES_MAX_LENGTH)
  private String password;
}
