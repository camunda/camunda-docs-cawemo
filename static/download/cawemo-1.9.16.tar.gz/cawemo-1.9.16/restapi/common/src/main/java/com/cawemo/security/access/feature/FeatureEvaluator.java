/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.access.feature;

import com.cawemo.service.file.FileType;
import com.cawemo.service.project.ProjectType;
import com.cawemo.util.Feature;
import java.util.Collection;

public interface FeatureEvaluator {

  boolean isFeatureEnabled(Object target, Feature feature);

  boolean isProjectTypeSupportedByLicense(String organizationId, ProjectType type);

  boolean isFileTypeSupportedByLicense(String projectId, FileType type);

  boolean isFileTypeSupportedByLicense(String fileId);

  boolean areFileTypesSupportedByLicense(Collection<String> fileIds);

  boolean areFileTypesSupportedByLicense(String projectId, Collection<String> fileIds);
}
