/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.configuration.metrics;

import io.micrometer.core.instrument.MeterRegistry;
import javax.servlet.DispatcherType;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsProperties;
import org.springframework.boot.actuate.metrics.web.servlet.WebMvcMetricsFilter;
import org.springframework.boot.actuate.metrics.web.servlet.WebMvcTagsProvider;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;

@Configuration
public class MetricsConfiguration {

  /**
   * Fix for disappearing metrics in Spring Boot 2.7.0, see
   * https://github.com/spring-projects/spring-boot/issues/31150#issuecomment-1134523787.
   *
   * Remove after updating to Spring Boot > 2.7.0
   */
  @Bean
  public FilterRegistrationBean<WebMvcMetricsFilter> webMvcMetricsFilter(MetricsProperties properties,
                                                                         MeterRegistry registry,
                                                                         WebMvcTagsProvider tagsProvider) {
    var request = properties.getWeb().getServer().getRequest();
    var filter = new WebMvcMetricsFilter(registry, tagsProvider, request.getMetricName(), request.getAutotime());
    var registration = new FilterRegistrationBean<>(filter);
    registration.setOrder(Ordered.HIGHEST_PRECEDENCE + 1);
    registration.setDispatcherTypes(DispatcherType.REQUEST, DispatcherType.ASYNC);
    return registration;
  }
}
