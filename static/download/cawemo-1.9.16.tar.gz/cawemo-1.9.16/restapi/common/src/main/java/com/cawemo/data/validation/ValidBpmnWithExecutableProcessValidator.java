/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.validation;

import com.cawemo.data.validation.constraint.ValidBpmnWithExecutableProcess;
import com.cawemo.util.BpmnUtil;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;
import org.camunda.bpm.model.bpmn.BpmnModelInstance;
import org.camunda.bpm.model.xml.ModelException;

public class ValidBpmnWithExecutableProcessValidator
  implements ConstraintValidator<ValidBpmnWithExecutableProcess, String> {

  public static boolean isValid(String bpmn) {
    if (StringUtils.isBlank(bpmn)) {
      return false;
    }

    try {
      var model = BpmnUtil.getBpmnModelInstance(bpmn);
      return hasDiagram(model) && hasExecutableProcessWithId(model);
    } catch (ModelException e) {
      return false;
    }
  }

  private static boolean hasDiagram(BpmnModelInstance model) {
    var diagrams = model.getDefinitions().getBpmDiagrams();
    return diagrams != null && !diagrams.isEmpty();
  }

  private static boolean hasExecutableProcessWithId(BpmnModelInstance model) {
    return BpmnUtil.getFirstExecutableProcess(model)
      .filter(process -> process.getId() != null) // parseModelFromStream doesn't complain about processes without id
      .isPresent();
  }

  @Override
  public boolean isValid(String value, ConstraintValidatorContext context) {
    return isValid(value);
  }
}
