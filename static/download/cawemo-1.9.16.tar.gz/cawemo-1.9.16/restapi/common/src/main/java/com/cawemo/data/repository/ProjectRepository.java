/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.User;
import com.cawemo.data.entity.view.ProjectAdminView;
import com.cawemo.data.entity.view.ProjectPermissionView;
import com.cawemo.data.entity.view.ProjectPermissionWithStatisticsView;
import com.cawemo.data.entity.view.ProjectStatisticsView;
import com.cawemo.service.project.ProjectPermissionLevel;
import com.cawemo.service.project.ProjectType;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ProjectRepository extends JpaRepository<Project, String> {

  List<Project> findByOrganization(Organization organization);

  List<Project> findByOrganizationAndType(Organization organization, ProjectType type);

  List<Project> findByNameAndOrganizationAndType(String name, Organization organization, ProjectType type);

  @Query("SELECT new com.cawemo.data.entity.view.ProjectPermissionView(p, pp.access) " +
    "FROM Project p " +
    "INNER JOIN p.organization.organizationPermissions op " +
    "LEFT JOIN p.projectPermissions pp ON pp.id.user = op.id.user " +
    "WHERE p IN :projects AND op.id.user = :user")
  List<ProjectPermissionView> findPermissionsByUserAndProjects(@Param("user") User user,
                                                               @Param("projects") Collection<Project> projects);

  default Optional<ProjectPermissionView> findPermissionByUserAndProject(User user, Project project) {
    return findPermissionsByUserAndProjects(user, List.of(project))
      .stream()
      .findFirst();
  }

  /**
   * Don't use directly, but
   * {@link com.cawemo.service.project.ProjectService#findAccessibleProjectsByUserAndOrganization} instead!
   */
  @Query("SELECT new com.cawemo.data.entity.view.ProjectPermissionView(p, pp.access) " +
    "FROM Project p " +
    "INNER JOIN p.organization.organizationPermissions op " +
    "LEFT JOIN p.projectPermissions pp ON pp.id.user = op.id.user " +
    "WHERE p.organization = :organization AND op.id.user = :user " +
    "ORDER BY p.created DESC")
  List<ProjectPermissionView> findPermissionViewByUserAndOrganization(@Param("user") User user,
                                                                      @Param("organization") Organization organization);

  @Query("SELECT new com.cawemo.data.entity.view.ProjectPermissionWithStatisticsView(" +
    "p, " +
    "pp.access, " +
    "(SELECT COUNT(*) FROM File f WHERE f.project = p), " +
    "(SELECT MAX(f.updated) FROM File f WHERE f.project = p), " +
    "(SELECT MAX(fo.updated) FROM Folder fo WHERE fo.project = p)) " +
    "FROM Project p " +
    "INNER JOIN p.organization.organizationPermissions op " +
    "LEFT JOIN p.projectPermissions pp ON pp.id.user = op.id.user " +
    "WHERE p.organization = :organization AND op.id.user = :user " +
    "ORDER BY p.created DESC")
  List<ProjectPermissionWithStatisticsView> findPermissionWithStatisticsByUserAndOrganization(@Param("user") User user,
                                                                                              @Param("organization")
                                                                                              Organization
                                                                                                organization);

  @SuppressWarnings("checkstyle:linelength")
  Optional<Project> findFirstByNameAndOrganizationAndTypeAndProjectPermissionsAccessAndProjectPermissionsIdUserOrderByCreatedDesc(
    String projectName, Organization organization, ProjectType type, ProjectPermissionLevel access, User user);

  @SuppressWarnings("checkstyle:linelength")
  Optional<Project> findFirstByOrganizationAndTypeAndProjectPermissionsAccessAndProjectPermissionsIdUserOrderByCreatedDesc(
    Organization organization, ProjectType type, ProjectPermissionLevel access, User user);

  @Query("SELECT new com.cawemo.data.entity.view.ProjectAdminView(p, pp.id.user) " +
    "FROM Project p " +
    "INNER JOIN ProjectPermission pp ON pp.id.project = p " +
    "AND pp.access = com.cawemo.service.project.ProjectPermissionLevel.OWNER " +
    "WHERE p.organization = :organization")
  List<ProjectAdminView> findAdminViewsByOrganization(@Param("organization") Organization organization);

  @Query("""
    SELECT new com.cawemo.data.entity.view.ProjectStatisticsView(
    (SELECT COUNT(*) FROM File f WHERE f.project = p),
    (SELECT MAX(f.updated) FROM File f WHERE f.project = p),
    (SELECT MAX(fo.updated) FROM Folder fo WHERE fo.project = p))
    FROM Project p
    WHERE p = :project
    """)
  ProjectStatisticsView getProjectStatistics(@Param("project") Project project);

  Optional<Project> findByIdAndOrganizationAndType(String catalogId, Organization organization, ProjectType type);
}
