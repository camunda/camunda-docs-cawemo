/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.mail;

import com.cawemo.service.mail.template.MailTemplateService;
import com.cawemo.service.mail.template.view.View;
import com.cawemo.util.Constants;
import java.io.UnsupportedEncodingException;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
class MailFactoryImpl implements MailFactory {

  private final CawemoMailProperties cawemoMailProperties;
  private final MailTemplateService mailTemplateService;

  @Override
  public Mail createMail(String recipientName, String recipientEmail, View view) {
    var from = createAddress(cawemoMailProperties.fromAddress(), cawemoMailProperties.fromName());
    var to = createAddress(recipientEmail, recipientName);
    var template = new RenderedMailTemplate(view);
    return new Mail(from, to, template.subject, template.plainTextBody, template.htmlBody);
  }

  private InternetAddress createAddress(String email, String name) {
    try {
      return StringUtils.isNotBlank(name) ?
        new InternetAddress(email, name, Constants.CHARSET_UTF_8) :
        new InternetAddress(email);
    } catch (UnsupportedEncodingException | AddressException e) {
      throw new IllegalArgumentException(
        String.format("Failed to create InternetAddress from email=%s and name=%s", email, name), e);
    }
  }

  private class RenderedMailTemplate {

    private final String subject;
    private final String plainTextBody;
    private final String htmlBody;

    private RenderedMailTemplate(View view) {
      var renderedView = mailTemplateService.render(view);
      String[] split = renderedView.split("---", 3);
      if (split.length != 3) {
        throw new IllegalArgumentException("Mail template must supply {subject}---{plainTextBody}---{htmlBody}; " +
          "instead got:\n" + renderedView);
      }
      subject = split[0].trim();
      plainTextBody = split[1].trim();
      htmlBody = split[2].trim();
    }
  }
}
