/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller;

import com.cawemo.controller.admin.AdminApiController;
import com.cawemo.controller.base.InternalApiController;
import com.cawemo.controller.plugin.PluginApiController;
import com.cawemo.data.dto.base.response.ApiResponseWrapperDto;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.AbstractMappingJacksonResponseBodyAdvice;

@ControllerAdvice(assignableTypes = {AdminApiController.class, InternalApiController.class, PluginApiController.class})
public class ResponseBodyWrapperAdvice extends AbstractMappingJacksonResponseBodyAdvice {

  /**
   * Wraps all JSON responses in a {@link ApiResponseWrapperDto}. Errors are already wrapped in
   * {@link InternalExceptionHandlingAdvice}.
   */
  @Override
  protected void beforeBodyWriteInternal(MappingJacksonValue bodyContainer,
                                         MediaType contentType,
                                         MethodParameter returnType,
                                         ServerHttpRequest request,
                                         ServerHttpResponse response) {
    var body = bodyContainer.getValue();
    if (!(body instanceof ApiResponseWrapperDto)) {
      bodyContainer.setValue(new ApiResponseWrapperDto().setData(body));
    }
  }
}
