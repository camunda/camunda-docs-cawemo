/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.base;

import com.cawemo.data.dto.base.request.AttentionGrabberDto;
import com.cawemo.data.dto.base.request.DiagramMigrateDto;
import com.cawemo.data.dto.base.request.FileCreateDto;
import com.cawemo.data.dto.base.request.FileCreateFromMilestoneDto;
import com.cawemo.data.dto.base.request.FileUpdateDto;
import com.cawemo.data.dto.base.request.FilesDownloadDto;
import com.cawemo.data.dto.base.request.FilesMoveDto;
import com.cawemo.data.dto.base.response.FileDto;
import com.cawemo.data.dto.base.response.FileLinkLegacyDto;
import com.cawemo.data.dto.base.response.FileListWrapperDto;
import com.cawemo.data.dto.base.response.FileWrapperDto;
import com.cawemo.data.dto.base.response.RelatedFileDto;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.FileLink;
import com.cawemo.data.entity.Milestone;
import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.Project;
import com.cawemo.data.repository.FileRepository;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.file.FileDownloadService;
import com.cawemo.service.file.FileLinkMapper;
import com.cawemo.service.file.FileMapper;
import com.cawemo.service.file.FileService;
import com.cawemo.service.file.FileType;
import com.cawemo.service.project.ProjectService;
import com.cawemo.util.swagger.SwaggerUuidParameter;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.io.BufferedOutputStream;
import java.util.List;
import java.util.zip.ZipOutputStream;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.ContentDisposition;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

@Tag(name = "Files")
@RequiredArgsConstructor
@RestController
@Validated
public class FileController implements InternalApiController {

  private static final MediaType MEDIA_TYPE_APPLICATION_ZIP = MediaType.parseMediaType("application/zip");
  private static final ContentDisposition CONTENT_DISPOSITION_ATTACHMENT =
    ContentDisposition.attachment().build();

  private final FileDownloadService fileDownloadService;
  private final FileLinkMapper fileLinkMapper;
  private final FileMapper fileMapper;
  private final FileRepository fileRepository;
  private final FileService fileService;
  private final ProjectService projectService;

  @PreAuthorize(
    "hasPermission(#file.projectId, 'com.cawemo.data.entity.Project', T(ProjectOperation).MODIFY_FILE)" +
      "&& isFileTypeCategoryAllowed(#file.projectId, #file.type.category) " +
      "&& isFileTypeSupportedByLicense(#file.projectId, #file.type)")
  @PostMapping(value = "/files", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public FileWrapperDto createFile(@Valid @RequestBody @Parameter(required = true) FileCreateDto file) {
    return fileMapper.asFileWrapperDto(fileService.createFile(file));
  }

  @PreAuthorize("hasPermission(#file, T(ProjectOperation).VIEW_FILE)")
  @GetMapping(value = "/files/{fileId}", produces = MediaType.APPLICATION_JSON_VALUE)
  public FileWrapperDto getFile(@SwaggerUuidParameter @PathVariable("fileId") File file) {
    return fileMapper.asFileWrapperDto(file);
  }

  @PreAuthorize("hasPermission(#project, T(ProjectOperation).VIEW_FILE)")
  @GetMapping(value = "/projects/{projectId}/files", produces = MediaType.APPLICATION_JSON_VALUE)
  public FileListWrapperDto getFiles(@SwaggerUuidParameter @PathVariable("projectId") Project project,
                                     @RequestParam String processId) {
    var files = fileRepository.findByProcessIdAndProjectOrderByUpdatedDesc(processId, project);
    return new FileListWrapperDto(fileMapper.asFileWithoutContentDtoList(files));
  }

  @PreAuthorize("hasPermission(#file, T(ProjectOperation).VIEW_FILE)")
  @GetMapping(path = "/files/{fileId}/related", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<RelatedFileDto> getRelatedFiles(@SwaggerUuidParameter @PathVariable("fileId") File file,
                                              @AuthenticationPrincipal UserAwareUserDetails userDetails) {
    var projects = projectService
      .findAccessibleProjectsByUserAndOrganization(userDetails.getUser(), file.getProject().getOrganization());
    var files = fileRepository
      .findByProjectInAndRelationIdAndIdNot(projects, file.getRelationId(), file.getId());
    return fileMapper.asRelatedFileDtoList(files);
  }

  @PreAuthorize("hasPermission(#file, T(ProjectOperation).DELETE_FILE)")
  @DeleteMapping("/files/{fileId}")
  public void deleteFile(@SwaggerUuidParameter @PathVariable("fileId") File file) {
    fileService.deleteFile(file);
  }

  @PreAuthorize("hasPermissionToCollection(#fileIds, 'java.lang.String', 'com.cawemo.data.entity.File', " +
    "T(ProjectOperation).DELETE_FILE)")
  @DeleteMapping(value = "/files", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void batchDeleteFiles(
    @Parameter(description = "IDs of files to be deleted", required = true)
    @RequestBody List<String> fileIds) {
    fileService.batchDeleteFiles(fileIds);
  }

  @PreAuthorize("hasPermission(#file, T(ProjectOperation).MODIFY_FILE) " +
    "&& isFileTypeSupportedByLicense(#file.project.id, #file.type)")
  @PatchMapping(value = "/files/{fileId}", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public FileWrapperDto patchFile(@AuthenticationPrincipal UserAwareUserDetails userDetails,
                                  @SwaggerUuidParameter @PathVariable("fileId") File file,
                                  @Valid @RequestBody @Parameter(required = true) FileUpdateDto fileDto) {
    var updatedFile = fileService.updateFile(file, userDetails.getUser(), fileDto);
    return fileMapper.asFileWrapperDto(updatedFile);
  }

  @PreAuthorize("hasPermissionToCollection(#duplicateList, 'java.lang.String', 'com.cawemo.data.entity.File', " +
    "T(ProjectOperation).MODIFY_FILE) && areFileTypesSupportedByLicense(#duplicateList)")
  @PostMapping(value = "/files/duplicate", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public FileListWrapperDto duplicateFile(
    @Parameter(description = "IDs of files to be duplicated", required = true)
    @RequestBody List<String> duplicateList) {
    var files = fileService.duplicateFiles(duplicateList);
    return new FileListWrapperDto(fileMapper.asFileWithoutContentDtoListFromFileList(files));
  }

  @PreAuthorize(
    "(#dto.targetFolderId != null || #dto.targetProjectId != null) ? " +
      "hasPermission(#milestone.file.project, T(ProjectOperation).VIEW_FILE) && " +
      "(#dto.targetFolderId != null ? " +
      "(hasPermission(#dto.targetFolderId, 'com.cawemo.data.entity.Folder', T(ProjectOperation).MODIFY_FILE) && " +
      "isFileTypeCategoryAllowedForFolder(#dto.targetFolderId, #milestone.file.type.category))" +
      " : " +
      "(hasPermission(#dto.targetProjectId, 'com.cawemo.data.entity.Project', T(ProjectOperation).MODIFY_FILE) && " +
      "isFileTypeCategoryAllowed(#dto.targetProjectId, #milestone.file.type.category))) " +
      " : " +
      "hasPermission(#milestone.file.project, T(ProjectOperation).MODIFY_FILE)")
  @PostMapping(value = "/milestones/{milestoneId}/duplicate")
  public FileWrapperDto createFromMilestone(@Valid @RequestBody FileCreateFromMilestoneDto dto,
                                            @SwaggerUuidParameter @PathVariable("milestoneId") Milestone milestone) {
    var result = fileService.createFromMilestone(milestone, dto);
    return fileMapper.asFileWrapperDto(result);
  }

  @PreAuthorize("hasPermissionToCollection(#dto.fileIds, 'java.lang.String', 'com.cawemo.data.entity.File', " +
    "T(ProjectOperation).MODIFY_FILE) " +
    "&& hasPermission(#dto.targetProjectId, 'com.cawemo.data.entity.Project', T(ProjectOperation).MODIFY_FILE) " +
    "&& areFileTypeCategoriesAllowed(#dto.targetProjectId, #dto.fileIds) " +
    "&& areFileTypesSupportedByLicense(#dto.targetProjectId, #dto.fileIds)")
  @PostMapping(value = "/files/move", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void moveFiles(@RequestBody @Valid FilesMoveDto dto) {
    fileService.moveFiles(dto);
  }

  @PreAuthorize("""
    hasPermissionToCollection(
      #dto.fileIds, 'java.lang.String', 'com.cawemo.data.projection.FileWithoutContent', T(ProjectOperation).VIEW_FILE)
    &&
    hasPermissionToCollection(
      #dto.folderIds, 'java.lang.String', 'com.cawemo.data.entity.Folder', T(ProjectOperation).VIEW_FILE)
    """)
  @PostMapping(value = "/files/download", consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<StreamingResponseBody> downloadFiles(@RequestBody @Valid FilesDownloadDto dto) {
    var response =
      ResponseEntity.ok().headers(headers -> headers.setContentDisposition(CONTENT_DISPOSITION_ATTACHMENT));
    var fileIds = dto.fileIds();
    var folderIds = dto.folderIds();
    return (fileIds.size() == 1 && folderIds.isEmpty())
      ? downloadSingleFile(response, fileIds.get(0))
      : downloadMultipleFiles(response, fileIds, folderIds);
  }

  @PreAuthorize("hasPermission(#file, T(ProjectOperation).COMMENT_AND_MENTION)")
  @PostMapping(value = "/files/{fileId}/attention", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void createAttentionGrabber(@AuthenticationPrincipal UserAwareUserDetails userDetails,
                                     @SwaggerUuidParameter @PathVariable("fileId") File file,
                                     @RequestBody @Valid AttentionGrabberDto dto) {
    fileService.createAttentionGrabber(userDetails.getUser(), file, dto);
  }

  @PreAuthorize("hasPermission(#file, T(ProjectOperation).COMMENT_AND_MENTION)")
  @DeleteMapping("/files/{fileId}/attention")
  public void deleteAttentionGrabber(@AuthenticationPrincipal UserAwareUserDetails userDetails,
                                     @SwaggerUuidParameter @PathVariable("fileId") File file) {
    fileService.deleteAttentionGrabber(userDetails.getUser(), file);
  }

  /**
   * This endpoint is not proxied by the webapp and thus doesn't require permission checks.
   */
  @GetMapping(value = "/organizations/{organizationId}/files/unmigrated", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<FileDto> getDiagramsWithoutProcessId(@PathVariable("organizationId") Organization organization,
                                                   @RequestParam(required = false) Integer limit) {
    var pageSize = (limit != null && limit > 0) ? limit : Integer.MAX_VALUE - 1;
    var pageable = PageRequest.of(0, pageSize, Sort.by(Sort.Direction.DESC, "created"));
    var slice = fileRepository
      .findByProjectOrganizationAndProcessIdIsNullAndType(organization, pageable, FileType.BPMN);
    return fileMapper.asFileDtoList(slice.getContent());
  }

  /**
   * This endpoint is not proxied by the webapp and thus doesn't require permission checks.
   */
  @PatchMapping(value = "/files/migrate", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public FileListWrapperDto patchDiagramsWithoutProcessId(@Valid @RequestBody @Parameter(required = true)
                                                            List<DiagramMigrateDto> dtoList) {
    var migratedFiles = fileService.patchDiagramsWithoutProcessId(dtoList);
    return new FileListWrapperDto(fileMapper.asFileWithoutContentDtoListFromFileList(migratedFiles));
  }

  /**
   * This endpoint is used by the react client to migrate old legacy links to new ones when opening a diagram.
   */
  @PreAuthorize("hasPermission(#file, T(ProjectOperation).VIEW_FILE)")
  @GetMapping(value = "/files/{fileId}/links", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<FileLinkLegacyDto> getLegacyFileLinks(@SwaggerUuidParameter @PathVariable("fileId") File file) {
    return fileLinkMapper.asLegacyDtoList(fileService.findLegacyFileLinksBySourceFile(file));
  }

  /**
   * This endpoint is used by the react client to migrate old legacy links to new ones when opening a file.
   */
  @PreAuthorize("hasPermission(#fileLink.sourceFile, T(ProjectOperation).MODIFY_FILE)")
  @DeleteMapping("/links/{fileLinkId}")
  public void deleteLegacyFileLink(@SwaggerUuidParameter @PathVariable("fileLinkId") FileLink fileLink) {
    fileService.deleteLegacyFileLink(fileLink);
  }

  private ResponseEntity<StreamingResponseBody> downloadSingleFile(
    ResponseEntity.BodyBuilder response, String fileId) {
    var file = fileService.getFile(fileId);
    return response.headers(headers -> headers.setContentType(file.getType().getContentType()))
      .body(out -> fileDownloadService.copyFileContentToOutputStream(file, out));
  }

  private ResponseEntity<StreamingResponseBody> downloadMultipleFiles(
    ResponseEntity.BodyBuilder response, List<String> fileIds, List<String> folderIds) {
    return response.headers(headers -> headers.setContentType(MEDIA_TYPE_APPLICATION_ZIP))
      .body(out -> {
        try (var zipOutputStream = new ZipOutputStream(new BufferedOutputStream(out))) {
          try {
            fileDownloadService.copyFilesToZipOutputStream(fileIds, folderIds, zipOutputStream);
          } catch (Exception e) {
            // Force the creation of an invalid zip archive as a workaround for
            // https://github.com/camunda/web-modeler/issues/8066.
            out.write("ERROR".getBytes());
            throw e;
          }
        }
      });
  }
}
