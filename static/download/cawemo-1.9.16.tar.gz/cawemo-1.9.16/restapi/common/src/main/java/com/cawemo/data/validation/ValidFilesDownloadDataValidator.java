/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.validation;

import com.cawemo.data.dto.base.request.FilesDownloadDto;
import com.cawemo.data.validation.constraint.ValidFilesDownloadData;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidFilesDownloadDataValidator implements ConstraintValidator<ValidFilesDownloadData, FilesDownloadDto> {

  @Override
  public boolean isValid(FilesDownloadDto dto, ConstraintValidatorContext context) {
    return !dto.fileIds().isEmpty() || !dto.folderIds().isEmpty();
  }
}
