/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.response;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.HashMap;
import java.util.Map;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class TemplateDto {

  @JsonProperty(access = JsonProperty.Access.READ_ONLY)
  private Long version;

  private TemplateMetadataDto metadata;

  @JsonAnySetter
  @JsonAnyGetter
  @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
  private Map<String, Object> additionalProperties = new HashMap<>();
}
