/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.organization;

import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.User;
import com.cawemo.data.entity.view.InvitedCollaboratorView;
import com.cawemo.service.project.ProjectInvitationWithAdmins;
import com.cawemo.service.project.ProjectPermissionLevel;
import com.cawemo.service.user.InviteeStatus;
import java.util.List;
import lombok.Getter;

class OrganizationCollaboratorWithStatus extends OrganizationCollaborator {

  OrganizationCollaboratorWithStatus(InvitedCollaboratorView view) {
    super(view.getId(), view.getName(), view.getEmail(), OrganizationPermissionLevel.NONE);
  }

  OrganizationCollaboratorWithStatus(OrganizationCollaborator collaborator) {
    super(collaborator.getId(), collaborator.getName(), collaborator.getEmail(), collaborator.getAccess());
    collaborator
      .getProjects()
      .forEach(this::addProjectAccess);
  }

  @Override
  void addProjectAccess(ProjectAccess projectAccess) {
    super.addProjectAccess(ProjectAccessWithStatus.of(projectAccess));
  }

  void addProjectAccess(ProjectInvitationWithAdmins invitationWithAdmins) {
    super.addProjectAccess(ProjectAccessWithStatus.of(invitationWithAdmins));
  }

  @Getter
  static class ProjectAccessWithStatus extends ProjectAccess {

    private final InviteeStatus status;

    private ProjectAccessWithStatus(Project project, ProjectPermissionLevel access,
                                    InviteeStatus inviteeStatus,
                                    List<User> admins) {
      super(project, access, admins);
      this.status = inviteeStatus;
    }

    private static ProjectAccessWithStatus of(ProjectInvitationWithAdmins invitationWithAdmins) {
      var invitation = invitationWithAdmins.getInvitation();
      var project = invitation.getProject();
      return new ProjectAccessWithStatus(project, invitation.getAccess(), InviteeStatus.SENT,
        invitationWithAdmins.getAdmins());
    }

    private static ProjectAccess of(ProjectAccess projectAccess) {
      return new ProjectAccessWithStatus(projectAccess.getProject(), projectAccess.getPermissionAccess(),
        InviteeStatus.COLLABORATOR, projectAccess.getAdmins());
    }
  }
}
