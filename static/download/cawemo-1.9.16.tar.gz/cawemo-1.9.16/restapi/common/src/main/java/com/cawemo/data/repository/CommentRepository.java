/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.Comment;
import com.cawemo.data.entity.File;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CommentRepository extends JpaRepository<Comment, String> {

  List<Comment> findByFileAndReference(File file, String reference);
}
