/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity;

import com.cawemo.data.entity.listener.SessionEntityListener;
import com.cawemo.util.Constants;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(
  name = "sessions",
  indexes = @Index(columnList = "user_id")
)
@EntityListeners({AuditingEntityListener.class, SessionEntityListener.class})
@Data
@Accessors(chain = true)
public class Session implements Serializable {

  @Id
  @GeneratedValue(generator = "uuid")
  @GenericGenerator(name = "uuid", strategy = "uuid2")
  private String id;

  @CreatedBy
  @ManyToOne
  @JoinColumn(name = "user_id", nullable = false)
  @OnDelete(action = OnDeleteAction.CASCADE)
  private User user;

  @Column(nullable = false, updatable = false)
  private ZonedDateTime validUntil;

  @CreatedDate
  @Column(nullable = false, updatable = false)
  private ZonedDateTime created;

  @LastModifiedDate
  @Column(nullable = false)
  private ZonedDateTime updated;

  @Override
  public boolean equals(Object object) {
    if (object == null) {
      return false;
    } else if (object == this) {
      return true;
    } else if (!(object instanceof Session)) {
      return false;
    } else {
      return Objects.equals(this.id, ((Session) object).getId());
    }
  }

  @Override
  public int hashCode() {
    return Constants.ENTITY_HASHCODE;
  }
}
