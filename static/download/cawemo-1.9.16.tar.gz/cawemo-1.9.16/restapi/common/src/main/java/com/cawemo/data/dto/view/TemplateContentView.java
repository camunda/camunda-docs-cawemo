/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.view;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.List;
import java.util.SortedMap;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@JsonPropertyOrder({"$schema", "name", "description", "id", "appliesTo", "properties"})
public class TemplateContentView {

  @JsonProperty("$schema")
  private String schema;

  private String name;

  private String description;

  private String id;

  private List<String> appliesTo;

  private List<Object> properties;

  @JsonAnyGetter
  @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
  private SortedMap<String, Object> additionalProperties;
}
