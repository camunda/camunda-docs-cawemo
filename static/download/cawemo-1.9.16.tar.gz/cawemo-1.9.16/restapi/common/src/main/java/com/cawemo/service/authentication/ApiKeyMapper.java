/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.authentication;

import com.cawemo.data.dto.base.request.ApiKeyCreateDto;
import com.cawemo.data.dto.base.request.ApiKeyUpdateDto;
import com.cawemo.data.dto.base.response.ApiKeyDto;
import com.cawemo.data.dto.base.response.ApiKeyWithSecretDto;
import com.cawemo.data.entity.ApiKey;
import java.util.List;
import org.mapstruct.BeanMapping;
import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.NullValueMappingStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring")
public interface ApiKeyMapper {

  @Named(value = "asApiKeyDtoWithoutSecret")
  @Mapping(source = "organization.id", target = "organizationId")
  @Mapping(source = "user.id", target = "userId")
  ApiKeyDto asApiKeyDto(ApiKey apiKey);

  @IterableMapping(qualifiedByName = "asApiKeyDtoWithoutSecret")
  List<ApiKeyDto> asApiKeyDtoList(List<ApiKey> apiKeys);

  @Mapping(source = "organization.id", target = "organizationId")
  @Mapping(source = "user.id", target = "userId")
  ApiKeyWithSecretDto asApiKeyWithSecretDto(ApiKey apiKey);

  @Mapping(source = "dto.organizationId", target = "organization.id")
  @Mapping(target = "created", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "updated", ignore = true)
  @Mapping(target = "user", ignore = true)
  ApiKey asApiKey(ApiKeyCreateDto dto, String secret);

  @Mapping(source = "dto.description", target = "description")
  @BeanMapping(
    ignoreByDefault = true,
    nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
  )
  ApiKey updateFromDto(@MappingTarget ApiKey apiKey, ApiKeyUpdateDto dto);
}
