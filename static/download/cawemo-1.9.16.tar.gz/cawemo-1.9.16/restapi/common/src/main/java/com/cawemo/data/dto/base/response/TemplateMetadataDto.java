/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.response;

import java.util.List;
import lombok.Data;

@Data
public class TemplateMetadataDto {

  private String templateVersionId;

  private String catalogOrganizationId;

  private long created;

  private long updated;

  private List<String> tags;
}
