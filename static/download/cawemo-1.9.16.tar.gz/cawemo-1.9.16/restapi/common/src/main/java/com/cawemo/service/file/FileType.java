/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;

@Getter
@RequiredArgsConstructor
public enum FileType {

  BPMN(FileTypeCategory.DIAGRAM, ".bpmn", MediaType.parseMediaType("application/bpmn+xml")),
  DMN(FileTypeCategory.DIAGRAM, ".dmn", MediaType.parseMediaType("application/dmn+xml")),

  TEMPLATE_GENERIC(FileTypeCategory.ELEMENT_TEMPLATE, ".json", MediaType.APPLICATION_JSON),
  TEMPLATE_SERVICE_TASK(FileTypeCategory.ELEMENT_TEMPLATE, ".json", MediaType.APPLICATION_JSON);

  private final FileTypeCategory category;
  private final String fileExtension;
  private final MediaType contentType;

  public static Set<FileType> forCategory(FileTypeCategory category) {
    return Arrays.stream(values())
      .filter(type -> type.category == category)
      .collect(Collectors.toSet());
  }
}
