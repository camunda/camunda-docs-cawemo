/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.organization;

import com.cawemo.data.entity.OrganizationPermission;
import com.cawemo.data.entity.event.PreRemoveOrganizationPermissionEvent;
import com.cawemo.service.authentication.AuthenticationService;
import com.cawemo.service.project.ProjectPermissionService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@RequiredArgsConstructor
public class OrganizationPermissionEventListener {

  private final ProjectPermissionService projectPermissionService;
  private final OrganizationPermissionService organizationPermissionService;

  @EventListener
  @Transactional
  public void preRemoveOrganizationPermission(PreRemoveOrganizationPermissionEvent event) {
    var permission = event.getSource();

    ensurePermissionIsRemovable(permission);

    var organization = permission.getId().getOrganization();
    var user = permission.getId().getUser();

    projectPermissionService.transferProjectAdminPermissionsToOrganizationAdmin(
      AuthenticationService.getAuthenticatedUser(), user, organization);
    projectPermissionService.deleteProjectPermissionsInBatch(user, organization);
  }

  private void ensurePermissionIsRemovable(OrganizationPermission permission) {
    var id = permission.getId();
    if (permission.getAccess() == OrganizationPermissionLevel.ADMIN &&
      !organizationPermissionService
        .otherPermissionExists(id.getOrganization(), id.getUser(), OrganizationPermissionLevel.ADMIN)) {
      throw new AdminPermissionNotRemovableException(permission);
    }
  }
}
