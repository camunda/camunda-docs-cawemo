/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.converter;

import java.util.Collection;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.hibernate.SessionFactory;

@RequiredArgsConstructor
public class GenericEntityIdCollectionConverter<T> implements EntityIdCollectionConverter<T> {

  private final SessionFactory sessionFactory;
  private final Class<T> entityType;

  @Override
  public Class<T> getEntityType() {
    return entityType;
  }

  @Override
  public Collection<T> convert(Collection<String> entityIds) {
    try (var session = sessionFactory.openSession()) {
      return session
        .byMultipleIds(entityType)
        .multiLoad(entityIds.toArray(String[]::new))
        .stream()
        .filter(Objects::nonNull)
        .toList();
    }
  }
}
