/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import com.cawemo.data.validation.constraint.NullOrNotBlank;
import com.cawemo.util.Constants;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class CommentCreateDto {

  @Size(max = Constants.VARCHAR_MAX)
  @NotBlank
  private String fileId;

  @NotBlank
  private String content;

  @Size(max = Constants.VARCHAR_MAX)
  @NullOrNotBlank
  private String reference;

  private String originAppInstanceId;
}
