/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.authentication;

import com.cawemo.data.dto.base.request.ApiKeyCreateDto;
import com.cawemo.data.dto.base.request.ApiKeyUpdateDto;
import com.cawemo.data.entity.ApiKey;
import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.User;
import com.cawemo.data.repository.ApiKeyRepository;
import com.cawemo.util.Constants;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.keygen.StringKeyGenerator;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ApiKeyService {

  private final StringKeyGenerator stringKeyGenerator = new AlphanumericStringKeyGenerator(Constants.API_KEY_LENGTH);

  private final ApiKeyMapper apiKeyMapper;
  private final ApiKeyRepository apiKeyRepository;
  private final PasswordEncoder passwordEncoder;

  public List<ApiKey> getApiKeysForUser(Organization organization, User user) {
    return apiKeyRepository.findByOrganizationAndUser(organization, user);
  }

  /**
   * Creates an api key from {@link ApiKeyCreateDto} and persists it to the database. Be careful not to disclose any
   * secrets when using the returned api key as it includes the raw password in {@link ApiKey#getSecret()}.
   *
   * @return the api key with the raw password
   */
  public ApiKey createApiKey(ApiKeyCreateDto dto) {
    var rawSecret = stringKeyGenerator.generateKey();
    var apiKey = apiKeyMapper.asApiKey(dto, rawSecret);
    var hashedSecret = passwordEncoder.encode(rawSecret);
    var result = apiKeyRepository.save(apiKey.setSecret(hashedSecret));

    return result.setSecret(rawSecret);
  }

  public ApiKey updateApiKey(ApiKey apiKey, ApiKeyUpdateDto dto) {
    return apiKeyRepository.save(apiKeyMapper.updateFromDto(apiKey, dto));
  }

  public void deleteApiKey(ApiKey apiKey) {
    apiKeyRepository.delete(apiKey);
  }

  public void deleteApiKeysByOrganizationAndUser(Organization organization, User user) {
    apiKeyRepository.deleteByOrganizationAndUser(organization, user);
  }
}
