/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.publicapi;

import com.cawemo.data.dto.publicapi.request.TemplateCreateDto;
import com.cawemo.data.dto.publicapi.request.TemplateUpdateDto;
import com.cawemo.data.dto.publicapi.response.PublicApiTemplateDto;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.Project;
import com.cawemo.security.authentication.ApiKeyAwareUserDetails;
import com.cawemo.service.file.FileTypeCategory;
import com.cawemo.service.file.TemplateService;
import com.cawemo.service.project.ProjectType;
import com.cawemo.util.api.NoSuchObjectException;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Public API: Templates")
@RequiredArgsConstructor
@RestController
public class TemplateController implements PublicApiController {

  private final TemplateService templateService;

  @PreAuthorize(
    "hasPermission(#dto.metadata.catalogId, 'com.cawemo.data.entity.Project', T(ProjectOperation).MODIFY_FILE)"
  )
  @PostMapping(path = "/templates", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public PublicApiTemplateDto createTemplate(@Valid @RequestBody TemplateCreateDto dto,
                                             @AuthenticationPrincipal ApiKeyAwareUserDetails userDetails) {
    return templateService.createTemplate(dto, userDetails.getApiKey().getOrganization());
  }

  @PreAuthorize(
    "hasPermission(#template, T(ProjectOperation).MODIFY_FILE) && " +
    "(#dto.metadata == null || #dto.metadata.catalogId == null || #dto.metadata.catalogId == #template.project.id || " +
      "hasPermission(#dto.metadata.catalogId, 'com.cawemo.data.entity.Project', T(ProjectOperation).MODIFY_FILE)) && " +
    "#template.project.organization == #userDetails.apiKey.organization"
  )
  @PatchMapping(path = "/templates/{templateId}", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public PublicApiTemplateDto updateTemplate(@PathVariable("templateId") File template,
                                             @Valid @RequestBody TemplateUpdateDto dto,
                                             @AuthenticationPrincipal ApiKeyAwareUserDetails userDetails) {
    ensureTemplateType(template);

    return templateService.updateTemplate(dto, template);
  }

  @PreAuthorize(
    "hasPermission(#template, T(ProjectOperation).VIEW_FILE) && " +
    "#template.project.organization == #userDetails.apiKey.organization"
  )
  @GetMapping(path = "/templates/{templateId}", produces = MediaType.APPLICATION_JSON_VALUE)
  public PublicApiTemplateDto getTemplate(@PathVariable("templateId") File template,
                                          @RequestParam(required = false) boolean includeUnpublishedVersions,
                                          @AuthenticationPrincipal ApiKeyAwareUserDetails userDetails) {
    ensureTemplateType(template);

    return templateService.getTemplate(template, includeUnpublishedVersions);
  }

  @PreAuthorize(
    "(#catalog == null || (#catalog.organization == #userDetails.apiKey.organization && " +
      "hasPermission(#catalog, T(ProjectOperation).VIEW_FILE)))"
  )
  @GetMapping(path = "/templates", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<PublicApiTemplateDto> getTemplates(@RequestParam(name = "catalogId", required = false) Project catalog,
                                                 @RequestParam(required = false) boolean includeUnpublishedVersions,
                                                 @AuthenticationPrincipal ApiKeyAwareUserDetails userDetails) {
    if (catalog != null && catalog.getType() != ProjectType.CATALOG) {
      throw new NoSuchObjectException();
    }

    return templateService.getTemplates(userDetails.getApiKey().getOrganization(), catalog, includeUnpublishedVersions);
  }

  private void ensureTemplateType(File template) {
    if (template.getType().getCategory() != FileTypeCategory.ELEMENT_TEMPLATE) {
      throw new NoSuchObjectException();
    }
  }
}
