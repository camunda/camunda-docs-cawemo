/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.configuration.data;

import com.cawemo.controller.converter.EntityIdCollectionConverter;
import com.cawemo.controller.converter.GenericEntityIdCollectionConverter;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.Folder;
import com.cawemo.data.entity.Project;
import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EntityConverterConfiguration {

  @Bean
  public EntityIdCollectionConverter<File> fileCollectionConverter(SessionFactory sessionFactory) {
    return new GenericEntityIdCollectionConverter<>(sessionFactory, File.class);
  }

  @Bean
  public EntityIdCollectionConverter<Folder> folderCollectionConverter(SessionFactory sessionFactory) {
    return new GenericEntityIdCollectionConverter<>(sessionFactory, Folder.class);
  }

  @Bean
  public EntityIdCollectionConverter<Project> projectCollectionConverter(SessionFactory sessionFactory) {
    return new GenericEntityIdCollectionConverter<>(sessionFactory, Project.class);
  }
}
