/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.milestone;

import com.cawemo.data.dto.base.request.DiagramEnginePluginDto;
import com.cawemo.data.dto.base.request.MilestoneAddRelatedDiagramDto;
import com.cawemo.data.dto.base.request.MilestoneAutosaveDto;
import com.cawemo.data.dto.base.request.MilestoneCreateDto;
import com.cawemo.data.dto.base.request.MilestoneRestoreDto;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.Milestone;
import com.cawemo.data.entity.User;
import com.cawemo.data.projection.MilestoneWithoutContent;
import com.cawemo.data.repository.MilestoneRepository;
import com.cawemo.service.file.FileMapper;
import com.cawemo.service.file.FileService;
import com.cawemo.service.file.FileType;
import com.cawemo.util.Constants;
import com.cawemo.util.api.ApiError;
import com.cawemo.util.api.BadRequestException;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class MilestoneService {

  public static final String RELATED_DIAGRAM_PREFIX = "Copied from ";
  public static final String ENGINE_VERSION_PREFIX = "Version ";

  private final MilestoneRepository milestoneRepository;
  private final MilestoneMapper milestoneMapper;
  private final FileService fileService;
  private final FileMapper fileMapper;

  public List<MilestoneWithoutContent> getMilestones(String projectName, String processId, User user) {
    return milestoneRepository
      .findByFileProcessIdAndFileProjectNameAndFileProjectOrganizationOrganizationPermissionsIdUser(
        processId, projectName, user);
  }

  public Milestone createMilestone(MilestoneCreateDto dto) {
    var file = fileService.getFile(dto.getFileId());
    return createMilestone(file, dto.getName());
  }

  public Milestone createMilestone(File file, String name, String content, ZonedDateTime created) {
    var milestone = new Milestone()
      .setFile(file)
      .setName(name)
      .setContent(content)
      .setCreated(created);

    return milestoneRepository.save(milestone);
  }

  public Milestone createOrUpdateMilestone(DiagramEnginePluginDto dto, File file) {
    var deploymentTime = dto.getDeploymentTime().atZone(ZoneOffset.UTC);
    return milestoneRepository
      .findFirstByNameAndFileAndCreated(engineDeploymentMilestoneName(dto), file, deploymentTime)
      .map(milestone -> updateMilestone(milestoneMapper.updateFromDto(milestone, dto)))
      .orElseGet(() -> createMilestone(file, engineDeploymentMilestoneName(dto),
        dto.getProcessDefinition().getContent(), deploymentTime));
  }

  public Milestone updateMilestone(Milestone milestone) {
    return milestoneRepository.save(milestone);
  }

  @Transactional
  public void restoreMilestone(User user, Milestone milestone, MilestoneRestoreDto dto) {
    var file = milestone.getFile();
    if (file.getType() == FileType.BPMN && StringUtils.isBlank(dto.getProcessId())) {
      throw new BadRequestException(ApiError.INVALID_INPUT);
    }
    createMilestone(file, dto.getRestoredName(), milestone.getContent());
    fileMapper.updateFromDto(file, dto, milestone.getContent());
    fileService.updateFile(file, user, dto.getOriginAppInstanceId());
  }

  @Transactional
  public void addRelatedDiagramAsMilestone(User user, File targetDiagram, MilestoneAddRelatedDiagramDto dto) {
    var source = fileService.getFile(dto.getFileId());
    ensureTypeBpmn(source, targetDiagram);
    ensureDiagramsAreRelated(source, targetDiagram);

    var truncatedName = StringUtils
      .truncate(source.getProject().getName(), Constants.VARCHAR_MAX - RELATED_DIAGRAM_PREFIX.length());
    var name = RELATED_DIAGRAM_PREFIX + truncatedName;
    createMilestone(targetDiagram, name, source.getContent());
    var updatedTarget = fileMapper.updateFromDto(targetDiagram, dto, source);
    fileService.updateFile(updatedTarget, user, dto.getOriginAppInstanceId());
  }

  public Optional<Milestone> autosaveMilestone(File file, MilestoneAutosaveDto autosaveDto) {
    var latestMilestoneContent = milestoneRepository.findFirstByFileOrderByCreatedDesc(file)
      .map(Milestone::getContent)
      .orElse(null);
    return !file.getContent().equals(latestMilestoneContent)
      ? Optional.of(createMilestone(file, autosaveDto.getName()))
      : Optional.empty();
  }

  @Transactional
  public void deleteMilestone(Milestone milestone) {
    if (isPluginFile(milestone.getFile())) {
      deletePluginFileMilestone(milestone);
    } else {
      milestoneRepository.delete(milestone);
    }
  }

  private void ensureTypeBpmn(File source, File target) {
    if (source.getType() != FileType.BPMN || target.getType() != FileType.BPMN) {
      throw new BadRequestException(ApiError.INVALID_INPUT,
        String.format("invalid file types - source=%s, target=%s", source.getType(), target.getType()));
    }
  }

  private void ensureDiagramsAreRelated(File source, File target) {
    if (!target.getRelationId().equals(source.getRelationId())) {
      throw new BadRequestException(ApiError.INVALID_INPUT, "files are not related");
    }
  }

  private Milestone createMilestone(File file, String name) {
    return createMilestone(file, name, file.getContent());
  }

  private Milestone createMilestone(File file, String name, String content) {
    return createMilestone(file, name, content, null);
  }

  private String engineDeploymentMilestoneName(DiagramEnginePluginDto dto) {
    return ENGINE_VERSION_PREFIX + dto.getProcessDefinition().getVersion();
  }

  private boolean isPluginFile(File file) {
    return file.getProject().getType().isPluginType();
  }

  private void deletePluginFileMilestone(Milestone milestone) {
    var file = milestone.getFile();

    var milestones = milestoneRepository.findTop2ByFileOrderByCreatedDesc(file);
    var latest = milestones.get(0);
    var previous = milestones.size() == 2 ? milestones.get(1) : null;

    if (milestone.equals(latest)) {
      if (previous != null) {
        fileService.updateFile(file, previous.getContent());
      } else {
        fileService.deleteFile(file);
        return;
      }
    }
    milestoneRepository.delete(milestone);
  }
}
