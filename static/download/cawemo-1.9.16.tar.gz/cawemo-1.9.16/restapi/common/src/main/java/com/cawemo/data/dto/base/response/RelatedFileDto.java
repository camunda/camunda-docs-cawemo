/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.response;

import com.cawemo.service.project.ProjectType;
import java.time.ZonedDateTime;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class RelatedFileDto {

  private String id;

  private String name;

  private String slug;

  private ZonedDateTime updated;

  private ProjectContainer project;

  @Data
  @Accessors(chain = true)
  public static class ProjectContainer {

    private String name;

    private ProjectType type;
  }
}
