/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.base;

import com.cawemo.data.dto.base.request.UserUpdateDto;
import com.cawemo.data.dto.base.response.UserSelfDto;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.organization.OrganizationDetailsProvider;
import com.cawemo.service.user.UserSelfMapper;
import com.cawemo.service.user.UserService;
import com.cawemo.util.swagger.SwaggerUuidParameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "User")
@RestController
@RequiredArgsConstructor
public class UserController implements InternalApiController {

  private final OrganizationDetailsProvider organizationDetailsProvider;
  private final UserSelfMapper userSelfMapper;
  private final UserService userService;

  @GetMapping(value = "/self", produces = MediaType.APPLICATION_JSON_VALUE)
  public UserSelfDto getSelf(@AuthenticationPrincipal UserAwareUserDetails userDetails) {
    var user = userDetails.getUser();
    var organizations = organizationDetailsProvider.getOrganizationDetails(user);
    return userSelfMapper.asUserSelfDto(user, organizations);
  }

  /**
   * Updating user data is triggered by the IAM backend (via the webapp), thus the IAM ID is used here. The endpoint
   * is not proxied, so no authorization required (wouldn't be possible anyway as the user's session cookie is not
   * available in backend-to-backend communication).
   */
  @PutMapping(value = "/users/iam/{iamId}", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void updateUser(@SwaggerUuidParameter @PathVariable("iamId") String iamId,
                         @Valid @RequestBody UserUpdateDto dto) {
    userService.updateUser(iamId, dto);
  }
}
