/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.response;

import io.swagger.v3.oas.annotations.media.Schema;
import java.time.ZonedDateTime;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public abstract class MilestoneBaseDto {

  private String id;

  private String fileId;

  private String name;

  private String authorId;

  private String authorName;

  // TODO use @SwaggerTimestampField if possible
  @Schema(type = "integer", format = "int64", description = "Timestamp", example = "1576238401000")
  private ZonedDateTime created;
}
