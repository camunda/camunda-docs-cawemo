/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.converter;

import com.cawemo.service.preference.PreferenceKey;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@SuppressWarnings("unused") // used for PreferenceId
@Converter(autoApply = true)
public class PreferenceKeyConverter implements AttributeConverter<PreferenceKey, String> {

  @Override
  public String convertToDatabaseColumn(PreferenceKey attribute) {
    return attribute.getKey();
  }

  @Override
  public PreferenceKey convertToEntityAttribute(String dbData) {
    return PreferenceKey.fromString(dbData);
  }
}
