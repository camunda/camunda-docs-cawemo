/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.authentication.key;

import com.cawemo.configuration.security.WebSecurityConfiguration;
import com.cawemo.data.entity.ApiKey;
import com.cawemo.security.authentication.ApiKeyAwareUserDetails;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationDetailsSource;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.rememberme.AbstractRememberMeServices;
import org.springframework.security.web.authentication.rememberme.InvalidCookieException;
import org.springframework.security.web.authentication.rememberme.RememberMeAuthenticationException;
import org.springframework.security.web.authentication.www.BasicAuthenticationConverter;

@Slf4j
public abstract class AbstractApiKeyRememberMeService extends AbstractRememberMeServices {

  public static final String API_KEY_PARAM = "apiKey";
  public static final String DELIMITER = ":";
  private final BasicAuthenticationConverter converter = new BasicAuthenticationConverter();
  private final PasswordEncoder passwordEncoder;
  private final AuthenticationDetailsSource<ApiKey, ApiKeyAwareUserDetails> detailsSource;

  protected AbstractApiKeyRememberMeService(UserDetailsService userDetailsService,
                                            PasswordEncoder passwordEncoder,
                                            AuthenticationDetailsSource<ApiKey, ApiKeyAwareUserDetails> detailsSource) {
    super(WebSecurityConfiguration.REMEMBER_ME_KEY, userDetailsService);
    this.passwordEncoder = passwordEncoder;
    this.detailsSource = detailsSource;
  }

  abstract String principalParameter();

  abstract List<ApiKey> getApiKeys(String principal);

  @Override
  protected String extractRememberMeCookie(HttpServletRequest request) {
    var parameters = request.getParameterMap();

    if (parameters.containsKey(API_KEY_PARAM) && parameters.containsKey(principalParameter())) {
      return parameters.get(principalParameter())[0] + DELIMITER + parameters.get(API_KEY_PARAM)[0];
    } else {
      try {
        var token = converter.convert(request);
        return token == null ? null : token.getPrincipal() + DELIMITER + token.getCredentials();
      } catch (BadCredentialsException e) {
        log.debug("Invalid basic authentication token");
        return null;
      }
    }
  }

  @Override
  protected String[] decodeCookie(String cookieValue) throws InvalidCookieException {
    return cookieValue.split(DELIMITER, 2);
  }

  @Override
  protected UserDetails processAutoLoginCookie(String[] cookieTokens,
                                               HttpServletRequest request,
                                               HttpServletResponse response)
    throws RememberMeAuthenticationException, UsernameNotFoundException {
    if (cookieTokens.length != 2) {
      throw new RememberMeAuthenticationException("Couldn't parse credentials!");
    }
    var principal = cookieTokens[0];
    var credentials = cookieTokens[1];

    return getApiKeys(principal)
      .stream()
      .filter(apiKey -> passwordEncoder.matches(credentials, apiKey.getSecret()))
      .findFirst()
      .map(apiKey -> apiKey.setSecret(null))
      .map(detailsSource::buildDetails)
      .orElseThrow(() -> new UsernameNotFoundException("The given credentials couldn't be verified"));
  }

  @Override
  protected void onLoginSuccess(HttpServletRequest request,
                                HttpServletResponse response,
                                Authentication successfulAuthentication) {
    // Nothing to do here
  }
}
