/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity.view;

import com.cawemo.data.entity.Project;
import com.cawemo.service.project.ProjectPermissionLevel;
import java.time.ZonedDateTime;
import java.util.Objects;
import lombok.Getter;
import org.apache.commons.lang3.ObjectUtils;

@Getter
public class ProjectPermissionWithStatisticsView extends ProjectPermissionView {

  private final long fileCount;
  private final ZonedDateTime filesLastUpdated;
  private final ZonedDateTime foldersLastUpdated;
  private final ZonedDateTime lastModified;

  public ProjectPermissionWithStatisticsView(Project project, ProjectPermissionLevel projectPermission, long fileCount,
                                             ZonedDateTime filesLastUpdated, ZonedDateTime foldersLastUpdated) {
    super(project, projectPermission);
    this.fileCount = fileCount;
    this.filesLastUpdated = filesLastUpdated;
    this.foldersLastUpdated = foldersLastUpdated;
    var lastModifiedProjectContent = ObjectUtils.max(filesLastUpdated, foldersLastUpdated);
    this.lastModified = Objects.requireNonNullElse(lastModifiedProjectContent, project.getCreated());
  }
}
