/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.projection;

import com.cawemo.data.entity.FileShare;
import com.cawemo.data.entity.Folder;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.User;
import com.cawemo.service.file.FileType;
import java.time.ZonedDateTime;
import lombok.Value;

@Value
public class FileWithoutContent {

  String id;
  String name;
  Project project;
  Folder folder;
  User createdBy;
  ZonedDateTime created;
  User updatedBy;
  ZonedDateTime updated;
  Integer revision;
  String relationId;
  String processId;
  FileType type;
  FileShare share;
}
