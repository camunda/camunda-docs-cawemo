/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.base;

import com.cawemo.data.dto.base.request.MilestoneAddRelatedDiagramDto;
import com.cawemo.data.dto.base.request.MilestoneAutosaveDto;
import com.cawemo.data.dto.base.request.MilestoneCreateDto;
import com.cawemo.data.dto.base.request.MilestoneRestoreDto;
import com.cawemo.data.dto.base.request.MilestoneUpdateDto;
import com.cawemo.data.dto.base.response.MilestoneListWrapperDto;
import com.cawemo.data.dto.base.response.MilestoneWrapperDto;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.Milestone;
import com.cawemo.data.repository.MilestoneRepository;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.milestone.MilestoneMapper;
import com.cawemo.service.milestone.MilestoneService;
import com.cawemo.util.swagger.SwaggerUuidParameter;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Milestones")
@RestController
@RequiredArgsConstructor
public class MilestoneController implements InternalApiController {

  private final MilestoneMapper milestoneMapper;
  private final MilestoneRepository milestoneRepository;
  private final MilestoneService milestoneService;

  @PreAuthorize("hasPermission(#milestone.file, T(ProjectOperation).VIEW_MILESTONE)")
  @GetMapping(value = "/milestones/{milestoneId}", produces = MediaType.APPLICATION_JSON_VALUE)
  public MilestoneWrapperDto getMilestone(@SwaggerUuidParameter @PathVariable("milestoneId") Milestone milestone) {
    return milestoneMapper.asMilestoneWrapperDto(milestone);
  }

  @PreAuthorize("hasPermission(#file, T(ProjectOperation).VIEW_MILESTONE)")
  @GetMapping(value = "/files/{fileId}/milestones", produces = MediaType.APPLICATION_JSON_VALUE)
  public MilestoneListWrapperDto getAllMilestones(@SwaggerUuidParameter @PathVariable("fileId") File file) {
    var milestones = milestoneRepository.findByFileOrderByCreatedDesc(file);
    return new MilestoneListWrapperDto(milestoneMapper.asMilestoneWithoutContentDtoList(milestones));
  }

  @PreAuthorize(
    "hasPermission(#milestone.fileId, 'com.cawemo.data.entity.File', T(ProjectOperation).MODIFY_MILESTONE)" +
      "&& isFileTypeSupportedByLicense(#milestone.fileId)")
  @PostMapping(value = "/milestones",
    consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public MilestoneWrapperDto createMilestone(@Valid @RequestBody @Parameter(required = true)
                                               MilestoneCreateDto milestone) {
    var entity = milestoneService.createMilestone(milestone);
    return milestoneMapper.asMilestoneWrapperDto(entity);
  }

  @PreAuthorize("hasPermission(#milestone.file, T(ProjectOperation).MODIFY_MILESTONE)" +
    "&& isFileTypeSupportedByLicense(#milestone.file.project.id, #milestone.file.type)")
  @PatchMapping(value = "/milestones/{milestoneId}", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void updateMilestone(@SwaggerUuidParameter @PathVariable("milestoneId") Milestone milestone,
                              @Valid @RequestBody @Parameter(required = true) MilestoneUpdateDto milestoneUpdate) {
    milestoneRepository.save(milestoneMapper.updateFromDto(milestone, milestoneUpdate));
  }

  @PreAuthorize("hasPermission(#milestone.file, T(ProjectOperation).DELETE_MILESTONE)")
  @DeleteMapping(value = "/milestones/{milestoneId}")
  public void deleteMilestone(@SwaggerUuidParameter @PathVariable("milestoneId") Milestone milestone) {
    milestoneService.deleteMilestone(milestone);
  }

  @PreAuthorize("hasPermission(#milestone.file, T(ProjectOperation).MODIFY_FILE)" +
    " && hasPermission(#milestone.file, T(ProjectOperation).MODIFY_MILESTONE)" +
    "&& isFileTypeSupportedByLicense(#milestone.file.project.id, #milestone.file.type)")
  @PostMapping(value = "/milestones/{milestoneId}/restore", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void restoreMilestone(@AuthenticationPrincipal UserAwareUserDetails userDetails,
                               @SwaggerUuidParameter @PathVariable("milestoneId") Milestone milestone,
                               @Valid @RequestBody @Parameter(required = true) MilestoneRestoreDto milestoneRestore) {
    milestoneService.restoreMilestone(userDetails.getUser(), milestone, milestoneRestore);
  }

  @PreAuthorize("hasPermission(#targetDiagram, T(ProjectOperation).MODIFY_MILESTONE) && " +
    "hasPermission(#dto.fileId, 'com.cawemo.data.entity.File', T(ProjectOperation).VIEW_FILE) " +
    "&& isFeatureEnabled(#targetDiagram.project.organization, T(Feature).RELATED_DIAGRAMS)" +
    "&& isFileTypeSupportedByLicense(#targetDiagram.project.id, #targetDiagram.type)")
  @PostMapping(value = "/files/{fileId}/milestones/related", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void addRelatedDiagramAsMilestone(@AuthenticationPrincipal UserAwareUserDetails userDetails,
                                           @SwaggerUuidParameter @PathVariable("fileId") File targetDiagram,
                                           @Valid @RequestBody @Parameter(required = true)
                                             MilestoneAddRelatedDiagramDto dto) {
    milestoneService.addRelatedDiagramAsMilestone(userDetails.getUser(), targetDiagram, dto);
  }

  @PreAuthorize("hasPermission(#file, T(ProjectOperation).MODIFY_MILESTONE)" +
    "&& isFileTypeSupportedByLicense(#file.project.id, #file.type)")
  @PostMapping(value = "/files/{fileId}/milestones/autosave", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public MilestoneWrapperDto autosaveMilestone(
    @SwaggerUuidParameter @PathVariable("fileId") File file,
    @Valid @RequestBody @Parameter(required = true) MilestoneAutosaveDto dto) {

    return milestoneService.autosaveMilestone(file, dto)
      .map(milestoneMapper::asMilestoneWrapperDto)
      .orElse(null);
  }
}
