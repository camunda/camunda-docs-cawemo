/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.ProjectPermission;
import com.cawemo.data.entity.ProjectPermissionId;
import com.cawemo.data.entity.User;
import com.cawemo.data.entity.view.ProjectCollaboratorView;
import com.cawemo.data.entity.view.ProjectPermissionAdminView;
import com.cawemo.service.project.ProjectPermissionLevel;
import com.cawemo.service.project.ProjectType;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface ProjectPermissionRepository extends JpaRepository<ProjectPermission, ProjectPermissionId> {

  List<ProjectPermission> findByIdProjectAndAccess(Project project, ProjectPermissionLevel access);

  boolean existsByIdProjectAndAccessAndIdUserNot(Project project, ProjectPermissionLevel access, User user);

  Optional<ProjectPermission> findByIdProjectAndIdUserEmailIgnoreCase(Project project, String email);

  @Query("""
    SELECT p FROM ProjectPermission p INNER JOIN p.id.user u
    LEFT OUTER JOIN ProjectSubscription s ON u = s.id.user AND s.id.project = :project
    WHERE lower(u.username) IN :usernames AND p.id.project = :project AND
    (s.active = TRUE OR s.active IS NULL) AND p.access <> com.cawemo.service.project.ProjectPermissionLevel.READ
    """)
  List<ProjectPermission> findPermissionsForSubscribedUsersExcludingReadAccess(
    @Param("usernames") List<String> usernames, @Param("project") Project project);

  @Query("SELECT pp1 FROM ProjectPermission pp1 INNER JOIN pp1.id.project project " +
    "WHERE project.organization IN :organizations " +
    "AND pp1.access = com.cawemo.service.project.ProjectPermissionLevel.OWNER " +
    "AND EXISTS (SELECT 1 FROM ProjectPermission pp2 WHERE pp2.id.user = :user AND pp2.id.project = project " +
    "AND pp2.access = com.cawemo.service.project.ProjectPermissionLevel.OWNER)")
  List<ProjectPermission> findAllAdminPermissionsForProjectsUserIsAdminOf(
    @Param("organizations") Iterable<Organization> organizations, @Param("user") User user);

  List<ProjectPermission> findByIdProjectOrganizationAndIdProjectTypeAndIdUserAndAccess(Organization organization,
                                                                                        ProjectType type,
                                                                                        User user,
                                                                                        ProjectPermissionLevel access);

  boolean existsByIdProjectOrganizationAndIdUserNot(Organization organization, User user);

  boolean existsByIdProjectAndIdUserEmailIgnoreCase(Project project, String email);

  @Query("SELECT new com.cawemo.data.entity.view.ProjectPermissionAdminView(userPermission, ownerPermission.id.user) " +
    "FROM ProjectPermission userPermission " +
    "INNER JOIN userPermission.id.project project " +
    "INNER JOIN ProjectPermission ownerPermission ON ownerPermission.id.project = project " +
    "AND ownerPermission.access = com.cawemo.service.project.ProjectPermissionLevel.OWNER " +
    "WHERE project.organization = :organization AND userPermission.id.user.id = :userId")
  List<ProjectPermissionAdminView> getPermissionsWithProjectAdminsForOrganizationAndUser(
    @Param("organization") Organization organization, @Param("userId") String userId);

  @Transactional
  @Modifying
  @Query("DELETE FROM ProjectPermission pp WHERE pp.id.user = :user AND pp.id.project IN :projects")
  void deleteInBatchByIdUserAndIdProjectIn(@Param("user") User user,
                                           @Param("projects") List<Project> projects);

  @Query("""
    SELECT new com.cawemo.data.entity.view.ProjectCollaboratorView(u.id, u.name, u.email, u.username, pp.id.project.id,
      pp.access)
    FROM ProjectPermission pp
    INNER JOIN pp.id.user u
    WHERE pp.id.project.id IN :projectIds
    """)
  List<ProjectCollaboratorView> findByProjectIdIn(@Param("projectIds") List<String> projectIds);
}
