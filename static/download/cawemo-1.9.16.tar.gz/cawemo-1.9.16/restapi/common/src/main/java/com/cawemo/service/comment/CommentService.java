/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.comment;

import com.cawemo.data.dto.base.request.CommentCreateDto;
import com.cawemo.data.dto.base.request.CommentDeleteDto;
import com.cawemo.data.dto.base.request.CommentUpdateDto;
import com.cawemo.data.dto.base.request.NodeRemoveDto;
import com.cawemo.data.entity.Comment;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.User;
import com.cawemo.data.repository.CommentRepository;
import com.cawemo.service.file.FileService;
import com.cawemo.service.mail.MailService;
import com.cawemo.service.pusher.PusherService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CommentService {

  private final CommentMapper commentMapper;
  private final CommentRepository commentRepository;
  private final MailService mailService;
  private final FileService fileService;
  private final PusherService pusherService;

  public Comment createComment(User commenter, CommentCreateDto dto) {
    var file = fileService.getFile(dto.getFileId());
    var comment = commentRepository.save(commentMapper.asComment(file, dto));

    mailService.sendMailToMentionedCollaborators(commenter, comment);
    pusherService.addDiagramCommentNotification(comment, dto.getOriginAppInstanceId());

    return comment;
  }

  public Comment updateComment(User commenter, Comment comment, CommentUpdateDto dto) {
    var updatedComment = commentMapper.updateFromDto(comment, dto);
    commentRepository.save(updatedComment);

    mailService.sendMailToMentionedCollaborators(commenter, comment);
    pusherService.editDiagramCommentNotification(updatedComment, dto.getOriginAppInstanceId());

    return updatedComment;
  }

  public void deleteComment(Comment comment, CommentDeleteDto dto) {
    commentRepository.delete(comment);

    pusherService.removeDiagramCommentNotification(comment, dto.getOriginAppInstanceId());
  }

  public void deleteDiagramNodeComments(File diagram, NodeRemoveDto nodeRemoveDto, String nodeId) {
    var comments = commentRepository.findByFileAndReference(diagram, nodeId);
    commentRepository.deleteAll(comments);

    comments.forEach(comment ->
      pusherService.removeDiagramCommentNotification(comment, nodeRemoveDto.getOriginAppInstanceId()));
  }
}
