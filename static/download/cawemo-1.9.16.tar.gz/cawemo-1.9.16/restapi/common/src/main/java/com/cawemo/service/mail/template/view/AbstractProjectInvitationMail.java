/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.mail.template.view;

import com.cawemo.data.entity.User;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

@Getter
public abstract class AbstractProjectInvitationMail extends View {

  private final String message;
  private final String inviteLink;

  AbstractProjectInvitationMail(User user, String message, String inviteLink) {
    super("project_invitation", user);
    this.message = StringUtils.defaultIfBlank(message, null);
    this.inviteLink = inviteLink;
  }
}
