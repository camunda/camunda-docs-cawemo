/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.organization;

import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.User;
import com.cawemo.service.project.ProjectPermissionLevel;
import com.cawemo.service.project.ProjectPermissionWithAdmins;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor(access = AccessLevel.PACKAGE)
class OrganizationCollaborator {

  private final String id;
  private final String name;
  private final String email;
  private final OrganizationPermissionLevel access;
  private final List<ProjectAccess> projects = new ArrayList<>();

  OrganizationCollaborator(User user, OrganizationPermissionLevel access) {
    this(user.getId(), user.getName(), user.getEmail(), access);
  }

  public List<ProjectAccess> getProjects() {
    return projects.stream()
      .sorted(Comparator.comparing(access -> access.project.getName()))
      .collect(Collectors.toList());
  }

  void addProjectAccess(ProjectAccess access) {
    projects.add(access);
  }

  void addProjectAccess(ProjectPermissionWithAdmins permissionWithAdmins) {
    addProjectAccess(ProjectAccess.of(permissionWithAdmins));
  }

  @Getter
  @RequiredArgsConstructor(access = AccessLevel.PROTECTED)
  public static class ProjectAccess {

    private final Project project;
    private final ProjectPermissionLevel permissionAccess;
    private final List<User> admins;

    private static ProjectAccess of(ProjectPermissionWithAdmins permissionWithAdmins) {
      var permission = permissionWithAdmins.getPermission();
      var project = permission.getId().getProject();
      return new ProjectAccess(project, permission.getAccess(), permissionWithAdmins.getAdmins());
    }
  }
}
