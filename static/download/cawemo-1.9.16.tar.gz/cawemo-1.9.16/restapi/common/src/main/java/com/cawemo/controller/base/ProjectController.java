/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.base;

import com.cawemo.data.dto.base.request.EmailDto;
import com.cawemo.data.dto.base.request.ProjectCollaboratorUpdateDto;
import com.cawemo.data.dto.base.request.ProjectCreateDto;
import com.cawemo.data.dto.base.request.ProjectUpdateDto;
import com.cawemo.data.dto.base.response.ProjectCollaboratorDto;
import com.cawemo.data.dto.base.response.ProjectDto;
import com.cawemo.data.dto.base.response.ProjectListWrapperDto;
import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.Project;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.project.AbstractProjectCollaboratorModifier;
import com.cawemo.service.project.ProjectCollaboratorMapper;
import com.cawemo.service.project.ProjectMapper;
import com.cawemo.service.project.ProjectPermissionService;
import com.cawemo.service.project.ProjectService;
import com.cawemo.util.swagger.SwaggerUuidParameter;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Projects")
@RestController
@RequiredArgsConstructor
public class ProjectController implements InternalApiController {

  private final AbstractProjectCollaboratorModifier projectCollaboratorModifier;
  private final ProjectMapper projectMapper;
  private final ProjectCollaboratorMapper projectCollaboratorMapper;
  private final ProjectPermissionService permissionService;
  private final ProjectService projectService;

  @PreAuthorize("hasPermission(#project, T(ProjectOperation).VIEW_PROJECT)")
  @GetMapping(path = "/projects/{projectId}", produces = MediaType.APPLICATION_JSON_VALUE)
  public ProjectDto getProject(@SwaggerUuidParameter @PathVariable(name = "projectId") Project project,
                               @AuthenticationPrincipal UserAwareUserDetails userDetails) {
    return projectService.getProjectInfoIncludingFoldersAndFiles(project, userDetails.getUser());
  }

  @PreAuthorize("hasPermission(#organization, T(OrganizationOperation).VIEW_PROJECTS)")
  @GetMapping(path = "/organizations/{organizationId}/projects", produces = MediaType.APPLICATION_JSON_VALUE)
  public ProjectListWrapperDto getProjects(@SwaggerUuidParameter
                                             @PathVariable(name = "organizationId") Organization organization,
                                           @AuthenticationPrincipal UserAwareUserDetails userDetails) {
    var projects = projectService.getAllAccessibleProjects(organization, userDetails.getUser());
    return new ProjectListWrapperDto(projects);
  }

  @PreAuthorize("hasPermission(#organization, T(OrganizationOperation).VIEW_ORGANIZATION_DATA)")
  @GetMapping(path = "/organizations/{organizationId}/admin-projects", produces = MediaType.APPLICATION_JSON_VALUE)
  public ProjectListWrapperDto getAllProjects(@SwaggerUuidParameter
                                              @PathVariable(name = "organizationId") Organization organization) {
    var projects = projectMapper.asProjectDtoList(
      projectService.findProjectsWithAdminsByOrganization(organization));
    return new ProjectListWrapperDto(projects);
  }

  @PreAuthorize("hasPermission(#dto.organizationId, 'com.cawemo.data.entity.Organization', " +
    "T(OrganizationOperation).CREATE_PROJECT) && isProjectTypeSupportedByLicense(#dto.organizationId, #dto.type)")
  @PostMapping(path = "/projects", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public ProjectDto createProject(@Valid @RequestBody @Parameter(required = true) ProjectCreateDto dto,
                                  @AuthenticationPrincipal UserAwareUserDetails userDetails) {
    var user = userDetails.getUser();
    var project = projectService.createProject(dto, user);
    return projectService.getProjectInfoExcludingFoldersAndFiles(project, user);
  }

  @PreAuthorize("hasPermission(#project, T(ProjectOperation).MODIFY_PROJECT) " +
    "&& isProjectTypeSupportedByLicense(#project.organization.id, #project.type)")
  @PatchMapping(path = "/projects/{projectId}", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void updateProject(@SwaggerUuidParameter @PathVariable(name = "projectId") Project project,
                            @Valid @RequestBody @Parameter(required = true) ProjectUpdateDto dto) {
    projectService.updateProject(project, dto);
  }

  @PreAuthorize("hasPermission(#project, T(ProjectOperation).DELETE_PROJECT)")
  @DeleteMapping(path = "/projects/{projectId}")
  public void deleteProject(@SwaggerUuidParameter @PathVariable(name = "projectId") Project project) {
    projectService.deleteProject(project);
  }

  @PreAuthorize("hasPermissionToCollection(#projectIds, 'java.lang.String', 'com.cawemo.data.entity.Project', " +
    "T(ProjectOperation).DELETE_PROJECT)")
  @DeleteMapping(value = "/projects", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void deleteProjects(@Parameter(description = "IDs of projects to be deleted", required = true)
                             @RequestBody List<String> projectIds) {
    projectService.deleteProjects(projectIds);
  }

  @PreAuthorize("hasPermission(#project, T(ProjectOperation).VIEW_PROJECT)")
  @GetMapping(value = "/projects/{projectId}/collaborators", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<ProjectCollaboratorDto> getCollaborators(@PathVariable("projectId") Project project,
                                                       @AuthenticationPrincipal UserAwareUserDetails userDetails) {
    return permissionService.getCollaborators(project, userDetails.getUser())
      .stream()
      .map(projectCollaboratorMapper::asCollaboratorDto)
      .sorted(Comparator.comparing(ProjectCollaboratorDto::getEmail))
      .collect(Collectors.toList());
  }

  @PreAuthorize("hasPermission(#project, T(ProjectOperation).MODIFY_PERMISSIONS) || " +
    "hasPermission(#project, T(ProjectOperation).LEAVE_PROJECT)")
  @DeleteMapping(value = "/projects/{projectId}/collaborators", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void removeCollaborator(@AuthenticationPrincipal UserAwareUserDetails userDetails,
                                 @PathVariable("projectId") Project project,
                                 @Valid @RequestBody EmailDto dto) {
    projectCollaboratorModifier.deleteProjectPermission(userDetails.getUser(), project, dto.getEmail());
  }

  @PreAuthorize("hasPermission(#project, T(ProjectOperation).MODIFY_PERMISSIONS)")
  @PatchMapping(value = "/projects/{projectId}/collaborators", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void updateCollaborator(@PathVariable("projectId") Project project,
                                 @Valid @RequestBody ProjectCollaboratorUpdateDto dto) {
    projectCollaboratorModifier.updateProjectPermission(project, dto);
  }
}
