/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.configuration.security;

import com.cawemo.security.authentication.PathAwareRememberMeAuthenticationFilter;
import com.cawemo.security.authentication.PreAuthenticatedLoginFilter;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.security.authentication.cookie.SessionCookieRememberMeService;
import com.cawemo.security.authentication.key.EngineApiKeyRememberMeService;
import com.cawemo.security.authentication.key.UnifiedApiKeyRememberMeService;
import com.cawemo.util.logging.RequestLoggingFilter;
import java.util.EnumMap;
import java.util.Map;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.RememberMeAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.data.repository.query.SecurityEvaluationContextExtension;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.logout.LogoutFilter;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;
import org.springframework.security.web.authentication.rememberme.RememberMeAuthenticationFilter;
import org.springframework.security.web.util.matcher.AndRequestMatcher;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.NegatedRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;

@EnableWebSecurity
@RequiredArgsConstructor
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

  public static final String REMEMBER_ME_KEY = "cawemo";
  private static final String LOGIN_URL = "/internal-api/login";
  private static final Map<HttpMethod, String[]> UNAUTHENTICATED_ROUTES = new EnumMap<>(HttpMethod.class);

  public static final String[] REQUEST_LOGGING_EXCLUDED_PATHS = {
    "/health/**",
    "/info",
    "/metrics"
  };

  private final LogoutSuccessHandler logoutSuccessHandler;
  private final AuthenticationFailureHandler failureHandler;
  private final SessionCookieRememberMeService sessionCookieRememberMeService;
  private final EngineApiKeyRememberMeService engineApiKeyRememberMeService;
  private final UnifiedApiKeyRememberMeService unifiedApiKeyRememberMeService;

  // can be used to add additional configuration in saas or enterprise module
  private final Optional<AbstractHttpConfigurer<?, HttpSecurity>> additionalConfigurer;

  static {
    var getRoutes = new String[]{
      "/internal-api/dry-run/delete/users/iam/*",
      "/internal-api/invitations/*",
      "/internal-api/license-check",
      "/internal-api/projects/*/invitations/*",
      "/internal-api/self/name",
      "/internal-api/shares/*",
      "/internal-api/tokens/*",
      "/internal-api/tokens",
      "/error",
      "/health",
      "/health/**",
      "/info",
      "/metrics",
      "/swagger-ui.html",
      "/swagger-ui/**",
      "/v3/api-docs",
      "/v3/api-docs/*"
    };
    UNAUTHENTICATED_ROUTES.put(HttpMethod.GET, getRoutes);

    var postRoutes = new String[]{
      LOGIN_URL,
      "/internal-api/shares/*/authenticate"
    };
    UNAUTHENTICATED_ROUTES.put(HttpMethod.POST, postRoutes);

    var putRoutes = new String[]{
      "/internal-api/users/iam/*"
    };
    UNAUTHENTICATED_ROUTES.put(HttpMethod.PUT, putRoutes);

    var deleteRoutes = new String[]{
      "/internal-api/users/iam/*"
    };
    UNAUTHENTICATED_ROUTES.put(HttpMethod.DELETE, deleteRoutes);
  }

  @Override
  protected void configure(HttpSecurity http) throws Exception {
    http
      .csrf().disable()

      .sessionManagement()
      .sessionCreationPolicy(SessionCreationPolicy.STATELESS)

      .and()
      .formLogin().disable()
      .addFilter(preAuthenticatedLoginFilter())

      .logout()
      .logoutUrl("/internal-api/logout")
      .logoutSuccessHandler(logoutSuccessHandler)
      .permitAll()

      .and()
      .exceptionHandling()
      .authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED))

      .and()
      // exclude "/health/**" and "/info" to not log every Kubernetes readiness/liveness probe request
      .addFilterBefore(new RequestLoggingFilter(REQUEST_LOGGING_EXCLUDED_PATHS), LogoutFilter.class)

      // TODO #5275: Split this into multiple HttpSecurity
      .addFilterBefore(internalApiSessionAuthenticationFilter(), AbstractPreAuthenticatedProcessingFilter.class)
      .addFilterBefore(adminApiSessionAuthenticationFilter(), AbstractPreAuthenticatedProcessingFilter.class)
      .addFilterBefore(unifiedApiKeyAuthenticationFilter(), AbstractPreAuthenticatedProcessingFilter.class)
      .addFilterBefore(engineApiKeyAuthenticationFilter(), AbstractPreAuthenticatedProcessingFilter.class)

      .authorizeRequests(authorizeRequests -> UNAUTHENTICATED_ROUTES
        .forEach((httpMethod, routes) -> authorizeRequests.antMatchers(httpMethod, routes).permitAll()))

      .authorizeRequests()
      .anyRequest()
      .authenticated();

    if (additionalConfigurer.isPresent()) {
      http.apply(additionalConfigurer.get());
    }
  }

  @Override
  protected void configure(AuthenticationManagerBuilder auth) {
    auth
      .authenticationProvider(preAuthenticatedAuthenticationProvider())
      .authenticationProvider(rememberMeAuthenticationProvider());
  }

  @Bean
  @Override
  public AuthenticationManager authenticationManagerBean() throws Exception {
    return super.authenticationManagerBean();
  }

  @Bean
  public PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder(12);
  }

  @Bean
  public SecurityEvaluationContextExtension securityEvaluationContextExtension() {
    return new SecurityEvaluationContextExtension();
  }

  @Bean
  public PreAuthenticatedLoginFilter preAuthenticatedLoginFilter() throws Exception {
    var filter = new PreAuthenticatedLoginFilter(LOGIN_URL);
    filter.setAuthenticationFailureHandler(failureHandler);
    filter.setAuthenticationManager(authenticationManagerBean());
    filter.setContinueFilterChainOnUnsuccessfulAuthentication(false);
    return filter;
  }

  @Bean
  public PreAuthenticatedAuthenticationProvider preAuthenticatedAuthenticationProvider() {
    var provider = new PreAuthenticatedAuthenticationProvider();
    provider.setPreAuthenticatedUserDetailsService(token -> (UserAwareUserDetails) token.getPrincipal());
    return provider;
  }

  @Bean
  public RememberMeAuthenticationProvider rememberMeAuthenticationProvider() {
    return new RememberMeAuthenticationProvider(REMEMBER_ME_KEY);
  }

  private RememberMeAuthenticationFilter internalApiSessionAuthenticationFilter() throws Exception {
    var matcher = new AndRequestMatcher(new AntPathRequestMatcher("/internal-api/**"),
      new NegatedRequestMatcher(new AntPathRequestMatcher(LOGIN_URL)));
    return new PathAwareRememberMeAuthenticationFilter(matcher, authenticationManagerBean(),
      sessionCookieRememberMeService);
  }

  private RememberMeAuthenticationFilter adminApiSessionAuthenticationFilter() throws Exception {
    var matcher = new AntPathRequestMatcher("/adminApi/**");
    return new PathAwareRememberMeAuthenticationFilter(matcher, authenticationManagerBean(),
      sessionCookieRememberMeService);
  }

  // TODO #8949: Remove Once Legacy Authentication Has Been Deprecated
  private RememberMeAuthenticationFilter engineApiKeyAuthenticationFilter() throws Exception {
    var matcher = new AntPathRequestMatcher("/pluginApi/engine/**");
    return new PathAwareRememberMeAuthenticationFilter(matcher, authenticationManagerBean(),
      engineApiKeyRememberMeService);
  }

  private RememberMeAuthenticationFilter unifiedApiKeyAuthenticationFilter() throws Exception {
    var matcher = new OrRequestMatcher(
      new AntPathRequestMatcher("/api/**"),
      new AntPathRequestMatcher("/pluginApi/modeler/**"),
      new AntPathRequestMatcher("/pluginApi/engine/**")
    );
    return new PathAwareRememberMeAuthenticationFilter(matcher, authenticationManagerBean(),
      unifiedApiKeyRememberMeService);
  }
}
