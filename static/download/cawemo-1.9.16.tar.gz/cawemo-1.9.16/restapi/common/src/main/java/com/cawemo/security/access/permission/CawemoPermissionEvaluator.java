/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.access.permission;

import com.cawemo.service.authentication.AuthenticationService;
import com.cawemo.util.Permission;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;

public class CawemoPermissionEvaluator implements PermissionEvaluator, EvaluatorRegistry {

  private final ConversionService conversionService;
  private final Map<Class<?>, EntityPermissionEvaluator> evaluatorRegistry = new HashMap<>();
  private final Map<Class<?>, EntityCollectionPermissionEvaluator> collectionEvaluatorRegistry = new HashMap<>();

  public CawemoPermissionEvaluator(ConversionService conversionService) {
    this.conversionService = conversionService;
  }

  @Override
  public boolean hasPermission(Authentication authentication, Object targetDomainObject, Object permission) {
    if (!(permission instanceof Permission)) {
      throw new IllegalArgumentException("Given class " + permission.getClass().getSimpleName()
        + " not supported for permission checking.");
    }

    if (targetDomainObject == null) {
      return false;
    }

    var targetDomainClass = targetDomainObject.getClass();
    if (!evaluatorRegistry.containsKey(targetDomainClass)) {
      return false;
    }

    var evaluator = evaluatorRegistry.get(targetDomainClass);
    var userDetails = AuthenticationService.getUserDetails(authentication);
    @SuppressWarnings("unchecked")
    var result = evaluator.hasPermission(userDetails, targetDomainObject, (Permission) permission);
    return result;
  }

  @Override
  public boolean hasPermission(Authentication authentication,
                               Serializable targetId,
                               String targetType,
                               Object permission) {

    try {
      var sourceClass = targetId.getClass();
      var targetClass = Class.forName(targetType);

      if (conversionService.canConvert(sourceClass, targetClass)) {
        var conversionResult = conversionService.convert(targetId, targetClass);
        return hasPermission(authentication, conversionResult, permission);
      }
    } catch (ClassNotFoundException e) {
      throw new IllegalArgumentException("Couldn't convert " + targetId.getClass() + " to " + targetType + ". " +
        "This is probably an error in a hasPermission check.");
    }

    return false;
  }

  public boolean hasPermissionToCollection(Authentication authentication,
                                           Collection<?> collection,
                                           String targetElementType,
                                           Permission permission) {
    // make sure that we don't check an invalid collection
    if (containsNull(collection)) {
      return false;
    }

    try {
      var targetClass = Class.forName(targetElementType);

      if (!collection.stream().allMatch(targetClass::isInstance)) {
        throw new IllegalArgumentException("Not all collection entries are an instance of " + targetClass.getName());
      }

      if (!collectionEvaluatorRegistry.containsKey(targetClass)) {
        return false;
      }

      var evaluator = collectionEvaluatorRegistry.get(targetClass);
      var userDetails = AuthenticationService.getUserDetails(authentication);
      return evaluator.hasPermission(userDetails, collection, permission);
    } catch (ClassNotFoundException e) {
      throw new IllegalArgumentException("Could not find class for name " + targetElementType);
    }
  }

  public boolean hasPermissionToCollection(Authentication authentication,
                                           Collection<?> collection,
                                           String sourceElementType,
                                           String targetElementType,
                                           Permission permission) {
    // make sure that we don't check an invalid collection
    if (containsNull(collection)) {
      return false;
    }

    try {
      var sourceClass = Class.forName(sourceElementType);
      var targetClass = Class.forName(targetElementType);

      if (!collectionEvaluatorRegistry.containsKey(targetClass)) {
        return false;
      }

      var sourceDesc = TypeDescriptor.collection(collection.getClass(), TypeDescriptor.valueOf(sourceClass));
      var targetDesc = TypeDescriptor.collection(collection.getClass(), TypeDescriptor.valueOf(targetClass));

      if (conversionService.canConvert(sourceDesc, targetDesc)) {
        var conversionResult = (Collection<?>) conversionService.convert(collection, sourceDesc, targetDesc);
        var userDetails = AuthenticationService.getUserDetails(authentication);
        var evaluator = collectionEvaluatorRegistry.get(targetClass);
        @SuppressWarnings("unchecked")
        var result = evaluator.hasPermission(userDetails, conversionResult, permission);
        return result;
      }
    } catch (ClassNotFoundException e) {
      throw new IllegalArgumentException("Could not convert collection of " + sourceElementType + " to collection of "
        + targetElementType + ". This is probably an error in a hasPermissionToCollection check.");
    }

    return false;
  }

  @Override
  public <T> void addEvaluator(Class<T> type, EntityPermissionEvaluator<? extends T, ? extends Permission> evaluator) {
    evaluatorRegistry.put(type, evaluator);
  }

  @Override
  public <T> void addEvaluator(Class<T> type,
                               EntityCollectionPermissionEvaluator<? extends T, ? extends Permission> evaluator) {
    collectionEvaluatorRegistry.put(type, evaluator);
  }

  private boolean containsNull(Collection<?> collection) {
    return collection.stream().anyMatch(Objects::isNull);
  }
}
