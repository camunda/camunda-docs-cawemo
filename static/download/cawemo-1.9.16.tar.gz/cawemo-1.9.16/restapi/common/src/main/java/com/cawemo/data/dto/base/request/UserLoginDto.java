/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import com.cawemo.util.Constants;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * The data in this DTO is received from IAM (through the webapp) and stored in Cawemo, too.<br/><br/>
 * {@link #iamId}: user's UUID in IAM; maps to  {@link com.cawemo.data.entity.User#iamId}<br/>
 * {@link #name}: concatenation of first name and last name; maps to  {@link com.cawemo.data.entity.User#name}<br/>
 * {@link #email}: user's e-mail address; maps to {@link com.cawemo.data.entity.User#email}<br/>
 * {@link #verified}: e-mail address already verified? maps to {@link com.cawemo.data.entity.User#verified}<br/><br/>
 * The {@link com.cawemo.data.entity.User#username} is stored in Cawemo only.<br/>
 * The user's password is stored in IAM only.
 */
@Data
@Accessors(chain = true)
public class UserLoginDto {

  @NotBlank
  @Size(max = Constants.VARCHAR_MAX)
  private String iamId;

  @NotBlank
  @Size(max = Constants.VARCHAR_MAX)
  private String name;

  @NotBlank
  @Size(max = Constants.EMAIL_MAX_LENGTH)
  private String email;

  private boolean verified;

  private String inviteToken;
}
