/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import com.cawemo.data.validation.constraint.Email;
import com.cawemo.data.validation.constraint.InviteLimit;
import com.cawemo.util.Constants;
import java.util.Set;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class FileShareEmailDto {

  @NotEmpty
  @InviteLimit
  private Set<@NotBlank @Email String> emails;

  @Pattern(regexp = Constants.DOES_NOT_CONTAIN_URL_PATTERN, flags = Pattern.Flag.DOTALL)
  private String message;
}
