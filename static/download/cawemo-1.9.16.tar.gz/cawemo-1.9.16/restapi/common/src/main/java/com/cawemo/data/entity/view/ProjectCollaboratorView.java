/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity.view;

import com.cawemo.service.project.ProjectPermissionLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class ProjectCollaboratorView {

  private final String id;
  private final String name;
  private final String email;
  private final String username;
  private final String projectId;
  private final ProjectPermissionLevel permissionAccess;
}
