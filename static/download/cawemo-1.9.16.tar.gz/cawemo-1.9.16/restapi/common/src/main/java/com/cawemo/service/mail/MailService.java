/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.mail;

import com.cawemo.data.dto.base.request.FileShareEmailDto;
import com.cawemo.data.entity.Comment;
import com.cawemo.data.entity.FileShare;
import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.User;
import com.cawemo.service.mail.template.view.MentionMail;
import com.cawemo.service.mail.template.view.OrganizationAdminPermissionGrantedMail;
import com.cawemo.service.mail.template.view.OrganizationAdminPermissionRevokedMail;
import com.cawemo.service.mail.template.view.ShareDiagramMail;
import com.cawemo.service.project.ProjectPermissionService;
import com.cawemo.util.SetUtil;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MailService {

  // make sure to keep this regex in sync with UserService#generateUsername
  private static final Pattern MENTION_COLLABORATOR_PATTERN = Pattern.compile("@([\\w._-]+)");
  private static final String DIAGRAM_LINK_TEMPLATE = "%s/diagrams/%s";
  private static final String SETTINGS_LINK_TEMPLATE = "%s/settings";
  private static final String SETTINGS_LINK_WITH_ORGANIZATION_ID_TEMPLATE = "%s/settings?organizationId=%s";
  private static final String FILE_SHARE_LINK_TEMPLATE = "%s/shares/%s";

  protected final CustomServerProperties properties;
  protected final CawemoMailSender mailSender;
  protected final ProjectPermissionService permissionService;

  public void sendMailToMentionedCollaborators(User user, Comment comment) {
    var commentLink = String.format(DIAGRAM_LINK_TEMPLATE, properties.url(), comment.getFile().getId());
    var settingsLink = String.format(SETTINGS_LINK_TEMPLATE, properties.url());
    var view = new MentionMail(user, comment.getContent(), commentLink, settingsLink);

    var mentionedUsernames = MENTION_COLLABORATOR_PATTERN.matcher(comment.getContent())
      .results()
      .map(matchResult -> matchResult.group(1))
      .collect(Collectors.toList());

    var userEmails = permissionService
      .findPermissionsForSubscribedUsersExcludingReadAccess(mentionedUsernames, comment.getFile().getProject())
      .stream()
      .map(p -> p.getId().getUser().getEmail())
      .collect(Collectors.toList());

    mailSender.sendMail(userEmails, view);
  }

  public void sendDiagramShareMails(User user, FileShare fileShare, FileShareEmailDto dto) {
    var link = String.format(FILE_SHARE_LINK_TEMPLATE, properties.url(), fileShare.getId());
    var view = new ShareDiagramMail(user, dto.getMessage(), link);
    var emails = SetUtil.toLowerCaseIgnoringDuplicates(dto.getEmails());

    mailSender.sendMail(emails, view);
  }

  public void sendOrganizationAdminPermissionGrantedMail(User authenticatedUser, User permissionUser,
                                                         Organization organization) {
    var link = String.format(SETTINGS_LINK_WITH_ORGANIZATION_ID_TEMPLATE, properties.url(), organization.getId());
    var view = new OrganizationAdminPermissionGrantedMail(authenticatedUser, organization, link);
    mailSender.sendMail(permissionUser.getName(), permissionUser.getEmail(), view);
  }

  public void sendOrganizationAdminPermissionRevokedMail(User authenticatedUser, User permissionUser,
                                                         Organization organization) {
    var view = new OrganizationAdminPermissionRevokedMail(authenticatedUser, organization);
    mailSender.sendMail(permissionUser.getName(), permissionUser.getEmail(), view);
  }
}
