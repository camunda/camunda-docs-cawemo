/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.response;

import com.cawemo.service.project.ProjectPermissionLevel;
import com.cawemo.service.project.ProjectType;
import java.time.ZonedDateTime;
import java.util.List;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class ProjectDto {

  private String id;
  private String name;
  private String slug;
  private ProjectPermissionLevel permissionAccess;
  private List<ProjectCollaboratorDto> collaborators;
  private List<FileWithoutContentDto> files;
  private List<FolderChildDto> folders;
  private Integer filesCount;
  private ZonedDateTime created;
  private ZonedDateTime lastModified;
  private ProjectType type;
  private String organizationId;
  private List<ProjectCollaboratorDto> admins;
}
