/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.access.method;

import com.cawemo.security.access.feature.FeatureEvaluator;
import com.cawemo.security.access.permission.FileTypeEvaluator;
import com.cawemo.service.organization.OrganizationOperation;
import com.cawemo.service.project.ProjectOperation;
import com.cawemo.util.Feature;
import java.util.ArrayList;
import java.util.List;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.context.ApplicationContext;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.expression.spel.support.StandardTypeLocator;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
import org.springframework.security.access.expression.method.MethodSecurityExpressionOperations;
import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

@Component
public class CawemoMethodSecurityExpressionHandler extends DefaultMethodSecurityExpressionHandler {

  private final List<Class<?>> typeLocatorImports = new ArrayList<>();
  private final FeatureEvaluator featureEvaluator;
  private final FileTypeEvaluator fileTypeEvaluator;

  public CawemoMethodSecurityExpressionHandler(ApplicationContext applicationContext,
                                               PermissionEvaluator permissionEvaluator,
                                               FeatureEvaluator featureEvaluator,
                                               FileTypeEvaluator fileTypeEvaluator) {
    setPermissionEvaluator(permissionEvaluator);
    setTrustResolver(new AuthenticationTrustResolverImpl());
    setApplicationContext(applicationContext);
    this.featureEvaluator = featureEvaluator;
    this.fileTypeEvaluator = fileTypeEvaluator;

    addTypeLocatorImport(ProjectOperation.class);
    addTypeLocatorImport(OrganizationOperation.class);
    addTypeLocatorImport(Feature.class);
  }

  @Override
  public StandardEvaluationContext createEvaluationContextInternal(Authentication auth, MethodInvocation invocation) {
    var standardEvaluationContext = super.createEvaluationContextInternal(auth, invocation);
    var standardTypeLocator = (StandardTypeLocator) standardEvaluationContext.getTypeLocator();
    typeLocatorImports.forEach(cls -> standardTypeLocator.registerImport(cls.getPackageName()));
    return standardEvaluationContext;
  }

  @Override
  protected MethodSecurityExpressionOperations createSecurityExpressionRoot(Authentication authentication,
                                                                            MethodInvocation invocation) {
    var root = new CawemoMethodSecurityExpressionRoot(authentication, featureEvaluator, fileTypeEvaluator);
    root.setThis(invocation.getThis());
    root.setPermissionEvaluator(getPermissionEvaluator());
    root.setTrustResolver(getTrustResolver());
    root.setRoleHierarchy(getRoleHierarchy());
    root.setDefaultRolePrefix(getDefaultRolePrefix());
    return root;
  }

  protected void addTypeLocatorImport(Class<?> locatorImport) {
    typeLocatorImports.add(locatorImport);
  }
}
