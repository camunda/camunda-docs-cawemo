/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.base;

import com.cawemo.data.dto.base.request.OrganizationCollaboratorUpdateDto;
import com.cawemo.data.dto.base.request.OrganizationUpdateDto;
import com.cawemo.data.dto.base.response.OrganizationCollaboratorDto;
import com.cawemo.data.dto.base.response.OrganizationDetailsDto;
import com.cawemo.data.entity.Organization;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.organization.OrganizationCollaboratorMapper;
import com.cawemo.service.organization.OrganizationCollaboratorProvider;
import com.cawemo.service.organization.OrganizationDetailsMapper;
import com.cawemo.service.organization.OrganizationDetailsProvider;
import com.cawemo.service.organization.OrganizationPermissionService;
import com.cawemo.service.organization.OrganizationPermissionUpdater;
import com.cawemo.service.organization.OrganizationService;
import com.cawemo.util.swagger.SwaggerUuidParameter;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Organization")
@RestController
@RequiredArgsConstructor
public class OrganizationController implements InternalApiController {

  private final OrganizationService organizationService;
  private final OrganizationCollaboratorMapper organizationCollaboratorMapper;
  private final OrganizationCollaboratorProvider organizationCollaboratorProvider;
  private final OrganizationDetailsMapper organizationDetailsMapper;
  private final OrganizationDetailsProvider organizationDetailsProvider;
  private final OrganizationPermissionService organizationPermissionService;
  private final OrganizationPermissionUpdater organizationPermissionUpdater;

  @PreAuthorize("hasPermission(#organization, T(OrganizationOperation).VIEW_ORGANIZATION_DATA)")
  @GetMapping(path = "/organizations/{organizationId}/collaborators", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<OrganizationCollaboratorDto> getCollaborators(@SwaggerUuidParameter @PathVariable(name = "organizationId")
                                                              Organization organization) {
    return organizationCollaboratorMapper
      .asOrganizationCollaboratorDtoList(organizationCollaboratorProvider.getOrganizationCollaborators(organization));
  }

  @PreAuthorize("hasPermission(#organization, T(OrganizationOperation).MODIFY_COLLABORATOR_PERMISSION)")
  @PatchMapping(path = "/organizations/{organizationId}/collaborators", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void updateCollaborator(
    @SwaggerUuidParameter @PathVariable(name = "organizationId") Organization organization,
    @Valid @RequestBody @Parameter(required = true) OrganizationCollaboratorUpdateDto dto,
    @AuthenticationPrincipal UserAwareUserDetails userDetails) {
    var permission = organizationPermissionService.getByOrganizationAndUserEmail(organization, dto.getEmail());
    if (permission.getAccess() != dto.getPermissionAccess()) {
      var user = userDetails.getUser();
      organizationPermissionUpdater.updatePermissionAccess(permission, dto.getPermissionAccess(), user);
      organizationPermissionService.sendOrganizationPermissionChangedMail(permission, user);
    }
  }

  @PreAuthorize("hasPermission(#organization, T(OrganizationOperation).MODIFY_ORGANIZATION)")
  @PatchMapping(path = "/organizations/{organizationId}", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public OrganizationDetailsDto patchOrganization(@SwaggerUuidParameter @PathVariable("organizationId")
                                                    Organization organization,
                                                  @Valid @RequestBody @Parameter(required = true)
                                                    OrganizationUpdateDto dto) {
    var updatedOrganization = organizationService.updateOrganization(organization, dto);
    return organizationDetailsMapper.asDto(organizationDetailsProvider.getOrganizationDetails(updatedOrganization));
  }
}
