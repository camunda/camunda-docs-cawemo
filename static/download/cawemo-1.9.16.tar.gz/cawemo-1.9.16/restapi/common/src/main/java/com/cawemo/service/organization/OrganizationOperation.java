/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.organization;

import com.cawemo.util.Permission;

public enum OrganizationOperation implements Permission {

  /**
   * View full details of the organization including collaborators and projects.
   */
  VIEW_ORGANIZATION_DATA,
  MODIFY_ORGANIZATION,

  VIEW_PROJECTS,
  CREATE_PROJECT,
  REMOVE_COLLABORATOR,
  MODIFY_COLLABORATOR_PERMISSION,

  MODIFY_API_KEY,
  VIEW_API_KEYS,

  VIEW_USERS
}
