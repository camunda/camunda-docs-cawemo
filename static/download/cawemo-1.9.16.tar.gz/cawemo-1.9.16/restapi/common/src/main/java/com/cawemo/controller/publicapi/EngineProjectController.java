/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.publicapi;

import com.cawemo.data.dto.publicapi.request.EngineProjectCreateDto;
import com.cawemo.data.dto.publicapi.response.PublicApiEngineProjectDto;
import com.cawemo.security.authentication.ApiKeyAwareUserDetails;
import com.cawemo.service.project.ProjectMapper;
import com.cawemo.service.project.ProjectService;
import com.cawemo.service.project.ProjectType;
import com.cawemo.util.Constants;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Public API: Engine Projects")
@RequiredArgsConstructor
@RestController
@Validated
public class EngineProjectController implements PublicApiController {

  private final ProjectMapper projectMapper;
  private final ProjectService projectService;

  @PreAuthorize(
    "hasPermission(#userDetails.apiKey.organization, T(OrganizationOperation).CREATE_PROJECT)"
  )
  @PostMapping(path = "/engine-projects", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public PublicApiEngineProjectDto createEngineProject(@Valid @RequestBody EngineProjectCreateDto dto,
                                                       @AuthenticationPrincipal ApiKeyAwareUserDetails userDetails) {

    var project = projectService.createProjectForUser(userDetails.getApiKey().getOrganization(), dto.getName(),
      userDetails.getUser(), ProjectType.ENGINE);
    return projectMapper.asPublicApiEngineProjectDto(project);
  }

  @PreAuthorize(
    "hasPermission(#userDetails.apiKey.organization, T(OrganizationOperation).VIEW_PROJECTS)"
  )
  @GetMapping(path = "/engine-projects", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<PublicApiEngineProjectDto> getEngineProjects(
    @RequestParam(required = false) @Size(min = 1, max = Constants.VARCHAR_MAX) String name,
    @AuthenticationPrincipal ApiKeyAwareUserDetails userDetails) {

    var projects = projectService.getEngineProjects(userDetails.getApiKey().getOrganization(), name);
    return projectMapper.asPublicApiEngineProjectDtoList(projects);
  }
}
