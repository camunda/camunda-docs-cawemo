/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.authentication;

import com.cawemo.data.entity.User;
import com.cawemo.data.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationDetailsSource;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserAwareUserDetailsService implements UserDetailsService {

  private final UserRepository userRepository;
  private final AuthenticationDetailsSource<User, UserAwareUserDetails> detailsSource;

  @Override
  public UserDetails loadUserByUsername(String email) {
    return this.userRepository
      .findByEmailIgnoreCase(email)
      .map(detailsSource::buildDetails)
      .orElseThrow(() -> new UsernameNotFoundException(email));
  }
}
