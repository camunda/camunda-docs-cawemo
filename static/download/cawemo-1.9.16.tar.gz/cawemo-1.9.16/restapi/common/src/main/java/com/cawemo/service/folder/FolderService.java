/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.folder;

import com.cawemo.data.dto.base.request.FolderCreateDto;
import com.cawemo.data.dto.base.request.FolderUpdateDto;
import com.cawemo.data.dto.base.request.FoldersMoveDto;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.Folder;
import com.cawemo.data.entity.Project;
import com.cawemo.data.repository.FolderRepository;
import com.cawemo.data.repository.ProjectRepository;
import com.cawemo.util.api.CrossOrganizationOperationForbiddenException;
import com.cawemo.util.api.NoSuchObjectException;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class FolderService {

  private final FolderMapper folderMapper;
  private final FolderRepository folderRepository;
  private final ProjectRepository projectRepository;

  public Folder createFolder(FolderCreateDto dto) {
    var parent = getParent(dto.getParentId());
    var project = getProject(parent, dto.getProjectId());

    return folderRepository.save(folderMapper.asFolder(dto, project, parent));
  }

  public Folder updateFolder(Folder folder, FolderUpdateDto dto) {
    return folderRepository.save(folderMapper.updateFromDto(folder, dto));
  }

  public void deleteFolder(Folder folder) {
    folderRepository.delete(folder);
  }

  @Transactional
  public void moveFolders(FoldersMoveDto dto) {
    var targetParent = getParent(dto.getParentId());
    var targetProject = getProject(targetParent, dto.getProjectId());
    var folders = folderRepository.findFoldersToBeMoved(dto.getFolderIds(), targetProject, targetParent);
    folders.forEach(folder -> {
      ensureNoCrossOrganizationOperation(targetProject, folder);
      folder.setProject(targetProject);
      folder.setParent(targetParent);
      moveFilesInsideFolder(folder, targetProject);
      moveChildFolders(folder, targetProject);
    });
    folderRepository.saveAll(folders);
  }

  /**
   * Neither JPA nor Hibernate support recursive queries so this has to be done via Java and multiple database queries.
   */
  public Set<Folder> getChildrenRecursively(List<String> folderIds) {
    return folderRepository.findAllById(folderIds)
      .stream()
      .map(this::getChildrenRecursively)
      .flatMap(Collection::stream)
      .collect(Collectors.toSet());
  }

  /**
   * Neither JPA nor Hibernate support recursive queries so this has to be done via Java and multiple database queries.
   */
  public Map<Folder, Collection<File>> getFilesRecursively(List<Folder> folders) {
    return folders
      .stream()
      .map(this::getFilesRecursively)
      .collect(HashMap::new, Map::putAll, Map::putAll);
  }

  private Set<Folder> getChildrenRecursively(Folder folder) {
    var children = new HashSet<Folder>();
    folder.getChildren()
      .forEach(child -> {
        children.add(child);
        children.addAll(getChildrenRecursively(child));
      });

    return children;
  }

  private Map<Folder, Collection<File>> getFilesRecursively(Folder folder) {
    var filesByFolder = new HashMap<Folder, Collection<File>>();
    filesByFolder.put(folder, folder.getFiles());
    folder
      .getChildren()
      .forEach(child -> filesByFolder.putAll(getFilesRecursively(child)));

    return filesByFolder;
  }

  private Folder getParent(String parentId) {
    return (parentId == null) ? null :
      folderRepository
        .findById(parentId)
        .orElseThrow(NoSuchObjectException::new);
  }

  private Project getProject(Folder parent, String projectId) {
    return (parent != null) ? parent.getProject() :
      projectRepository
        .findById(projectId)
        .orElseThrow(NoSuchObjectException::new);
  }

  private void ensureNoCrossOrganizationOperation(Project project, Folder folder) {
    if (!folder.getProject().getOrganization().getId().equals(project.getOrganization().getId())) {
      throw new CrossOrganizationOperationForbiddenException();
    }
  }

  private void moveChildFolders(Folder folder, Project targetProject) {
    getChildrenRecursively(folder).forEach(child -> {
      child.setProject(targetProject);
      moveFilesInsideFolder(child, targetProject);
    });
  }

  private void moveFilesInsideFolder(Folder folder, Project targetProject) {
    folder
      .getFiles()
      .forEach(file -> file.setProject(targetProject));
  }
}
