/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller;

import com.cawemo.util.api.BadRequestException;
import com.cawemo.util.api.ForbiddenException;
import com.cawemo.util.api.NotFoundException;
import com.cawemo.util.api.PublicApiErrorMessages;
import com.cawemo.util.api.ServerException;
import java.net.URI;
import org.springframework.beans.TypeMismatchException;
import org.springframework.core.annotation.Order;
import org.springframework.core.convert.ConversionFailedException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.NativeWebRequest;
import org.zalando.problem.Problem;
import org.zalando.problem.Status;
import org.zalando.problem.spring.web.advice.ProblemHandling;
import org.zalando.problem.spring.web.advice.security.SecurityAdviceTrait;

/**
 * Although this advice is mainly aimed at controllers implementing
 * {@link com.cawemo.controller.publicapi.PublicApiController} it has to be unrestricted (i.e. not defining
 * "assignableTypes" or the like) to be able to handle certain types of exceptions,
 * see https://github.com/zalando/problem-spring-web#known-issues
 */
@Order(InternalExceptionHandlingAdvice.ADVICE_ORDER + 1)
@ControllerAdvice
public class DefaultExceptionHandlingAdvice implements ProblemHandling, SecurityAdviceTrait {

  public static final String CONSTRAINT_VIOLATION_TYPE_VALUE =
    "https://docs.camunda.org/cawemo/latest/reference/rest-api/overview/error-codes/#400-bad-request";
  private static final URI CONSTRAINT_VIOLATION_TYPE = URI.create(CONSTRAINT_VIOLATION_TYPE_VALUE);

  @ExceptionHandler
  public ResponseEntity<Problem> handleBadRequestException(BadRequestException e, NativeWebRequest request) {
    var problem = getProblem(Status.BAD_REQUEST, e.getMessage());
    return create(e, problem, request);
  }

  @ExceptionHandler
  public ResponseEntity<Problem> handleForbiddenException(ForbiddenException e, NativeWebRequest request) {
    var problem = getProblem(Status.FORBIDDEN, e.getMessage());
    return create(e, problem, request);
  }

  @ExceptionHandler
  public ResponseEntity<Problem> handleNotFoundException(NotFoundException e, NativeWebRequest request) {
    var message = e.getMessage() != null ? e.getMessage() : PublicApiErrorMessages.RESOURCE_NOT_FOUND;
    var problem = getProblem(Status.NOT_FOUND, message);
    return create(e, problem, request);
  }

  @ExceptionHandler
  public ResponseEntity<Problem> handleConversionFailedException(ConversionFailedException e,
                                                                 NativeWebRequest request) {
    return createNotFound(e, request);
  }

  @ExceptionHandler
  public ResponseEntity<Problem> handleNotFoundException(MissingPathVariableException e, NativeWebRequest request) {
    return createNotFound(e, request);
  }

  @Override
  public ResponseEntity<Problem> handleTypeMismatch(TypeMismatchException e, NativeWebRequest request) {
    return createNotFound(e, request);
  }

  @Override
  public ResponseEntity<Problem> handleAccessDenied(AccessDeniedException e, NativeWebRequest request) {
    return createNotFound(e, request);
  }

  @ExceptionHandler
  public ResponseEntity<Problem> handleServerException(ServerException e, NativeWebRequest request) {
    // message is stripped to not expose internal errors to users
    var problem = getProblem(Status.INTERNAL_SERVER_ERROR, null);
    return create(e, problem, request);
  }

  @Override
  public URI defaultConstraintViolationType() {
    return CONSTRAINT_VIOLATION_TYPE;
  }

  private ResponseEntity<Problem> createNotFound(Throwable e, NativeWebRequest request) {
    var problem = getProblem(Status.NOT_FOUND, PublicApiErrorMessages.RESOURCE_NOT_FOUND);
    return create(e, problem, request);
  }

  private static Problem getProblem(Status internalServerError, String message) {
    return Problem.builder()
      .withTitle(internalServerError.getReasonPhrase())
      .withStatus(internalServerError)
      .withDetail(message)
      .build();
  }
}
