/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.pusher;

import com.cawemo.service.pusher.PusherEvent;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class PusherMessage {

  private String type;

  private String payload;

  public PusherMessage setType(PusherEvent event) {
    this.type = event.getMessageType();
    return this;
  }

  public PusherMessage setType(String type) {
    this.type = type;
    return this;
  }
}
