/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.data.entity.File;
import com.cawemo.data.entity.User;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

@Getter
public class FileUpdateEvent extends ApplicationEvent {

  private final User user;
  private final String originAppInstanceId;

  public FileUpdateEvent(File source, User user, String originAppInstanceId) {
    super(source);
    this.user = user;
    this.originAppInstanceId = originAppInstanceId;
  }

  @Override
  public File getSource() {
    return (File) super.getSource();
  }
}
