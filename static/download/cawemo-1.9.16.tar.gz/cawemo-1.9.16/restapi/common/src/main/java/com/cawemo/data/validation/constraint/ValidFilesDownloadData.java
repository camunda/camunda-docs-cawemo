/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.validation.constraint;

import com.cawemo.data.validation.ValidFilesDownloadDataValidator;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;

@Target({ElementType.TYPE, ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = ValidFilesDownloadDataValidator.class)
public @interface ValidFilesDownloadData {

  String message() default "fileIds and folderIds must not both be empty";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}
