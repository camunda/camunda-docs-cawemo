/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.access.permission;

import com.cawemo.data.entity.Folder;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.project.ProjectOperation;
import java.util.Collection;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class FolderPermissionEvaluator implements EntityPermissionEvaluator<Folder, ProjectOperation>,
                                                  EntityCollectionPermissionEvaluator<Folder, ProjectOperation> {

  private final ProjectPermissionEvaluator projectPermissionEvaluator;

  @Override
  public boolean hasPermission(UserAwareUserDetails userDetails, Folder folder, ProjectOperation projectOperation) {
    return projectPermissionEvaluator.hasPermission(userDetails, folder.getProject(), projectOperation);
  }

  @Override
  public boolean hasPermission(UserAwareUserDetails userDetails, Collection<Folder> folders,
                               ProjectOperation projectOperation) {
    var projects = folders.stream().map(Folder::getProject).collect(Collectors.toList());
    return projectPermissionEvaluator.hasPermission(userDetails, projects, projectOperation);
  }
}
