/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.ProjectInvitation;
import com.cawemo.data.entity.view.InvitedCollaboratorView;
import com.cawemo.data.entity.view.ProjectInvitationAdminView;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ProjectInvitationRepository extends JpaRepository<ProjectInvitation, String> {

  List<ProjectInvitation> findByInvitedEmailIgnoreCase(String email);

  Optional<ProjectInvitation> findByProjectAndInvitedEmailIgnoreCase(Project project, String email);

  List<ProjectInvitation> findByProjectAndInvitedEmailIgnoreCaseIn(Project project, Iterable<String> emails);

  List<ProjectInvitation> findByProjectOrganizationAndInvitedEmailIgnoreCase(Organization organization, String email);

  @Query("SELECT DISTINCT " +
    "new com.cawemo.data.entity.view.InvitedCollaboratorView(u.id, u.name, pi.invitedEmail) " +
    "FROM ProjectInvitation pi " +
    "INNER JOIN pi.project p " +
    "LEFT JOIN User u ON lower(pi.invitedEmail) = lower(u.email) " +
    "WHERE p.organization = :organization AND NOT EXISTS " +
    "(SELECT 1 FROM OrganizationPermission op JOIN op.id.user u " +
    "WHERE op.id.organization = :organization AND lower(u.email) = lower(pi.invitedEmail))")
  List<InvitedCollaboratorView> getInvitedUsersWithoutOrganizationPermission(@Param("organization")
                                                                               Organization organization);

  @Query("SELECT new com.cawemo.data.entity.view.ProjectInvitationAdminView(pi, pp.id.user) " +
    "FROM ProjectInvitation pi " +
    "INNER JOIN pi.project p " +
    "INNER JOIN ProjectPermission pp ON pp.id.project = p " +
    "AND pp.access = com.cawemo.service.project.ProjectPermissionLevel.OWNER " +
    "WHERE p.organization = :organization AND lower(pi.invitedEmail) = lower(:email) ")
  List<ProjectInvitationAdminView> getInvitationsWithProjectAdminsForOrganizationAndInvitedEmail(
    @Param("organization") Organization organization, @Param("email") String email);

  @Query("SELECT " +
    "new com.cawemo.data.entity.view.InvitedCollaboratorView(u.id, u.name, pi.invitedEmail, pi.token, pi.access) " +
    "FROM ProjectInvitation pi " +
    "LEFT JOIN User u ON lower(pi.invitedEmail) = lower(u.email) " +
    "WHERE pi.project = :project")
  List<InvitedCollaboratorView> getInvitedCollaboratorsForProject(@Param("project") Project project);
}
