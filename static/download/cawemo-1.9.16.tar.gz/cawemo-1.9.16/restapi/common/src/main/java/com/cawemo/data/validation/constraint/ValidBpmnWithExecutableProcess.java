/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.validation.constraint;

import com.cawemo.data.validation.ValidBpmnWithExecutableProcessValidator;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = ValidBpmnWithExecutableProcessValidator.class)
public @interface ValidBpmnWithExecutableProcess {

  String message() default "The given BPMN is not valid or doesn't contain an executable process with id or diagram";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}
