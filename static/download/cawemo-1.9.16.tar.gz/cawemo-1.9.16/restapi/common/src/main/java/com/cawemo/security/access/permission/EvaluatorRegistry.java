/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.access.permission;

import com.cawemo.util.Permission;

public interface EvaluatorRegistry {

  <T> void addEvaluator(Class<T> type, EntityPermissionEvaluator<? extends T, ? extends Permission> evaluator);

  <T> void addEvaluator(Class<T> type,
                        EntityCollectionPermissionEvaluator<? extends T, ? extends Permission> evaluator);
}
