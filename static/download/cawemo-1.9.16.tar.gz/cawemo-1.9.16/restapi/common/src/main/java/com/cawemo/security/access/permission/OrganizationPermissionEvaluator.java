/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.access.permission;

import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.OrganizationPermissionId;
import com.cawemo.data.repository.OrganizationPermissionRepository;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.organization.OrganizationOperation;
import com.cawemo.service.organization.OrganizationPermissionMatcher;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
public class OrganizationPermissionEvaluator implements EntityPermissionEvaluator<Organization, OrganizationOperation> {

  private final OrganizationPermissionRepository organizationPermissionRepository;

  public OrganizationPermissionEvaluator(@Lazy OrganizationPermissionRepository organizationPermissionRepository) {
    this.organizationPermissionRepository = organizationPermissionRepository;
  }

  @Override
  public boolean hasPermission(UserAwareUserDetails userDetails, Organization organization,
                               OrganizationOperation operation) {
    var id = new OrganizationPermissionId()
      .setUser(userDetails.getUser())
      .setOrganization(organization);
    return organizationPermissionRepository.findById(id)
      .map(permission -> OrganizationPermissionMatcher.isAllowed(permission.getAccess(), operation))
      .orElse(false);
  }
}
