/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.access.permission;

import com.cawemo.data.projection.FileWithoutContent;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.project.ProjectOperation;
import java.util.Collection;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class FileWithoutContentPermissionEvaluator
  implements EntityCollectionPermissionEvaluator<FileWithoutContent, ProjectOperation> {

  private final ProjectPermissionEvaluator projectPermissionEvaluator;

  @Override
  public boolean hasPermission(
    UserAwareUserDetails userDetails, Collection<FileWithoutContent> files, ProjectOperation projectOperation) {
    var projects = files.stream().map(FileWithoutContent::getProject).toList();
    return projectPermissionEvaluator.hasPermission(userDetails, projects, projectOperation);
  }
}
