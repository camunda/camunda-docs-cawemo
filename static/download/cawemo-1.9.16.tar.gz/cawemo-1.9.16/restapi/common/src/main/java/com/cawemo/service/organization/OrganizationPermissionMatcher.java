/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.organization;

import java.util.Collections;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import lombok.experimental.UtilityClass;

@UtilityClass
public class OrganizationPermissionMatcher {

  private static final Map<OrganizationOperation, Set<OrganizationPermissionLevel>> PERMISSIONS =
    new EnumMap<>(OrganizationOperation.class);

  static {
    PERMISSIONS.put(OrganizationOperation.VIEW_ORGANIZATION_DATA,
      EnumSet.of(OrganizationPermissionLevel.ADMIN));
    PERMISSIONS.put(OrganizationOperation.MODIFY_ORGANIZATION,
      EnumSet.of(OrganizationPermissionLevel.ADMIN));

    PERMISSIONS.put(OrganizationOperation.VIEW_PROJECTS,
      EnumSet.of(OrganizationPermissionLevel.ADMIN, OrganizationPermissionLevel.USER));
    PERMISSIONS.put(OrganizationOperation.CREATE_PROJECT,
      EnumSet.of(OrganizationPermissionLevel.ADMIN, OrganizationPermissionLevel.USER));

    // in saas, non-admin users are also allowed to remove themselves; this case is handled directly in
    // SaasOrganizationController#removeCollaborator
    PERMISSIONS.put(OrganizationOperation.REMOVE_COLLABORATOR, EnumSet.of(OrganizationPermissionLevel.ADMIN));

    PERMISSIONS.put(OrganizationOperation.MODIFY_COLLABORATOR_PERMISSION,
      EnumSet.of(OrganizationPermissionLevel.ADMIN));

    PERMISSIONS.put(OrganizationOperation.MODIFY_API_KEY,
      EnumSet.of(OrganizationPermissionLevel.ADMIN, OrganizationPermissionLevel.USER));
    PERMISSIONS.put(OrganizationOperation.VIEW_API_KEYS,
      EnumSet.of(OrganizationPermissionLevel.ADMIN, OrganizationPermissionLevel.USER));

    PERMISSIONS.put(OrganizationOperation.VIEW_USERS,
      EnumSet.of(OrganizationPermissionLevel.ADMIN, OrganizationPermissionLevel.USER));
  }

  public static boolean isAllowed(OrganizationPermissionLevel permissionLevel, OrganizationOperation operation) {
    return PERMISSIONS.get(operation).contains(permissionLevel);
  }

  public static Map<OrganizationOperation, Set<OrganizationPermissionLevel>> getPermissions() {
    return Collections.unmodifiableMap(PERMISSIONS);
  }
}
