/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.base;

import com.cawemo.data.dto.base.request.FolderCreateDto;
import com.cawemo.data.dto.base.request.FolderUpdateDto;
import com.cawemo.data.dto.base.request.FoldersMoveDto;
import com.cawemo.data.dto.base.response.FolderDto;
import com.cawemo.data.entity.Folder;
import com.cawemo.service.file.FileService;
import com.cawemo.service.folder.FolderMapper;
import com.cawemo.service.folder.FolderService;
import com.cawemo.util.swagger.SwaggerUuidParameter;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Folders")
@RestController
@RequiredArgsConstructor
public class FolderController implements InternalApiController {

  private final FileService fileService;
  private final FolderMapper folderMapper;
  private final FolderService folderService;

  @PreAuthorize(
    "#dto.parentId != null ? " +
    "hasPermission(#dto.parentId, 'com.cawemo.data.entity.Folder', T(ProjectOperation).MODIFY_FOLDER) : " +
    "hasPermission(#dto.projectId, 'com.cawemo.data.entity.Project', T(ProjectOperation).MODIFY_FOLDER)")
  @PostMapping(value = "/folders", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public FolderDto createFolder(@Valid @RequestBody @Parameter(required = true) FolderCreateDto dto) {
    return folderMapper.asFolderDto(folderService.createFolder(dto), null);
  }

  @PreAuthorize("hasPermission(#folder.project, T(ProjectOperation).VIEW_PROJECT)")
  @GetMapping(value = "/folders/{folderId}", produces = MediaType.APPLICATION_JSON_VALUE)
  public FolderDto getFolder(@SwaggerUuidParameter @PathVariable(name = "folderId") Folder folder) {
    return folderMapper.asFolderDto(folder, fileService.findByFolder(folder));
  }

  @PreAuthorize("hasPermission(#folder, T(ProjectOperation).MODIFY_FOLDER)")
  @PatchMapping(path = "/folders/{folderId}", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public FolderDto updateFolder(@SwaggerUuidParameter @PathVariable(name = "folderId") Folder folder,
                                @Valid @RequestBody @Parameter(required = true) FolderUpdateDto dto) {
    return folderMapper.asFolderDto(folderService.updateFolder(folder, dto), fileService.findByFolder(folder));
  }

  @PreAuthorize("hasPermission(#folder, T(ProjectOperation).DELETE_FOLDER)")
  @DeleteMapping(path = "/folders/{folderId}")
  public void deleteFolder(@SwaggerUuidParameter @PathVariable(name = "folderId") Folder folder) {
    folderService.deleteFolder(folder);
  }

  @PreAuthorize("hasPermissionToCollection(#dto.folderIds, 'java.lang.String', 'com.cawemo.data.entity.Folder', " +
    "T(ProjectOperation).MODIFY_FOLDER) && " +
    "(#dto.parentId != null ? " +
      "hasPermission(#dto.parentId, 'com.cawemo.data.entity.Folder', T(ProjectOperation).MODIFY_FOLDER) : " +
      "hasPermission(#dto.projectId, 'com.cawemo.data.entity.Project', T(ProjectOperation).MODIFY_FOLDER))")
  @PostMapping(path = "/folders/move", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void moveFolders(@RequestBody @Valid FoldersMoveDto dto) {
    folderService.moveFolders(dto);
  }
}
