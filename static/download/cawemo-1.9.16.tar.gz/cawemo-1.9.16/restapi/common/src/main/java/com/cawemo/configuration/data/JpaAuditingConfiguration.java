/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.configuration.data;

import com.cawemo.data.entity.User;
import com.cawemo.service.authentication.AuthenticationService;
import java.time.Clock;
import java.time.ZonedDateTime;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@Configuration
@EnableJpaAuditing(dateTimeProviderRef = "zonedDateTimeProvider")
@Profile("!common-test")
public class JpaAuditingConfiguration {

  @Bean
  public AuditorAware<User> cawemoAuditorAware() {
    return AuthenticationService::getOptionalAuthenticatedUser;
  }

  @Bean
  public ZonedDateTimeProvider zonedDateTimeProvider() {
    return () -> ZonedDateTime.now(Clock.systemUTC());
  }
}
