/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity;

import com.cawemo.util.Constants;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(
  name = "file_shares",
  indexes = {
    @Index(columnList = "created_by"),
    @Index(columnList = "updated_by")
  }
)
@EntityListeners(AuditingEntityListener.class)
@Data
@Accessors(chain = true)
public class FileShare implements Serializable {

  @Id
  @GeneratedValue(generator = "uuid")
  @GenericGenerator(name = "uuid", strategy = "uuid2")
  private String id;

  @OneToOne
  @JoinColumn(name = "file_id", nullable = false, unique = true)
  @OnDelete(action = OnDeleteAction.CASCADE)
  private File file;

  private String password;

  @CreatedDate
  @Column(updatable = false, nullable = false)
  private ZonedDateTime created;

  @CreatedBy
  @ManyToOne
  @JoinColumn(name = "created_by", nullable = false)
  private User createdBy;

  @LastModifiedDate
  @Column(nullable = false)
  private ZonedDateTime updated;

  @LastModifiedBy
  @ManyToOne
  @JoinColumn(name = "updated_by", nullable = false)
  private User updatedBy;

  @Override
  public boolean equals(Object object) {
    if (object == null) {
      return false;
    } else if (object == this) {
      return true;
    } else if (!(object instanceof FileShare)) {
      return false;
    } else {
      return Objects.equals(this.id, ((FileShare) object).getId());
    }
  }

  @Override
  public int hashCode() {
    return Constants.ENTITY_HASHCODE;
  }
}
