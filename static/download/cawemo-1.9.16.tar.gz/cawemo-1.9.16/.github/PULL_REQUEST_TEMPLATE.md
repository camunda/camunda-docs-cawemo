Closes #

## Definition of Done - Checklist

- [ ] all acceptance criteria are met
- [ ] there are tests covering the implementation (for: new features, changed features, bug fixes)
- [ ] backward compatibility has been checked
- [ ] manual testing of the feature/change/fix was performed
- [ ] update the QA sheet whenever e2e tests have changed (e.g. added test cases, deleted existing ones, etc.)
- [ ] for UI features
    - [ ] signed-off by UX or PM
    - [ ] tested on all class A browsers (make sure the browser support matrix is up to date)
- [ ] for operations related features
    - [ ] signed-off by INFRA
- [ ] is this feature/bug fix worth being mentioned in the release notes? If so then label the epic/issue with the
 respective label `saas` or `on-premise` and include it in the next release milestone

**Note**: the PR should not be approved or merged if any of the previous points are not met
