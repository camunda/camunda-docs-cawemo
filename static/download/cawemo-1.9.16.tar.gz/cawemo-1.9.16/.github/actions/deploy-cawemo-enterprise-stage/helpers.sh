#!/bin/bash -eux

# Some of the below functions are borrowed/mirrored from
# https://github.com/camunda/cawemo-jenkins-shared-libs/blob/master/resources/bash-deployment-helpers.sh
# which means fixes should also be backported there.

function renderTemplate() {
  TEMPLATE_FILE="${1}"
  RENDER_FILE="${2}"
  IAM_SANDBOX_VERSION=$(curl -s "https://identity.sandbox.ultrawombat.com/api/version" | jq -r .release)

  rm -rf "${RENDER_FILE}"
  echo "Rendering resource from ${TEMPLATE_FILE}"
  # render cawemo deployment template
  cp "${TEMPLATE_FILE}" "${RENDER_FILE}"
  BRANCH_=${BRANCH:-}
  RESOURCE_ID=${RESOURCE_ID:-${BRANCH_::30}}
  sed -i "s/@ID@/${RESOURCE_ID}/g" "${RENDER_FILE}"
  sed -i "s/@BRANCH@/${BRANCH_}/g" "${RENDER_FILE}"
  sed -i "s/@TAG@/${TAG:-}/g" "${RENDER_FILE}"
  sed -i "s/@MIGRATION_MIGRATE@/${MIGRATION_MIGRATE:-}/g" "${RENDER_FILE}"
  sed -i "s,@RUN_DISPLAY_URL@,${RUN_DISPLAY_URL:-},g" "${RENDER_FILE}" # different sed separator, url contains /
  # fill in current unix time to provoke a change that leads to redeployment
  sed -i "s/@CHANGE_TRIGGER@/$(date +%s)/g" "${RENDER_FILE}"
  sed -i "s/@IAM_SANDBOX_VERSION@/${IAM_SANDBOX_VERSION}/g" "${RENDER_FILE}"
  sed -i "s/@FEATURE_LDAP@/${FEATURE_LDAP:-false}/g" "${RENDER_FILE}"
  sed -i "s/@CAMUNDA_CLOUD_SOURCE@/jenkins/g" "${RENDER_FILE}"
  sed -i "s|@CAMUNDA_CLOUD_MANAGED_BY@|${JENKINS_DOMAIN:-}|g" "${RENDER_FILE}"
  sed -i "s|@CAMUNDA_CLOUD_CREATED_BY@|${BUILD_URL:-}|g" "${RENDER_FILE}"
}

function applyDeployment() {
  applyResource "${1}"

  # wait for deployment to be rolled out
  sleep 1

  # Note: The main difference between this function and checkRollout() is that
  # this function does not need to know the resource name but let's kubectl
  # implicitly derive it from the RENDER_FILE.
  if ! kubectl rollout status -f "${RENDER_FILE}" --namespace=cawemo ; then
    exit 1
  fi
}

function applyResource() {
  TEMPLATE_FILE="${1}"
  RENDER_FILE="${1}.rendered.yml"
  renderTemplate "${TEMPLATE_FILE}" "${RENDER_FILE}"
  kubectl apply -f "${RENDER_FILE}"
}
