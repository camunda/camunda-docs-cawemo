### User Story

As a X I want to Y in order to Z.

### Acceptance Criteria

- [ ] xxx
- [ ] yyy
- [ ] zzz

### Dependencies

needs #...
needed by #...
relates to #... 

**Note**: use `needs/requires #...` or `needed by/required by #...` keywords in order to properly link dependencies.

## Definition of Ready - Checklist

- [ ] the issue has a meaningful title, description and testable acceptance criteria
- [ ] the acceptance criteria have been reviewed by another participant of the kick-off
- [ ] edge cases and limitations are clear
- [ ] unclear requirements have been broken down into separate issues (always make progress)
- [ ] for UI features
    - [ ] wireframes are attached/linked to the ticket if UX is involved in the kick-off

**Note**: the issue should not be in the `Ready for Dev` column if any of the previous points are not met
