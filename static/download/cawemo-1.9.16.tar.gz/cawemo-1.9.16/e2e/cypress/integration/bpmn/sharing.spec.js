import { getPassword, getEmail } from '../../helpers';

describe('Diagram sharing', function () {
  beforeEach(function () {
    cy.createUserAndLogin().as('user').then(cy.createProject).as('project').then(cy.createDiagram).as('diagram');
    cy.deleteAllEmails();
  });

  afterEach(function () {
    cy.removeUser(this.user);
  });

  it('a user can open and close the share modal', function () {
    // Open the diagram.
    cy.visit(`/diagrams/${this.diagram.id}`);

    // Assert that the share button has the proper title and click it.
    cy.getByTestId('share').should('have.attr', 'title', 'Share').click();

    // Assert that the correct title and button are displayed.
    cy.getByTestId('share-title')
      .should('have.text', 'Create share link')
      .getByTestId('create-share-cta')
      .should('have.text', 'Create link');
  });

  it('a user can create and remove a share link through the ui', function () {
    // Open the diagram.
    cy.visit(`/diagrams/${this.diagram.id}`);

    // Open the share modal and create a new link.
    cy.getByTestId('share').click().getByTestId('create-share-cta').click();

    // Assert that the modal title has changed.
    cy.getByTestId('share-title').should('have.text', 'Share Diagram');

    // Assert that the destroy link button exists and click it.
    cy.getByTestId('destroy-share-button')
      .should('have.text', 'Destroy Link')
      .click()
      .getByTestId('share-title')
      .should('have.text', 'Remove share link');

    // Click the button to remove the share.
    cy.getByTestId('confirm-remove-button').should('have.text', 'Remove link').click();

    // Assert that the link has been removed and the overlay is closed.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .should('have.text', 'Shared link has been removed.')
      .getByTestId('share-title')
      .should('not.exist');
  });

  it('a user can set and remove a share password through the ui', function () {
    // Open the diagram.
    cy.visit(`/diagrams/${this.diagram.id}`);

    // Open the share modal and create a new link.
    cy.getByTestId('share').click().getByTestId('create-share-cta').click();

    // Assert that the share doesn't have a password protection.
    // Open the password overlay.
    cy.getByTestId('share-password-status')
      .should('have.text', 'Password protect')
      .next()
      .should('have.text', 'Add')
      .click();

    // Assert that the correct title is displayed and enter a password.
    // Assert that the visibility toggle is working.
    cy.getByTestId('share-title')
      .should('have.text', 'Password Protect')
      .getByTestId('share-password-input')
      .should('have.attr', 'type', 'password')
      .type(getPassword())
      .getByTestId('share-password-input-adornment')
      .click()
      .getByTestId('share-password-input')
      .should('have.attr', 'type', 'text');

    // Assert that both form buttons exist and save password.
    cy.getByTestId('form-cancel')
      .should('be.visible')
      .getByTestId('form-submit')
      .should('have.text', 'Save password')
      .click();

    // Assert that the user is back on the previous page and that the password has been set.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .should('have.text', 'Password has been saved.')
      .getByTestId('share-password-status')
      .should('have.text', 'Password Protected')
      .next()
      .should('have.text', 'Remove')
      .click();

    // Assert that the user is on the "Remove password" overlay.
    // Remove the password again.
    cy.getByTestId('share-title')
      .should('have.text', 'Remove password protection')
      .getByTestId('remove-share-password')
      .should('have.text', 'Remove password')
      .click();

    // Assert that the user is back on the previous page and that the password has been removed.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .should('have.text', 'The password has been removed.')
      .getByTestId('share-password-status')
      .should('have.text', 'Password protect')
      .next()
      .should('have.text', 'Add');
  });

  it('a user send a share link via email', function () {
    // Open the diagram.
    cy.visit(`/diagrams/${this.diagram.id}`);

    // Open the share modal and create a new link.
    cy.getByTestId('share').click().getByTestId('create-share-cta').click();

    // Assert that the user is on the email share overlay.
    cy.getByTestId('share-via-email')
      .should('have.text', 'Email')
      .click()
      .getByTestId('share-title')
      .should('have.text', 'Share via Email');

    // Enter a new email address and submit it.
    cy.getByTestId('send-share-email')
      .should('be.disabled')
      .getByTestId('multi-select-input')
      .type(getEmail() + '{enter}')
      .getByTestId('send-share-email')
      .should('not.be.disabled')
      .should('have.text', 'Send')
      .click();

    // Assert that the email has been sent and that the user is back on the previous page.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .should('have.text', 'The email has been sent.')
      .getByTestId('share-title')
      .should('have.text', 'Share Diagram');
  });

  it('a user can copy the embed snippet', function () {
    // Open the diagram.
    cy.visit(`/diagrams/${this.diagram.id}`);

    // Open the share modal and create a new link.
    cy.getByTestId('share').click().getByTestId('create-share-cta').click();

    // Assert that the embed button works properly.
    cy.getByTestId('embed-button')
      .should('have.text', 'Embed')
      .click()
      .getByTestId('snackbar')
      .should('be.visible')
      .should('have.text', 'The snippet has been copied to the clipboard.');
  });

  it('an authenticated user can access a shared link', function () {
    cy.createShare(this.diagram.id).then((shareId) => {
      // Open the share.
      cy.visit(`/shares/${shareId}`);

      // Assert that the URL redirect works.
      cy.url().should('contain', `/share/${shareId}`);

      // Assert that the user menu exists and has the correct user.
      cy.getByTestId('user-menu-button').should('be.visible').should('have.text', this.user.name);

      // Assert that the diagram breadcrumb displays the correct title.
      cy.getByTestId('breadcrumb-diagram').should('have.text', this.diagram.name);

      // Assert that the modeler has loaded in read-only mode.
      cy.getBPMN('StartEvent_1')
        .should('be.visible')
        .click()
        .get('[data-action="append.append-task"]')
        .should('not.exist');

      // Assert that the diagram controls have loaded.
      cy.getByTestId('toggle-fullscreen').should('be.visible');
    });
  });

  it('an anonymous user can access a shared link', function () {
    cy.createShare(this.diagram.id).then((shareId) => {
      cy.logout();

      // Open the share.
      cy.visit(`/share/${shareId}`);

      // Assert that the user menu doesn't exist.
      // Assert that the guest info and login button exists.
      cy.getByTestId('user-menu-button')
        .should('not.exist')
        .getByTestId('login-link')
        .should('be.visible')
        .should('have.text', 'Login')
        .getByTestId('guest-info')
        .should('be.visible')
        .should('have.text', 'Viewing as Guest');

      // Assert that the modeler has loaded.
      cy.getBPMN('StartEvent_1').should('be.visible');
    });
  });

  it('a password-protected share requires a valid password', function () {
    const password = getPassword();

    cy.createShare(this.diagram.id).then((shareId) => {
      // Set a share password and open the share.
      cy.setSharePassword(shareId, password).visit(`/share/${shareId}`);

      // Assert that the modeler isn't loaded but instead a password input is displayed.
      cy.getByTestId('share-title')
        .should('have.text', 'Password protected')
        .getBPMN('StartEvent_1')
        .should('not.exist')
        .getByTestId('user-menu-button')
        .should('be.visible')
        .getByTestId('breadcrumb-diagram')
        .should('not.exist');

      // Assert that the submit button is disabled without a password.
      cy.getByTestId('form-submit')
        .should('be.disabled')
        .getByTestId('password-input')
        .should('have.attr', 'placeholder', 'Enter password')
        .type('INVALID PASSWORD')
        .getByTestId('form-submit')
        .click();

      // Assert that invalid passwords are rejected.
      cy.getByTestId('snackbar')
        .should('be.visible')
        .should('have.text', 'Sorry, you did not enter the correct password.');

      // Enter the correct password and submit.
      cy.getByTestId('password-input').clear().type(password);
      cy.findByText(/view link/i).click();

      // Assert that the modeler and breadcrumbs are loaded.
      cy.getBPMN('StartEvent_1')
        .should('be.visible')
        .getByTestId('breadcrumb-diagram')
        .should('have.text', this.diagram.name);

      // Log out the user to test the password protected share with an anonymous user.
      cy.logout().visit(`/share/${shareId}`);

      // Enter the password.
      cy.getByTestId('password-input').type(password);
      cy.findByText(/view link/i).click();

      // Assert that the shared diagram is displayed.
      cy.getByTestId('share-title').should('not.exist').getBPMN('StartEvent_1').should('be.visible');
    });
  });

  it('a password-protected embed requires a valid password', function () {
    const password = getPassword();

    cy.createShare(this.diagram.id).then((shareId) => {
      // Set a share password and open the embed.
      cy.setSharePassword(shareId, password).visit(`/embed/${shareId}`);

      // Assert that the submit button is disabled without a password.
      cy.getByTestId('password-input').type('INVALID PASSWORD').getByTestId('form-submit').click();

      // Assert that invalid passwords are rejected.
      cy.getByTestId('snackbar')
        .should('be.visible')
        .should('have.text', 'Sorry, you did not enter the correct password.');

      // Enter the correct password and submit.
      cy.getByTestId('password-input').clear().type(password);
      cy.findByText(/view link/i).click();

      // Assert that the modeler is loaded with breadcrumbs.
      cy.getBPMN('StartEvent_1').should('be.visible').getByTestId('breadcrumb-diagram').should('not.exist');

      // Remove the share password and reload the page.
      cy.setSharePassword(shareId, '').visit(`/embed/${shareId}`);

      // Assert that the modeler is loaded straight away.
      cy.getByTestId('share-title').should('not.exist').getBPMN('StartEvent_1').should('be.visible');
    });
  });

  it('a destroyed share link can no longer be accessed', function () {
    cy.createShare(this.diagram.id).then((shareId) => {
      // Open the share.
      cy.visit(`/share/${shareId}`);

      // Remove the share link and reload the page.
      cy.request('DELETE', `/internal-api/shares/${shareId}`).reload();

      // Assert that the "Not Found" page has been loaded and that the modeler doesn't exist.
      cy.getByTestId('page-title')
        .should('be.visible')
        .should('have.text', 'This link is no longer valid.')
        .getBPMN('StartEvent_1')
        .should('not.exist');

      // Open the embed.
      cy.visit(`/embed/${shareId}`, {
        failOnStatusCode: false
      });

      // Assert that the "Not Found" page has been loaded and that the modeler doesn't exist.
      cy.getByTestId('page-title')
        .should('be.visible')
        .should('have.text', 'Sorry, diagram not found.')
        .getBPMN('StartEvent_1')
        .should('not.exist');
    });
  });

  it('a user can access an embed', function () {
    cy.createShare(this.diagram.id).then((shareId) => {
      // Open the embed.
      cy.visit(`/embed/${shareId}`);

      // Assert that the breadcrumbs and user menu are not visible.
      // Assert that the "Powered by" is visible.
      cy.getByTestId('breadcrumbs')
        .should('not.exist')
        .getByTestId('user-menu-button')
        .should('not.exist')
        .getByTestId('powered-by')
        .should('be.visible')
        .should('have.attr', 'title', 'Powered by Cawemo');

      // Assert that the modeler has loaded in read-only mode.
      cy.getBPMN('StartEvent_1')
        .should('be.visible')
        .click()
        .get('[data-action="append.append-task"]')
        .should('not.exist');

      // Assert that the diagram controls have loaded.
      cy.getByTestId('toggle-fullscreen').should('be.visible');
    });
  });

  it('a user receives email invitations for a share', function () {
    const recipient = getEmail();

    cy.createShare(this.diagram.id).then((shareId) => {
      // Send an email to the given email.
      cy.request('POST', `/internal-api/shares/${shareId}/email`, {
        emails: [recipient],
        message: ''
      });

      // Get the share url and assert that it can be loaded.
      cy.getLinkFromEmail(recipient, 'share').then((url) => {
        cy.request('GET', url).its('status').should('eq', 200);
      });
    });
  });
});
