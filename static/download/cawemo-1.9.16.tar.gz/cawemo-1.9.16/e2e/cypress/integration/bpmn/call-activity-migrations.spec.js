import { getBaseUrl, getProcessIdFromXML, getProcessRefsFromXML } from '../../helpers';

describe('CallActivities', function () {
  describe('process_id Migration load test with 100 diagrams', function () {
    before(function () {
      cy.visit('/logout');
      const createMultipleDiagrams = function (project) {
        const createABunchOfDiagramsWithoutProcesId = [];
        for (let i = 0; i < 100; i++) {
          createABunchOfDiagramsWithoutProcesId.push(cy.createDiagram(project, { ommitProcessId: true }));
        }

        return Promise.all(createABunchOfDiagramsWithoutProcesId);
      };

      cy.createUser()
        .as('user')
        .then(cy.createProject)
        .as('project')
        .then(createMultipleDiagrams)
        .as('diagramsWithoutProcessId');
    });

    after(function () {
      cy.removeUser(this.user);
    });

    it('migrates 100 diagrams at once', function () {
      cy.createEnterpriseLicense(this.user).login(this.user);

      cy.wait(5000); // give the WebApp time to migrate the diagrams

      cy.intercept(getBaseUrl(`internal-api/projects/${this.project.id}*`)).as('getProject');

      cy.visit(`/projects/${this.project.id}`);

      cy.wait('@getProject').then(({ response }) => {
        const diagramsWithProcessId = response.body.data.files.filter((diagram) => !!diagram.processId);
        expect(diagramsWithProcessId.length).to.equal(100);
        cy.wait(1000);
      });
    });
  });

  describe.saas('Migration of existing diagrams in a saas enterprise organization', function () {
    beforeEach(function () {
      cy.createUser()
        .as('user')
        .then(cy.createProject)
        .as('project')
        .then((project) => {
          return cy.createDiagram(project, { ommitProcessId: true });
        })
        .as('diagramWithoutProcessId')
        .then(() => {
          // get randomly generated processId from xml
          return getProcessIdFromXML(this.diagramWithoutProcessId.content);
        })
        .as('randomDiagramsProcessId');
    });

    afterEach(function () {
      cy.removeUser(this.user);
    });

    it('migrates when an enterprise featured organization user logs in', function () {
      cy.createEnterpriseLicense(this.user).login(this.user);

      cy.intercept(getBaseUrl(`internal-api/files/${this.diagramWithoutProcessId.id}*`)).as('getDiagram');

      cy.visit(`/diagrams/${this.diagramWithoutProcessId.id}`);

      cy.wait('@getDiagram').then(({ response }) => {
        expect(response.body.data.file.processId).to.equal(this.randomDiagramsProcessId);

        cy.wait(1000);
      });
    });

    it('migrates when a non-enterprise organization gets a license activated', function () {
      const adminUserEmail = 'dev@cawemo.com';
      const adminUserPassword = 'camunda123';

      // Create the admin user
      cy.createUser({
        email: adminUserEmail,
        password: adminUserPassword
      });

      // first make sure the diagram is not migrated if its not an enterprise organization yet
      cy.login(this.user);

      cy.intercept(getBaseUrl(`internal-api/files/${this.diagramWithoutProcessId.id}*`)).as('getDiagram');

      cy.visit(`/diagrams/${this.diagramWithoutProcessId.id}`);

      cy.wait('@getDiagram').then(({ response }) => {
        expect(response.body.data.file.processId).to.equal(undefined);
      });

      cy.getBPMN('StartEvent_1').should('be.visible');

      // Open Puppeteer:
      // - log the cawemo admin in
      // - send a post to activate a license for the user
      cy.task('puppeteer.open')
        .task('puppeteer.login', {
          url: getBaseUrl('settings'),
          user: {
            email: adminUserEmail,
            password: adminUserPassword
          }
        })
        .task('puppeteer.fetch', {
          method: 'POST',
          url: `adminApi/organizations/${this.user.organization.id}/licenses`,
          body: JSON.stringify({
            name: 'enterprise'
          })
        });

      cy.visit(`/diagrams/${this.diagramWithoutProcessId.id}`);

      cy.wait('@getDiagram').then(({ response }) => {
        expect(response.body.data.file.processId).to.equal(this.randomDiagramsProcessId);
      });

      cy.getBPMN('StartEvent_1').should('be.visible');

      cy.task('puppeteer.close');
    });
  });

  describe('Existing diagrams are always migrated in on-premise', function () {
    before(function () {
      cy.createUser()
        .as('user')
        .then(cy.createProject)
        .as('project')
        .then((project) => {
          return cy.createDiagram(project, { ommitProcessId: true });
        })
        .as('diagramWithoutProcessId')
        .then(() => {
          // get randomly generated processId from xml
          return getProcessIdFromXML(this.diagramWithoutProcessId.content);
        })
        .as('randomDiagramsProcessId');
    });

    after(function () {
      cy.removeUser(this.user);
    });

    it.enterprise('does migrate diagrams when a user logs in', function () {
      cy.login(this.user);

      cy.intercept(getBaseUrl(`internal-api/files/${this.diagramWithoutProcessId.id}*`)).as('getDiagram');

      cy.visit(`/diagrams/${this.diagramWithoutProcessId.id}`);

      cy.wait('@getDiagram').then(({ response }) => {
        expect(response.body.data.file.processId).to.equal(this.randomDiagramsProcessId);

        cy.wait(1000);
      });
    });
  });

  describe('Migration of Process_1 diagrams', function () {
    beforeEach(function () {
      cy.createUser()
        .as('user')
        .then(cy.createProject)
        .as('project')
        .readFile('cypress/fixtures/diagrams/process-id-one.xml')
        .then((content) => {
          return cy.createDiagram(this.project, { xml: content, ommitProcessId: true });
        })
        .as('diagramWithCustomProcessId');
    });

    afterEach(function () {
      cy.removeUser(this.user);
    });

    it('migrates Process_1 diagrams to Process_${diagramId}', function () {
      // make sure prior to migration the diagram we test useses Process_1 as the processId and processRef in its content
      expect(getProcessIdFromXML(this.diagramWithCustomProcessId.content)).to.equal('Process_1');
      expect(getProcessRefsFromXML(this.diagramWithCustomProcessId.content)).to.equal('Process_1');

      cy.createEnterpriseLicense(this.user).login(this.user).wait(1000);

      const newProcessId = `Process_${this.diagramWithCustomProcessId.id}`;

      cy.intercept(getBaseUrl(`internal-api/files/${this.diagramWithCustomProcessId.id}*`)).as('getDiagram');

      cy.visit(`/diagrams/${this.diagramWithCustomProcessId.id}`);

      cy.wait('@getDiagram').then(({ response }) => {
        const diagram = response.body.data.file;

        // check that the fetched diagram metadata now has the correct processId
        expect(diagram.processId).to.not.equal('Process_1');
        expect(diagram.processId).to.equal(newProcessId);

        // check that the fetched diagram content now uses the correct processId for the process nad processRef
        expect(getProcessIdFromXML(diagram.content)).to.equal(newProcessId);
        expect(getProcessRefsFromXML(diagram.content)).to.equal(newProcessId);

        cy.wait(1000);
      });
    });
  });

  describe('Migration of diagrams without a process id', function () {
    beforeEach(function () {
      cy.createUser()
        .as('user')
        .then(cy.createProject)
        .as('project')
        .then((project) => {
          return cy.createDiagram(project, { ommitProcessId: true, generateXMLWithoutProcessId: true });
        })
        .as('diagramWithoutProcessIdAttribute');
    });

    afterEach(function () {
      cy.removeUser(this.user);
    });

    it('migrates a diagrams without process id node in XML to `NO_PROCESS_ID`', function () {
      expect(getProcessIdFromXML(this.diagramWithoutProcessIdAttribute.content)).to.equal(undefined);

      cy.createEnterpriseLicense(this.user).login(this.user).wait(1000);

      cy.intercept(getBaseUrl(`internal-api/files/${this.diagramWithoutProcessIdAttribute.id}*`)).as('getDiagram');

      cy.visit(`/diagrams/${this.diagramWithoutProcessIdAttribute.id}`);

      cy.wait('@getDiagram').then(({ response }) => {
        const diagram = response.body.data.file;

        expect(diagram.processId).to.equal('NO_PROCESS_ID');

        expect(getProcessIdFromXML(diagram.content)).to.equal(undefined);

        cy.wait(1000);
      });
    });
  });

  describe('Non-migration of existing diagrams in a saas non-enterprise organization', function () {
    before(function () {
      cy.createUser()
        .as('user')
        .then(cy.createProject)
        .as('project')
        .then((project) => {
          return cy.createDiagram(project, { ommitProcessId: true });
        })
        .as('diagramWithoutProcessId');
    });

    after(function () {
      cy.removeUser(this.user);
    });

    it.saas('does not migrate diagrams when a non-enterprise organization user logs in', function () {
      cy.login(this.user);

      cy.intercept(getBaseUrl(`internal-api/files/${this.diagramWithoutProcessId.id}*`)).as('getDiagram');

      cy.visit(`/diagrams/${this.diagramWithoutProcessId.id}`);

      cy.wait('@getDiagram').then(({ response }) => {
        expect(response.body.data.file.processId).to.equal(undefined);
        cy.wait(1000);
      });
    });
  });

  describe('Migration of old links', function () {
    beforeEach(function () {
      cy.createUserAndLogin()
        .as('user')
        .then((user) => {
          Cypress.env('user', user);
          return cy.createProject(user);
        })
        .as('project')
        .then((project) => {
          return Promise.all([
            cy.createDiagram(project).as('parentDiagram'),
            cy.createDiagram(project).as('childDiagram')
          ]);
        })
        .then(() => {
          return cy.createLink({
            source_file_id: this.parentDiagram.id,
            target_file_id: this.childDiagram.id,
            source_element_id: 'StartEvent_1',
            author_id: Cypress.env('user').id
          });
        });

      cy.window().then((win) => {
        win.localStorage.removeItem('hasSeenLinkMigrationMessage');
      });
    });

    afterEach(function () {
      cy.removeUser(this.user);
    });

    it('Puts old links into the specification property and shows a notification once', function () {
      cy.intercept(getBaseUrl(`internal-api/files/${this.parentDiagram.id}/link*`)).as('getLinks');

      cy.visit(`/diagrams/${this.parentDiagram.id}`).getBPMN('StartEvent_1').should('be.visible');

      cy.wait('@getLinks').then(({ response }) => {
        expect(response.body.data.length).to.equal(1);
      });

      // when this diagram get's opened up, a migration will start in the background if old diagram links were found
      // this will move the link to the specification property and send a DELETE request to remove the old link, so the migration does not happen twice

      cy.getByTestId('specification-toggle').click();

      // we want to make sure that the specification property now contains the link
      cy.getBPMN('StartEvent_1')
        .click()
        .getByTestId('specification-preview')
        .should('contain', 'This Call Activity links to');

      // when loading the page again, we don't want to show the message any longer.
      cy.visit(`/diagrams/${this.parentDiagram.id}`);

      // we also want to make sure the link got deleted, so fetching links should return an empty array
      cy.wait('@getLinks').then(({ response }) => {
        expect(response.body.data.length).to.equal(0);
      });

      cy.getBPMN('StartEvent_1').should('be.visible');
    });

    it('will not migrate old links if the permission of the user has no access to modeling', function () {
      // register a listening alias for when the client tries to fetch links
      cy.intercept(getBaseUrl(`internal-api/files/${this.parentDiagram.id}/link*`)).as('getLinks');

      // update the permission of the testing user to be 'READ'
      cy.updatePermissionAccess({ user: this.user, project: this.project, permission: 'READ' });

      // visit the created diagram which contains old links
      cy.visit(`/diagrams/${this.parentDiagram.id}`).getBPMN('StartEvent_1').should('be.visible');

      // Assert that the migration endpoint has not been called after 2 seconds.
      cy.wait(2000)
        .get('@getLinks')
        .then((response) =>
          assert.equal(response, null, 'Expected `null` because the route should not have been called.')
        );
    });
  });
});
