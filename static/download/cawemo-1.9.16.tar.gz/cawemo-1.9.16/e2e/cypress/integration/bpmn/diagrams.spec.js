import { getBaseUrl, getNameFor, sanitizeName } from '../../helpers';

describe('Diagrams', function () {
  beforeEach(function () {
    // Create a new user and project.
    cy.createUserAndLogin().as('user').then(cy.createProject).as('project');

    cy.window().then((win) => {
      win.localStorage.setItem('cawemo.collaborator_sidebar_visible', 'false');
    });
  });

  afterEach(function () {
    cy.removeUser(this.user);
    cy.removeAllProjectsIfEnterprise();
  });

  it('a user (with right permissions) can create a new bpmn diagram using button', function () {
    cy.visit(`/projects/${this.project.id}`);
    cy.findByText(/project doesn't have any diagrams/i).should('exist');

    // Admin
    cy.createBPMNDiagramUsingButton();
    cy.assertBPMNDiagramIsCreated();
    cy.getByTestId('top-bar').within(() => {
      // Navigate to project page
      cy.findByRole('link', { name: this.project.name }).click();
    });
    cy.assertEntityPresent('New BPMN Diagram', 'BPMN');

    // Editor
    changeUserPermissionAndVisitProjectPage(this.user, this.project, 'WRITE');
    cy.createBPMNDiagramUsingButton();
    cy.assertBPMNDiagramIsCreated();

    // Viewer
    changeUserPermissionAndVisitProjectPage(this.user, this.project, 'READ');
    cy.assertEntityPresent('New BPMN Diagram', 'BPMN');
    cy.assertNoActionButtonPresentInProjectPage();

    // Commenter
    changeUserPermissionAndVisitProjectPage(this.user, this.project, 'COMMENT');
    cy.assertEntityPresent('New BPMN Diagram', 'BPMN');
    cy.assertNoActionButtonPresentInProjectPage();
  });

  it('a user (with right permissions) can upload diagrams', function () {
    cy.visit(`/projects/${this.project.id}`);
    cy.findByText(/project doesn't have any diagrams/i).should('exist');

    /**
     * Upload using button
     **/
    // Admin
    assertUploadIsPossibleUsingButton();

    // Editor
    cy.removeAllFiles(this.project.id);
    changeUserPermissionAndVisitProjectPage(this.user, this.project, 'WRITE');
    assertUploadIsPossibleUsingButton();

    // Viewer
    cy.removeAllFiles(this.project.id);
    changeUserPermissionAndVisitProjectPage(this.user, this.project, 'READ');
    cy.findByText(/project doesn't have any diagrams/i).should('exist'); // wait till page load
    cy.assertNoActionButtonPresentInProjectPage();

    // Commenter
    cy.removeAllFiles(this.project.id);
    changeUserPermissionAndVisitProjectPage(this.user, this.project, 'COMMENT');
    cy.findByText(/project doesn't have any diagrams/i).should('exist'); // wait till page load
    cy.assertNoActionButtonPresentInProjectPage();

    /**
     * Upload using drag'n'drop
     **/
    // Admin
    cy.removeAllFiles(this.project.id);
    changeUserPermissionAndVisitProjectPage(this.user, this.project, 'OWNER');
    assertUploadIsPossibleUsingDragNDrop();

    // Editor
    cy.removeAllFiles(this.project.id);
    changeUserPermissionAndVisitProjectPage(this.user, this.project, 'WRITE');
    assertUploadIsPossibleUsingDragNDrop();

    // Viewer
    cy.removeAllFiles(this.project.id);
    changeUserPermissionAndVisitProjectPage(this.user, this.project, 'READ');
    cy.findByText(/project doesn't have any diagrams/i).should('exist'); // wait till page load
    cy.assertUploadIsNotPossibleUsingDragNDrop();

    // Commenter
    cy.removeAllFiles(this.project.id);
    changeUserPermissionAndVisitProjectPage(this.user, this.project, 'COMMENT');
    cy.findByText(/project doesn't have any diagrams/i).should('exist'); // wait till page load
    cy.assertUploadIsNotPossibleUsingDragNDrop();
  });

  it('bpmn uploads are validated', function () {
    cy.visit(`/projects/${this.project.id}`);
    cy.findByText(/project doesn't have any diagrams/i).should('exist');

    cy.getByTestId('drop-target').attachFile('diagrams/process-id-one.bpmn', { subjectType: 'drag-n-drop' });
    cy.findByText(/"process-id-one.bpmn" is being uploaded to cawemo/i).should('exist');
    cy.reload();

    cy.getByTestId('drop-target').attachFile('diagrams/process-id-one.png', { subjectType: 'drag-n-drop' });
    cy.findByText(/the following 1 file is invalid/i).should('exist');
    cy.reload();

    cy.getByTestId('drop-target').attachFile('diagrams/process-id-one.svg', { subjectType: 'drag-n-drop' });
    cy.findByText(/the following 1 file is invalid/i).should('exist');
  });

  it('a user (with right permissions) can replace a diagram', function () {
    cy.createDiagram(this.project).then((diagram) => {
      cy.visit(`/diagrams/${diagram.id}`);
      cy.assertBPMNDiagramIsCreated();

      // Admin
      assertReplaceIsPossibleUsingDragNDrop();
      assertReplaceIsPossibleUsingBreadcrumb(diagram.name);

      // Editor
      changeUserPermissionAndVisitDiagramPage(this.user, this.project, diagram, 'WRITE');
      cy.assertBPMNDiagramIsCreated(); // wait till page load
      assertReplaceIsPossibleUsingDragNDrop();
      assertReplaceIsPossibleUsingBreadcrumb(diagram.name);

      // Viewer
      changeUserPermissionAndVisitDiagramPage(this.user, this.project, diagram, 'READ');
      cy.assertBPMNDiagramIsCreated(); // wait till page load
      cy.assertUploadIsNotPossibleUsingDragNDrop();

      // Commenter
      changeUserPermissionAndVisitDiagramPage(this.user, this.project, diagram, 'COMMENT');
      cy.assertBPMNDiagramIsCreated(); // wait till page load
      cy.assertUploadIsNotPossibleUsingDragNDrop();
    });
  });

  it('admin & editor can rename a diagram using breadcrumb menu', function () {
    const newName = getNameFor('diagram');

    // Create a new diagram and open it.
    cy.createDiagram(this.project).then((diagram) => {
      cy.intercept({
        method: 'PATCH',
        url: getBaseUrl(`internal-api/files/${diagram.id}*`)
      }).as('renameDiagram');

      cy.visit(`/diagrams/${diagram.id}`);

      // Admin
      cy.openBreadcrumbMenu(diagram.name);
      assertRenameIsPossibleUsingBreadcrumbMenu(diagram.name, newName);

      // Editor
      const newName2 = getNameFor('diagram');
      changeUserPermissionAndVisitDiagramPage(this.user, this.project, diagram, 'WRITE');
      cy.openBreadcrumbMenu(newName);
      assertRenameIsPossibleUsingBreadcrumbMenu(newName, newName2);
    });
  });

  it('admin & editor can delete a diagram using breadcrumb menu', function () {
    // Admin
    cy.createDiagram(this.project).then((diagram) => {
      cy.visit(`/diagrams/${diagram.id}`);
      cy.openBreadcrumbMenu(diagram.name);
      cy.assertDeletingDiagramIsPossible(diagram.name, this.project);
    });

    // Editor
    cy.createDiagram(this.project).then((diagram) => {
      changeUserPermissionAndVisitDiagramPage(this.user, this.project, diagram, 'WRITE');
      cy.openBreadcrumbMenu(diagram.name);
      cy.assertDeletingDiagramIsPossible(diagram.name, this.project);
    });
  });

  it('admin & editor can duplicate a diagram using breadcrumb menu', function () {
    // Admin
    cy.createDiagram(this.project).then((diagram) => {
      cy.visit(`/diagrams/${diagram.id}`);
      appendTaskToDiagram();
      cy.openBreadcrumbMenu(diagram.name);
      duplicateDiagram();
      assertDiagramIsDuplicated(diagram.name);
    });

    // Editor
    cy.createDiagram(this.project).then((diagram) => {
      changeUserPermissionAndVisitDiagramPage(this.user, this.project, diagram, 'WRITE');
      appendTaskToDiagram();
      cy.openBreadcrumbMenu(diagram.name);
      duplicateDiagram();
      assertDiagramIsDuplicated(diagram.name);
    });
  });

  it('viewer & commenter cannot rename, delete, replace or duplicate a diagram using breadcrumb menu', function () {
    // Viewer, Commenter
    cy.createDiagram(this.project).then((diagram) => {
      changeUserPermissionAndVisitDiagramPage(this.user, this.project, diagram, 'READ'); // Viewer
      cy.assertNoBreadcrumbMenuPresent(diagram.name);

      changeUserPermissionAndVisitDiagramPage(this.user, this.project, diagram, 'COMMENT'); // Commenter
      cy.assertNoBreadcrumbMenuPresent(diagram.name);
    });
  });

  it('admin & editor can delete a diagram using entity menu', function () {
    // Admin
    cy.createDiagram(this.project).then((diagram) => {
      cy.visit(`/projects/${this.project.id}`);
      cy.openEntityMenu(diagram.name);
      cy.assertDeletingFileIsPossible(diagram.name, this.project);
    });

    // Editor
    cy.createDiagram(this.project).then((diagram) => {
      changeUserPermissionAndVisitProjectPage(this.user, this.project, 'WRITE');
      cy.openEntityMenu(diagram.name);
      cy.assertDeletingFileIsPossible(diagram.name, this.project);
    });
  });

  it('admin & editor can duplicate a diagram using entity menu', function () {
    // Admin
    cy.createDiagram(this.project).then((diagram) => {
      cy.visit(`/projects/${this.project.id}`);
      cy.openEntityMenu(diagram.name);
      duplicateDiagram();
      assertDiagramIsDuplicatedInProjectPage(diagram.name);
    });

    // Editor
    cy.createDiagram(this.project).then((diagram) => {
      changeUserPermissionAndVisitProjectPage(this.user, this.project, 'WRITE');
      cy.openEntityMenu(diagram.name);
      duplicateDiagram();
      assertDiagramIsDuplicatedInProjectPage(diagram.name);
    });
  });

  it('viewer & commenter cannot delete or duplicate a diagram but can just download it using entity menu', function () {
    // Viewer, Commenter
    cy.createDiagram(this.project).then((diagram) => {
      changeUserPermissionAndVisitProjectPage(this.user, this.project, 'READ');
      cy.openEntityMenu(diagram.name);
      cy.assertOnlyDownloadActionIsPresent();

      changeUserPermissionAndVisitProjectPage(this.user, this.project, 'COMMENT');
      cy.openEntityMenu(diagram.name);
      cy.assertOnlyDownloadActionIsPresent();
    });
  });

  it('a user can delete multiple diagrams from the project page', function () {
    // Create 2 new diagrams and open the project page.
    cy.createDiagram(this.project).createDiagram(this.project).visit(`/projects/${this.project.id}`);

    // Check the diagram's checkboxes.
    cy.getByTestId('entity-checkbox').click({ multiple: true, force: true });

    // Assert that the "Delete" button is visible and click it.
    cy.getByTestId('entity-head-dropdown')
      .should('have.text', '2 items selected')
      .click()
      .getByTestId('delete-diagram')
      .click();

    // Assert that the confirmation modal is shown and confirm.
    cy.contains('Deleting 2 files').should('be.visible').getByTestId('confirm-button').click();

    // Assert that the snackbar is displayed.
    cy.getByTestId('snackbar').should('be.visible').and('contain', 'Your data has been deleted.');

    // Assert that the diagram has been deleted.
    cy.getByTestId('empty-state').should('be.visible');
  });

  it('a user can duplicate multiple diagrams from the project page', function () {
    // Create 2 new diagram and open the project.
    cy.createDiagram(this.project).createDiagram(this.project).visit(`/projects/${this.project.id}`);

    // Check the diagram checkbox.
    cy.getByTestId('entity-checkbox').click({ multiple: true, force: true });

    // Assert that the "Duplicate" button is visible and click it.
    cy.getByTestId('entity-head-dropdown').click().getByTestId('duplicate-diagram').click();

    // Assert that the diagram has been duplicated.
    cy.getByTestId('entity-list').first().find('li').should('have.length', 4);
  });

  it("a user can't move a diagram into a catalog or read-only project", function () {
    // Join a user to the organization (with a different project)
    // and create a new catalog
    cy.joinUserToOrganization(this.user).then((collaborator) => {
      cy.createProject(collaborator).then((differentProject) => {
        cy.createProject(this.user, 'CATALOG').then((catalog) => {
          cy.createProject(this.user).then((targetProject) => {
            // Create a new diagram and open the project.
            cy.createDiagram(this.project).then(() => {
              cy.visit(`/projects/${this.project.id}`);

              // Find the diagram tile and check the checkbox.
              cy.getByTestId('entity-context-dropdown').click({ force: true });

              // Assert that the "Move" entry exists and click it.
              cy.getByTestId('move-diagram').should('have.text', 'Move').click();

              // Go one level up to the organization root.
              cy.getByTestId('move-level-up').click();

              // Assert that the target catalog exists and select it.
              cy.getByTestId(`item-${differentProject.name}`)
                .should('not.exist')
                .getByTestId(`item-${catalog.name}`)
                .should('not.exist')
                .getByTestId(`item-${targetProject.name}`)
                .should('exist')
                .getByTestId(`item-${this.project.name}`)
                .should('exist');
            });
          });
        });
      });
    });
  });

  it('a user can move a single diagram into a different project', function () {
    // Create a new project to move the diagrams into.
    cy.createProject(this.user).then((targetProject) => {
      // Create a new diagram.
      cy.createDiagram(this.project).then((diagram) => {
        // Open the project.
        cy.visit(`/projects/${this.project.id}`);

        // Open the context menu of the diagram.
        cy.getByTestId('entity-context-dropdown').click({ force: true });

        // Assert that the "Move" entry exists and click it.
        cy.getByTestId('move-diagram').should('have.text', 'Move').click();

        // Assert that the move component has the correct title and body.
        cy.getByTestId('move-component-title')
          .should('have.text', this.project.name)
          .getByTestId('empty-message')
          .should('be.visible');

        // Go one level up to the organization root.
        cy.getByTestId('move-level-up').click();

        // Assert that the "Move" button is disabled.
        cy.getByTestId('confirm-move').should('be.disabled');

        // Assert that the target project exists and select it.
        cy.getByTestId(`item-${targetProject.name}`).should('have.text', targetProject.name).click();

        // Assert that the "Move" button is enabled.
        cy.getByTestId('confirm-move').should('not.be.disabled').click();

        // Assert that the confirmation is shown before the actual move.
        cy.getByTestId('move-component-title')
          .should('have.text', 'Move items?')
          .getByTestId('confirm-move-message')
          .should('contain', 'These items will inherit permissions');

        // Confirm the move.
        cy.getByTestId('confirm-move').click();

        // Assert that the confirmation dialog is displayed and confirm.
        cy.getByTestId('dialog-title').should('have.text', 'Moving 1 file').getByTestId('confirm-button').click();

        // Assert that the snackbar is shown.
        cy.getByTestId('snackbar').should('be.visible').should('have.text', 'Your data has been moved.');

        // Assert that the diagram is shown inside the target project.
        cy.getByTestId('breadcrumb-project-menu')
          .should('have.text', targetProject.name)
          .getByTestId('entity-list')
          .first()
          .find('li')
          .should('have.length', 1)
          .getByTestId(`entity-${diagram.name}`)
          .should('exist');
      });
    });
  });

  it('a user can move multiple diagrams into a new project', function () {
    const newTargetProject = getNameFor('project');

    // Create 2 diagrams.
    cy.createDiagram(this.project).createDiagram(this.project);

    // Open the project.
    cy.visit(`/projects/${this.project.id}`);

    // Check both diagram's checkboxes.
    cy.getByTestId('entity-checkbox').click({ multiple: true, force: true });

    // Click on "Move" inside the menu.
    cy.getByTestId('entity-head-dropdown').click().getByTestId('move-diagram').click();

    // Go one level up to the organization root.
    cy.getByTestId('move-level-up').click();

    // Click the "Create new" button.
    cy.getByTestId('create-new-target').should('be.visible').and('have.attr', 'title', 'Create new').click();

    // Enter a new project name into the input.
    cy.getByTestId('target-name')
      .should('be.visible')
      .and('have.value', 'New Project')
      .type(newTargetProject)
      .getByTestId('submit')
      .click();

    // Click the "Confirm" button.
    cy.getByTestId('confirm-move').should('not.be.disabled').click();

    // Assert that the confirmation screen is displayed and confirm.
    cy.getByTestId('move-component-title').should('have.text', 'Move items?').getByTestId('confirm-move').click();

    // Assert that the confirmation dialog is displayed and confirm.
    cy.getByTestId('dialog-title').should('have.text', 'Moving 2 files').getByTestId('confirm-button').click();

    // Assert that the newly created project is opened.
    cy.getByTestId('project-name').should('have.text', newTargetProject);

    // Assert that the move has succeeded.
    cy.getByTestId('snackbar')
      .should('have.text', 'Your data has been moved.')
      .getByTestId('entity-list')
      .first()
      .find('li')
      .should('have.length', 2);
  });

  it('a user can move a diagram into a (new) subfolder', function () {
    const newTargetFolder = getNameFor('folder');

    // Create 1 folder.
    cy.createFolder(this.project).then((folder) => {
      // Create 1 diagram.
      cy.createDiagram(this.project).then((diagram) => {
        // Open the project.
        cy.visit(`/projects/${this.project.id}`);

        // Open the context menu of the diagram.
        cy.getByTestId('entity-context-dropdown').last().click({ force: true });

        // Click the "Move" entry.
        cy.getByTestId('move-diagram').click();

        // Assert that the target folder exists.
        cy.getByTestId(`item-${folder.name}`).should('be.visible').and('have.text', folder.name);

        // Select the target folder.
        cy.getByTestId(`select-item-${folder.name}`).click({ force: true });

        // Assert that the "Move" button is not disabled and click it.
        cy.getByTestId('confirm-move').should('not.be.disabled').click();

        // Assert that the folder view has been loaded after the move.
        cy.url().should('include', `/folders/${folder.id}`);

        // Assert that the moved diagram is in place.
        cy.getByTestId(`entity-${diagram.name}`).should('be.visible');

        // Go back to the project.
        cy.getByTestId('breadcrumb-project').click();

        // Assert that the folder is visible, but not the moved diagram.
        cy.getByTestId(`entity-${folder.name}`)
          .should('be.visible')
          .getByTestId(`entity-${diagram.name}`)
          .should('not.exist');

        // Open the folder.
        cy.getByTestId(`entity-${folder.name}`).click();

        // Open the context menu of the diagram.
        cy.getByTestId('entity-context-dropdown').click({ force: true });

        // Click the "Move" entry.
        cy.getByTestId('move-diagram').click();

        // Click the "Create new" button.
        cy.getByTestId('create-new-target').should('be.visible').and('have.attr', 'title', 'Create new').click();

        // Enter a new folder name into the input.
        cy.getByTestId('target-name')
          .should('be.visible')
          .and('have.value', 'New Folder')
          .type(newTargetFolder + '{enter}');

        // Click the "Confirm" button.
        cy.getByTestId('confirm-move').should('not.be.disabled').click();

        // Assert that the newly created folder is opened.
        cy.getByTestId('folder-name').should('have.text', newTargetFolder);

        // Assert that only the moved diagram is displayed.
        cy.getByTestId(`entity-${folder.name}`)
          .should('not.exist')
          .getByTestId(`entity-${diagram.name}`)
          .should('be.visible');
      });
    });
  });

  it('on diagram export, a milestone is created', function () {
    cy.prepareDownload();

    // Create a new diagram and open it.
    cy.createDiagram(this.project).then((diagram) => {
      cy.visit(`/diagrams/${diagram.id}`);

      // Wait until the diagram has been loaded.
      cy.getBPMN('StartEvent').should('be.visible');

      // Trigger an export via the export menu.
      cy.getByTestId('export-menu')
        .click()
        .getByTestId('export-xml')
        .should('have.text', 'Download as BPMN 2.0 XML')
        .click();

      // Assert that the snackbar displays the correct message.
      cy.getByTestId('snackbar').should('be.visible').and('contain', `.bpmn" is being downloaded to your computer.`);

      // Open the milestone page.
      cy.visit(`/milestones/${diagram.id}`);

      // Assert that the milestone has been created with the correct name.
      cy.getByTestId('milestone').should('have.length', 1).and('contain', 'Autosaved during export');

      // Go back to the diagram page.
      cy.visit(`/diagrams/${diagram.id}`);

      // Add a task to the StartEvent and wait for the diagram to save.
      cy.append('StartEvent_1', 'append-task', 'Task #1').getByTestId('autosave').should('contain', 'Autosaved');

      // Create a milestone.
      cy.createMilestone(diagram.id);

      // Trigger an export via the export menu again.
      cy.getByTestId('export-menu').click().getByTestId('export-xml').click();

      // Open the milestone page.
      cy.visit(`/milestones/${diagram.id}`);

      // Assert that this time, no new milestone has been created and that there are these 2:
      // - the first one is the one that we created manually
      // - the second one is the auto-created milestone from the first export
      cy.getByTestId('milestone').should('have.length', 2).first().should('contain', 'Untitled milestone');
    });
  });

  it('export bpmn - png, svg, xml', { browser: '!firefox' }, function () {
    cy.prepareDownload();

    cy.createDiagram(this.project).then((diagram) => {
      cy.visit(`/diagrams/${diagram.id}`);
      cy.assertBPMNDiagramIsCreated();
      cy.getByTestId('export-menu').click();

      cy.findByRole('menuitem', { name: /export as png image/i }).click();
      assertExportSuccessful(diagram.name, 'png', 4000);

      cy.getByTestId('export-menu').click();
      cy.findByRole('menuitem', { name: /export as svg image/i }).click();
      assertExportSuccessful(diagram.name, 'svg', 800);

      cy.getByTestId('export-menu').click();
      cy.findByRole('menuitem', { name: /download as bpmn 2.0 xml/i }).click();
      assertExportSuccessful(diagram.name, 'bpmn', 850);
    });
  });
});

const changeUserPermissionAndVisitProjectPage = (user, project, permission) => {
  cy.updatePermissionAccess({ user, project, permission });
  cy.visit(`/projects/${project.id}`);
};

const changeUserPermissionAndVisitDiagramPage = (user, project, diagram, permission) => {
  cy.updatePermissionAccess({ user, project, permission });
  cy.visit(`/diagrams/${diagram.id}`);
};

const assertRenameIsPossibleUsingBreadcrumbMenu = (name, newName) => {
  cy.findByRole('menuitem', { name: /edit name/i }).click();
  cy.findByDisplayValue(name)
    .click()
    .type(newName + '{enter}')
    .wait('@renameDiagram');
  cy.reload();
  cy.getByTestId('top-bar').within(() => {
    cy.findByRole('button', { name: newName }).should('exist');
  });
};

const appendTaskToDiagram = () => {
  cy.append('StartEvent_1', 'append-task', 'Task #1');
};

const duplicateDiagram = () => {
  cy.findByRole('menuitem', { name: /duplicate/i }).click();
};

const assertDiagramIsDuplicated = (diagramName) => {
  cy.getByTestId('top-bar').within(() => {
    cy.findByRole('button', { name: `${diagramName} - Copy` }).should('exist');
  });
  cy.contains('Task #1').should('exist');
};

const assertDiagramIsDuplicatedInProjectPage = (diagramName) => {
  cy.assertEntityPresent(diagramName, 'BPMN');
  const copiedDiagramName = `${diagramName} - Copy`;
  cy.assertEntityPresent(copiedDiagramName, 'BPMN');
};

const assertUploadIsPossibleUsingButton = () => {
  assertUploadIsPossible('button');
};

const assertUploadIsPossibleUsingDragNDrop = () => {
  assertUploadIsPossible('dragndrop');
};

const assertUploadIsPossible = (type = 'button') => {
  if (type === 'dragndrop') {
    cy.getByTestId('drop-target').attachFile('diagrams/process-id-one.xml', { subjectType: 'drag-n-drop' });
  } else if (type === 'button') {
    cy.findByText(/new/i).click();
    cy.get('[id="raised-button-file"]').attachFile('diagrams/process-id-one.xml');
  }
  cy.findByText(/"process-id-one.xml" is being uploaded to cawemo/i).should('exist');
  cy.assertEntityPresent('process-id-one.xml', 'BPMN');
};

const assertReplaceIsPossibleUsingDragNDrop = () => {
  assertReplaceIsPossible('dragndrop');
};

const assertReplaceIsPossibleUsingBreadcrumb = (diagramName) => {
  assertReplaceIsPossible('breadcrumb', diagramName);
};

const assertReplaceIsPossible = (type = 'breadcrumb', diagramName) => {
  if (type === 'breadcrumb') {
    cy.openBreadcrumbMenu(diagramName);
    cy.get('[id="raised-button-file"]').attachFile('diagrams/process-id-one.xml');
  } else if (type === 'dragndrop') {
    cy.getByTestId('drop-target').attachFile('diagrams/process-id-one.xml', { subjectType: 'drag-n-drop' });
  }
  cy.findByText(/autosaved at/i).should('exist');
  cy.findByText(/the previous diagram content has been saved as a milestone/i).should('exist');
};

const assertExportSuccessful = (diagramName, type, size) => {
  cy.readFile(`cypress/downloads/${sanitizeName(diagramName)}.${type}`, 'binary', { timeout: 15000 }).should(
    (buffer) => {
      expect(buffer.length).to.be.gt(size);
    }
  );
};
