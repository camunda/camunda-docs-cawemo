import { getComment, getURL, getMention } from '../../helpers';

describe('Specification property', function () {
  beforeEach(function () {
    cy.createUserAndLogin().as('user').then(cy.createProject).as('project').then(cy.createDiagram).as('diagram');
  });

  afterEach(function () {
    cy.removeUser(this.user);
  });

  it('a user can toggle the specification sidebar', function () {
    cy.visit(`/diagrams/${this.diagram.id}`);

    // Assert that the sidebar is closed by default.
    cy.getByTestId('specification-wrapper').should('not.exist');

    // Open the sidebar.
    cy.getByTestId('specification-toggle')
      .should('have.text', 'Details')
      .should('have.attr', 'title', 'Open Details Panel')
      .click()
      .getByTestId('specification-wrapper')
      .should('be.visible');

    cy.wait(500);

    // Refresh and check if sidebar stays open.
    cy.reload();

    cy.wait(500);

    cy.getByTestId('specification-wrapper').should('be.visible');

    // Close the sidebar and check if it stays closed.
    cy.getByTestId('specification-toggle')
      .should('have.attr', 'title', 'Close Details Panel')
      .click()
      .getByTestId('specification-wrapper')
      .should('not.exist');

    cy.wait(500);

    // Refresh and check if sidebar stays closed.
    cy.reload().getByTestId('specification-wrapper').should('not.exist');

    cy.wait(500);
  });

  it('a user can create comments', function () {
    const rootComment = getComment();
    const elementComment = getComment();
    const url = getURL();
    const mention = getMention();

    cy.visit(`/diagrams/${this.diagram.id}`);

    // Open the sidebar
    cy.getByTestId('specification-toggle').click();

    // Assert that the button is disabled by default.
    cy.getByTestId('comment-submit').should('be.disabled');

    // Type a new comment.
    cy.getByTestId('comment-input')
      .find('textarea')
      .first()
      .should('have.focus')
      .should('have.attr', 'placeholder', 'Reply...')
      .type(rootComment);

    // Submit new comment.
    cy.getByTestId('comment-submit').should('not.be.disabled').click();

    // Assert that the comment has been created.
    cy.getByTestId('comment-wrapper')
      .should('have.length', 1)
      .getByTestId('comment-author')
      .should('have.text', 'You')
      .getByTestId('comment-content')
      .should('have.text', rootComment);

    // Test keyboard shortcuts.
    cy.getByTestId('comment-input')
      .find('textarea')
      .first()
      .click()
      .type(rootComment + '{shift}{enter}{enter}' + rootComment)
      .type('{enter}');

    // Create and assert a new comment with an URL.
    cy.getByTestId('comment-input')
      .find('textarea')
      .first()
      .click()
      .type(url + '{enter}')
      .getByTestId('comment-wrapper')
      .should('have.length', 3)
      .last()
      .find('[data-test="comment-content"]')
      .children('a')
      .should('have.attr', 'href', url);

    // Create and assert a new comment with a mention.
    cy.getByTestId('comment-input')
      .find('textarea')
      .first()
      .click()
      .type(mention + '{enter}')
      .getByTestId('comment-wrapper')
      .should('have.length', 4)
      .last()
      .find('[data-test="comment-content"]')
      .should('have.text', mention);

    // Create a comment for the start event.
    cy.getBPMN('StartEvent_1')
      .click()
      .getByTestId('comment-wrapper')
      .should('have.length', 0)
      .getByTestId('comment-input')
      .find('textarea')
      .first()
      .click()
      .type(elementComment + '{enter}')
      .getByTestId('comment-wrapper')
      .should('have.length', 1);

    // Assert that element comments are not displayed without selection.
    cy.getBPMN('Process_')
      .first()
      .click()
      .getByTestId('comment-wrapper')
      .should('have.length', 4)
      .should('not.have.text', elementComment);

    // Assert that the start event has an overlay.
    cy.getByTestId('bpmn-overlay')
      .should('have.length', 1)
      .click()
      .getBPMN('StartEvent_1')
      .should('have.class', 'selected')
      .getByTestId('comment-content')
      .should('have.text', elementComment);
  });

  it('a user can delete a comment', function () {
    cy.visit(`/diagrams/${this.diagram.id}`);

    // Create two comments and open the sidebar.
    cy.createComment(this.diagram.id).createComment(this.diagram.id);

    cy.wait(500);

    cy.reload().getByTestId('specification-toggle').click();

    cy.wait(500);

    // Open the first comment's menu.
    cy.getByTestId('comment-wrapper').first().find('[data-test="comment-button"]').click({ force: true });

    // Delete the comment
    cy.getByTestId('delete-comment')
      .should('have.text', 'Delete Comment')
      .click()
      .getByTestId('comment-submit-delete')
      .should('be.visible')
      .should('have.text', 'Delete Comment')
      .click();

    // Assert that the comment has been deleted.
    cy.getByTestId('comment-wrapper').should('have.length', 1);
  });

  it('a user can edit a comment', function () {
    cy.visit(`/diagrams/${this.diagram.id}`);

    // Create a comment and open the sidebar.
    cy.createComment(this.diagram.id);

    cy.wait(500);

    cy.reload().getByTestId('specification-toggle').click();

    cy.wait(500);

    // Open the first comment's menu.
    cy.getByTestId('comment-button').click({ force: true });

    // Edit the comment.
    cy.getByTestId('edit-comment')
      .should('have.text', 'Edit Comment')
      .click()
      .focused()
      .clear()
      .type('Edited comment')
      .getByTestId('comment-submit-update')
      .should('be.visible')
      .should('have.text', 'Update Comment')
      .click();

    // Assert that the comment has been deleted.
    cy.getByTestId('comment-wrapper')
      .should('have.length', 1)
      .getByTestId('comment-content')
      .should('have.text', 'Edited comment');
  });

  it('a user can manage documentation', function () {
    const url = getURL();
    const elementDocumentation = getComment();
    const rootDocumentation = getComment();

    cy.visit(`/diagrams/${this.diagram.id}`);

    // Open the sidebar.
    cy.getByTestId('specification-toggle').click();

    // Assert that the documentation and title are correct.
    cy.getByTestId('specification-preview')
      .should('have.text', 'You can click to add specifications...')
      .getByTestId('specification-title')
      .should('have.text', this.diagram.name);

    // Create a new root documentation.
    cy.getByTestId('specification-preview')
      .click()
      .getByTestId('specification-input')
      .should('be.visible')
      .should('have.focus')
      .type(`${rootDocumentation}{enter}${url}`);

    // Assert that the title changes on element renaming.
    cy.getBPMN('StartEvent_1')
      .click()
      .getByTestId('specification-title')
      .should('have.text', 'StartEvent')
      .getBPMN('StartEvent_1')
      .dblclick()
      .get('[contenteditable]')
      .type('Start Event #1{enter}')
      .getBPMN('Process_')
      .first()
      .click()
      .getBPMN('StartEvent_1')
      .first()
      .click()
      .getByTestId('specification-title')
      .should('have.text', 'Start Event #1');

    // Create a new documentation for the start event.
    cy.getByTestId('specification-preview')
      .should('have.text', 'You can click to add specifications...')
      .click()
      .getByTestId('specification-input')
      .type(elementDocumentation)
      .getBPMN('Process_')
      .first()
      .click();

    // Assert that the root preview is correct.
    cy.getByTestId('specification-preview').should('contain', rootDocumentation);

    // Assert that the start event has documentation.
    cy.getByTestId('bpmn-overlay')
      .should('have.length', 1)
      .click()
      .getBPMN('StartEvent_1')
      .should('have.class', 'selected')
      .getByTestId('specification-preview')
      .should('have.text', elementDocumentation);

    // Delete documentation from the start event.
    cy.getByTestId('specification-preview').click().focused().clear().getBPMN('Process_').first().click();

    // Assert that the start event doesn't have an overlay.
    cy.getByTestId('bpmn-overlay').should('not.exist');

    // Assert that the link is working.
    cy.getByTestId('specification-preview')
      .find('a')
      .should('have.attr', 'href', url)
      .should('have.attr', 'rel', 'noopener');

    cy.wait(1000);
  });

  it('overlays should be visible on shares and embeds', function () {
    const elementDocumentation = getComment();
    const rootDocumentation = getComment();

    cy.visit(`/diagrams/${this.diagram.id}`);

    // Open the sidebar.
    cy.getByTestId('specification-toggle').click();

    // Create a new root documentation.
    cy.getByTestId('specification-preview')
      .click()
      .getByTestId('specification-input')
      .should('be.visible')
      .type(rootDocumentation);

    // Assert that the title changes on element renaming.
    cy.getBPMN('StartEvent_1')
      .click()
      .getByTestId('specification-preview')
      .click()
      .getByTestId('specification-input')
      .type(elementDocumentation);

    // Append a new task to the StartEvent.
    cy.append(null, 'append-task', 'Task #1');

    // Create a comment for the newly created task.
    cy.getBPMN('Activity_').then(($el) => {
      cy.createComment(this.diagram.id, $el.attr('data-element-id'));
    });

    // Create a share and open it.
    cy.createShare(this.diagram.id).then((shareId) => {
      cy.visit(`/shares/${shareId}`);

      // Get the first overlay icon and click it to show the tooltip.
      cy.getByTestId('bpmn-overlay').should('have.length', 2).first().click({ force: true });

      // Assert that the correct documentation is displayed.
      cy.getByTestId('specification-overlay').should('be.visible').and('have.text', elementDocumentation);

      // Get the last overlay icon and click it to show the tooltip.
      cy.getByTestId('bpmn-overlay').last().click({ force: true });

      // Assert that the correct documentation is displayed.
      cy.getByTestId('specification-overlay').should('be.visible').and('have.text', rootDocumentation);

      // Assert that the task doesn't have an overlay, since it's a comment.
      cy.getBPMN('Activity_').then(($el) => {
        cy.get(`[data-container-id="${$el.attr('data-element-id')}]`).should('not.exist');
      });

      // Open the same share as an embed.
      cy.visit(`/embed/${shareId}`);

      // Get the first overlay icon and click it to show the tooltip.
      cy.getByTestId('bpmn-overlay').should('have.length', 2).first().click({ force: true });

      // Assert that the correct documentation is displayed.
      cy.getByTestId('specification-overlay').should('be.visible').and('have.text', elementDocumentation);

      // Get the last overlay icon and click it to show the tooltip.
      cy.getByTestId('bpmn-overlay').last().click({ force: true });

      // Assert that the correct documentation is displayed.
      cy.getByTestId('specification-overlay').should('be.visible').and('have.text', rootDocumentation);
    });
  });
});
