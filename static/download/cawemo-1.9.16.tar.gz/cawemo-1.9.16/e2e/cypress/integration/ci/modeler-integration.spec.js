import downloadDiagram from '../../utils/download-diagram';
import openDiagramInModeler from '../../utils/modeler/open-diagram-in-modeler';
import saveContentAsFile from '../../utils/save-content-as-file';
import { getBaseUrl, isSaaS } from '../../helpers';

if (Cypress.env('ci')) {
  describe('Modeler integration', function () {
    before(function () {
      // Create owner, project, diagram and API key.
      cy.createUser().then((owner) => {
        Cypress.env('owner', owner);
        Cypress.env('modelerProjectName', `${owner.name}'s diagrams`);

        cy.createProject(owner).then((project) => {
          Cypress.env('project', project);

          cy.createDiagram(project).then((diagram) => Cypress.env('diagram', diagram));
        });
        cy.createApiKey(owner, owner.organization.id, Cypress.env('engineApiKeySecret'));
      });
    });

    after(function () {
      cy.removeUser(Cypress.env('owner'));
    });

    beforeEach(function () {
      cy.prepareDownload();
      cy.login(Cypress.env('owner'));
    });

    it('download and sync a diagram correctly', function () {
      const owner = Cypress.env('owner');
      // Assert that there are no deployed projects, yet.
      cy.contains('Modeler project').should('not.exist');

      cy.visit(`/diagrams/${Cypress.env('diagram').id}`);

      // Create a few elements in the diagram.
      cy.getBPMN('StartEvent_1')
        .click()
        .get('[data-action="append.append-task"]')
        .should('be.visible')
        .click()
        .getByTestId('autosave')
        .should('contain', 'Autosaved')
        .get('[contenteditable]')
        .type('Modeler Sync Task #1{enter}')
        .getByTestId('autosave')
        .should('contain', 'Autosaved')
        .get('[data-action="append.end-event"]')
        .click();

      // Wait until the diagram has saved.
      cy.wait(200).getByTestId('autosave').should('contain', 'Autosaved');

      // Open the export menu and click the "Export as BPMN" button.
      cy.getByTestId('export-menu').click().getByTestId('export-xml').click();

      cy.get('a[download]')
        .then(downloadDiagram)
        .then(saveContentAsFile('downloaded-diagram.bpmn'))
        .then(openDiagramInModeler({ apiKey: Cypress.env('engineApiKey'), user: owner }));

      cy.wait(10000);

      cy.intercept(getBaseUrl('internal-api/files/*/related*')).as('getRelatedFiles');

      // Assert that there is the deployed project.
      cy.visit('/')
        .getByTestId(`entity-${Cypress.env('modelerProjectName')}`)
        .should('exist')
        .click()
        .getByTestId('entity-list')
        .find('li')
        .should('have.length', 1)
        .click();

      // Store the synced diagram URL for further use and assert that the task has the correct text.
      cy.url()
        .then((syncedDiagram) => Cypress.env('syncedDiagram', syncedDiagram))
        .getBPMN('Activity_')
        .first()
        .should('have.text', 'Modeler Sync Task #1');

      // wait for the last request to finish before logout is triggered in the following "beforeEach"
      cy.intercept(getBaseUrl(`internal-api/files/*/related*`)).as('getRelatedFiles');
      cy.wait('@getRelatedFiles');
    });

    it('an uploaded diagram can be diffed', function () {
      cy.visit(`/diagrams/${Cypress.env('diagram').id}`);

      cy.getBPMN('Activity_')
        .first()
        .dblclick()
        .get('[contenteditable]')
        .clear()
        .type('Changed Task{enter}')
        .getByTestId('autosave')
        .should('contain', 'Autosaved');

      cy.visit(`/milestones/${Cypress.env('diagram').id}`);

      cy.getByTestId('version').click();

      cy.getBPMN('Activity_').first().should('have.class', 'diff-changed');

      cy.getByTestId('version')
        .should('contain', Cypress.env('modelerProjectName'))
        .getByTestId('version-menu')
        .click()
        .getByTestId('open-version')
        .click()
        .getByTestId('breadcrumb-diagram')
        .should('not.have.text', Cypress.env('diagram').name)
        .getByTestId('version')
        .should('contain', Cypress.env('diagram').name);
    });

    it('a modeler milestone can be deleted only by the admin', function () {
      // Create a second user using the invited email address.
      cy.createUser().then((collaborator) => {
        if (isSaaS()) {
          // in Enterprise all users are already added to the only organization
          // the access to the organization is enough because ENGINE projects are visible to everyone
          cy.task('db.createOrganizationPermission', { organization: Cypress.env('owner').organization, user: collaborator });
        }

        // Change the session.
        cy.login(collaborator);

        // Open the synced diagram.
        cy.visit(Cypress.env('syncedDiagram'));

        // Assert that the delete menu item is not visible.
        cy.getByTestId('milestone-menu-button')
          .last()
          .click({ force: true })
          .getByTestId('milestone-menu-item-delete')
          .should('not.exist');

        // Log in as the administrator and open the synced diagram.
        cy.login(Cypress.env('owner')).visit(Cypress.env('syncedDiagram'));

        // Assert that the milestone is visible.
        cy.getByTestId('milestone').should('have.length', 1).and('contain', 'Untitled milestone');

        // Assert that the "Delete" entry is visible in the milestone menu and click it.
        cy.getByTestId('milestone-menu-button')
          .last()
          .click({ force: true })
          .getByTestId('milestone-menu-item-delete')
          .should('be.visible')
          .click()
          .getByTestId('confirm-button')
          .click();

        // Assert that the diagram has been deleted and that the user is redirected back
        // to the project page.
        cy.url().should('include', 'projects');

        // Delete the invited user.
        cy.removeUser(collaborator);
      });
    });
  });
}
