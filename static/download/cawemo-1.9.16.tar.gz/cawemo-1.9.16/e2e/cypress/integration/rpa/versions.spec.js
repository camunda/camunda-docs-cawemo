import { getBaseUrl, getNameFor, isEnterprise, isSaaS } from '../../helpers';

describe('Template versions', function () {
  beforeEach(function () {
    cy.createUserAndLogin()
      .as('user')
      .then((user) => {
        cy.createProject(user, 'CATALOG')
          .as('catalog')
          .then((catalog) => {
            cy.createTemplate(catalog, 'TEMPLATE_SERVICE_TASK').as('template');
          });
      });

    cy.window().then((win) => {
      win.localStorage.setItem('cawemo.diffing', 'false');
    });
  });

  afterEach(function () {
    cy.removeUser(this.user);
    cy.removeAllProjectsIfEnterprise();
  });

  it('the owner can publish a new version', function () {
    // Give the current user an enterprise license.
    cy.createEnterpriseLicense(this.user);

    // Stub the template saving route.
    cy.intercept({
      url: getBaseUrl(`internal-api/files/${this.template.id}**`),
      method: 'PATCH'
    }).as('saving');

    // Open the template.
    cy.visit(`/templates/${this.template.id}`);

    // Wait until the template has loaded.
    cy.wait('@saving');

    // Wait until the template's name is shown, meaning that the template has loaded.
    cy.get('input[name="name"]').should('be.visible').and('have.value', this.template.name);

    // Assert that the "Publish" button is visible and click it.
    cy.getByTestId('publish-template').should('be.visible').and('have.text', 'Publish').click();

    // Assert that the validation failed because no topic was specified, and that the
    // proper snackbar is displayed.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .and('have.text', 'This template cannot be published. Please complete all required fields.');

    // Assert that the publish dialog is not visible.
    cy.getByTestId('dialog-title').should('not.exist');

    // Write the package name to satisfy the validation.
    cy.getByTestId('implementation-name').type('package.name');

    // Wait until the template has saved.
    cy.wait('@saving');

    // Hit the "Publish" button.
    cy.getByTestId('publish-template').click();

    // Assert that the dialog title is visible and has the right text.
    cy.getByTestId('dialog-title').should('be.visible').and('have.text', 'Publish a new version');

    // Assert that the "Confirm" button has the right text and click it.
    cy.getByTestId('confirm').should('have.text', 'Publish').click();

    // Assert that the snackbar is visible and has the right text.
    cy.getByTestId('snackbar').should('be.visible').and('have.text', `"${this.template.name}" has been published.`);

    // Assert that the "Publish" button is disabled.
    cy.getByTestId('publish-template').should('be.disabled');

    // Update the service task label.
    cy.get('input[name="service-task-label"]').type('label-1');

    // Wait until the template has saved.
    cy.wait('@saving');

    // Assert that the "Publish" button is disabled.
    cy.getByTestId('publish-template').should('not.be.disabled').click();

    // Assert that the input has the right placeholder and set a new version name.
    cy.getByTestId('version-name').should('have.attr', 'placeholder', 'Untitled version 2').type('Version 2');

    // Click the "Confirm" button.
    cy.getByTestId('confirm').click();

    // Assert that the snackbar is visible and has the right text.
    cy.getByTestId('snackbar').should('be.visible').and('have.text', `"${this.template.name}" has been published.`);

    // Assert that the "Show version history" entry is visible and click it.
    cy.getByTestId('version-history').should('be.visible').and('have.attr', 'title', 'Show version history').click();

    // Assert that the correct URL is loaded.
    cy.url().should('include', '/versions/');

    // Wait for the editor to load.
    cy.waitForEditor();

    // Assert that there are 3 versions.
    cy.getByTestId('milestone').should('have.length', 2);

    // Assert that all versions have the correct text.
    cy.getByTestId('milestone').eq(0).should('contain', 'Version 2');
    cy.getByTestId('milestone').eq(1).should('contain', 'Untitled version 1');
  });

  it("collaborators or owners without a license can't publish or see versions", function () {
    // Open the template.
    cy.visit(`/templates/${this.template.id}`);

    // Wait until the template's name is shown, meaning that the template has loaded.
    cy.get('input[name="name"]').should('be.visible').and('have.value', this.template.name);

    if (!isEnterprise()) {
      // Assert that the "Publish" button is not visible.
      cy.getByTestId('publish-template').should('not.exist');

      // Open the breadcrumb menu.
      cy.getByTestId('breadcrumb-template').click({ force: true });

      // Assert that the "Show version history" is not visible.
      cy.getByTestId('version-history').should('not.exist');

      // Open the version history.
      cy.visit(`/versions/${this.template.id}`);

      // Assert that the user was redirected back to the template page.
      cy.url().should('include', '/templates/');
    }

    // Join a new user to the organization.
    cy.joinUserToOrganization(this.user).then((collaborator) => {
      // Login as the new user.
      cy.login(collaborator).visit(`/templates/${this.template.id}`);

      // Wait until the template's name is shown, meaning that the template has loaded.
      cy.get('input[name="name"]').should('be.visible').and('have.value', this.template.name);

      // Assert that the "Publish" button is not visible.
      cy.getByTestId('publish-template').should('not.exist');

      // Open the version history.
      cy.visit(`/versions/${this.template.id}`);

      // Assert that the user was redirected back to the template page.
      cy.url().should('include', '/templates/');

      cy.removeUser(collaborator);
    });
  });

  it('the owner can rename a version', function () {
    // Give the current user an enterprise license.
    cy.createEnterpriseLicense(this.user);

    // Create a new version and open the version history.
    cy.createMilestone(this.template.id, 'Version').visit(`/versions/${this.template.id}`);

    // Wait for the editor to load.
    cy.waitForEditor();

    // Open the versions's menu.
    cy.getByTestId('milestone-menu-button').click({ force: true });

    // Assert that the "Edit name" entry is visible and click it.
    cy.getByTestId('milestone-menu-item-rename').should('be.visible').and('have.text', 'Edit name').click();

    // Enter the new versions name.
    cy.getByTestId('editable-input').should('exist').type('Renamed version{enter}');

    // Check if renaming succeeded.
    cy.getByTestId('editable-text').should('have.text', 'Renamed version');
  });

  it('the owner can delete a version', function () {
    // Give the current user an enterprise license.
    cy.createEnterpriseLicense(this.user);

    // Create a new version and open the version history.
    cy.createMilestone(this.template.id, 'Version 1')
      .createMilestone(this.template.id, 'Version 2')
      .visit(`/versions/${this.template.id}`);

    // Wait for the editor to load.
    cy.waitForEditor();

    // Open the versions's menu.
    cy.getByTestId('milestone-menu-button').last().click({ force: true });

    // Assert that the "Delete" entry is visible and click it.
    cy.getByTestId('milestone-menu-item-delete').should('be.visible').and('have.text', 'Delete').click();

    // Assert that the dialog title has the correct text.
    cy.getByTestId('dialog-title').should('have.text', 'Delete version');

    // Assert that the confirm button has the right text and click it.
    cy.getByTestId('confirm-button').should('have.text', 'Delete version').click();

    // Assert that the proper snackbar is displayed.
    cy.getByTestId('snackbar').should('be.visible').should('have.text', 'Version has been deleted.');

    // Assert that 1 milestone has been deleted.
    cy.getByTestId('milestone').should('have.length', 1);

    // Open the versions's menu.
    cy.getByTestId('milestone-menu-button').click({ force: true });

    // Click the "Delete" entry.
    cy.getByTestId('milestone-menu-item-delete').click();

    // Assert that the dialog title has the correct text.
    cy.getByTestId('dialog-title').should('have.text', 'Delete latest published version');

    // Click the confirm button.
    cy.getByTestId('confirm-button').click();

    // Assert that all versions are gone and that the "Latest version" is displayed.
    cy.getByTestId('milestone').should('have.length', 1).and('contain', 'Latest version');
  });

  it('the owner can restore a version', function () {
    // Give the current user an enterprise license.
    cy.createEnterpriseLicense(this.user);

    // Stub the template saving route.
    cy.intercept({
      url: getBaseUrl(`internal-api/files/${this.template.id}**`),
      method: 'PATCH'
    }).as('saving');

    // Open the template page.
    cy.visit(`/templates/${this.template.id}`);

    // Wait until the template has been loaded.
    cy.wait('@saving');

    // Create a version.
    cy.createMilestone(this.template.id, 'Version');

    // Update the template description.
    cy.get('textarea[name="description"]').type('Description update');

    // Wait until the template has been saved.
    cy.wait('@saving');

    // Open the version history page.
    cy.visit(`/versions/${this.template.id}`);

    // Wait for the editor to load.
    cy.waitForEditor();

    // Assert that the updated description is visible.
    cy.contains('"description": "Description update"').should('exist');

    // Open the versions's menu.
    cy.getByTestId('milestone-menu-button').click({ force: true });

    // Click the "Restore as latest" entry.
    cy.getByTestId('milestone-menu-item-restore').should('be.visible').and('have.text', 'Restore as latest').click();

    // Assert that the proper snackbar is displayed.
    cy.getByTestId('snackbar').should('be.visible').and('have.text', 'Version has been restored.');

    // Assert that 2 new versions have been created.
    cy.getByTestId('milestone').should('have.length', 3);

    // Assert that the previous description (empty) is visible.
    cy.contains('"description": "Description update"').should('not.exist');
    cy.contains('"description": ""').should('exist');

    // Select the "Autosaved" version.
    cy.getByTestId('milestone').eq(1).should('contain', 'Autosaved during restore').click();

    // Assert that the updated description is visible.
    cy.contains('"description": "Description update"').should('exist');
  });

  it('the owner can copy a version into a new catalog', function () {
    const newTargetCatalog = getNameFor('catalog');

    // Give the current user an enterprise license.
    cy.createEnterpriseLicense(this.user);

    // Stub the template saving route.
    cy.intercept({
      url: getBaseUrl(`internal-api/files/${this.template.id}**`),
      method: 'PATCH'
    }).as('saving');

    // Open the template page.
    cy.visit(`/templates/${this.template.id}`);

    // Wait until the template has been loaded.
    cy.wait('@saving');

    // Update the template description.
    cy.get('textarea[name="description"]').type('Description update');

    // Wait until the template has been saved.
    cy.wait('@saving');

    // Create a version and open the version history.
    cy.createMilestone(this.template.id, 'Version').visit(`/versions/${this.template.id}`);

    // Wait for the editor to load.
    cy.waitForEditor();

    if (isSaaS()) {
      // Close the EOL banner that might interfere with the test.
      cy.get('[data-test="banner"]').find('button').click();
    }

    // Open the versions's menu.
    cy.getByTestId('milestone-menu-button').click({ force: true });

    // Assert that the "Copy to catalog" entry is visible.
    cy.getByTestId('milestone-menu-item-copy').should('be.visible').and('have.text', 'Copy to...').click();

    // Go one level up to the organization root.
    cy.getByTestId('move-level-up').click();

    // Click the "Create new" button.
    cy.getByTestId('create-new-target').should('be.visible').and('have.attr', 'title', 'Create new').click();

    // Enter a new project name into the input.
    cy.getByTestId('target-name')
      .should('be.visible')
      .and('have.value', 'New Catalog')
      .type(newTargetCatalog)
      .getByTestId('submit')
      .click();

    // Click the "Confirm" button.
    cy.getByTestId('confirm-move').should('not.be.disabled').click();

    // Assert that the proper snackbar is visible.
    cy.getByTestId('snackbar').should('be.visible').and('have.text', 'Template has been created from this version.');

    // Assert that the catalog page is opened.
    cy.url().should('include', '/projects/').getByTestId('project-name').should('have.text', newTargetCatalog);

    // Assert that the copied template is visible and open it.
    cy.getByTestId('entity-list')
      .children()
      .should('have.length', 1)
      .first()
      .should('contain', `${this.template.name} - Copy of Version`)
      .click();

    // Assert that the updated description is visible.
    cy.get('textarea[name="description"]').should('have.value', 'Description update');
  });

  it('the owner can copy a version into an existing catalog', function () {
    // Give the current user an enterprise license.
    cy.createEnterpriseLicense(this.user);

    // Create a second catalog.
    cy.createProject(this.user, 'CATALOG').then((catalog) => {
      // Stub the template saving route.
      cy.intercept({
        url: getBaseUrl(`internal-api/files/${this.template.id}**`),
        method: 'PATCH'
      }).as('saving');

      // Open the template page.
      cy.visit(`/templates/${this.template.id}`);

      // Wait until the template has been loaded.
      cy.wait('@saving');

      // Update the template description.
      cy.get('textarea[name="description"]').type('Description update');

      // Wait until the template has been saved.
      cy.wait('@saving');

      // Create a version and open the version history.
      cy.createMilestone(this.template.id, 'Version').visit(`/versions/${this.template.id}`);

      // Wait for the editor to load.
      cy.waitForEditor();

      if (isSaaS()) {
        // Close the EOL banner that might interfere with the test.
        cy.get('[data-test="banner"]').find('button').click();
      }

      // Open the versions's menu.
      cy.getByTestId('milestone-menu-button').click({ force: true });

      // Open the "Copy to...".
      cy.getByTestId('milestone-menu-item-copy').click();

      // Go one level up to the organization root.
      cy.getByTestId('move-level-up').click();

      // Assert that the target catalog exists and select it.
      cy.getByTestId(`item-${catalog.name}`).should('have.text', catalog.name).click();

      // Assert that the "Move" button is enabled.
      cy.getByTestId('confirm-move').should('not.be.disabled').click();

      // Assert that the proper snackbar is visible.
      cy.getByTestId('snackbar').should('be.visible').and('have.text', 'Template has been created from this version.');

      // Assert that the new diagram is inside the correct catalog.
      cy.url().should('include', '/projects/').getByTestId('breadcrumb-project-menu').should('have.text', catalog.name);

      // Assert that the copied template is visible and open it.
      cy.getByTestId('entity-list')
        .children()
        .should('have.length', 1)
        .first()
        .should('contain', `${this.template.name} - Copy of Version`)
        .click();

      // Assert that the updated description is visible.
      cy.get('textarea[name="description"]').should('have.value', 'Description update');
    });
  });

  it('the owner can publish the latest version', function () {
    // Give the current user an enterprise license.
    cy.createEnterpriseLicense(this.user);

    // Open the template page.
    cy.visit(`/versions/${this.template.id}`);

    // Wait for the editor to load.
    cy.waitForEditor();

    // Assert that one version "Latest version" exists.
    cy.getByTestId('milestone').should('have.length', 1).and('contain', 'Latest version');

    // Click the "Publish" button.
    cy.getByTestId('publish-version').click({ force: true });

    // Assert that the validation failed because no topic was specified, and that the
    // proper snackbar is displayed.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .and('have.text', 'This template cannot be published. Please complete all required fields.');

    // Assert that the publish dialog is not visible.
    cy.getByTestId('dialog-title').should('not.exist');

    // Open the template.
    cy.getByTestId('breadcrumb-diagram').click();

    // Stub the template saving route.
    cy.intercept({
      url: getBaseUrl(`internal-api/files/${this.template.id}**`),
      method: 'PATCH'
    }).as('saving');

    // Write the package name to satisfy the validation.
    cy.getByTestId('implementation-name').type('package.name');

    // Wait until the template has saved.
    cy.wait('@saving').wait('@saving');

    // Assert that the "Show version history" entry is visible and click it.
    cy.getByTestId('version-history').click();

    // Click the "Publish" button.
    cy.getByTestId('publish-version').click({ force: true });

    // Assert that the proper dialog is displayed.
    cy.getByTestId('dialog-title').should('be.visible').and('have.text', 'Publish a new version');

    // Assert that the proper default name is displayed.
    cy.getByTestId('version-name').should('have.attr', 'placeholder', 'Untitled version 1');

    // Click the "Confirm" button.
    cy.getByTestId('confirm').click();

    // Assert that the proper snackbar is displayed.
    cy.getByTestId('snackbar').should('be.visible').and('have.text', `"${this.template.name}" has been published.`);

    // Assert that the "Latest version" is replaced with the actual version.
    cy.getByTestId('milestone').should('have.length', 1).and('contain', 'Untitled version 1');
  });

  it('the owner can toggle version diffing', function () {
    // Give the current user an enterprise license.
    cy.createEnterpriseLicense(this.user);

    // Stub the template saving route.
    cy.intercept({
      url: getBaseUrl(`internal-api/files/${this.template.id}**`),
      method: 'PATCH'
    }).as('saving');

    // Open the template page.
    cy.visit(`/templates/${this.template.id}`);

    // Wait until the template has been loaded.
    cy.wait('@saving');

    // Create a version.
    cy.createMilestone(this.template.id, 'Version 1');

    // Update the template description.
    cy.get('textarea[name="description"]').type('Description update');

    // Wait until the template has been saved.
    cy.wait('@saving');

    // Create a version and open the version history.
    cy.createMilestone(this.template.id, 'Version 2').visit(`/versions/${this.template.id}`);

    // Wait for the editor to load.
    cy.waitForEditor();

    // Assert that the diffing editor is not visible, only the regular editor.
    cy.get('.monaco-diff-editor').should('not.exist').get('.monaco-editor').should('be.visible');

    // Assert that the left title is visible and has the correct text.
    cy.getByTestId('right-editor-title').should('be.visible').and('have.text', 'Version 2');

    // Assert that the right title is not visible.
    cy.getByTestId('left-editor-title').should('not.exist');

    // Assert that the diffing toggle is not checked and click it.
    cy.getByTestId('diffing-toggle').should('not.be.checked').click({ force: true });

    // Assert that the diffing toggle choice was persisted in localStorage.
    cy.window().then((win) => {
      expect(win.localStorage.getItem('cawemo.diffing')).to.eq('true');
    });

    // Assert that the diffing editor is visible.
    cy.get('.monaco-diff-editor').should('be.visible');

    // Assert that the left title has the right text.
    cy.getByTestId('left-editor-title').should('have.text', 'Version 1');

    // Assert that the right title is now visible and has the right text.
    cy.getByTestId('right-editor-title').should('be.visible').and('have.text', 'Version 2');

    // Assert that the updated description is visible on right side.
    cy.contains('"description": "Description update"').should('exist');

    // Assert that the previous description is visible on the left side.
    cy.contains('"description": ""').should('exist');

    // Assert that the accessibility icon for insertion is visible.
    cy.get('.codicon-diff-insert').should('exist').and('have.length', 1);

    // Assert that the accessibility icon for deletion is visible.
    cy.get('.codicon-diff-remove').should('exist').and('have.length', 1);

    // Assert that the diffing toggle is checked and click it.
    cy.getByTestId('diffing-toggle').should('be.checked').click({ force: true });

    // Assert that the diffing toggle choice was persisted in localStorage.
    cy.window().then((win) => {
      expect(win.localStorage.getItem('cawemo.diffing')).to.eq('false');
    });

    // Assert that the updated description is visible.
    cy.contains('"description": "Description update"').should('exist');

    // Assert that the previous description is not visible.
    cy.contains('"description": ""').should('not.exist');

    // Assert that the diffing editor is not visible, only the regular editor.
    cy.get('.monaco-diff-editor').should('not.exist').get('.monaco-editor').should('be.visible');

    // Assert that the left title is visible and has the correct text.
    cy.getByTestId('right-editor-title').should('be.visible').and('have.text', 'Version 2');

    // Assert that the right title is not visible.
    cy.getByTestId('left-editor-title').should('not.exist');
  });

  it('the owner can use the editor controls', function () {
    // Give the current user an enterprise license.
    cy.createEnterpriseLicense(this.user);

    // Open the template page.
    cy.visit(`/versions/${this.template.id}`);

    // Wait for the editor to load.
    cy.waitForEditor();

    // Assert that the fullscreen toggle is visible.
    cy.getByTestId('toggle-fullscreen').should('be.visible');

    // Assert that the minimap initially isn't visible.
    cy.get('.minimap').should('not.be.visible');

    // Assert that the minimap toggle does not exist.
    cy.getByTestId('toggle-minimap').should('not.exist');

    // Assert that the editor has 13px font size by default.
    cy.get('.view-lines').should('have.css', 'font-size', '13px');

    // Assert that the zoom out button is visible and click it.
    cy.getByTestId('zoom-out').should('be.visible').click({ force: true });

    // Assert that the editor has a smaller font size of 12px.
    cy.get('.view-lines').should('have.css', 'font-size', '12px');

    // Assert that the zoom in button is visible and click.
    cy.getByTestId('zoom-in').should('be.visible').click({ force: true });

    // Assert that the editor's font size is back to 13px.
    cy.get('.view-lines').should('have.css', 'font-size', '13px');
  });

  it('diffing view is shown only if there are at least two versions', function () {
    // Create new generic template
    cy.createTemplate(this.catalog).then((template) => {
      // Create 2 versions and open the versions page
      cy.createEnterpriseLicense(this.user);
      cy.createMilestone(template.id, 'Version 1')
        .createMilestone(template.id, 'Version 2')
        .visit(`/versions/${template.id}`);
      cy.waitForEditor();

      // Enable diffing and assert that the diffing is shown
      cy.getByTestId('diffing-toggle').click({ force: true });
      assertDiffingIsShownFor('Version 1', 'Version 2');

      // Assert that the diffing is not shown when the oldest version is selected
      selectVersion('Version 1');
      assertOnlyOneEditorIsShownAndShows('Version 1');

      // Assert that the diffing is shown when the newest version is selected again
      selectVersion('Version 2');
      assertDiffingIsShownFor('Version 1', 'Version 2');

      // Delete one version and assert that the diffing is not shown anymore as only one version is left
      openVersionMenuFor('Version 1');
      deleteVersion();
      assertOnlyOneEditorIsShownAndShows('Version 2');

      // Delete the remaining version, assert that the diffing is again not shown and the latest version is shown
      openVersionMenuFor('Version 2');
      deleteVersion();
      assertVersionIsShown('Latest version');
      assertOnlyOneEditorIsShownAndShows('Latest version');

      // Assert that publishing the latest version works
      cy.getByTestId('publish-version').click();
      cy.findByRole('dialog').within(() => {
        cy.findByRole('button', { name: /publish/i }).click();
      });
      assertVersionIsShown('Untitled version 1');
      assertOnlyOneEditorIsShownAndShows('Untitled version 1');
    });
  });
});

const selectVersion = (versionName) => {
  cy.getByTestId('milestone-sidebar').within(() => {
    cy.findByText(versionName).click();
  });
};

const openVersionMenuFor = (versionName) => {
  cy.get(`[data-cy="milestone-${versionName}"]`).within(() => {
    cy.getByTestId('milestone-menu-button').click();
  });
};

const deleteVersion = () => {
  cy.findByRole('menuitem', { name: /delete/i }).click();
  cy.findByRole('dialog').within(() => {
    cy.findByRole('button', { name: /delete version/i }).click();
  });
};

const assertDiffingIsShownFor = (versionName1, versionName2) => {
  cy.getByTestId('left-editor-title').should('have.text', versionName1).and('be.visible');
  cy.getByTestId('right-editor-title').should('have.text', versionName2).and('be.visible');
  cy.get('.monaco-diff-editor').should('exist');
};

const assertOnlyOneEditorIsShownAndShows = (versionName) => {
  cy.getByTestId('left-editor-title').should('not.exist');
  cy.getByTestId('right-editor-title').should('have.text', versionName).and('be.visible');
  cy.get('.monaco-diff-editor').should('not.exist');
};

const assertVersionIsShown = (versionName) => {
  cy.get(`[data-cy="milestone-${versionName}"]`).should('exist');
};
