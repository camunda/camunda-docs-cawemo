import { getBaseUrl } from '../../helpers';

describe('DMN diagram modeling', function () {
  beforeEach(function () {
    // Create a new user, project, and DMN diagram.
    cy.createUserAndLogin()
      .as('user')
      .then(cy.createProject)
      .as('project')
      .then(cy.createDmnDiagram)
      .as('diagram')
      .then((diagram) => cy.visit(`/diagrams/${diagram.id}`));
  });

  afterEach(function () {
    cy.removeUser(this.user);
  });

  it('a DMN diagram can be edited', function () {
    // Wait until the diagram has been loaded completely and select the first element.
    cy.get('[data-element-id^="Decision_"]').should('be.visible').click();

    // Assert that the "Append Decision" button is visible and click it.f
    cy.get('[data-action="append.decision"]').should('be.visible').and('have.attr', 'title', 'Append Decision').click();

    // Type a new name for the decision table.
    cy.get('.djs-direct-editing-content').should('be.visible').type('Decision 2{enter}');

    // Assert that the "Autosaved" message is visible.
    cy.getByTestId('autosave').should('be.visible').and('contain', 'Autosaved');

    // Assert that the "Append InputData" button is visible and click it.
    cy.get('[data-action="append.input-data"]')
      .should('be.visible')
      .and('have.attr', 'title', 'Append InputData')
      .click();

    // Assert that the "Create Knowledge Source" button is visible and click it.
    cy.get('[data-action="create.knowledge-source"]')
      .should('be.visible')
      .and('have.attr', 'title', 'Create Knowledge Source')
      .click();

    // Place the knowledge source in the diagram canvas.
    cy.get('svg[data-element-id^="Definitions_"]').click(450, 200);

    // Type a new name for the Knowledge Source.
    cy.get('.djs-direct-editing-content').should('be.visible').type('Input #1{enter}');

    // Assert that the "Saving..." message is visible.
    cy.getByTestId('autosave').should('be.visible').and('contain', 'Saving...');

    // Select the second decision table.
    cy.get('[data-element-id^="Decision_"]').last().click();

    // Sometimes, the prior command (clicking the last DecisionTable) fails,
    // in case this happens we click it again.
    cy.get('[data-element-id^="Decision_"]')
      .last()
      .then(($el) => {
        if (!$el.hasClass('selected')) {
          cy.get('[data-element-id^="Decision_"]').last().click();
        }
      });

    // Assert that the wrench icon is visible and click it.
    cy.get('[data-action="replace"]').should('be.visible').and('have.attr', 'title', 'Change type').click();

    // Convert the decision table to a Literal Expression.
    cy.get('[data-id="replace-with-literal-expression"]').should('be.visible').click();

    // Get the second decision table.
    cy.get('[data-element-id^="Decision_"]')
      .last()
      .then(($element) => {
        // Get the element's id through the `data-element-id` attribute.
        const id = $element.data('element-id');

        // Assert that an overlay with this ID exists and that it
        // has the correct icon.
        cy.get(`.djs-overlays[data-container-id="${id}"]`)
          .should('exist')
          .find('.dmn-icon-literal-expression')
          .should('be.visible');
      });
  });

  it('DecisionTable views are working', function () {
    // Open the decision table view.
    cy.get('[data-overlay-id]').should('be.visible').click();

    // Assert that the overview is visible.
    cy.getByTestId('dmn-overview').should('be.visible');

    // Assert that the diagram controls are not visible.
    cy.getByTestId('zoom-in').should('not.exist');

    // Assert that the correct diagram elements are displayed in the overview.
    cy.getByTestId('dmn-overview')
      .find('[data-element-id^="Decision_"]')
      .should('be.visible')
      .and('have.text', 'Decision 1');

    // Assert that the decision table is properly displayed.
    cy.getByTestId('dmn-editor')
      .find('.dmn-decision-table-container')
      .should('be.visible')
      .and('contain', 'Decision 1');

    // Assert that the overview toggle has the proper text and click it.
    cy.getByTestId('toggle-overview').should('be.visible').and('have.text', 'Close Overview').click();

    // Assert that the overview has been hidden.
    cy.getByTestId('dmn-overview').should('not.exist');

    // Assert that the overview toggle has a different label and click it.
    cy.getByTestId('toggle-overview').should('have.text', 'Open Overview').click();

    // Assert that the overview is visible again.
    cy.getByTestId('dmn-overview').should('be.visible');

    // Assert that the diagram has not been saved, yet.
    cy.getByTestId('autosave').should('not.exist');

    // Assert that the first table row has "-" as content and select it.
    cy.get('.tjs-table td').eq(1).should('have.text', '-').click();

    // Change the first rows' content to "Hello World" and submit.
    cy.get('.tjs-table .content-editable').first().type('Hello World{enter}');

    // Assert that the "Autosaved" message is visible.
    cy.getByTestId('autosave').should('be.visible').and('contain', 'Autosaved');

    // Assert that the table now contains 2 rows.
    cy.get('.tjs-table tbody tr').should('have.length', 2);

    // Observe the route for diagram saving.
    cy.intercept({
      method: 'PATCH',
      url: getBaseUrl(`internal-api/files/**/*`)
    }).as('saving');

    // Change the decision's element name and wait for the HTTP request to fire.
    cy.get('.decision-table-name .content-editable').clear().type('Changed name').wait('@saving');

    // Assert that the "Autosaved" message is visible.
    cy.getByTestId('autosave').should('be.visible').and('contain', 'Autosaved');

    // Assert that the "Edit DRD" button is visible and click it.
    cy.get('.view-drd-button').first().should('have.text', 'Edit DRD').click();

    // Assert that the DRD view is shown and that the overview is not visible.
    cy.getByTestId('dmn-overview').should('not.exist');

    // Assert that the decision table has the updated name.
    cy.get('[data-element-id^="Decision_"]').should('have.text', 'Changed name');

    // Assert that the diagram controls are visible again.
    cy.getByTestId('zoom-in').should('be.visible');
  });

  it('ExpressionLiteral views are working', function () {
    // Select the decision table.
    cy.get('[data-element-id^="Decision_"]').click();

    // Assert and select the "Change type" action.
    cy.get('[data-action="replace"]').should('be.visible').click();

    // Assert and select the "Literal Expression" option.
    cy.get('[data-id="replace-with-literal-expression"]')
      .should('be.visible')
      .and('have.text', 'Literal Expression')
      .click();

    // Open the Literal Expression view.
    cy.get('.drill-down-overlay').should('be.visible').click();

    // Assert that the overview is visible.
    cy.getByTestId('dmn-overview').should('be.visible');

    // Assert that the diagram controls are not visible.
    cy.getByTestId('zoom-in').should('not.exist');

    // Assert that the correct diagram elements are displayed in the overview.
    cy.getByTestId('dmn-overview')
      .find('[data-element-id^="Decision_"]')
      .should('be.visible')
      .and('have.text', 'Decision 1');

    // Assert that the decision table is properly displayed.
    cy.getByTestId('dmn-editor')
      .find('.dmn-literal-expression-container')
      .should('be.visible')
      .and('contain', 'Decision 1');

    // Assert that the overview toggle has the proper text and click it.
    cy.getByTestId('toggle-overview').should('be.visible').and('have.text', 'Close Overview').click();

    // Assert that the overview has been hidden.
    cy.getByTestId('dmn-overview').should('not.exist');

    // Assert that the overview toggle has a different label and click it.
    cy.getByTestId('toggle-overview').should('have.text', 'Open Overview').click();

    // Assert that the overview is visible again.
    cy.getByTestId('dmn-overview').should('be.visible');

    // Observe the route for diagram saving.
    cy.intercept({
      method: 'PATCH',
      url: getBaseUrl(`internal-api/files/**/*`)
    }).as('saving');

    // Change the decision's element name and wait for the HTTP request to fire.
    cy.get('.decision-name .content-editable').clear().type('Changed name').wait('@saving');

    // Assert that the "Autosaved" message is visible.
    cy.getByTestId('autosave').should('be.visible').and('contain', 'Autosaved');

    // Assert that the "Edit DRD" button is visible and click it.
    cy.get('.view-drd-button').first().should('have.text', 'Edit DRD').click();

    // Assert that the DRD view is shown and that the overview is not visible.
    cy.getByTestId('dmn-overview').should('not.exist');

    // Assert that the decision table has the updated name.
    cy.get('[data-element-id^="Decision_"]').should('have.text', 'Changed name');

    // Assert that the diagram controls are visible again.
    cy.getByTestId('zoom-in').should('be.visible');
  });

  // TODO include other browsers again by removing {browser: 'chrome'}
  //  after fixing the viewport assertions
  it('diagram controls can be used in a DMN diagram', { browser: 'chrome' }, function () {
    const dimensions = {};
    let rect = {};

    // Get and store the current width and height of the decision table.
    cy.get('[data-element-id^="Decision_"]').then(($element) => {
      dimensions.width = $element.outerWidth();
      dimensions.height = $element.outerHeight();
    });

    // Assert that the "Zoom in" button is visible and click it.
    cy.getByTestId('zoom-in').should('be.visible').click();

    // Assert that the width and height of the decision table have increased.
    cy.get('[data-element-id^="Decision_"]').then(($element) => {
      expect(dimensions.width).to.be.lessThan($element.outerWidth());
      expect(dimensions.height).to.be.lessThan($element.outerHeight());
    });

    // Assert that the "Zoom out" button is visible and click it.
    cy.getByTestId('zoom-out').should('be.visible').click();

    // Assert that the width and height of the decision table are the same as before.
    cy.get('[data-element-id^="Decision_"]').then(($element) => {
      expect(dimensions.width).to.equal(Math.ceil($element.outerWidth()));
      expect(dimensions.height).to.equal(Math.ceil($element.outerHeight()));
    });

    // Open the minimap and assert that it is visible.
    cy.getByTestId('toggle-minimap').click().get('.viewport-dom').should('be.visible');

    // Get the current position and dimension from Decision_.
    cy.get('[data-element-id^="Decision_"]').then(($el) => (rect = $el[0].getBoundingClientRect()));

    // Move the minimap canvas by dragging it.
    cy.get('.viewport-dom')
      .trigger('mousedown', { which: 1 })
      .trigger('mousemove', { clientX: 5, clientY: 5 })
      .trigger('mouseup', { force: true });

    // Assert that the Decision_ has changed its position due
    // to dragging the minimap.
    cy.get('[data-element-id^="Decision_"]').then(($el) => {
      const { x, y } = $el[0].getBoundingClientRect();

      expect(rect.x).to.not.equal(x);
      expect(rect.y).to.not.equal(y);
    });

    // Get the current position and dimension from Decision_.
    cy.get('[data-element-id^="Decision_"]')
      .should('not.be.visible')
      .then(($el) => (rect = $el[0].getBoundingClientRect()));

    // Click the viewport reset control and assert that the
    // Decision_ is back in the viewport area.
    cy.getByTestId('viewport-reset')
      .click()
      .get('[data-element-id^="Decision_"]')
      .should('be.visible')
      .then(($el) => {
        const { x, y } = $el[0].getBoundingClientRect();

        expect(rect.x).to.be.greaterThan(x);
        expect(rect.y).to.be.greaterThan(y);
      });

    // Assert that the "Toggle fullscreen" button is visible.
    cy.getByTestId('toggle-fullscreen').should('be.visible');

    // Assert that the attention grabber button doesn't exist.
    cy.getByTestId('toggle-attentiongrabber').should('not.exist');
  });

  it('a user can copy & paste DMN rules between diagrams', function () {
    cy.createDmnDiagram(this.project).then((diagram) => {
      // Open the diagram.
      cy.visit(`/diagrams/${this.diagram.id}`);

      // Open the decision table view.
      cy.get('[data-overlay-id]').should('be.visible').click();

      // Change the first column's content to "Column #1".
      cy.get('.tjs-table td').eq(1).click().get('.tjs-table .content-editable').first().type('Column #1');

      // Change the second column's content to "Column #2" and press Enter.
      cy.get('.tjs-table td').eq(2).click().get('.tjs-table .content-editable').eq(1).type('Column #2{enter}');

      // Wait for the changes to be saved
      cy.findByText('Saving...').should('exist');
      cy.findByText(/Autosaved/).should('exist');

      // Right click on the first column to open the context menu.
      cy.get('.tjs-table td').eq(1).rightclick();

      // Assert that the entry "Copy Rule" exists and click it.
      cy.get('.context-menu-entry-copy-rule').should('have.text', 'Copy Rule').click();

      // Open the project page and open the other diagram.
      cy.getByTestId('breadcrumb-project').click().getByTestId(`entity-${diagram.name}`).click();

      // Open the decision table view.
      cy.get('[data-overlay-id]').should('be.visible').click();

      // Assert that no rows exist yet.
      cy.get('.tjs-table tbody tr').should('have.length', 0);

      // Select the first column and trigger a right-click.
      cy.get('.tjs-table td').eq(1).click().get('.tjs-table .content-editable').first().rightclick();

      // Assert that the entry "Paste Rule Below" exists and click it.
      cy.get('.context-menu-entry-paste-rule-below').should('be.visible').and('have.text', 'Paste Rule Below').click();

      // Assert that there are 2 rows now (the first one is empty, the second one contains)
      // the pasted content.
      cy.get('.tjs-table tbody tr').should('have.length', 2);

      // Assert that the right columns have the appropriate, copied rule.
      cy.get('.tjs-table td')
        .eq(5)
        .should('have.text', 'Column #1')
        .get('.tjs-table td')
        .eq(6)
        .should('have.text', 'Column #2');
    });
  });
});
