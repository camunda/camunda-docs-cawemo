import { getBaseUrl, getNameFor, sanitizeName } from '../../helpers';

describe('DMN diagrams', function () {
  beforeEach(function () {
    // Create a new user and project
    cy.createUserAndLogin().as('user').then(cy.createProject).as('project');

    cy.window().then((win) => {
      win.localStorage.setItem('cawemo.collaborator_sidebar_visible', 'false');
    });
  });

  afterEach(function () {
    cy.removeUser(this.user);
  });

  it('a new DMN diagram can be created', function () {
    // Navigate to the project page.
    cy.visit(`/projects/${this.project.id}`);

    // Open the "New diagram" dropdown.
    cy.getByTestId('diagram-dropdown').click();

    // Assert that the "New DMN diagram" option is visible and click it.
    cy.getByTestId('create-dmn-diagram').should('be.visible').and('have.text', 'DMN Diagram').click();

    // Assert that the diagram route is shown.
    cy.url().should('include', '/diagrams/');

    // Assert that the DMN renderer is visible.
    cy.getByTestId('dmn-renderer').should('be.visible');

    // Assert that a default decision table exists in the modeler,
    // containing a specific class and text.
    cy.get('[data-element-id^="Decision_"]')
      .should('be.visible')
      .and('have.class', 'djs-element')
      .and('have.text', 'Decision 1');

    // Navigate to the project.
    cy.getByTestId('breadcrumb-project').click();

    // Assert that the new DMN diagram is listed properly.
    cy.getByTestId('entity-New DMN Diagram')
      .should('be.visible')
      .and('have.length', 1)
      .and('contain', 'New DMN Diagram');
  });

  it('a DMN diagram can be renamed', function () {
    // Observed route for diagram renaming.
    cy.intercept({
      method: 'PATCH',
      url: getBaseUrl(`internal-api/files/**/*`)
    }).as('renaming');

    // Navigate to the project page.
    cy.visit(`/projects/${this.project.id}`);

    // Create a new DMN diagram through the dropdown.
    cy.getByTestId('diagram-dropdown').click().getByTestId('create-dmn-diagram').click();

    // Assert that the editable input is shown after diagram creation.
    cy.getByTestId('editable-input').should('be.visible').and('have.value', 'New DMN Diagram');

    // Rename the diagram and wait until the request finishes.
    const name = getNameFor('diagram');
    cy.getByTestId('editable-input')
      .wait(100)
      .type(name + '{enter}')
      .wait('@renaming');

    // Assert that the diagram's name is visible and correct.
    cy.getByTestId('breadcrumb-diagram').should('be.visible').and('have.text', name);

    // Open the diagram menu and assert that the "Edit name" option exists.
    cy.getByTestId('breadcrumb-diagram')
      .click()
      .getByTestId('diagram-menu-item-rename-diagram')
      .should('be.visible')
      .and('have.text', 'Edit name')
      .click();

    // Rename the diagram and wait until the request finishes.
    const name2 = getNameFor('diagram');
    cy.getByTestId('editable-input')
      .type(name2 + '{enter}')
      .wait('@renaming');
  });

  it('a DMN diagram can be deleted from the diagram page', function () {
    // Create a new DMN diagram.
    cy.createDmnDiagram(this.project).then((diagram) => {
      // Navigate to the diagram page.
      cy.visit(`/diagrams/${diagram.id}`);

      // Open the diagram menu.
      cy.getByTestId('breadcrumb-diagram').click();

      // Assert that the "Delete" option is visible and click it.
      cy.getByTestId('diagram-menu-delete').should('be.visible').and('have.text', 'Delete').click();

      // Assert that the dialog is visible and has the proper title.
      cy.getByTestId('dialog-title').should('have.text', 'Deleting diagram');

      // Assert that the confirm button contains "Delete diagram" and click it.
      cy.getByTestId('confirm-button').should('have.text', 'Delete diagram').click();

      // Assert that the project route is shown.
      cy.url().should('include', '/projects/');

      // Assert that no diagrams are shown.
      cy.getByTestId('empty-state').should('be.visible');
    });
  });

  it('a DMN diagram can be deleted from the project page', function () {
    // Create 3 new DMN diagrams.
    for (let i = 0; i < 3; i++) {
      cy.createDmnDiagram(this.project);
    }

    // Open the project page.
    cy.visit(`/projects/${this.project.id}`);

    // Open the first diagram dropdown.
    cy.getByTestId('entity-context-dropdown').first().click({ force: true });

    // Assert that the "Delete" option is visible and click it.
    cy.getByTestId('delete-diagram').should('be.visible').and('have.text', 'Delete').click();

    // Assert that the dialog is visible and has the proper title.
    cy.getByTestId('dialog-title').should('have.text', 'Deleting 1 file');

    // Assert that the confirm button contains "Delete diagram" and click it.
    cy.getByTestId('confirm-button').should('have.text', 'Delete').click();

    // Assert that the proper snackbar is visible.
    cy.getByTestId('snackbar').should('be.visible').and('contain', 'Your data has been deleted.');

    // Assert that the diagram has been deleted.
    cy.getByTestId('entity-list').children().should('have.length', 2);

    // Check the remaining diagram's checkboxes.
    cy.getByTestId('entity-checkbox').click({ multiple: true, force: true });

    // Assert that the multi-action button has the proper text.
    cy.getByTestId('entity-head-dropdown').should('be.visible').and('have.text', '2 items selected').click();

    // Assert that the "Delete" option is visible and click it.
    cy.getByTestId('delete-diagram').should('be.visible').and('have.text', 'Delete').click();

    // Assert that the dialog is visible and has the proper title and confirm deletion.
    cy.getByTestId('dialog-title').should('have.text', 'Deleting 2 files').getByTestId('confirm-button').click();

    // Assert that the proper snackbar is visible.
    cy.getByTestId('snackbar').should('be.visible').and('contain', 'Your data has been deleted.');

    // Assert that all diagrams have been deleted.
    cy.getByTestId('empty-state').should('be.visible');
  });

  it('a DMN diagram can be duplicated from the diagram page', function () {
    // Create a new DMN diagram.
    cy.createDmnDiagram(this.project).then((diagram) => {
      // Navigate to the diagram page.
      cy.visit(`/diagrams/${diagram.id}`);

      // Open the diagram menu.
      cy.getByTestId('breadcrumb-diagram').click();

      // Assert that the "Duplicate" option is visible and click it.
      cy.getByTestId('diagram-menu-duplicate').should('be.visible').and('have.text', 'Duplicate').click();

      // Assert that the duplicated diagram has a "- Copy" appendix.
      cy.getByTestId('breadcrumb-diagram').should('have.text', diagram.name + ' - Copy');

      // Assert that the proper snackbar is visible.
      cy.getByTestId('snackbar').should('be.visible').and('contain', 'Your diagram has been duplicated.');

      // Navigate to the project.
      cy.getByTestId('breadcrumb-project').click();

      // Assert that the project contains 2 diagrams.
      cy.getByTestId('entity-list').children().should('have.length', 2);
    });
  });

  it('a DMN diagram can be duplicated from the project page', function () {
    // Create a new DMN diagram.
    cy.createDmnDiagram(this.project).then((diagram) => {
      // Navigate to the diagram page.
      cy.visit(`/projects/${this.project.id}`);

      // Open the first diagram dropdown.
      cy.getByTestId('entity-context-dropdown').click({ force: true });

      // Assert that the "Duplicate" option is visible and click it.
      cy.getByTestId('duplicate-diagram').should('be.visible').and('have.text', 'Duplicate').click();

      // Assert that the duplicated diagram appears on the page.
      cy.getByTestId(`entity-${diagram.name} - Copy`).should('exist');

      // Assert that there are now 2 diagrams.
      cy.getByTestId('entity-list').children().should('have.length', 2);

      // Check all diagram's checkboxes.
      cy.getByTestId('entity-checkbox').click({ multiple: true, force: true });

      // Assert that the multi-action button has the proper text.
      cy.getByTestId('entity-head-dropdown').should('have.text', '2 items selected').click();

      // Assert that the "Duplicate" option is visible and click it.
      cy.getByTestId('duplicate-diagram').should('have.text', 'Duplicate').click();

      // Assert that there are now 4 diagrams.
      cy.getByTestId('entity-list').children().should('have.length', 4);
    });
  });

  it('a user can move a single diagram into a different project', function () {
    // Create a new project to move the diagrams into.
    cy.createProject(this.user).then((targetProject) => {
      // Create a new DMN diagram.
      cy.createDmnDiagram(this.project).then((diagram) => {
        // Open the project.
        cy.visit(`/projects/${this.project.id}`);

        // Open the context menu of the diagram.
        cy.getByTestId('entity-context-dropdown').click({ force: true });

        // Assert that the "Move" entry exists and click it.
        cy.getByTestId('move-diagram').should('have.text', 'Move').click();

        // Assert that the move component has the correct title and body.
        cy.getByTestId('move-component-title')
          .should('have.text', this.project.name)
          .getByTestId('empty-message')
          .should('be.visible');

        // Go one level up to the organization root.
        cy.getByTestId('move-level-up').click();

        // Assert that the "Move" button is disabled.
        cy.getByTestId('confirm-move').should('be.disabled');

        // Assert that the target project exists and select it.
        cy.getByTestId(`item-${targetProject.name}`).should('have.text', targetProject.name).click();

        // Assert that the "Move" button is enabled.
        cy.getByTestId('confirm-move').should('not.be.disabled').click();

        // Assert that the confirmation is shown before the actual move.
        cy.getByTestId('move-component-title')
          .should('have.text', 'Move items?')
          .getByTestId('confirm-move-message')
          .should('contain', 'These items will inherit permissions');

        // Confirm the move.
        cy.getByTestId('confirm-move').click();

        // Assert that the confirmation dialog is displayed and confirm.
        cy.getByTestId('dialog-title').should('have.text', 'Moving 1 file').getByTestId('confirm-button').click();

        // Assert that the snackbar is shown.
        cy.getByTestId('snackbar').should('be.visible').should('have.text', 'Your data has been moved.');

        // Assert that the diagram is shown inside the target project.
        cy.getByTestId('breadcrumb-project-menu')
          .should('have.text', targetProject.name)
          .getByTestId('entity-list')
          .first()
          .find('li')
          .should('have.length', 1)
          .getByTestId(`entity-${diagram.name}`)
          .should('exist');
      });
    });
  });

  it('a user can move multiple diagrams into a different project', function () {
    // Create 3 new DMN diagrams.
    for (let i = 0; i < 3; i++) {
      cy.createDmnDiagram(this.project);
    }

    // Create a new project.
    cy.createProject(this.user).then((targetProject) => {
      // Open the project.
      cy.visit(`/projects/${this.project.id}`);

      // Assert that there are 3 diagrams.
      cy.getByTestId('entity-list').children().should('have.length', 3);

      // Check all diagram's checkboxes.
      cy.getByTestId('entity-checkbox').click({ multiple: true, force: true });

      // Assert that the multi-action button has the proper text.
      cy.getByTestId('entity-head-dropdown')
        .should('have.text', '3 items selected')
        .click()
        .getByTestId('move-diagram')
        .click();

      // Go one level up to the organization root.
      cy.getByTestId('move-level-up').click();

      // Select the target project.
      cy.getByTestId(`item-${targetProject.name}`).click();

      // Click the "Move" button twice to confirm the action.
      cy.getByTestId('confirm-move').click().click();

      // Assert that the confirmation dialog is displayed and confirm.
      cy.getByTestId('dialog-title').should('have.text', 'Moving 3 files').getByTestId('confirm-button').click();

      // Assert that the move has succeeded.
      cy.getByTestId('snackbar')
        .should('have.text', 'Your data has been moved.')
        .getByTestId('entity-list')
        .first()
        .find('li')
        .should('have.length', 3);
    });
  });

  it('a DMN diagram can be exported as XML', function () {
    // Create a new DMN diagram.
    cy.createDmnDiagram(this.project).then((diagram) => {
      // Navigate to the diagram page.
      cy.visit(`/diagrams/${diagram.id}`);

      // Wait until the diagram has been loaded completely.
      cy.get('[data-element-id^="Decision_"]').should('be.visible');

      // Assert that the export menu is visible and click it.
      cy.getByTestId('export-menu').should('be.visible').click();

      // Get the file download as XML and assert that the XML is good.
      cy.getDownload().then((xml) => {
        expect(xml).to.contain('camunda:diagramRelationId');
        expect(xml).to.contain('<decisionTable');
        expect(xml).to.contain('name="Decision 1"');
      });

      // Assert that the proper snackbar is visible.
      cy.getByTestId('snackbar')
        .should('be.visible')
        .and('have.text', `"${sanitizeName(diagram.name)}.dmn" is being downloaded to your computer.`);
    });
  });
});
