import { getNameFor, getBaseUrl } from '../../helpers';

describe('Folders', function () {
  beforeEach(function () {
    cy.createUserAndLogin()
      .as('user')
      .then(cy.createProject)
      .as('project')
      .then(() => {
        window.localStorage.setItem('cawemo.collaborator_sidebar_visible', 'false');
        window.localStorage.setItem('cawemo.sorting.project', '0=asc');
      });
    cy.deleteAllEmails();
  });

  afterEach(function () {
    cy.removeUser(this.user);
  });

  it('a user can create a new folder', function () {
    // Open the project.
    cy.visit(`/projects/${this.project.id}`);

    // Open the diagram dropdown.
    cy.getByTestId('diagram-dropdown').click();

    // Assert that the option to create a folder is visible and click it.
    cy.getByTestId('create-folder').should('be.visible').and('have.text', 'Folder').click();

    // Assert that the URL is set to the opened folder.
    cy.url().should('include', '/folders/');

    // Assert that the folder's name is displayed above the Entity List.
    cy.getByTestId('folder-name').should('be.visible').and('have.text', 'New Folder');

    // Assert that the action button is visible.
    cy.getByTestId('diagram-dropdown').should('be.visible').and('have.text', 'New');

    // Assert that the proper empty state is displayed.
    cy.getByTestId('empty-state').should('be.visible').and('contain', "This folder doesn't have any content yet.");

    // Assert that the project is displayed in the breadcrumbs and click it.
    cy.getByTestId('breadcrumb-project').should('be.visible').and('have.text', this.project.name).click();

    // Assert that the URL is back to the root project.
    cy.url().should('include', '/projects/');

    // Assert that the project name is displayed above the Entity List.
    cy.getByTestId('project-name').should('be.visible').and('have.text', this.project.name);

    // Assert that the newly created folder is displayed in the Entity List.
    cy.getByTestId('entity-New Folder').should('be.visible').and('contain', 'New Folder');
  });

  it('folders can contain sub-folders and files', function () {
    const diagram1 = getNameFor('diagram');
    const diagram2 = getNameFor('diagram');

    // Create a new folder.
    cy.createFolder(this.project).then((folder) => {
      // Open the folder.
      cy.visit(`/folders/${folder.id}`);

      // Open the diagram dropdown and create a new BPMN diagram.
      cy.getByTestId('diagram-dropdown').click().getByTestId('create-bpmn-diagram').should('be.visible').click();

      // Enter a name for the diagram and go back to the folder.
      cy.getByTestId('editable-input')
        .should('have.value', 'New BPMN Diagram')
        .wait(100)
        .type(diagram1 + '{enter}')
        .getByTestId('breadcrumb-diagram')
        .should('have.text', diagram1)
        .go('back');

      // Assert that the newly created diagram is displayed.
      cy.getByTestId('entity-list').children().should('have.length', 1);

      // Open the diagram dropdown and create a new DMN diagram.
      cy.getByTestId('diagram-dropdown').click().getByTestId('create-dmn-diagram').should('be.visible').click();

      // Enter a name for the diagram and go back to the folder.
      cy.getByTestId('editable-input')
        .should('have.value', 'New DMN Diagram')
        .wait(100)
        .type(diagram2 + '{enter}')
        .getByTestId('breadcrumb-diagram')
        .should('have.text', diagram2)
        .go('back');

      // Assert that the newly created diagram is displayed.
      cy.getByTestId('entity-list').children().should('have.length', 2);

      // Open the diagram dropdown and create a new folder.
      cy.getByTestId('diagram-dropdown').click().getByTestId('create-folder').should('be.visible').click();

      // Assert that the empty state is displayed.
      cy.getByTestId('empty-state').should('be.visible');

      // Assert that the folder's name is displayed above the Entity List.
      cy.getByTestId('folder-name').should('be.visible').and('have.text', 'New Folder');

      // Assert that the action button is visible.
      cy.getByTestId('diagram-dropdown').should('be.visible').and('have.text', 'New');

      // Go back to the parent folder.
      cy.go('back');

      // Assert that the newly created diagrams and folder are displayed.
      cy.getByTestId('entity-list').children().should('have.length', 3);
    });
  });

  it('folders can be sorted and searched', function () {
    cy.createFolder(this.project).then((folder) => {
      // Create a couple of folders and diagrams.
      cy.createDiagram(this.project, { parentId: folder.id, name: 'DEF' });
      cy.createDiagram(this.project, { parentId: folder.id, name: 'ABC' });
      cy.createFolder(this.project, { parentId: folder.id, name: 'HIJ' });
      cy.createFolder(this.project, { parentId: folder.id, name: 'KLM' });

      // Open the project.
      cy.visit(`/folders/${folder.id}`);

      // Assert that folders come first in alphabetical order, followed by diagrams.
      cy.getByTestId('entity-list')
        .children('li')
        .first()
        .should('have.attr', 'data-test', 'entity-HIJ')
        .next()
        .should('have.attr', 'data-test', 'entity-KLM')
        .next()
        .should('have.attr', 'data-test', 'entity-ABC')
        .next()
        .should('have.attr', 'data-test', 'entity-DEF');

      // Click on the "Name" column to change the sorting order.
      cy.getByTestId('entity-head-Name').click();

      cy.getByTestId('sort-icon-Name').should('be.visible');

      // Assert that folders still come first, but in reversed order.
      cy.getByTestId('entity-list')
        .children('li')
        .first()
        .should('have.attr', 'data-test', 'entity-KLM')
        .next()
        .should('have.attr', 'data-test', 'entity-HIJ')
        .next()
        .should('have.attr', 'data-test', 'entity-DEF')
        .next()
        .should('have.attr', 'data-test', 'entity-ABC');

      // Reload the browser.
      cy.reload();

      cy.getByTestId('sort-icon-Name').should('be.visible');

      // Assert that folders still come first, but in reversed order.
      cy.getByTestId('entity-list')
        .children('li')
        .first()
        .should('have.attr', 'data-test', 'entity-KLM')
        .next()
        .should('have.attr', 'data-test', 'entity-HIJ')
        .next()
        .should('have.attr', 'data-test', 'entity-DEF')
        .next()
        .should('have.attr', 'data-test', 'entity-ABC');

      // Type in the first folder's name.
      cy.getByTestId('expand-entity-search').click().getByTestId('entity-search-input').type('HIJ');

      // Assert that the only the first folder appears.
      cy.getByTestId('entity-list').children('li').should('have.length', 1);

      // Assert that the second folder doesn't appear.
      cy.getByTestId('entity-KLM').should('not.exist');
    });
  });

  it.saas('a user can rename a folder', function () {
    const name = getNameFor('folder');

    // Create a new folder and open it.
    cy.createFolder(this.project).then((folder) => {
      cy.intercept({
        method: 'PATCH',
        url: getBaseUrl(`internal-api/folders/${folder.id}*`)
      }).as('renameFolder');

      cy.visit(`/folders/${folder.id}`);

      // Open the folder menu in the breadcrumbs, find the "Edit name"
      // option and click it.
      cy.getByTestId('breadcrumb-folder-menu')
        .click()
        .getByTestId('rename-folder')
        .should('have.text', 'Edit name')
        .click();

      // Type the new name in the input and assert that the new name is displayed.
      cy.getByTestId('editable-input')
        .type(name + '{enter}')
        .wait('@renameFolder')
        .getByTestId('breadcrumb-folder-menu')
        .should('have.text', name)
        .getByTestId('folder-name')
        .should('have.text', name);

      // Assert that new name is still displayed after a page refresh.
      cy.reload().getByTestId('breadcrumb-folder-menu').should('have.text', name);

      // Invite a collaborator with comment-only permissions.
      cy.createUser().then((user) => {
        cy.createInvitation(user, this.project.id, 'COMMENT');

        // Change the session.
        cy.login(user);

        // Await the invitation email and open the link.
        cy.getLinkFromEmail(user.email, 'invite').then(cy.visit);

        // Open the folder and assert that the collaborator can't see
        // the breadcrumb dropdown, only the text.
        cy.getByTestId(`entity-${name}`)
          .should('be.visible')
          .click()
          .getByTestId('breadcrumb-folder-menu')
          .should('not.exist')
          .getByTestId('breadcrumb-folder')
          .should('be.visible')
          .and('have.text', name);

        // Remove the invited user.
        cy.removeUser(user);
      });
    });
  });

  it('a user can delete a folder', function () {
    cy.createFolder(this.project).then((folder1) => {
      cy.createFolder(this.project).then((folder2) => {
        cy.createFolder(this.project).then((folder3) => {
          cy.createFolder(this.project).then((folder4) => {
            cy.createDiagram(this.project);

            cy.visit(`/projects/${this.project.id}`);

            cy.getByTestId('entity-list').children().should('have.length', 5);
            cy.assertFolderEntityPresent(folder1.name);
            cy.assertFolderEntityPresent(folder2.name);
            cy.assertFolderEntityPresent(folder3.name);
            cy.assertFolderEntityPresent(folder4.name);

            // Using entity menu
            cy.openEntityMenu(folder1.name);
            assertDeletingFolderIsPossible(folder1.name, this.project.name);

            // Using breadcrumb menu
            cy.clickEntity(folder2.name);
            cy.openBreadcrumbMenu(folder2.name);
            assertDeletingFolderIsPossible(folder2.name, this.project.name);

            // Multiple delete
            cy.getByTestId('entity-list').children().should('have.length', 3); // 3 items remaining
            cy.getByTestId('entity-checkbox').check({ multiple: true, force: true });
            cy.findByRole('button', { name: /3 items selected/i }).click();
            cy.findByRole('menuitem', { name: /delete/i }).click();
            cy.findByRole('dialog').within(() => {
              cy.findByText(/deleting 2 folders and 1 file/i).should('exist');
              cy.findByRole('button', { name: /delete/i }).click();
            });
            cy.findByText(/data has been deleted/i).should('exist');
            cy.findByText(/this project doesn't have any diagrams yet/i).should('exist');
          });
        });
      });
    });
  });

  it('a user can move folders', function () {
    const newTargetFolder = getNameFor('folder');

    // Create a diagram and unrelated project.
    cy.createDiagram(this.project).createProject(this.user).as('project2');

    // Create two new folders.
    cy.createFolder(this.project).then((folder1) => {
      cy.createFolder(this.project).then((folder2) => {
        // Open the project.
        cy.visit(`/projects/${this.project.id}`);

        // Open the context menu of the second folder.
        cy.getByTestId(`entity-${folder2.name}`).find('[data-test="entity-context-dropdown"]').click({ force: true });

        // Assert that the "Move" entry exists and click it.
        cy.getByTestId('move-diagram').should('have.text', 'Move').click();

        // Assert that the second folder can't be moved into itself.
        cy.getByTestId(`item-${folder2.name}`).should('have.css', 'pointer-events', 'none');

        // Assert that the second folder can be moved into the first one and confirm.
        cy.getByTestId(`item-${folder1.name}`).click().getByTestId('confirm-move').should('not.be.disabled').click();

        // Assert that the first folder is opened and that the second folder has been moved.
        cy.url()
          .should('include', folder1.id)
          .getByTestId('entity-list')
          .children()
          .should('have.length', 1)
          .getByTestId(`entity-${folder2.name}`)
          .should('be.visible');

        // Go back to the project.
        cy.getByTestId('breadcrumb-project').click();

        // Assert that the second folder is no longer visible.
        cy.getByTestId('entity-list')
          .children()
          .should('have.length', 2)
          .getByTestId(`entity-${folder2.name}`)
          .should('not.exist');

        // Check the folder's and diagram's checkboxes.
        cy.getByTestId('entity-checkbox').click({ multiple: true, force: true });

        // Click on "Move" inside the menu.
        cy.getByTestId('entity-head-dropdown').click().getByTestId('move-diagram').click();

        // Go one level up to the organization root.
        cy.getByTestId('move-level-up').click();

        // Assert that the items can't be moved into the same project that they are already in.
        cy.getByTestId(`item-${this.project.name}`).click().getByTestId('confirm-move').should('be.disabled');

        cy.get('@project2').then((project2) => {
          // Assert that the items can be moved into the second project.
          cy.getByTestId(`item-${project2.name}`).click().getByTestId('confirm-move').should('not.be.disabled').click();

          // Assert that the confirmation screen is displayed and confirm.
          cy.getByTestId('move-component-title').should('have.text', 'Move items?').getByTestId('confirm-move').click();

          // Assert that the confirmation dialog is displayed and confirm.
          cy.getByTestId('dialog-title')
            .should('be.visible')
            .and('have.text', 'Moving 1 folder and 1 file')
            .getByTestId('confirm-button')
            .click();

          // Assert that the chosen project is opened and that the moved items are inside.
          cy.url()
            .should('include', project2.id)
            .getByTestId('entity-list')
            .children()
            .should('have.length', 2)
            .getByTestId(`entity-${folder1.name}`)
            .should('be.visible');
        });

        // Assert that the snackbar has disappeared to prevent side effects.
        cy.getByTestId('snackbar').should('not.exist');

        // Check the folder's and diagram's checkboxes.
        cy.getByTestId('entity-checkbox').click({ multiple: true, force: true });

        // Click on "Move" inside the menu.
        cy.getByTestId('entity-head-dropdown').click().getByTestId('move-diagram').click();

        // Click the "Create new" button.
        cy.getByTestId('create-new-target').click();

        // Enter a new folder name into the input.
        cy.getByTestId('target-name')
          .should('be.visible')
          .and('have.value', 'New Folder')
          .type(newTargetFolder)
          .getByTestId('submit')
          .click();

        // Click the "Confirm" button.
        cy.getByTestId('confirm-move').should('not.be.disabled').click();

        // Assert that the folder has been created, is opened, and that the moved items are inside.
        cy.getByTestId('folder-name')
          .should('have.text', newTargetFolder)
          .getByTestId('entity-list')
          .children()
          .should('have.length', 2);
      });
    });
  });

  it('a user can move a folder containing subfolder to a different project', function () {
    // project1 already created in beforeEach
    const project1 = this.project;

    // Create project2
    cy.createProject(this.user).as('project2');
    cy.get('@project2').then((project2) => {
      cy.visit(`/projects/${project2.id}`);

      // Create a folder and subfolder in project2
      createFolder('folder');
      createFolder('subfolder');

      // Move the folder to project1
      cy.findByRole('link', { name: project2.name }).click();
      cy.findByRole('heading', { name: project2.name }).should('exist');
      cy.openEntityMenu('folder');
      cy.findByRole('menuitem', { name: /move/i }).click();
      cy.getByTestId('move-level-up').click();
      cy.findByText(project1.name).should('exist');
      cy.getByTestId(`item-${project1.name}`).click();
      cy.findByRole('button', { name: /move/i }).click();
      cy.findByText(/These items will inherit permissions from the project they are moved to/i).should('exist');
      cy.findByRole('button', { name: /move here/i }).click();
      cy.findByRole('dialog').within(() => {
        cy.findByText(/moving 1 folder/i).should('exist');
        cy.findByRole('button', { name: /move/i }).click();
      });

      // Assert move was successful
      cy.findByText(/data has been moved/i).should('exist');
      cy.findByRole('heading', { name: project1.name }).should('exist');
      cy.assertFolderEntityPresent('folder');

      // Assert breadcrumb values are correct
      cy.getByTestId('top-bar').within(() => {
        cy.findByRole('button', { name: project1.name }).should('exist');
      });

      // Open the folder and assert the breadcrumb values are correct
      cy.clickEntity('folder');
      cy.findByRole('heading', { name: 'folder' }).should('exist');
      cy.assertFolderEntityPresent('subfolder');
      cy.getByTestId('top-bar').within(() => {
        cy.findByRole('link', { name: project1.name }).should('exist');
        cy.findByRole('button', { name: 'folder' }).should('exist');
      });

      // Open the subfolder and assert the breadcrumb values are correct
      cy.clickEntity('subfolder');
      cy.findByRole('heading', { name: 'subfolder' }).should('exist');
      cy.getByTestId('top-bar').within(() => {
        cy.findByRole('link', { name: project1.name }).should('exist');
        cy.findByRole('link', { name: 'folder' }).should('exist');
        cy.findByRole('button', { name: 'subfolder' }).should('exist');
      });
    });
  });
});

const createFolder = (name) => {
  cy.findByRole('button', { name: /new/i }).click();
  cy.findByRole('menuitem', { name: /folder/i }).click();
  cy.getByTestId('editable-input').should('have.value', 'New Folder').wait(100).type(`${name}{enter}`);
  cy.findByText(/this folder doesn't have any/i).should('exist');
};

const assertDeletingFolderIsPossible = (entityName, projectName) => {
  cy.findByRole('menuitem', { name: /delete/i }).click();
  cy.findByRole('dialog').within(() => {
    cy.findByText(/deleting 1 folder/i).should('exist');
    cy.findByRole('button', { name: /delete/i }).click();
  });
  cy.findByText(/data has been deleted/i).should('exist');
  cy.findByRole('heading', { name: projectName }).should('exist'); // making sure we're still in the project page
  cy.assertEntityNotPresent(entityName);
};
