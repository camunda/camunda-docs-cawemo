import { isEnterprise, getBaseUrl } from '../../helpers';

describe('User interface', function () {
  beforeEach(function () {
    cy.createUserAndLogin().as('user');
  });

  afterEach(function () {
    cy.removeUser(this.user);
  });

  it('a user can navigate between pages using breadcrumbs', function () {
    // Create a project and diagram and open the milestone page.
    cy.createProject(this.user).then((project) => {
      cy.createDiagram(project).then((diagram) => {
        cy.visit(`/milestones/${diagram.id}`);

        // Assert that there are 4 breadcrumbs.
        // (Home - Project - Diagram - Milestones)
        cy.getByTestId('breadcrumbs').children().should('have.length', 4);

        // Assert that all breadcrumbs have the correct texts.
        cy.getByTestId('breadcrumb-milestone')
          .should('have.text', 'Milestones')
          .getByTestId('breadcrumb-diagram')
          .should('have.text', diagram.name)
          .getByTestId('breadcrumb-project')
          .should('have.text', project.name)
          .getByTestId('breadcrumb-home')
          .should('have.text', 'Home');

        // Navigate to the diagram page and assert that URL and page title are correct.
        cy.getByTestId('breadcrumb-diagram')
          .click()
          .url()
          .should('contain', '/diagrams/')
          .and('contain', diagram.id)
          .title()
          .should('eq', diagram.name);

        // Assert that there are 3 breadcrumbs.
        // (Home - Project - Diagram)
        cy.getByTestId('breadcrumbs').children().should('have.length', 3);

        // Navigate to the project page and assert that URL and page title are correct.
        cy.getByTestId('breadcrumb-project')
          .click()
          .url()
          .should('contain', '/projects/')
          .and('contain', project.id)
          .title()
          .should('eq', project.name);

        // Assert that there are 2 breadcrumbs.
        // (Home - Project)
        cy.getByTestId('breadcrumbs').children().should('have.length', 2);

        // Navigate to the home page and assert that URL and page title are correct.
        cy.getByTestId('breadcrumb-home').click().url().should('eq', getBaseUrl()).title().should('eq', 'Home');

        // Assert that there is 1 breadcrumb.
        // (Home)
        cy.getByTestId('breadcrumbs').children().should('have.length', 1);
      });
    });
  });

  it('a user sees the correct overlays from the user menu', function () {
    // Visit the home page and assert that the user menu has the user's
    // name as label.
    cy.visit('/').getByTestId('user-menu-button').should('have.text', this.user.name).click({ force: true });

    // Assert that the user menu has the right amount of entries.
    cy.getByTestId('user-menu')
      .find('li')
      .should('have.length', isEnterprise() ? 3 : 4);

    // Open the user menu and navigate to the settings page.
    // Assert that the URL has changed.
    cy.getByTestId('user-menu-button')
      .getByTestId('settings-menu-item')
      .should('have.text', 'Settings')
      .click()
      .url()
      .should('contain', getBaseUrl('settings'));

    // Open the user menu.
    cy.getByTestId('user-menu-button').click({ force: true });

    // Assert that the profile entry has the user's name and email.
    cy.getByTestId('profile-menu-item').should('contain', this.user.name).and('contain', this.user.email);

    if (isEnterprise()) {
      // Assert that the feedback entry doesn't exist.
      cy.getByTestId('feedback-menu-item').should('not.exist');
    } else {
      // Assert that the feedback entry exists and opens the community forum with cawemo tag
      cy.getByTestId('feedback-menu-item')
        .should('have.text', 'Provide feedback');

      // because Cypress does not support multiple browser tabs
      // we have to trick it into opening the link within the same tab and go back
      cy.get('li[data-test="feedback-menu-item"] > div > a')
        .invoke('removeAttr','target')
        .click();

      cy.url().should('include', 'forum.camunda.io/tag/cawemo')
      cy.go('back')
    }
  });

  it('username having characters from other languages is supported', function () {
    const name = '雷仙ирèйế';
    cy.createUser({ name }).then((user) => {
      cy.login(user).visit('/');
      cy.findByText(`Welcome, ${name}`).should('exist');
      cy.findByText(`You don't have any projects yet.`).should('exist');
    });
  });
});
