import { getIamBaseUrl } from '../../helpers';
import { faker } from '@faker-js/faker';

describe.enterprise.default.saas('Profile', function () {
  beforeEach(function () {
    cy
      .createUserAndLogin()
      .as('user')

      // Open Cawemo so the user gets created in the database
      .visit('/');
    cy.deleteAllEmails();
  });

  afterEach(function () {
    cy.removeUser(this.user);
  });

  it(`a user's name is updated without returning to Cawemo`, function() {
    const newName = faker.name.fullName();

    cy
      .visit(getIamBaseUrl())

      // Click edit button in "Personal information" section
      .get('[data-test="profile-personal-section"] [data-test="edit-button"]')
      .first()
      .click()

      // Find name field and save new name
      .get('[data-test="profile-personal-section"] [data-test="name"]')
      .clear()
      .type(newName)
      .get('[data-test="profile-personal-section"] [data-test="submit"]')
      .click()

      // Wait for IAM call to restapi
      .wait(1000)

      // Assert on changed values in database
      .task('db.getUserDetailsByIamId', this.user.iamId).then(userDetails => {
        expect(userDetails.name).to.equal(newName);
      });
  });

  it(`a user's email is updated without returning to Cawemo`, function() {
    const newMail = faker.internet.exampleEmail();

    cy
      .visit(getIamBaseUrl())

      // Click edit button in "Contact information" section
      .get('[data-test="profile-contact-section"] [data-test="edit-button"]')
      .first()
      .click()

      // Enter user password into password field
      .get('[data-test="profile-contact-section"] [data-test="password"]')
      .type(this.user.password)

      // Enter new email into email field and submit
      .get('[data-test="profile-contact-section"] [data-test="new-email"]')
      .clear()
      .type(newMail)
      .get('[data-test="profile-contact-section"] [data-test="submit"]')
      .click()

      // Await the verification email.
      .getLinkFromEmail(newMail, 'verify')
      .then(cy.visit)

      // Don't let Cypress cancel the underlying api request
      .intercept(getIamBaseUrl('/api/me/email'))

      // Wait for IAM call to restapi
      .wait(1000)

      // Assert on changed values in database
      .task('db.getUserDetailsByIamId', this.user.iamId).then(userDetails => {
        expect(userDetails.email.toLowerCase()).to.equal(newMail.toLowerCase());
      });
  });
});
