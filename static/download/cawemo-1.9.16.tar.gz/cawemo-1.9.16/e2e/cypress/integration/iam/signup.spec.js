import { getBaseUrl, getUser, getIamBaseUrl } from '../../helpers';
import { ADMIN_USER } from '../../../scripts/prepare/fixtures';

describe('Sign up', function () {
  it.saas('a user can\'t sign up using the landing page', function () {
    // Open the home page
    cy.visit('/');

    // Assert that cawemo signup button doesn't exist anymore
    cy.get('#cawemo-signup-button').should('not.exist');
  });

  it.saas('a user can sign up to C8', function () { 
    // Open the home page
    cy.visit('/');

    // Click on C8 signup button
    cy.get('#c8-signup-button').click();

    // Assert that the user lands on the C8 signup page
    cy.url().should('eq', 'https://signup.camunda.com/cawemo?utm_source=cawemo.com&utm_medium=referral');
  });

  it.saas('a user can sign up directly via signup link', function () {
    const user = getUser();

    // Open the signup page directly.
    cy.visit('/signup');

    // Assert that the signup page is displayed by checking the header.
    cy.getByTestId('userinfo-header').should('have.text', 'Sign up to continue to Cawemo');

    // Assert that the privacy link is visible.
    cy.getByTestId('privacy-link').should('be.visible');

    // Assert that the login link is visible.
    cy.getByTestId('login-link').should('be.visible');

    // Assert that the terms link is visible.
    cy.getByTestId('terms-link').should('be.visible');

    // Assert that the Google sign up link is visible.
    cy.get('button[title="Sign Up with Google"]').should('be.visible');

    // Assert that the LinkedIn sign up link is visible.
    cy.get('button[title="Sign Up with LinkedIn"]').should('be.visible');

    // Type the user's name into the form.
    cy.getByTestId('name').should('have.attr', 'placeholder', 'Your name').type(user.name);

    // Type the user's email into the form.
    cy.getByTestId('email').should('have.attr', 'placeholder', 'Your email address').type(user.email);

    // Type the user's password into the form.
    cy.getByTestId('new-password').should('have.attr', 'placeholder', 'Choose a password').type(user.password);

    // Click the sign up button.
    cy.getByTestId('submit').should('have.text', 'Sign Up').click();

    // Assert that the user has been redirected back to Cawemo.
    cy.url().should('eq', getBaseUrl());

    // Assert that the avatar from the homepage is visible.
    cy.getByTestId(`avatar-${user.name}`).should('be.visible');

    // Remove the user.
    cy.removeUser(user);
  });

  it.saas("an already registered user can't sign up again", function () {
    // Create a user in the database;
    cy.createUser().then((user) => {
      // Open the sign up page.
      cy.visit('/signup');

      // Type the user's name, email, password, and submit the sign up form.
      cy.getByTestId('name')
        .type(user.name)
        .getByTestId('email')
        .type(user.email)
        .getByTestId('new-password')
        .type(user.password)
        .getByTestId('submit')
        .click();

      // Assert that an error message is displayed.
      cy.getByTestId('error-message')
        .should('be.visible')
        .and('have.text', 'An account with this email address already exists');

      // Assert that the user stayed on IAM.
      cy.url().should('include', getIamBaseUrl());

      // Remove the user.
      cy.removeUser(user);
    });
  });

  it.enterprise.default('a user can sign up via token', function () {
    const user = getUser();

    cy.createSignupInvitationToken({ invitedEmail: user.email, inviter: ADMIN_USER }).then((tokenId) => {
      cy.visit(getBaseUrl(`signup?token=${tokenId}`));

      // Assert that the email input is already populated and disabled.
      cy.getByTestId('email').should('have.value', user.email).and('be.disabled');

      // Type the user's name, password, and submit the sign up form.
      cy.getByTestId('name')
        .type(user.name)
        .getByTestId('new-password')
        .type(user.password)
        .getByTestId('submit')
        .click();

      // Assert that the user has been redirected to Cawemo.
      cy.url().should('eq', getBaseUrl());

      // Assert that the avatar from the homepage is visible.
      cy.getByTestId(`avatar-${user.name}`).should('be.visible');

      // Remove the user.
      cy.removeUser(user);
    });
  });
});
