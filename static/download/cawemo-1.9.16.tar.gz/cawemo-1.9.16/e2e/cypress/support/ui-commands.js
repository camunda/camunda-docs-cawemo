import downloadDiagram from '../utils/download-diagram';
import { getBaseUrl } from '../helpers';

/**
 * Gets an element from the page by the `data-test` selector.
 *
 * @param {String} id The selector to match.
 */
Cypress.Commands.add('getByTestId', function (id) {
  cy.get(`[data-test="${id}"]`);
});

/**
 * Gets one or more BPMN elements from the page based on a given ID.
 * Uses fuzzy matching, meaning that the selector can be incomplete, like
 * `Task_`.
 *
 * @param {String} id The BPMN element ID to match.
 */
Cypress.Commands.add('getBPMN', function (id) {
  cy.get(`[data-element-id^="${id}"]`);
});

/**
 * Appends a new BPMN element to the page.
 *
 * @param {String} source The source element to append to. If `null`, the script
 *  assumes that an element has already been selected.
 * @param {String} type The type of element to append. Valid types are "append-task",
 *  "gateway", "end-event", "intermediate-event" and "text-annotation".
 * @param {String} name The (optional) name to give to the element.
 */
Cypress.Commands.add('append', function (source, type, name) {
  if (source) {
    cy.getBPMN(source).first().click();
  }

  cy.get(`[data-action="append.${type}"]`)
    .should('be.visible')
    .click({ force: true })
    .getByTestId('autosave')
    .should('be.visible')
    .and('contain', 'Autosaved');

  if (name) {
    cy.get('[contenteditable]').type(`${name} {enter}`);
  }

  cy.wait(200).getByTestId('autosave').should('be.visible').and('contain', 'Autosaved');
});

Cypress.Commands.add('getTemplateJSON', function () {
  cy.getByTestId('export-json').click();

  cy.get('a[download]')
    .last()
    .then(downloadDiagram)
    .then((json) => {
      cy.wrap(JSON.parse(json));
    });
});

Cypress.Commands.add('getDownload', function () {
  return cy.get('a[download]').then((anchor) => {
    return new Cypress.Promise((resolve) => {
      const xhr = new XMLHttpRequest();

      xhr.open('GET', anchor.prop('href'), true);
      xhr.responseType = 'blob';

      // Once loaded, use FileReader to get the string back from the blob.
      xhr.onload = () => {
        if (xhr.status == 200) {
          const blob = xhr.response;
          const reader = new FileReader();

          reader.onload = () => {
            // Once we have a string, resolve the promise to let
            // the Cypress chain continue, e.g. to assert on the result.
            resolve(reader.result);
          };
          reader.readAsText(blob);
        }
      };
      xhr.send();
    });
  });
});

/**
 * Prepares the browser for file downloads. The command clears the downloads folder and
 * allows downloads in Electron, Chrome, and Edge without any users popups or file save dialogs.
 *
 * This is necessary due to an issue with Electron, see https://github.com/cypress-io/cypress/issues/8865
 */
Cypress.Commands.add('prepareDownload', function () {
  cy.task('clearDownloads');

  if (!Cypress.isBrowser('firefox')) {
    cy.wrap(
      Cypress.automation('remote:debugger:protocol', {
        command: 'Page.setDownloadBehavior',
        params: { behavior: 'allow', downloadPath: 'cypress/downloads' }
      }),
      { log: false }
    );
  }
});

Cypress.Commands.add('waitForEditor', function () {
  cy.get('.monaco-editor textarea').should('exist').get('.view-lines').should('be.visible').wait(2500);
});

Cypress.Commands.add('assertNoActionButtonPresentInProjectPage', function () {
  cy.findByRole('button', { name: /new/i }).should('not.exist');
});

Cypress.Commands.add('relogin', function (user) {
  cy.logout();
  cy.login(user);
  cy.visit('/');
});

// Commands for 'Entity'
Cypress.Commands.add('assertEntityPresent', function (entityName, entityType) {
  let type = 'Project';
  if (entityType === 'CATALOG') {
    type = 'Catalog project';
  } else if (entityType === 'BPMN') {
    type = 'BPMN diagram';
  } else if (entityType === 'TEMPLATE') {
    type = 'Template';
  }
  cy.getByTestId(`entity-${entityName}`).should('exist');
  cy.getByTestId(`entity-${entityName}`).within(() => {
    cy.findByText(type).should('exist');
    cy.findByText(entityName).should('exist');
  });
});

Cypress.Commands.add('assertFolderEntityPresent', function (entityName) {
  cy.getByTestId(`entity-${entityName}`).should('exist');
  cy.getByTestId(`entity-${entityName}`).within(() => {
    cy.findByText(entityName).should('exist');
  });
});

Cypress.Commands.add('assertEntityNotPresent', function (entityName) {
  cy.getByTestId(`entity-${entityName}`).should('not.exist');
});

Cypress.Commands.add('toggleEntitySelection', function (entityName) {
  cy.getByTestId(`entity-${entityName}`).within(() => {
    cy.getByTestId('entity-checkbox').click({ force: true });
  });
});

Cypress.Commands.add('openEntityMenu', function (entityName) {
  cy.getByTestId(`entity-${entityName}`).within(() => {
    cy.getByTestId('entity-context-dropdown').click();
  });
});

Cypress.Commands.add('assertNoEntityMenuPresent', function (entityName) {
  cy.getByTestId(`entity-${entityName}`).within(() => {
    cy.getByTestId('entity-context-dropdown').should('not.exist');
  });
});

Cypress.Commands.add('assertOnlyDownloadActionIsPresent', function () {
  cy.assertNoDeleteOptionInMenu();
  cy.assertNoDuplicateOptionInMenu();
  cy.assertDownloadOptionInMenu();
});

Cypress.Commands.add('clickEntity', function (entityName) {
  cy.getByTestId(`entity-${entityName}`).click();
});

// Commands for 'Breadcrumb Menu'
Cypress.Commands.add('openBreadcrumbMenu', function (menuName) {
  cy.findByRole('button', { name: menuName }).click();
});

Cypress.Commands.add('assertNoBreadcrumbMenuPresent', function (menuName) {
  cy.getByTestId('top-bar').within(() => {
    cy.findByText(menuName).should('exist');
    cy.findByRole('button', { name: menuName }).should('not.exist');
  });
});

// Commands for any 'Dropdown Menu'
Cypress.Commands.add('assertNoDeleteOptionInMenu', function () {
  cy.findByRole('menuitem', { name: /delete/i }).should('not.exist');
});

Cypress.Commands.add('assertNoDuplicateOptionInMenu', function () {
  cy.findByRole('menuitem', { name: /duplicate/i }).should('not.exist');
});

Cypress.Commands.add('assertDownloadOptionInMenu', function () {
  cy.findByRole('menuitem', { name: /download/i }).should('exist');
});

Cypress.Commands.add('assertNoRenameOptionInMenu', function (entityName) {
  cy.findByRole('menuitem', { name: /edit name/i }).should('not.exist');
});

// Commands for Dropdown Menu Actions
Cypress.Commands.add('assertDeletingProjectIsPossible', function (entityName) {
  assertDeleteIsPossible(entityName, 'project');
});

Cypress.Commands.add('assertDeletingCatalogIsPossible', function (entityName) {
  assertDeleteIsPossible(entityName, 'catalog');
});

Cypress.Commands.add('assertDeletingDiagramIsPossible', function (entityName, project) {
  assertDeleteIsPossible(entityName, 'diagram', project);
});

const assertDeleteIsPossible = (entityName, type, project) => {
  cy.findByRole('menuitem', { name: /delete/i }).click();
  cy.findByRole('dialog').within(() => {
    cy.findByText(new RegExp(`deleting ${type}`, 'i')).should('exist');
    cy.findByRole('button', { name: new RegExp(`delete ${type}`, 'i') }).click();
  });
  cy.findByText(new RegExp(`${type} has been deleted`, 'i')).should('exist');
  if (type === 'diagram') {
    cy.url().should('include', 'projects').and('include', project.id);
  } else {
    cy.url().should('eq', getBaseUrl());
  }
  cy.assertEntityNotPresent(entityName);
};

Cypress.Commands.add('assertDeletingFileIsPossible', function (entityName, project) {
  cy.findByRole('menuitem', { name: /delete/i }).click();
  cy.findByRole('dialog').within(() => {
    cy.findByText(new RegExp(`deleting 1 file`, 'i')).should('exist');
    cy.findByRole('button', { name: new RegExp(`delete`, 'i') }).click();
  });
  cy.findByText(new RegExp(`data has been deleted`, 'i')).should('exist');
  cy.url().should('include', 'projects').and('include', project.id);
  cy.assertEntityNotPresent(entityName);
});

Cypress.Commands.add('assertRenamingProjectIsPossibleUsingBreadcrumbMenu', function (name, newName) {
  cy.findByRole('menuitem', { name: /edit name/i }).click();
  cy.findByDisplayValue(name).type(newName + '{enter}');
  cy.reload();
  cy.getByTestId('top-bar').within(() => {
    cy.findByRole('button', { name: newName }).should('exist');
  });
});

// Commands for 'Diagrams'
Cypress.Commands.add('createBPMNDiagramUsingButton', function () {
  cy.findByRole('button', { name: /new/i }).click();
  cy.findByRole('menuitem', { name: /bpmn diagram/i }).click();
});

Cypress.Commands.add('assertBPMNDiagramIsCreated', function () {
  cy.url()
    .should('include', 'diagrams')
    .getByTestId('modeler')
    .should('be.visible')
    .getBPMN('StartEvent_1')
    .should('be.visible');
});

Cypress.Commands.add('assertUploadIsNotPossibleUsingDragNDrop', function () {
  cy.getByTestId('drop-target').should('not.exist');
});
