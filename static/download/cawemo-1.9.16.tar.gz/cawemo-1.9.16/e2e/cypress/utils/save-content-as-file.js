import fs from 'fs';

const saveContentAsFile = (fileName) => (xml) => {
  const filePath = `cypress/fixtures/${fileName}`;

  return cy.writeFile(filePath, xml).then(() => {
    return filePath;
  });
};

export default saveContentAsFile;
