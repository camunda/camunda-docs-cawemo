const openDownloadedDiagramInModeler = (store) => (diagramPath) => {
  cy.task('modeler.prepare', store).then(() => {
    cy.exec(`node scripts/open-modeler-and-save ${diagramPath}`).then((result) => {
      cy.log(result.stdout);
      cy.log(result.stderr);
    });
  });
};

export default openDownloadedDiagramInModeler;
