const path = require('path');
const fs = require('fs');
const db = require('./db');
const ldap = require('./ldap');
const puppeteer = require('./puppeteer');
const modeler = require('./modeler');

const isFirefox = (browser) => browser.family === 'firefox';
const downloadDirectory = path.join(__dirname, '..', 'downloads');

module.exports = (on, config) => {
  db.init(config);
  ldap.init(config);
  on('task', { db, ldap, puppeteer, modeler });
  on('task', {
    log(message) {
      console.log(message);
      return null;
    },

    clearDownloads() {
      fs.rmSync(downloadDirectory, { recursive: true, force: true });

      return null;
    }
  });

  on('before:browser:launch', (browser, options) => {
    if (isFirefox(browser)) {
      // Special settings for Firefox browser
      // to prevent showing popup dialogs that block the rest of the test
      options.preferences['browser.download.dir'] = downloadDirectory;
      options.preferences['browser.download.folderList'] = 2;

      // Needed to prevent the download prompt for CSV, Excel, and ZIP files
      // TIP: with Firefox DevTools open, download the file yourself
      // and observe the reported MIME type in the Developer Tools
      const mimeTypes = [
        'text/csv',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // Excel
        'application/zip'
      ];

      options.preferences['browser.helperApps.neverAsk.saveToDisk'] = mimeTypes.join(',');

      return options;
    }
  });
};
