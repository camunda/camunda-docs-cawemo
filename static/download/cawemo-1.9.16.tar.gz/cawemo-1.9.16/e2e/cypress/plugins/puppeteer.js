const puppeteer = require('puppeteer');
let browser, page;

module.exports = {
  async open() {
    browser = await puppeteer.launch({
      args: ['--no-sandbox'],
      slowMo: 5 // prevents "Node is either not visible or not an HTMLElement" error when creating BPMN elements
    });
    page = await browser.newPage();

    await page.evaluateOnNewDocument(() => {
      localStorage.setItem('cawemo.downtime.seen.1713254400000', 'true');
    });

    return null;
  },

  async login({ url, user }) {
    await page.goto(url);
    await page.click('[data-test="login-button"]');
    await page.waitForSelector('[data-test="email"]');
    await page.type('[data-test="email"]', user.email);
    await page.type('[data-test="password"]', user.password);
    await page.waitForTimeout(1000);
    await page.click('[data-test="submit"]');

    await page.waitForSelector(`[data-test="user-menu-button"]`);

    return user;
  },

  async createElements() {
    await page.waitForSelector('[data-element-id="StartEvent_1"]');
    await page.click('[data-element-id="StartEvent_1"]');
    await page.click('[data-action="append.append-task"]');
    await page.type('[contenteditable]', 'Task #1 by Puppeteer');
    await page.keyboard.press('Enter');
    await page.click('[data-action="append.end-event"]');

    return null;
  },

  async toggleAttentionGrabber() {
    // wait for "toggle-minimap" and "viewport-reset", as they are rendered later and might change the position
    // of the already rendered "toggle-attentiongrabber" (this could lead to a click on the wrong button)
    await page.waitForSelector('[data-test="toggle-minimap"]');
    await page.waitForSelector('[data-test="viewport-reset"]');

    await page.waitForSelector('[data-test="toggle-attentiongrabber"]');
    await page.click('[data-test="toggle-attentiongrabber"]');
    await page.waitForTimeout(1000);
    await page.mouse.click(200, 200);

    return null;
  },

  async close() {
    await browser.close();
    return null;
  },

  async fetch({ url, method, body }) {
    return page.evaluate(
      (url, method, body) => {
        return fetch(url, {
          method,
          body
        }).then((response) => {
          return response.json();
        });
      },
      url,
      method,
      body
    );
  }
};
