const ldap = require('ldapjs');

let client;
let ldapManager;
let ldapPassword;

const init = (config) => {
  client = ldap.createClient({ url: config.env.LDAP_SERVER_URL });
  ldapManager = config.env.LDAP_MANAGER_DN;
  ldapPassword = config.env.LDAP_MANAGER_PASSWORD;
}

const bind = () => {
  client.bind(ldapManager, ldapPassword, (e) => {
    if (e) {
      console.error("error while binding ldap client: " + e);
    }
  });
};

const createUser = ({ username, name, email, password, dn = `cn=${username},dc=example,dc=com`}) => {
  bind();
  const nameParts = name.split(' ');
  client.add(dn, {
    cn: username,
    givenName: nameParts[0],
    sn: nameParts.length > 1 ? nameParts[1] : nameParts[0],
    displayName: name,
    mail: email.toLowerCase().trim(),
    userPassword: password,
    objectClass: 'inetOrgPerson',
  }, (e) => {
    if (e) {
      console.error("error while adding ldap user: " + e);
    }
  });

  return {
    dn,
    username,
    name,
    email,
    password,
  };
};

module.exports = {
  init,
  createUser({ username, name, email, password }) {
    return createUser({ username, name, email, password });
  }
}
