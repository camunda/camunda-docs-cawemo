const config = {
  env: {
    DB_USER: process.env.CYPRESS_DB_USER || 'master',
    DB_HOST: process.env.CYPRESS_DB_HOST || 'localhost',
    DB_PASSWORD: process.env.CYPRESS_DB_PASSWORD || 'master',
    DB_NAME: process.env.CYPRESS_DB_NAME || 'app',
    DB_PORT: process.env.CYPRESS_DB_PORT || '5432',

    IAM_DB_USER: process.env.CYPRESS_IAM_DB_USER || 'camunda',
    IAM_DB_HOST: process.env.CYPRESS_IAM_DB_HOST || 'localhost',
    IAM_DB_PASSWORD: process.env.CYPRESS_IAM_DB_PASSWORD || 'jd239hewndi2lwafnds',
    IAM_DB_NAME: process.env.CYPRESS_IAM_DB_NAME || 'iam',
    IAM_DB_PORT: process.env.CYPRESS_IAM_DB_PORT || '15432',

    LDAP_SERVER_URL: process.env.CYPRESS_LDAP_SERVER_URL || 'ldap://localhost',
    LDAP_MANAGER_DN: process.env.CYPRESS_LDAP_MANAGER_DN || 'cn=admin,dc=example,dc=com',
    LDAP_MANAGER_PASSWORD: process.env.CYPRESS_MANAGER_PASSWORD || 'camunda123'
  }
};

const ADMIN_USER = {
  id: '00000000-0000-0000-0000-000000000001',
  email: 'admin@example.com',
  name: 'Admin',
  password: 'camunda123',
  username: 'admin'
};

const ADMIN_ORGANIZATION = {
  id: '10000000-0000-0000-0000-000000000001',
  name: "Admin's Organization"
};

module.exports = {
  ADMIN_USER,
  ADMIN_ORGANIZATION,
  config
};
