/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements. Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */

const https = require('follow-redirects').https;
const fs = require('fs');
const os = require('os');
const decompress = require('decompress');

const osType = os.type();
let modelerFileName, modelerArchiveFileName;

const modelerVersion = process.env.MODELER_VERSION || '4.7.0';
const modelerPluginVersion = process.env.MODELER_PLUGIN_VERSION || '3.0.0';

const downloadsDir = 'cypress/fixtures/modeler/downloads';
const executablesDir = 'cypress/fixtures/modeler/executable';

if (osType === 'Linux') {
  modelerFileName = `${modelerVersion}/camunda-modeler-${modelerVersion}-linux-x64.tar.gz`;
  modelerArchiveFileName = 'camunda-modeler.tar.gz';
  modelerArchiveUnpackCallback = () => {
    fs.rename(
      `${executablesDir}/camunda-modeler-${modelerVersion}-linux-x64`,
      `${executablesDir}/camunda-modeler-linux-x64`,
      (err) => {
        console.log(err);
      }
    );
  };
} else if (osType === 'Darwin') {
  modelerFileName = `${modelerVersion}/camunda-modeler-${modelerVersion}-mac.zip`;
  modelerArchiveFileName = 'camunda-modeler.zip';
  modelerArchiveUnpackCallback = () => {};
}

const modelerUrl = `https://downloads.camunda.cloud/release/camunda-modeler/${modelerFileName}`;
const modelerPluginUrl = `https://downloads.camunda.cloud/enterprise-release/cawemo/cloud-connect-modeler-plugin/cloud-connect-${modelerPluginVersion}.zip`;

function downloadAndUnpack(url, downloadTo, decompressTo, callback = () => {}, headers = {}) {
  return new Promise((resolve, reject) => {
    let options = {
      rejectUnauthorized: false,
      requestCert: true,
      agent: false,
      headers: headers
    };

    let zipFile = fs.createWriteStream(downloadTo);

    let request = https.get(url, options, (response) => {
      console.log(`Downloading ${url}`);
      if (!response.statusCode.toString().startsWith('2')) {
        // 2xx means successful download
        throw new Error(`HTTP code ${response.statusCode} when downloading ${url}`);
      }
      response.pipe(zipFile);

      zipFile.on('finish', function () {
        console.log(`Unpacking ${downloadTo}`);
        zipFile.close(() => {
          decompress(downloadTo, decompressTo).then(() => {
            callback();
            resolve();
          });
        });
      });
    });

    request.end();

    request.on('error', (err) => {
      throw err;
    });
  });
}

function getBasicAuthHeaders(user, pass) {
  return user && pass ? { Authorization: 'Basic ' + Buffer.from(user + ':' + pass).toString('base64') } : {};
}

if (!process.env.AUTH_USER || !process.env.AUTH_PASS) {
  console.error('[ERROR] AUTH_USER and AUTH_PASS env vars should both be defined!');
  process.exit(1);
}

Promise.all([
  downloadAndUnpack(
    modelerPluginUrl,
    `${downloadsDir}/cloud-connect.zip`,
    'cypress/fixtures/modeler/user-data/plugins/cloud-connect',
    () => {},
    getBasicAuthHeaders(process.env.AUTH_USER, process.env.AUTH_PASS)
  ),
  downloadAndUnpack(
    modelerUrl,
    `${downloadsDir}/${modelerArchiveFileName}`,
    executablesDir,
    modelerArchiveUnpackCallback
  )
]);
