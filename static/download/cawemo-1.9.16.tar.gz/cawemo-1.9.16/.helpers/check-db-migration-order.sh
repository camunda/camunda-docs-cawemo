#!/bin/bash

# This script checks that for branches rebased on master there are no newer
# commits (compared to master) that add/modify migrations "before" the "newest"
# migration on master based on Flyway version numbers. If the checks succeeds or
# is not applicable the script will exit with with exit code 0, otherwise with a
# non-zero exit code.

# Flyway version number format: https://flywaydb.org/documentation/migrations#naming

master_branch="origin/master"
current_branch=$(git symbolic-ref HEAD | sed -e 's,.*/\(.*\),\1,')

latest_master_branch_commit=$(git rev-parse "$master_branch")
latest_common_commit=$(git merge-base "$master_branch" "$current_branch")

# check if current branch is rebased on master branch
if [ ! "$latest_master_branch_commit" = "$latest_common_commit" ]; then
  echo "Success: The current branch $current_branch is not rebased on $master_branch so no need to check for DB migration order."
  exit 0
fi

latest_current_branch_commit=$(git rev-parse HEAD)

# new commits on current branch with respect to master branch
range="$latest_master_branch_commit..$latest_current_branch_commit"

# versions of all DB migrations added in the new commits on the current_branch
added_migrations=$(git diff --name-status "$range" | grep -e "^A" | cut -f2 | grep "restapi/common/src/main/resources/db/migration" | grep -o -e "V[0-9._]\+")

if [ "$added_migrations" = "" ]; then
  echo "Success: No new DB migrations added so no need to check for DB migration order."
	exit 0
fi

# version of the DB migration in the most recent commit on the master_branch
most_recent_existing_migration=$(git ls-tree -r --name-only "$latest_master_branch_commit" | grep "restapi/common/src/main/resources/db/migration" | grep -o -e "V[0-9._]\+" | tail -n 1)

# check for new DB migration's version equal to most recent
for m in $added_migrations; do
	if [ "$m" = "$most_recent_existing_migration" ]; then
		echo "Fail: Detected a problem with the DB migration order on the current branch $current_branch!"
		echo ""
		echo "Reason: A newly added DB migration ($m) uses the same version as the most recent DB migration ($most_recent_existing_migration)."
		echo ""
		exit 1
	fi
done

# check for new migration's version older to most recent
oldest_migration=$(printf "%s\n%s" "$added_migrations" "$most_recent_existing_migration" | sort | head -n 1)
if [ ! "$oldest_migration" = "$most_recent_existing_migration" ]; then
  echo "Fail: Detected a problem with the DB migration order on the current branch $current_branch!"
	echo ""
	echo "Reason: A newly added DB migration ($oldest_migration) uses an older version than the most recent DB migration ($most_recent_existing_migration)."
	echo ""
	exit 1
fi

echo "Success: All newly added DB migrations are in order."
exit 0
