> Check out the project running [live](https://cawemo.com), in [saas staging](https://stage.cawemo.com),
> [on-premises staging](https://stage.cawemo.camunda.cloud) and [on-premises staging with ldap integration](https://stage-ldap.cawemo.camunda.cloud).

# Status Check

[![master](https://github.com/camunda/cawemo/actions/workflows/build-and-test.yml/badge.svg)](https://github.com/camunda/cawemo/actions/workflows/build-and-test.yml)
[![browsers-test](https://github.com/camunda/cawemo/actions/workflows/cron-browsers-test.yml/badge.svg)](https://github.com/camunda/cawemo/actions/workflows/cron-browsers-test.yml)
[![vulnerability-check](https://github.com/camunda/cawemo/actions/workflows/cron-vulnerability-check.yml/badge.svg)](https://github.com/camunda/cawemo/actions/workflows/cron-vulnerability-check.yml)
[![iam-it-test](https://github.com/camunda/cawemo/actions/workflows/cron-iam-it-test.yml/badge.svg)](https://github.com/camunda/cawemo/actions/workflows/cron-iam-it-test.yml)
[![plugins-it-test](https://github.com/camunda/cawemo/actions/workflows/cron-plugins-it-test.yml/badge.svg)](https://github.com/camunda/cawemo/actions/workflows/cron-plugins-it-test.yml)
[![dispatch-plugins-it-test](https://github.com/camunda/cawemo/actions/workflows/dispatch-plugins-it-test.yml/badge.svg)](https://github.com/camunda/cawemo/actions/workflows/dispatch-plugins-it-test.yml)

# Cawemo

The sources of the Cawemo [SaaS](https://cawemo.com) and [On-Premises](https://docs.camunda.org/cawemo/latest/technical-guide/installation/) can be found [here](https://github.com/camunda/cawemo/tree/master).

## How to Develop

Checkout [our development documentation](https://github.com/camunda/web-modeler-team-internal-docs) to learn how to set up Cawemo on your machine.

#### TLDR

Use the following `make` targets during development:

```
make env-up-saas               # set up run-time environment for saas
make env-up-enterprise         # set up run-time environment for enterprise
make env-up-enterprise-ldap    # set up run-time environment for enterprise with ldap

make env-down-saas             # tear down run-time environment for saas
make env-down-enterprise       # tear down run-time environment for enterprise
make env-down-enterprise-ldap  # tear down run-time environment for enterprise with ldap

make local-saas                # run saas app in local development mode
make local-saas-maintenance    # run saas app in local development mode (with maintenance mode enabled)
make local-enterprise          # run enterprise app in local development mode
make local-enterprise-ldap     # run enterprise app in local development mode with ldap

make all-saas                  # build application for production
make all-enterprise            # build application for production
```


## How to Operate

Checkout our [Operations FAQ](https://github.com/camunda/web-modeler-team-internal-docs/blob/main/Product-Specific/Camunda-7-Cawemo/Infrastructure/Operate/Operations-FAQ.md) for answers to frequently asked ops questions.


## Additional Resources

* [Documentation](https://github.com/camunda/web-modeler-team-internal-docs/)

## License
This repository contains files subject to a [commercial license](./LICENSE.txt).
