const db = require('../../cypress/plugins/db');
const ldap = require('../../cypress/plugins/ldap');

const { ADMIN_USER, ADMIN_ORGANIZATION, config } = require('./fixtures');

const prepare = async () => {
  await db.init(config);
  await ldap.init(config);

  // delete admin user from IAM
  await db.removeUserIAM({ email: ADMIN_USER.email });

  // delete admin, their organization and permissions from Cawemo
  await db.removeOrganization(ADMIN_ORGANIZATION);
  await db.removeOrganizationPermission(ADMIN_ORGANIZATION);
  await db.removeUserEnterprise({ id: ADMIN_USER.id });

  // delete admin setup token
  await db.removeAdminSetupToken();

  // create new admin user in Cawemo
  await db.createAdminUserEnterprise({
    iamId: ADMIN_USER.id,
    id: ADMIN_USER.id,
    name: ADMIN_USER.name,
    email: ADMIN_USER.email,
    username: ADMIN_USER.username
  });

  // create admin organization
  await db.createOrganizationForUser(ADMIN_ORGANIZATION, ADMIN_USER);

  // create admin user in IAM (+ LDAP)
  if (process.env.CYPRESS_FEATURE_LDAP_ENABLED === 'true') {
    await ldap.createUser({
      username: ADMIN_USER.username,
      name: ADMIN_USER.name,
      email: ADMIN_USER.email,
      password: ADMIN_USER.password
    });

    await db.createLdapUserIAM({
      iamId: ADMIN_USER.id,
      username: ADMIN_USER.username,
      email: ADMIN_USER.email,
      name: ADMIN_USER.name,
      password: ADMIN_USER.password
    });
  } else {
    await db.createUserIAM({
      iamId: ADMIN_USER.id,
      email: ADMIN_USER.email,
      name: ADMIN_USER.name,
      password: ADMIN_USER.password
    });
  }

  process.exit(0);
};

if (process.env.CYPRESS_PRODUCT_CONTEXT === 'enterprise') {
  prepare();
} else {
  process.exit(0);
}
