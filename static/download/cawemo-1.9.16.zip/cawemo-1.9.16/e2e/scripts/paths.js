/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements. Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */

const path = require('path');
const os = require('os');

const cwd = process.cwd();
const pathToUserData = path.join(cwd, '/cypress/fixtures/modeler/user-data');
const osType = os.type();

let osTypeModelerPath;

if (osType === 'Linux') {
  osTypeModelerPath = '/cypress/fixtures/modeler/executable/camunda-modeler-linux-x64/camunda-modeler';
} else if (osType === 'Darwin') {
  osTypeModelerPath = '/cypress/fixtures/modeler/executable/Camunda Modeler.app/Contents/MacOS/Camunda Modeler';
}

const modelerPath = path.join(cwd, osTypeModelerPath);

module.exports = {
  pathToUserData,
  modelerPath
};
