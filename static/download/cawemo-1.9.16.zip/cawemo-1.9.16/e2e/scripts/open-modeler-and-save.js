/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements. Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */

const Application = require('spectron').Application;

const terminateExistingModelerInstances = require('./terminate-existing-modeler-instances');
const { modelerPath, pathToUserData } = require('./paths');

const sleepMS = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

class Modeler {
  constructor() {
    terminateExistingModelerInstances();

    this.app = new Application({
      path: modelerPath,
      args: [process.argv[2], '--dangerously-enable-node-integration', '--no-sandbox'],
      chromeDriverArgs: [`--user-data-dir=${pathToUserData}`, '--no-sandbox'],
      webdriverOptions: {
        deprecationWarnings: false
      }
    });

    this.open = this.open.bind(this);
    this.close = this.close.bind(this);
  }

  async open() {
    await this.app.start();
    await this.app.client.waitUntilWindowLoaded();
  }

  async close() {
    await this.app.stop();
    await terminateExistingModelerInstances();
  }

  async click(selector) {
    await this.app.client.click(selector);
  }

  async doubleClick(selector) {
    await this.app.client.doubleClick(selector);
  }

  async keys(keys) {
    await this.app.client.keys(keys);
  }
}

(async () => {
  const modeler = new Modeler();
  await modeler.open();
  await modeler.doubleClick('[data-element-id="StartEvent_1"]');
  await modeler.keys(['A', 'Enter']);
  await modeler.click('[title="Save diagram"]');
  await sleepMS(5000);
  await modeler.close();
})();
