/**
 * Retrieves the XML from a diagram download by fetching the DATA URI
 * provided by Cawemo. The result is then returned as a string.
 *
 * @param {HTMLElement} anchor The anchor element that triggers the download.
 * @returns {Promise}
 */
const downloadDiagram = (anchor) => {
  return new Cypress.Promise((resolve) => {
    const xhr = new XMLHttpRequest();

    xhr.open('GET', anchor.prop('href'), true);
    xhr.responseType = 'blob';

    // Once loaded, use FileReader to get the string back from the blob.
    xhr.onload = () => {
      if (xhr.status == 200) {
        const blob = xhr.response;
        const reader = new FileReader();

        reader.onload = () => {
          // Once we have a string, resolve the promise to let
          // the Cypress chain continue, e.g. to assert on the result.
          resolve(reader.result);
        };
        reader.readAsText(blob);
      }
    };
    xhr.send();
  });
};

export default downloadDiagram;
