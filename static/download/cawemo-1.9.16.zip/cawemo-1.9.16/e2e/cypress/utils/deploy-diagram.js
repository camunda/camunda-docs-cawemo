/**
 * This function takes a BPMN 2.0 XML string and creates a deployment
 * for it using the Camunda REST API.
 *
 * @param {String} xml The diagram's XML.
 * @returns {Promise}
 */
const deployDiagram = (xml) => {
  if (!xml) {
    throw new Error("Didn't receive a valid BPMN 2.0 XML for deploying. Aborting.");
  }

  const blob = new Blob([xml], { type: 'text/xml' });
  const formData = new FormData();
  const xhr = new XMLHttpRequest();

  // These 2 values are required for the REST API.
  formData.set('data', blob, 'diagram.bpmn');
  formData.set('deployment-name', 'Cypress Deployment');

  xhr.open('POST', Cypress.env('ENGINE_URL') + '/engine-rest/deployment/create');

  xhr.onerror = (err) => {
    throw err;
  };

  xhr.send(formData);
};

export default deployDiagram;
