import { getComment, isEnterprise, getBaseUrl, getIamBaseUrl, isLdapEnabled } from '../helpers';

/**
 * Logs in an existing user and wraps him.
 *
 * @param {Object} user The user to log in.
 */
Cypress.Commands.add('login', function (user) {
  cy.request({
    method: 'POST',
    url: getIamBaseUrl('api/login'),
    log: false,
    body: {
      username: user.email,
      password: user.password
    }
  }).then(({ body }) => {
    cy.setCookie('iam_auth', body.token, { log: false });

    cy.request({
      url: getIamBaseUrl('api/authorize'),
      followRedirect: false,
      log: false,
      qs: {
        client_id: 'cawemo-id',
        redirect_uri: getBaseUrl('iam-login-callback'),
        response_type: 'code',
        scope: 'cawemo-read',
        state: '{"returnUrl":"/"}',
        view: 'login'
      }
    }).then(({ headers }) => {
      cy.request({
        url: headers.location,
        log: false,
        followRedirect: false
      });
    });
  });

  cy.wrap(user, { log: false });
});

/**
 * Logs out the currently authenticated user and clears all cookies.
 */
Cypress.Commands.add('logout', function () {
  cy.request({
    url: getIamBaseUrl('logout'),
    log: true
  }).then(() => cy.clearCookies());
});

/**
 * Creates a new comment. The content is created automatically.
 *
 * @param {String} fileId The ID of the file.
 * @param {String} reference An optional reference to a BPMN element.
 */
Cypress.Commands.add('createComment', function (fileId, reference, failOnStatusCode = true) {
  cy.request({
    method: 'POST',
    url: '/internal-api/comments',
    failOnStatusCode: failOnStatusCode,
    body: {
      fileId,
      content: getComment(),
      reference
    }
  });
});

/**
 * Tries to retrieve a URL from an email sent by the restapi (like project invitations).
 *
 * Polls MailHog's API for a certain amount of times until an email has been received. The email body is then searched
 * for the expected URL. If the URL is found, it will be returned.
 *
 * If the URL is not found or no email has been received in time, null will be returned.
 *
 * @param {String} email The recipient's email address.
 * @param {String} type What type of email to look for.
 * @param {Number} timesTried Only used for recursive calls.
 * @returns {String|null} The found URL or null.
 */
Cypress.Commands.add('getLinkFromEmail', (email, type, timesTried = 0) => {
  if (timesTried > 30) {
    // no email received after 30 retries
    return null;
  }

  const regex = {
    verify: /http:\/\/\S*\/email-verify\S*/,
    share: /http:\/\/\S*\/shares\S*/,
    mention: /http:\/\/\S*\/diagrams\S*/,
    invite: isEnterprise()
      ? /http:\/\/\S*\/projects\/\S*/
      : // invite tokens are used in SaaS only
        /http:\/\/\S*\/projects\/\S*\/join\?inviteToken=\S*/,
    'signup-invite': /http:\/\/\S*\/signup\?token=\S*/
  };

  cy.request('GET', `${Cypress.env('EMAIL_URL')}/api/v2/search?kind=to&query=${email.toLowerCase()}`).then(
    (response) => {
      if (response.body.total === 0) {
        // no email received yet: wait 1 second and recursively call this function again
        return cy.wait(1000).getLinkFromEmail(email, type, timesTried + 1);
      }
      // email received: find link in plain text body
      const emailBody = response.body.items[0].MIME.Parts[0].Body;
      const match = emailBody.match(regex[type]);
      return match ? match[0] : null;
    }
  );
});

Cypress.Commands.add('deleteAllEmails', function () {
  cy.request('DELETE', `${Cypress.env('EMAIL_URL')}/api/v1/messages`);
});

/**
 * Create a new invitation.
 *
 * @param {Object} user The user to invite.
 * @param {String} projectId The ID of the project. Only required for SaaS.
 */
Cypress.Commands.add('createInvitation', function (user, projectId, projectAccess = 'WRITE') {
  if (isEnterprise() && !isLdapEnabled()) {
    cy.request('POST', `/internal-api/invitations`, {
      emails: [user.email]
    }).then((response) => {
      const result = response.body.data.invitationResults[0];

      if (result.status === 'SENT') {
        return `/signup?token=${result.token.id}`;
      }
    });
  } else {
    cy.request('POST', `/internal-api/projects/${projectId}/invite`, {
      emails: [user.email],
      projectAccess,
      text: ''
    }).then((response) => {
      const result = response.body.data.invitationResults[0];

      if (result.status === 'SENT') {
        if (isEnterprise() && isLdapEnabled()) {
          return `/projects/${projectId}`;
        } else {
          return `/projects/${projectId}/join?inviteToken=${result.tokenId}`;
        }
      }
    });
  }
});

/**
 * Creates a new share. Wraps the ID of the created share.
 *
 * @param {String} fileId The ID of the file.
 */
Cypress.Commands.add('createShare', function (fileId) {
  cy.request('POST', `/internal-api/shares`, { fileId }).its('body.data.share.id');
});

/**
 * Sets a password for an existing share.
 *
 * @param {String} shareId The ID of the share.
 * @param {String} password The password to set.
 */
Cypress.Commands.add('setSharePassword', function (shareId, password) {
  cy.request('POST', `/internal-api/shares/${shareId}/password`, { password });
});

/**
 * Creates and authenticates a new user.
 *
 * @param {Object} config The same config that would be passed to `cy.createUser`.
 */
Cypress.Commands.add('createUserAndLogin', function (config) {
  cy.createUser(config).then((result) => {
    cy.login(result);
  });
});

/**
 * Creates a new milestone.
 *
 * @param {String} fileId The ID of the file.
 */
Cypress.Commands.add('createMilestone', function (fileId, name = 'Untitled milestone') {
  cy.request('POST', `/internal-api/milestones`, { fileId, name });
});
