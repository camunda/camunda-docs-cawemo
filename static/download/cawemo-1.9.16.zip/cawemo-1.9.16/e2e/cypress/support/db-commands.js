import {
  getUser,
  getNameFor,
  getUuid,
  getRandomDiagram,
  getProcessIdFromXML,
  getRandomRpaTemplate,
  isEnterprise,
  isLdapEnabled,
  getDmnDiagram
} from '../helpers';

/**
 * Creates a new user in the database.
 *
 * @param {Object} config
 */
Cypress.Commands.add('createUser', function (config = {}) {
  config.withUsername = true;
  const user = getUser(config);
  if (isEnterprise()) {
    if (isLdapEnabled()) {
      cy.task('ldap.createUser', user).task('db.createLdapUserIAM', user);
    } else {
      cy.task('db.createUserIAM', user);
    }
    cy.task('db.createUserEnterprise', user).wrap(user);
  } else {
    cy.task('db.createUserIAM', user).task('db.createUserSaaS', user).wrap(user);
  }
});

/**
 * Creates a new admin user for enterprise.
 */
Cypress.Commands.add('createAdminUserEnterprise', function (organization, user) {
  cy.task('db.createAdminUserEnterprise', {
    iamId: user.id,
    id: user.id,
    name: user.name,
    email: user.email,
    username: user.username
  }).task('db.createOrganizationPermission', { organization, user, permission: 'ADMIN' });
});

/**
 * Creates a new user only on the ldap server.
 *
 * @param {Object} config
 */
Cypress.Commands.add('createUserInLdapOnly', function (config = {}) {
  config.withUsername = true;
  const user = getUser(config);
  cy.task('ldap.createUser', user).wrap(user);
});

/**
 * Removes an existing user from the database.
 *
 * @param {Object} user
 */
Cypress.Commands.add('removeUser', function (user) {
  if (isEnterprise()) {
    cy.task('db.removeUserEnterprise', user);
  } else {
    cy.task('db.removeUserSaaS', user);
  }
});

/**
 * Removes all users from the database (except the dummy user and the organization admin in enterprise)
 */
Cypress.Commands.add('removeAllUsers', function (user) {
  cy.task('db.removeAllUsers', user);
});

/**
 * Removes an existing organization from the database.
 *
 * @param {Object} organization
 */
Cypress.Commands.add('removeOrganization', function (organization) {
  cy.task('db.removeOrganization', organization);
});

/**
 * Removes all existing projects from the database.
 */
Cypress.Commands.add('removeAllProjects', function () {
  cy.task('db.removeAllProjects');
});

/**
 * Removes all existing projects from the database if the product context is enterprise.
 */
Cypress.Commands.add('removeAllProjectsIfEnterprise', function () {
  if (isEnterprise()) {
    cy.removeAllProjects();
  }
});

Cypress.Commands.add('joinUserToOrganization', function (user) {
  cy.createUser().then((collaborator) => {
    cy.task('db.joinUserToOrganization', { user, collaborator }).wrap(collaborator);
  });
});

/**
 * Creates a new signup invitation with its corresponding token in the database.
 */
Cypress.Commands.add('createSignupInvitationToken', function ({ invitedEmail, inviter }) {
  const tokenId = getUuid();
  cy.task('db.createSignupInvitation', { tokenId, invitedEmail, inviter }).wrap(tokenId);
});

/**
 * Creates a new project.
 *
 * @param {Object} user A valid user object.
 */
Cypress.Commands.add('createProject', function (user, type = 'DEFAULT') {
  const project = {
    id: getUuid(),
    name: getNameFor(type == 'DEFAULT' ? 'project' : 'catalog'),
    user,
    type
  };

  cy.task('db.createProject', project).wrap(project);
});

/**
 * Creates a new folder.
 *
 * @param {Object} project A valid project object.
 */
Cypress.Commands.add('createFolder', function (project, params = {}) {
  const folder = {
    id: getUuid(),
    name: params.name || getNameFor('folder'),
    project,
    parentId: params.parentId || null
  };

  cy.task('db.createFolder', folder).wrap(folder);
});

/**
 * Creates a new legacy diagram without a process id for version <= 1.2
 *
 * @param {Object} project A valid project object.
 * @param {Object} options Extra options to control behavior of diagram creation
 */
Cypress.Commands.add('createLegacyDiagram', function (project, params = {}) {
  const relationId = params.relationId || getUuid();
  const processId = params.processId || getUuid();

  const content = params.xml || getRandomDiagram(relationId, processId, params.generateXMLWithoutProcessId);

  const diagram = {
    id: getUuid(),
    name: params.name || getNameFor('diagram'),
    project,
    content,
    relationId
  };

  cy.task('db.createLegacyDiagram', diagram).wrap(diagram);
});

/**
 * Creates a new template.
 */

Cypress.Commands.add('createTemplate', function (project, type = 'TEMPLATE_GENERIC') {
  const template = {
    id: getUuid(),
    name: getNameFor('template'),
    project,
    relationId: getUuid(),
    content: getRandomRpaTemplate(type),
    type
  };

  cy.task('db.createDiagram', template).wrap(template);
});

/**
 * Creates a new diagram.
 *
 * @param {Object} project A valid project object.
 * @param {Object} options Extra options to control behavior of diagram creation
 */
Cypress.Commands.add('createDiagram', function (project, params = {}) {
  const relationId = params.relationId || getUuid();

  let content = params.xml || getRandomDiagram(relationId, params.customProcessId, params.generateXMLWithoutProcessId);
  const processId = getProcessIdFromXML(content);

  const diagram = {
    id: getUuid(),
    name: params.name || getNameFor('diagram'),
    project,
    processId: params.ommitProcessId ? null : processId,
    content,
    relationId,
    type: params.type || 'BPMN',
    folderId: params.parentId || null
  };

  cy.task('db.createDiagram', diagram).wrap(diagram);
});

Cypress.Commands.add('createDmnDiagram', function (project) {
  return cy.createDiagram(project, { type: 'DMN', xml: getDmnDiagram(), ommitProcessId: true });
});

Cypress.Commands.add('removeAllFiles', function (projectId) {
  return cy.task('db.removeAllFiles', projectId);
});

/**
 * Creates a new link.
 */
Cypress.Commands.add('createLink', function (link) {
  link.authorId = '1';
  link.id = `${link.source_file_id}_${link.source_element_id}`;

  cy.task('db.createLink', link).wrap(link);
});

/**
 * Creates a new enterprise license for a specific user, enabling enterprise features
 * (only if the product context is saas; in enterprise/on-prem a license entry is not required).
 *
 * @param {Object} user A valid user object.
 */
Cypress.Commands.add('createEnterpriseLicense', function (user, licenseType = 'enterprise') {
  if (!isEnterprise()) {
    const license = {
      licenseId: getUuid(),
      organizationId: user.organization.id,
      licenseType: licenseType
    };
    cy.task('db.createLicense', license).wrap(license);
  }
});

/**
 * Creates a new API key for a specific user,
 *
 * @param {Object} user A valid user object.
 */
Cypress.Commands.add('createApiKey', function (user, organizationId, apiKeySecret) {
  const key = {
    keyId: getUuid(),
    licenseId: getUuid(),
    organizationId: organizationId || user.organization.id,
    apiKeySecret: apiKeySecret || 'e924fdf81f3c8be122064b5317c697749c79f6251654913bbdd2c6c96d977bc8',
    name: 'Cypress',
    userId: user.id
  };

  cy.task('db.createApiKey', key).wrap(key);
});

/**
 * Creates a project and diagram with an owner and a collaborator
 * to test common collaboration scenarios without having to go
 * through the invitation workflow first.
 *
 * Wraps an object with properties representing the created data:
 *  - Project
 *  - Diagram
 *  - Project owner
 *  - Project collaborator
 */
Cypress.Commands.add('prepareCollaboration', function (config) {
  cy.createUserAndLogin(config).then((owner) => {
    cy.createUser().then((user) => {
      cy.prepareProjectAndCollaborator(owner, user).then((project) => {
        cy.createDiagram(project).then((diagram) => {
          cy.wrap(Object.assign({}, { owner }, { user }, { project }, { diagram }));
        });
      });
    });
  });
});

/**
 * Creates a project for an existing owner and collaborator with a particular
 * permission level for the collaborator.
 *
 * @param {Object} owner A valid user object.
 * @param {Object} collaborator A valid user object.
 * @param {'OWNER'|'WRITE'|'READ'|'COMMENT'} permission Permission level of the collaborator.
 */
Cypress.Commands.add('prepareProjectAndCollaborator', function (owner, collaborator, permission) {
  cy.createProject(owner).then((project) => {
    cy.addCollaborator(project, owner, collaborator, permission);
  });
});

Cypress.Commands.add('addCollaborator', function (project, owner, collaborator, permission) {
  cy.task('db.createProjectPermission', { project, user: collaborator, permission });
  if (!isEnterprise()) {
    cy.task('db.createOrganizationPermission', { organization: owner.organization, user: collaborator, permission });
  }
  cy.wrap(project);
});

/**
 * Expects the data object created by 'prepareCollaboration' and deletes all the data from the database.
 *
 * @param {Object} data created by 'prepareCollaboration'
 */
Cypress.Commands.add('removeCollaboration', function (data) {
  cy.removeUser(data.owner);
  cy.removeUser(data.user);

  // in saas, the project has already been deleted together with the owner's organization
  cy.removeAllProjectsIfEnterprise();
});

Cypress.Commands.add('updatePermissionAccess', function ({ user, project, permission }) {
  cy.task('db.updatePermissionAccess', { user, project, permission });
});
