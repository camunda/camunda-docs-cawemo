import { getBaseUrl } from '../helpers';

/**
 * Overwrites the `cy.request` command to include a Referer header by default, containing
 * the base URL. This header is required for the backend to accept the request.
 */
Cypress.Commands.overwrite('request', function (originalFn, method, url, body) {
  let options = {};

  if (typeof method == 'string') {
    options = {
      url,
      method,
      body,
      headers: {
        Referer: getBaseUrl()
      }
    };
  } else {
    options = Object.assign({}, method, {
      headers: {
        Referer: getBaseUrl()
      }
    });
  }

  return originalFn(options);
});

/**
 * Overwrites the `cy.visit` command to include a Referer header by default, containing
 * the base URL. This header is required for the backend to accept the request.
 */
Cypress.Commands.overwrite('visit', function (originalFn, url, options = {}) {
  options.headers = {
    Referer: getBaseUrl()
  };

  return originalFn(url, options);
});

Cypress.Commands.overwrite('log', (subject, message) => cy.task('log', message));
