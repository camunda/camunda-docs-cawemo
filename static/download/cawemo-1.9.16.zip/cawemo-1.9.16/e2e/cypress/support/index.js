import '@testing-library/cypress/add-commands';
import 'cypress-file-upload';
import './environments';
import './overwrites';
import './db-commands';
import './api-commands';
import './ui-commands';

Cypress.on('uncaught:exception', (err, runnable) => {
  // returning false here prevents Cypress from
  // failing the test
  return false;
});

beforeEach(() => {
  cy.window().then((win) => {
    // set as seen the downtime banner that might interfere with the tests.
    win.localStorage.setItem('cawemo.downtime.seen.1713254400000', 'true');
  });
});
