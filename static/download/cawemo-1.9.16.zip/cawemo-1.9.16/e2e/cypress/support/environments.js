import { isEnterprise, isLdapEnabled } from '../helpers';

it.enterprise = (description, fn) => {
  return !isEnterprise()
    ? it.skip(`[enterprise] ${description}`, fn)
    : it(`[enterprise] ${description}`, fn);
};

it.enterprise.default = (description, fn) => {
  return (isEnterprise() && isLdapEnabled()) || !isEnterprise()
    ? it.skip(`[enterprise default] ${description}`, fn)
    : it(`[enterprise default] ${description}`, fn);
};

it.enterprise.ldap = (description, fn) => {
  return !isEnterprise() || !isLdapEnabled()
    ? it.skip(`[enterprise LDAP] ${description}`, fn)
    : it(`[enterprise LDAP] ${description}`, fn);
};

it.enterprise.ldap.saas = (description, fn) => {
  return !(isEnterprise() && isLdapEnabled()) || !isEnterprise()
    ? it.skip(`[enterprise LDAP or saas] ${description}`, fn)
    : it(`[enterprise LDAP or saas] ${description}`, fn);
};

it.saas = (description, fn) => {
  return isEnterprise() ? it.skip(`[saas] ${description}`, fn) : it(`[saas] ${description}`, fn);
};

describe.enterprise = (description, fn) => {
  return !isEnterprise()
    ? describe.skip(`[enterprise] ${description}`, fn)
    : describe(`[enterprise] ${description}`, fn);
};

describe.enterprise.default = (description, fn) => {
  return (isEnterprise() && isLdapEnabled()) || !isEnterprise()
    ? describe.skip(`[enterprise default] ${description}`, fn)
    : describe(`[enterprise default] ${description}`, fn);
};

describe.enterprise.ldap = (description, fn) => {
  return !isEnterprise() || !isLdapEnabled()
    ? describe.skip(`[enterprise LDAP] ${description}`, fn)
    : describe(`[enterprise LDAP] ${description}`, fn);
};

describe.enterprise.ldap.saas = (description, fn) => {
  return !(isEnterprise() && isLdapEnabled()) || !isEnterprise()
    ? describe.skip(`[enterprise LDAP or saas] ${description}`, fn)
    : describe(`[enterprise LDAP or saas] ${description}`, fn);
};

describe.enterprise.default.saas = (description, fn) => {
  return (isEnterprise() && isLdapEnabled())
    ? describe.skip(`[enterprise default or saas] ${description}`, fn)
    : describe(`[enterprise default or saas] ${description}`, fn);
};

describe.saas = (description, fn) => {
  return isEnterprise()
    ? describe.skip(`[saas] ${description}`, fn)
    : describe(`[saas] ${description}`, fn);
};
