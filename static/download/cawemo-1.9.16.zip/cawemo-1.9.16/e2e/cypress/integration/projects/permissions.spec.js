describe('Permissions', function () {
  beforeEach(function () {
    cy.prepareCollaboration().as('data');
  });

  afterEach(function () {
    cy.removeCollaboration(this.data);
  });

  it('a write-only user has the right permissions', function () {
    // Log in as the collaborator and open the project.
    cy.login(this.data.user).visit(`/projects/${this.data.project.id}`);

    // Assert that the "Create diagram" button exists and that the user can
    // see and edit collaborators.
    cy.getByTestId('diagram-dropdown')
      .should('exist')
      .getByTestId(`entity-${this.data.owner.name}`)
      .should('exist')
      .and('contain', this.data.owner.name)
      .getByTestId('add-collaborator')
      .should('not.exist');

    // Open the existing diagram.
    cy.getByTestId(`entity-${this.data.diagram.name}`).find('a').click();

    // Assert that all modeling tools exist and that the diagram
    // can be edited.
    cy.getBPMN('StartEvent_1')
      .click()
      .get('.djs-context-pad')
      .should('exist')
      .get('.djs-palette')
      .should('exist')
      .getByTestId('toggle-attentiongrabber')
      .should('exist')
      .getByTestId('breadcrumb-diagram')
      .should('have.prop', 'tagName')
      .and('eq', 'BUTTON');

    // Assert that the specification sidebar can be used.
    cy.getByTestId('specification-toggle')
      .should('exist')
      .click()
      .getByTestId('specification-preview')
      .should('exist')
      .click()
      .getByTestId('specification-input')
      .should('exist');

    // Programmatically create a comment to assert that the user has permissions.
    cy.createComment(this.data.diagram.id).then((response) => {
      expect(response.status).to.eq(200);
      expect(response.body).to.have.property('data');
    });
  });

  it('a comment-only user has the right permissions', function () {
    cy.visit(`/projects/${this.data.project.id}`);

    // Assert that the current permission level is correct.
    cy.getByTestId(`entity-${this.data.user.name}`)
      .should('contain', 'Editor')
      .find('[data-test="entity-context-dropdown"]')
      .click()
      .getByTestId('change-permission-COMMENT')
      .click({ force: true });

    // Select the COMMENT permission and assert the successful change.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .and('have.text', 'Collaborator permissions have been updated.')
      .getByTestId('permission-menu')
      .should('not.exist');

    // Log in as the comment-only collaborator and open the project.
    cy.login(this.data.user).visit(`/projects/${this.data.project.id}`);

    // Assert that the "Create diagram" button doesn't exist.
    cy.getByTestId('diagram-dropdown').should('not.exist');

    // Assert that the collaborators are visible.
    cy.getByTestId(`entity-${this.data.owner.name}`).should('exist').and('contain', this.data.owner.name);

    // Open the existing diagram.
    cy.getByTestId(`entity-${this.data.diagram.name}`).find('a').click();

    // Assert that the user can't model.
    cy.getBPMN('StartEvent_1')
      .click()
      .get('.djs-context-pad')
      .should('not.exist')
      .get('.djs-palette')
      .should('not.exist')
      .getByTestId('toggle-attentiongrabber')
      .should('exist')
      .getByTestId('breadcrumb-diagram')
      .should('have.prop', 'tagName')
      .and('eq', 'P');

    // Assert that the specification sidebar exists and that
    // the user can create comments.
    cy.getByTestId('specification-toggle').should('exist').click();

    // Assert that the user can't write documentation.
    cy.getByTestId('specification-preview')
      .should('exist')
      .click()
      .getByTestId('specification-input')
      .should('not.exist');

    // Programmatically create a comment to assert that the user has permissions.
    cy.createComment(this.data.diagram.id).then((response) => {
      expect(response.status).to.eq(200);
      expect(response.body).to.have.property('data');
    });
  });

  it('a read-only user has the right permissions', function () {
    cy.visit(`/projects/${this.data.project.id}`);

    // Assert that the current permission level is correct.
    cy.getByTestId(`entity-${this.data.user.name}`)
      .should('contain', 'Editor')
      .find('[data-test="entity-context-dropdown"]')
      .click()
      .getByTestId('change-permission-READ')
      .click({ force: true });

    // Select the COMMENT permission and assert the successful change.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .and('have.text', 'Collaborator permissions have been updated.')
      .getByTestId('permission-menu')
      .should('not.exist');

    // Log in as the comment-only collaborator and open the project.
    cy.login(this.data.user).visit(`/projects/${this.data.project.id}`);

    // Assert that the user can't create a new diagram or see other collaborators.
    cy.getByTestId('diagram-dropdown').should('not.exist').getByTestId('collaborator-toggle').should('not.exist');

    // Open the existing diagram.
    cy.getByTestId(`entity-${this.data.diagram.name}`).click();

    // Assert that the user can't model or collaborate.
    cy.getBPMN('StartEvent_1')
      .click()
      .get('.djs-context-pad')
      .should('not.exist')
      .get('.djs-palette')
      .should('not.exist')
      .getByTestId('toggle-attentiongrabber')
      .should('not.exist')
      .getByTestId('specification-toggle')
      .should('not.exist')
      .getByTestId('breadcrumb-diagram')
      .should('have.prop', 'tagName')
      .and('eq', 'P');

    // Programmatically create a comment to assert that the user doesn't have permissions.
    cy.createComment(this.data.diagram.id, null, false).then((response) => {
      expect(response.status).to.eq(404);
    });
  });

  it('an admin user has the right permissions', function () {
    cy.visit(`/projects/${this.data.project.id}`);

    // Assert that the current permission level is correct.
    cy.getByTestId(`entity-${this.data.user.name}`)
      .find('[data-test="entity-context-dropdown"]')
      .click()
      .getByTestId('change-permission-OWNER')
      .click({ force: true });

    // Select the COMMENT permission and assert the successful change.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .and('have.text', 'Collaborator permissions have been updated.')
      .getByTestId('permission-menu')
      .should('not.exist');

    // Log in as the comment-only collaborator and open the project.
    cy.login(this.data.user).visit(`/projects/${this.data.project.id}`);

    // Assert that the project dropdown contains all options.
    cy.getByTestId('breadcrumb-project-menu')
      .should('be.visible')
      .click()
      .getByTestId('rename-project')
      .should('be.visible')
      .getByTestId('delete-project')
      .should('be.visible')
      .getByTestId('leave-project')
      .should('be.visible');

    // Assert that the "Create diagram" button exists and that the user can
    // see and edit collaborators.
    cy.getByTestId('diagram-dropdown')
      .should('exist')
      .getByTestId(`entity-${this.data.owner.name}`)
      .should('exist')
      .and('contain', this.data.owner.name)
      .getByTestId('add-collaborator')
      .should('exist');

    // Open the existing diagram.
    cy.visit(`/diagrams/${this.data.diagram.id}`);

    // Assert that all modeling tools exist and that the diagram
    // can be edited.
    cy.getBPMN('StartEvent_1')
      .click()
      .get('.djs-context-pad')
      .should('exist')
      .get('.djs-palette')
      .should('exist')
      .getByTestId('toggle-attentiongrabber')
      .should('exist')
      .getByTestId('breadcrumb-diagram')
      .should('have.prop', 'tagName')
      .and('eq', 'BUTTON');

    // Assert that the specification sidebar can be used.
    cy.getByTestId('specification-toggle')
      .should('exist')
      .click()
      .getByTestId('specification-preview')
      .should('exist')
      .click()
      .getByTestId('specification-input')
      .should('exist');

    // Programmatically create a comment to assert that the user has permissions.
    cy.createComment(this.data.diagram.id).then((response) => {
      expect(response.status).to.eq(200);
      expect(response.body).to.have.property('data');
    });
  });
});
