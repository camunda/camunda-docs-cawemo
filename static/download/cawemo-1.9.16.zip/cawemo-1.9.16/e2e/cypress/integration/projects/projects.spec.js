import { getNameFor, getBaseUrl, isEnterprise } from '../../helpers';

describe('Projects', function () {
  context('Projects - General', function () {
    beforeEach(function () {
      cy.createUserAndLogin()
        .as('user')
        .then(() => {
          window.localStorage.setItem('cawemo.collaborator_sidebar_visible', 'false');
        });
    });

    afterEach(function () {
      cy.removeUser(this.user);
    });

    it('a user can create a new bpmn project', function () {
      const project = getNameFor('project');

      cy.visit('/');

      // Since On-Premise always has both options, we need to open the dropdown first.
      if (isEnterprise()) {
        cy.getByTestId('project-dropdown').click();
      }

      // Create a new project using the button.
      cy.getByTestId('create-project').should('have.text', 'New project').click();

      // Assert that the user has been redirected to the project page.
      cy.url().should('include', 'projects');

      // Provide a new project name.
      cy.getByTestId('editable-input')
        .should('have.value', 'New Project')
        .wait(100)
        .type(project + '{enter}')
        .getByTestId('breadcrumb-project-menu')
        .should('have.text', project);

      // Assert that the page title is "Diagrams".
      cy.getByTestId('project-name').should('be.visible').and('have.text', project);
    });

    it('a user can rename a project he created', function () {
      const name = getNameFor('project');

      // Create a new project and open it.
      cy.createProject(this.user).then((project) => {
        cy.visit(`/projects/${project.id}`);

        // Enter a new project name.
        cy.getByTestId('breadcrumb-project-menu')
          .click({ force: true })
          .getByTestId('rename-project')
          .click()
          .getByTestId('editable-input')
          .type(name + '{enter}');

        // Reload the page and assert that the new name has been saved.
        cy.reload().getByTestId('breadcrumb-project-menu').should('have.text', name);
      });
    });

    it('a user can delete a project he created', function () {
      // Create a new project and open it.
      cy.createProject(this.user).then((project) => {
        cy.visit(`/projects/${project.id}`);

        // Delete the project through the menu.
        cy.getByTestId('breadcrumb-project-menu').click({ force: true }).getByTestId('delete-project').click();

        // Assert that the confirmation modal is displayed and confirm.
        cy.contains('Deleting project').should('be.visible').getByTestId('confirm-button').click();

        // Assert that the user has been redirected to the homepage and that
        // the project has been deleted.
        cy.url().should('eq', getBaseUrl()).getByTestId(`entity-${project.name}`).should('not.exist');

        // Assert that the snackbar is visible.
        cy.getByTestId('snackbar').should('be.visible').and('have.text', 'Your project has been deleted.');
      });
    });

    it('a user can search for diagrams and folders', function () {
      // Create a new project.
      cy.createProject(this.user).then((project) => {
        // Create two diagrams.
        cy.createDiagram(project).as('diagram1');
        cy.createDiagram(project).as('diagram2');
        cy.createFolder(project).as('folder1');
        cy.createFolder(project).as('folder2');

        // Open the project.
        cy.visit(`/projects/${project.id}`).wait(500);

        // Expand the search input by clicking the button.
        cy.getByTestId('expand-entity-search').should('have.attr', 'aria-label', 'Search through this list').click();

        // Assert that the entity search is visible and focused.
        cy.getByTestId('entity-search-input').should('be.visible').and('have.focus');

        // Type in a diagram's name.
        cy.get('@diagram1').then((diagram) => {
          cy.getByTestId('entity-search-input').type(diagram.name);
        });

        // Assert that the only the first diagram appears.
        cy.getByTestId('entity-list').children('li').should('have.length', 1);

        // Assert that the second diagram doesn't appear.
        cy.get('@diagram2').then((diagram) => {
          cy.getByTestId(`entity-${diagram.name}`).should('not.exist');
        });

        // Close the search input and assert that the input value has been cleared.
        cy.getByTestId('expand-entity-search').click().getByTestId('entity-search-input').should('have.value', '');

        // Assert that all diagrams and folders appear.
        cy.getByTestId('entity-list').children('li').should('have.length', 4);

        // Expand the search input by clicking the button.
        cy.getByTestId('expand-entity-search').click();

        // Type in a folder's name.
        cy.get('@folder1').then((folder) => {
          cy.getByTestId('entity-search-input').type(folder.name);
        });

        // Assert that the only the first folder appears.
        cy.getByTestId('entity-list').children('li').should('have.length', 1);

        // Assert that the second folder doesn't appear.
        cy.get('@folder2').then((folder) => {
          cy.getByTestId(`entity-${folder.name}`).should('not.exist');
        });
      });
    });

    it('a user can change the diagram sort order', function () {
      // Create a new project.
      cy.createProject(this.user).then((project) => {
        // Create a couple of folders and diagrams.
        cy.createDiagram(project, { name: 'DEF' });
        cy.createDiagram(project, { name: 'ABC' });
        cy.createFolder(project, { name: 'HIJ' });
        cy.createFolder(project, { name: 'KLM' });

        // Open the project.
        cy.visit(`/projects/${project.id}`);

        // Assert that folders come first in alphabetical order, followed by diagrams.
        cy.getByTestId('entity-list')
          .children('li')
          .first()
          .should('have.attr', 'data-test', 'entity-HIJ')
          .next()
          .should('have.attr', 'data-test', 'entity-KLM')
          .next()
          .should('have.attr', 'data-test', 'entity-ABC')
          .next()
          .should('have.attr', 'data-test', 'entity-DEF');

        // Click on the "Name" column to change the sorting order.
        cy.getByTestId('entity-head-Name').dblclick();

        cy.getByTestId('sort-icon-Name').should('be.visible');

        // Assert that folders still come first, but in reversed order.
        cy.getByTestId('entity-list')
          .children('li')
          .first()
          .should('have.attr', 'data-test', 'entity-KLM')
          .next()
          .should('have.attr', 'data-test', 'entity-HIJ')
          .next()
          .should('have.attr', 'data-test', 'entity-DEF')
          .next()
          .should('have.attr', 'data-test', 'entity-ABC');

        // Reload the browser.
        cy.reload();

        cy.getByTestId('sort-icon-Name').should('be.visible');

        // Assert that folders still come first, but in reversed order.
        cy.getByTestId('entity-list')
          .children('li')
          .first()
          .should('have.attr', 'data-test', 'entity-KLM')
          .next()
          .should('have.attr', 'data-test', 'entity-HIJ')
          .next()
          .should('have.attr', 'data-test', 'entity-DEF')
          .next()
          .should('have.attr', 'data-test', 'entity-ABC');
      });
    });

    it('a project with many collaborators is shown properly in the home page', function () {
      cy.prepareCollaboration().then((data) => {
        const owner = data.owner;
        const project = data.project;

        const addCollaborator = () => {
          cy.createUser().then((collaborator) => {
            cy.addCollaborator(project, owner, collaborator);
          });
        };

        addCollaborator();
        addCollaborator();
        addCollaborator();
        addCollaborator();
        addCollaborator();
        addCollaborator();
        addCollaborator();

        cy.login(owner).visit('/');
        cy.assertEntityPresent(project.name);
      });
    });
  });

  context('Projects - Permissions', function () {
    beforeEach(function () {
      cy.prepareCollaboration().as('data');
    });

    afterEach(function () {
      cy.removeCollaboration(this.data);
    });

    it('a user needs the right permissions to rename or delete a project using breadcrumb menu', function () {
      const collaborator = this.data.user;
      const project = this.data.project;

      // Editor (default permission of the collaborator)
      cy.login(collaborator).visit(`/projects/${this.data.project.id}`);
      cy.openBreadcrumbMenu(project.name);
      cy.assertNoDeleteOptionInMenu();
      cy.assertNoRenameOptionInMenu();

      // Viewer
      changeCollaboratorPermissionAndReloadPage(collaborator, project, 'READ');
      cy.openBreadcrumbMenu(project.name);
      cy.assertNoDeleteOptionInMenu();
      cy.assertNoRenameOptionInMenu();

      // Commenter
      changeCollaboratorPermissionAndReloadPage(collaborator, project, 'COMMENT');
      cy.openBreadcrumbMenu(project.name);
      cy.assertNoDeleteOptionInMenu();
      cy.assertNoRenameOptionInMenu();

      // Admin
      changeCollaboratorPermissionAndReloadPage(collaborator, project, 'OWNER');
      const newName = getNameFor('project');
      cy.openBreadcrumbMenu(project.name);
      cy.assertRenamingProjectIsPossibleUsingBreadcrumbMenu(project.name, newName);
      cy.openBreadcrumbMenu(newName);
      cy.assertDeletingProjectIsPossible(project.name);
    });

    it('a user needs the right permissions to delete a project using entity menu', function () {
      const collaborator = this.data.user;
      const owner = this.data.owner;
      const project = this.data.project;

      // Editor (default permission of the collaborator)
      cy.login(collaborator).visit('/');
      if (!isEnterprise()) {
        // Switch to project owner's organization.
        cy.findByText(`${collaborator.name}'s Organization`).click();
        cy.findByText(`${owner.name}'s Organization`).click();
      }
      cy.openEntityMenu(project.name);
      cy.assertNoDeleteOptionInMenu();

      // Viewer
      changeCollaboratorPermissionAndReloadPage(collaborator, project, 'READ');
      cy.assertNoEntityMenuPresent(project.name);

      // Commenter
      changeCollaboratorPermissionAndReloadPage(collaborator, project, 'COMMENT');
      cy.openEntityMenu(project.name);
      cy.assertNoDeleteOptionInMenu();

      // Admin
      changeCollaboratorPermissionAndReloadPage(collaborator, project, 'OWNER');
      cy.openEntityMenu(project.name);
      cy.assertDeletingProjectIsPossible(project.name);
    });

    it('a user needs the right permissions to delete multiple projects from home page', function () {
      const collaborator = this.data.user;
      const { owner, project } = this.data;

      // Create multiple projects.
      cy.prepareProjectAndCollaborator(owner, collaborator, 'OWNER').then((project2) => {
        cy.prepareProjectAndCollaborator(owner, collaborator, 'OWNER').then((project3) => {
          cy.login(collaborator).visit('/');

          if (!isEnterprise()) {
            // Switch to project owner's organization.
            cy.findByText(`${collaborator.name}'s Organization`).click();
            cy.findByText(`${owner.name}'s Organization`).click();
          }

          // Select all projects.
          cy.toggleEntitySelection(project.name);
          cy.toggleEntitySelection(project2.name);
          cy.toggleEntitySelection(project3.name);

          // Assert that Delete option is disabled.
          cy.findByRole('button', { name: /3 items selected/i }).click({ force: true });
          cy.findByRole('menuitem', { name: /delete/i }).should('exist');
          cy.findByRole('menuitem', { name: /delete/i }).should('have.css', 'pointer-events', 'none');

          // Select only projects which the collaborator has 'Admin' permissions.
          cy.reload();
          cy.toggleEntitySelection(project2.name);
          cy.toggleEntitySelection(project3.name);

          // Assert that Delete is possible.
          cy.findByRole('button', { name: /2 items selected/i }).click({ force: true });
          cy.findByRole('menuitem', { name: /delete/i }).click();
          cy.findByRole('button', { name: /delete projects/i }).click();
          cy.findByText(/projects have been deleted/i).should('exist');
        });
      });
    });
  });
});

const changeCollaboratorPermissionAndReloadPage = (collaborator, project, permission) => {
  cy.updatePermissionAccess({ user: collaborator, project, permission });
  cy.reload();
};
