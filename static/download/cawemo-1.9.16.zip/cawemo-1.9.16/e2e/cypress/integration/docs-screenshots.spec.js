if (Cypress.env('docs')) {
  describe('Docs screenshots', function () {
    beforeEach(function () {
      cy.createUserAndLogin({
        name: 'John Doe',
        email: 'john.doe@example.org'
      }).as('user');
    });

    afterEach(function () {
      cy.removeUser(this.user);
    });

    it('screenshots are generated', function () {
      cy.createEnterpriseLicense(this.user, 'cawemo-team');

      cy.visit('/settings');

      cy.getByTestId('create-api-key')
        .click()
        .getByTestId('api-key-input')
        .type('Modeler API Key{enter}')
        .getByTestId('complete-api-key')
        .click();

      cy.screenshot('api-keys');

      cy.visit('/')
        .getByTestId('project-dropdown')
        .click()
        .getByTestId('create-catalog')
        .click()
        .getByTestId('editable-input')
        .wait(100)
        .type('RPA Catalog{enter}')
        .getByTestId('diagram-dropdown')
        .click()
        .getByTestId('create-service-task-template')
        .click()
        .getByTestId('editable-input')
        .wait(100)
        .type('Create account in legacy application{enter}');

      cy.get('input[name="service-task-label"]')
        .type('Create account in legacy application')
        .get('textarea[name="description"]')
        .type(
          'Creates a new account in the legacy application based on the provided name and returns the ID of the created account.'
        )
        .getByTestId('implementation-type')
        .click()
        .getByTestId('uipath')
        .click()
        .getByTestId('implementation-name')
        .type('create-account')
        .getByTestId('add-input-parameter')
        .click()
        .get('input[name="parameter-label-5"]')
        .type('name')
        .get('input[name="parameter-description-5"]')
        .type("employee's name")
        .get('main')
        .scrollTo('top');

      cy.screenshot('template-form-editor');

      cy.getByTestId('toggle-editor').click().waitForEditor();

      cy.screenshot('template-code-editor');

      cy.visit('/');

      cy.getByTestId('project-dropdown')
        .click()
        .getByTestId('create-project')
        .click()
        .getByTestId('editable-input')
        .wait(100)
        .type('Project #1{enter}')
        .getByTestId('diagram-dropdown')
        .click()
        .getByTestId('create-bpmn-diagram')
        .click()
        .getByTestId('editable-input')
        .wait(100)
        .type('Awesome Process Model{enter}')
        .getByTestId('breadcrumb-diagram')
        .click()
        .get('[id="raised-button-file"]')
        .attachFile('diagrams/docs-process-model.bpmn')
        .findByText(/is being uploaded to replace this diagram/i).should('exist')
        .findByText(/is being uploaded to replace this diagram/i).should('not.exist')
        .findByText(/the previous diagram content has been saved as a milestone/i).should('exist')
        .findByText(/the previous diagram content has been saved as a milestone/i).should('not.exist')
        .getByTestId('specification-toggle')
        .click();

      cy.screenshot('cawemo-bpmn-modeling');
    });
  });
}
