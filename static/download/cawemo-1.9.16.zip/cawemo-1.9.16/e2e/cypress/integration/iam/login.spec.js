import { getBaseUrl, getIamBaseUrl, isEnterprise, isLdapEnabled } from '../../helpers';

describe('Login', function () {
  beforeEach(function () {
    cy.createUser().as('user').visit('/login');
  });

  afterEach(function () {
    cy.removeUser(this.user);
  });

  it('an existing user can log in', function () {
    // Assert that the login page is displayed by checking the header.
    cy.getByTestId('userinfo-header').should('have.text', 'Log in to continue to Cawemo');

    if (!isLdapEnabled()) {
      // Assert that the password reset link is visible.
      cy.getByTestId('password-reset-link').should('be.visible');
    }

    // Assert that the privacy link is visible on SaaS.
    cy.getByTestId('privacy-link').should('be.visible');

    if (!isEnterprise()) {
      // Assert that the terms link is visible on SaaS.
      cy.getByTestId('terms-link').should('be.visible');

      // Assert that the Google login link is visible on SaaS.
      cy.get('button[title="Login with Google"]').should('be.visible');

      // Assert that the LinkedIn login link is visible on SaaS.
      cy.get('button[title="Login with LinkedIn"]').should('be.visible');
    }

    // Type the user's email into the form.
    cy.getByTestId('email').should('have.attr', 'placeholder', 'Your email').type(this.user.email);

    // Type the user's password into the form.
    cy.getByTestId('password').should('have.attr', 'placeholder', 'Your password').type(this.user.password);

    // Click the login button.
    cy.getByTestId('submit').should('have.text', 'Login').click();

    // Assert that the user has been redirected back to Cawemo.
    cy.url().should('eq', getBaseUrl());

    // Assert that the avatar from the homepage is visible.
    cy.getByTestId(`avatar-${this.user.name}`).should('be.visible');
  });

  it('a user cannot log in with invalid credentials', function () {
    // Type the user's email, an invalid password, and submit the login form.
    cy.getByTestId('email')
      .type(this.user.email)
      .getByTestId('password')
      .type('invalid password')
      .getByTestId('submit')
      .click();

    // Assert that an error message is displayed.
    cy.getByTestId('error-message')
      .should('be.visible')
      .and('have.text', 'We could not find an account matching your login details.');

    // Assert that the user stayed on IAM.
    cy.url().should('include', getIamBaseUrl());
  });

  it.enterprise.ldap('a user that only exists in LDAP can log in', function () {
    // Assert that the password reset link is hidden.
    cy.getByTestId('password-reset-link').should('not.exist');

    cy.createUserInLdapOnly().then((user) => {
      // Type the user's email, password, and submit the login form.
      cy.getByTestId('email')
        .type(user.email)
        .getByTestId('password')
        .type(user.password)
        .getByTestId('submit')
        .click();

      // Assert that the user has been redirected back to Cawemo.
      cy.url().should('eq', getBaseUrl());

      // Assert that the avatar from the homepage is visible.
      cy.getByTestId(`avatar-${user.name}`).should('be.visible');

      // Remove the LDAP user.
      cy.removeOrganization(user).removeUser(user);
    });
  });
});
