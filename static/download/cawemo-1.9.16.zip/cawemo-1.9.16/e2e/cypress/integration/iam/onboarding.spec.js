import { getUser } from '../../helpers';

describe('User onboarding', function () {
  context('Onboarding - Flow A', function () {
    beforeEach(function () {
      cy.createUserAndLogin({ segment: 'A' }).as('user');
    });

    afterEach(function () {
      cy.removeUser(this.user);
    });

    it.saas('flow A works correctly', function () {
      // Onboarding shown
      cy.visit('/');
      assertOnboardingFlowAIsShownInHomePage();
      cy.findByRole('button', { name: /new bpmn diagram/i }).click();
      assertOnboardingFlowAIsShownInDiagramPage();

      // Onboarding shown only once
      cy.visit('/');
      assertOnboardingFlowANotShownInHomePage();

      // Onboarding not shown on subsequent login
      cy.relogin(this.user);
      assertOnboardingFlowANotShownInHomePage();
    });
  });

  context('Onboarding - Flow B', function () {
    beforeEach(function () {
      cy.createUserAndLogin({ segment: 'B' }).as('user');
    });

    afterEach(function () {
      cy.removeUser(this.user);
    });

    it.saas('flow B works correctly', function () {
      // Onboarding shown
      cy.visit('/');
      assertOnboardingFlowBIsShownInHomePage();
      cy.findByRole('button', { name: /new project/i }).click();
      assertOnboardingFlowBIsShownInProjectPage();

      // Onboarding shown only once
      cy.visit('/');
      assertOnboardingFlowBNotShownInHomePage();

      // Onboarding not shown on subsequent login
      cy.relogin(this.user);
      assertOnboardingFlowBNotShownInHomePage();
    });
  });

  context('No onboarding', function () {
    it.saas('no onboarding is shown for users signing-up via invitation to collaborate', function () {
      cy.createUserAndLogin().then((user) => {
        cy.createProject(user).then((project) => {
          const collaborator = getUser({ segment: 'A' });

          // Invite a collaborator
          cy.createInvitation(collaborator, project.id).as('invitation');

          cy.logout();

          // Open the invitation and click Register
          cy.get('@invitation').then(cy.visit);
          cy.findByRole('button', { name: /register/i }).click();

          // Create a new user account through IAM
          cy.getByTestId('name')
            .type(collaborator.name)
            .getByTestId('email')
            .type(collaborator.email)
            .getByTestId('new-password')
            .type(collaborator.password)
            .getByTestId('submit')
            .click();

          // Onboarding not shown immediately after login
          assertOnboardingFlowBNotShownInProjectPage();
          cy.visit('/');
          assertOnboardingFlowBNotShownInHomePage();
          assertOnboardingFlowANotShownInHomePage();

          // Onboarding not shown on subsequent login
          cy.relogin(collaborator);
          assertOnboardingFlowBNotShownInHomePage();
          assertOnboardingFlowANotShownInHomePage();

          cy.removeUser(user);
          cy.removeUser(collaborator);
        });
      });
    });

    it.saas('no onboarding is shown for users in segments C & D', function () {
      assertNoOnboardingForUsersInSegments(['C', 'D']);
    });

    it.enterprise('no onboarding is shown for enterprise', function () {
      assertNoOnboardingForUsersInSegments(['A', 'B', 'C', 'D']);
    });
  });
});

const assertNoOnboardingForUsersInSegments = (segments) => {
  segments.forEach((segment) => {
    cy.createUserAndLogin({ segment }).then((user) => {
      assertNoOnboardingShown();
      cy.removeUser(user);
    });
  });
};

const assertNoOnboardingShown = () => {
  cy.visit('/');
  assertOnboardingFlowANotShownInHomePage();
  assertOnboardingFlowBNotShownInHomePage();
};

const assertOnboardingFlowANotShownInHomePage = () => {
  cy.findByRole('heading', { name: /welcome to cawemo/i }).should('not.exist');
  cy.findByText(/Give it a try now!/i).should('not.exist');
  cy.findByRole('button', { name: /new bpmn diagram/i }).should('not.exist');
};

const assertOnboardingFlowBNotShownInHomePage = () => {
  cy.wait(1500);
  cy.findByText(/cawemo lets you use projects and catalogs to manage your BPMN diagrams./i).should('not.exist');
  cy.findByText(/create a project to get started/i).should('not.exist');
};

const assertOnboardingFlowBNotShownInProjectPage = () => {
  cy.wait(1500);
  cy.findByText(/great! now click here to create a new bpmn diagram/i).should('not.exist');
};

const assertOnboardingFlowAIsShownInHomePage = () => {
  cy.findByRole('dialog').within(() => {
    cy.findByRole('heading', { name: /welcome to cawemo/i }).should('exist');
    cy.findByText(/You can describe business processes using Business Process Model and Notation/i).should('exist');
    cy.findByText(/BPMN 2.0/i).should('exist');
    cy.findByText(/Give it a try now!/i).should('exist');
    cy.findByRole('button', { name: /close/i }).should('exist');
    cy.findByRole('button', { name: /new bpmn diagram/i }).should('exist');
  });
};

const assertOnboardingFlowAIsShownInDiagramPage = () => {
  cy.findByText(/cawemo organizes diagrams into projects and folders/i).should('exist');
  cy.get('body').click();
  cy.findByText(/cawemo organizes diagrams into projects and folders/i).should('not.exist');
  cy.getByTestId('top-bar').within(() => {
    cy.findByText(/first project/i).should('exist');
    cy.findByText(/first diagram/i).should('exist');
  });
};

const assertOnboardingFlowBIsShownInHomePage = () => {
  cy.findByText(/cawemo lets you use projects to manage your BPMN diagrams./i).should('exist');
  cy.findByText(/create a project to get started/i).should('exist');
  cy.get('body').click();
  cy.findByText(/cawemo lets you use projects to manage your BPMN diagrams./i).should('not.exist');
  cy.findByText(/create a project to get started/i).should('not.exist');
};

const assertOnboardingFlowBIsShownInProjectPage = () => {
  cy.findByText(/great! now click here to create/i).should('exist');
  cy.findByText(/a new bpmn diagram/i).should('exist');
  cy.get('body').click();
  cy.findByText(/great! now click here to create/i).should('not.exist');
};
