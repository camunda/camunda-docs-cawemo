if (Cypress.env('ci')) {
  describe('Asset Refresh', function () {
    beforeEach(function () {
      cy.createUserAndLogin().as('user').visit('/');
    });

    afterEach(function () {
      cy.removeUser(this.user);
    });

    it('refreshes the FE app after a different version was detected in the BE', function (done) {
      cy.window().then((win) => {
        win.addEventListener('beforeunload', () => {
          done();
        });
        cy.writeFile('/tmp/asset-refresh.json', {ready: new Date(), purpose:"This file can be used to signal the executing script that the test is ready."})
      });

      const blurAndFocusWindow = () => {
        cy.window().trigger('blur').wait(1000).window().trigger('focus').wait(9000).then(blurAndFocusWindow);
      };

      blurAndFocusWindow();
    });
  });
}
