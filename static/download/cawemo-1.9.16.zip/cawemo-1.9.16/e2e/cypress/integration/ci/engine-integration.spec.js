import deployDiagram from '../../utils/deploy-diagram';
import downloadDiagram from '../../utils/download-diagram';
import { getBaseUrl, isEnterprise, isSaaS } from '../../helpers';
import { ADMIN_USER, ADMIN_ORGANIZATION } from '../../../scripts/prepare/fixtures';

if (Cypress.env('ci')) {
  describe('Engine integration', function () {
    before(function () {
      // stores the user in Cypress' env object and creates project, diagram and API key.
      function prepareTestData(user) {
        Cypress.env('user', user);

        cy.createProject(user).then((project) => {
          Cypress.env('project', project);

          cy.createDiagram(project).then((diagram) => Cypress.env('diagram', diagram));
        });

        cy.createApiKey(user, ADMIN_ORGANIZATION.id, Cypress.env('engineApiKeySecret'));
      }

      if (isSaaS()) {
        cy.createUser({ id: ADMIN_USER.id, organizationId: ADMIN_ORGANIZATION.id }).then((user) => {
          prepareTestData(user);
        });
      } else {
        prepareTestData({ ...ADMIN_USER, organization: ADMIN_ORGANIZATION });
      }
    });

    after(function () {
      cy.removeUser(Cypress.env('user'));
    });

    beforeEach(function () {
      cy.prepareDownload();
      cy.login(Cypress.env('user'));
    });

    it('download and deploy a diagram correctly', function () {
      // Assert that there are no deployed projects, yet.
      cy.contains('Engine deployment').should('not.exist');

      cy.visit(`/diagrams/${Cypress.env('diagram').id}`);

      // Create a few elements in the diagram.
      cy.getBPMN('StartEvent_1')
        .click()
        .get('[data-action="append.append-task"]')
        .should('be.visible')
        .click()
        .getByTestId('autosave')
        .should('contain', 'Autosaved')
        .get('[contenteditable]')
        .type('Deployment Task #1{enter}')
        .getByTestId('autosave')
        .should('contain', 'Autosaved')
        .get('[data-action="append.end-event"]')
        .click();

      // Wait until the diagram has saved.
      cy.wait(200).getByTestId('autosave').should('contain', 'Autosaved');

      // Open the export menu and click the "Export as BPMN" button.
      cy.getByTestId('export-menu').click().getByTestId('export-xml').click();

      // Download the diagram, parse its contents and deploy it to the engine.
      cy.get('a[download]').then(downloadDiagram).then(deployDiagram).wait(10000);

      cy.intercept(getBaseUrl('internal-api/files/*/related*')).as('getRelatedFiles');

      // Assert that there is the deployed project and open it.
      cy.visit('/')
        .getByTestId('entity-Cypress Integration Tests Deployments')
        .should('exist')
        .and('contain', 'Cypress Integration Tests Deployments')
        .click()
        .getByTestId('entity-list')
        .find('li')
        .should('have.length', 1)
        .click();

      // Store the process URL for further use and assert that the task has the correct text.
      cy.url()
        .then((processUrl) => Cypress.env('processUrl', processUrl))
        .getBPMN('Activity_')
        .first()
        .should('have.text', 'Deployment Task #1');

      // wait for the last request to finish before logout is triggered in the following "beforeEach"
      cy.intercept(getBaseUrl('internal-api/files/*/related*')).as('getRelatedFiles');
      cy.wait('@getRelatedFiles');
    });

    it('a deployed diagram displays in the milestone view', function () {
      // Open the deployed process.
      cy.visit(Cypress.env('processUrl'));

      // Assert that the milestone sidebar is visible and contains "Version 1".
      cy.getByTestId('milestone-sidebar-title')
        .should('have.text', 'Deployments')
        .getByTestId('milestone')
        .should('have.length', 1)
        .and('contain', 'Version 1');

      // Assert that the diagram is read-only.
      cy.getBPMN('StartEvent_1')
        .click()
        .get('.djs-context-pad')
        .should('not.exist')
        .get('.djs-palette')
        .should('not.exist')
        .getByTestId('toggle-attentiongrabber')
        .should('not.exist');

      // Assert that related diagrams are visible.
      cy.contains('Related diagrams').should('be.visible');

      // Assert that the original digram appears in the related diagrams section.
      cy.getByTestId('version-list')
        .should('be.visible')
        .getByTestId('version')
        .should('have.length', 1)
        .and('contain', Cypress.env('diagram').name);
    });

    it('the version number is incremented after each deploy', function () {
      // Open the original diagram.
      cy.visit(`/diagrams/${Cypress.env('diagram').id}`);

      // Modify the diagram by appending a task.
      cy.getBPMN('Event_')
        .dblclick()
        .get('[contenteditable]')
        .type('Modified event{enter}')
        .getBPMN('Activity_')
        .click()
        .get('[data-action="append.append-task"]')
        .click();

      // Wait until the diagram has saved.
      cy.wait(200).getByTestId('autosave').should('contain', 'Autosaved');

      // Open the export menu and click the "Export as BPMN" button.
      cy.getByTestId('export-menu').click().getByTestId('export-xml').click();

      // Download the diagram, parse its contents and deploy it to the engine.
      cy.get('a[download]').then(downloadDiagram).then(deployDiagram).wait(10000);

      // Open the deployed process.
      cy.visit(Cypress.env('processUrl'));

      // Assert that a second version "Version 2" has been added.
      cy.getByTestId('milestone').should('have.length', 2).first().should('contain', 'Version 2');

      // Assert that the BPMN changes are reflected.
      cy.contains('Modified event').should('exist').getBPMN('Activity_').should('have.length', 2);
    });

    it('a deployed diagram can be shared', function () {
      // Open the deployed process.
      cy.visit(Cypress.env('processUrl'));

      // Open the breadcrumb menu and click the "Share or embed" entry.
      cy.getByTestId('breadcrumb-diagram')
        .should('contain', 'Process_')
        .click()
        .getByTestId('diagram-menu-item-copy-embed')
        .should('have.text', 'Share or embed')
        .click();

      // Create a share and assert that it is available.
      cy.getByTestId('create-share-cta')
        .should('exist')
        .click()
        .getByTestId('share-link-container')
        .then(($input) => {
          cy.request('GET', $input.val()).then((response) => {
            expect(response.status).to.eq(200);
          });
        });
    });

    it('a deployed diagram can be diffed', function () {
      // Open the original diagram.
      cy.visit(`/diagrams/${Cypress.env('diagram').id}`);

      // Modify the diagram by changing the task's text.
      cy.getBPMN('Activity_')
        .first()
        .dblclick()
        .get('[contenteditable]')
        .clear()
        .type('Changed Task{enter}')
        .getByTestId('autosave')
        .should('contain', 'Autosaved');

      // Open the milestone page.
      cy.visit(`/milestones/${Cypress.env('diagram').id}`);

      // Select the related diagram (the deployed process).
      cy.getByTestId('version').click();

      // Assert that the diffing is visible.
      cy.getBPMN('Activity_').first().should('have.class', 'diff-changed');

      // Open the deployed process from the related diagrams section
      // and assert that it is opened.
      cy.getByTestId('version-menu')
        .click()
        .getByTestId('open-version')
        .click()
        .getByTestId('breadcrumb-diagram')
        .should('not.have.text', Cypress.env('diagram').name)
        .getByTestId('version')
        .should('contain', Cypress.env('diagram').name);
    });

    it("a deployed diagram's version can be deleted only by the admin", function () {
      // Create a second user and invite him.
      cy.createUser().then((user) => {
        if (isSaaS()) {
          // in Enterprise all users are already added to the only organization
          // the access to the organization is enough because ENGINE projects are visible to everyone
          cy.task('db.createOrganizationPermission', { organization: ADMIN_ORGANIZATION, user });
        }

        // Change the session.
        cy.login(user);

        // Open the deployed process.
        cy.visit(Cypress.env('processUrl'));

        // Assert that the delete menu item is not visible.
        cy.getByTestId('milestone-menu-button')
          .last()
          .click({ force: true })
          .getByTestId('milestone-menu-item-delete')
          .should('not.exist');

        // Log in as the administrator and open the deployed process.
        const loginUser = isEnterprise() ? ADMIN_USER : Cypress.env('user');
        cy.login(loginUser).visit(Cypress.env('processUrl'));

        // Assert that the "Delete" entry is visible in the milestone menu and click it.
        cy.getByTestId('milestone-menu-button')
          .last()
          .click({ force: true })
          .getByTestId('milestone-menu-item-delete')
          .should('be.visible')
          .click()
          .getByTestId('confirm-button')
          .click();

        // Assert that the version has been deleted.
        cy.getByTestId('milestone').should('have.length', 1);

        // Delete the invited user.
        cy.removeUser(user);
      });
    });

    it('deployed diagrams and projects can be deleted only by the admin', function () {
      if (isEnterprise()) {
        cy.login(ADMIN_USER);
      }

      // Open the engine project and click the entity list's context menu
      // to delete the deployed process.
      cy.visit('/')
        .getByTestId('entity-Cypress Integration Tests Deployments')
        .click()
        .getByTestId('entity-context-dropdown')
        .click({ force: true })
        .getByTestId('delete-diagram')
        .click();

      // Confirm process deletion.
      cy.getByTestId('confirm-button').click();

      // Open the engine project's breadcrumb menu and assert that the "Delete"
      // entry is visible. Click it.
      cy.getByTestId('breadcrumb-project-menu')
        .click()
        .getByTestId('rename-project')
        .should('not.exist')
        .getByTestId('delete-project')
        .should('be.visible')
        .click();

      // Confirm project deletion.
      cy.getByTestId('confirm-button').click();

      // Assert that the user is redirected to the homepage.
      cy.url().should('eq', getBaseUrl());

      //  Assert that the project "Engine deployment" is deleted.
      cy.contains('Engine deployment').should('not.exist');
    });
  });
}
