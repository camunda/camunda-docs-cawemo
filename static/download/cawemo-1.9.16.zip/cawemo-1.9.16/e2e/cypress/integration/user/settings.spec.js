import { getBaseUrl, getUser } from '../../helpers';

describe.saas('Settings', function () {
  beforeEach(function () {
    cy.createUserAndLogin().as('user');
  });

  afterEach(function () {
    cy.removeUser(this.user);
  });

  it('a user can change the organization name', function () {
    cy.visit('/settings');

    // Assert that the "Name" tile is displayed.
    cy.contains('Name').should('exist');

    // Assert that the input has the right name value and that the submit button
    // is disabled by default.
    cy.getByTestId('organization-name')
      .should('be.visible')
      .and('have.value', this.user.organization.name)
      .getByTestId('submit-organization-name')
      .should('be.disabled');

    // Clear the input and write a new organization name. Assert that the button
    // is no longer disabled and submit.
    cy.getByTestId('organization-name')
      .clear()
      .getByTestId('submit-organization-name')
      .should('be.disabled')
      .getByTestId('organization-name')
      .type('New organization name')
      .getByTestId('submit-organization-name')
      .should('not.be.disabled')
      .click();

    // Assert that the snackbar is visible and displays the correct message.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .and('have.text', 'Your organization has successfully been renamed.');
  });

  it('a user can copy his id and organization id', function () {
    // Create an Enterprise license for the user first and open the settings page.
    cy.createEnterpriseLicense(this.user).visit('/settings');

    // Assert that the "API keys" tile is displayed.
    cy.contains('API keys').should('exist');

    // Assert that the correct user id is displayed
    cy.getByTestId('user-id')
      .should('have.value', this.user.id);

    // Assert that the user id can be copied to the clipboard.
    cy.getByTestId('copy-user-id')
      .click()
      .getByTestId('snackbar')
      .should('be.visible')
      .and('have.text', 'The user ID has been copied to your clipboard.');
  });

  it('a user can create new api keys', function () {
    // Create an Enterprise license for the user first and open the settings page.
    cy.createEnterpriseLicense(this.user).visit('/settings');

    // Click on the "Create API key" button.
    cy.getByTestId('create-api-key').should('have.text', 'Create API key').click();

    // Assert that the input is displayed and write the key's name.
    cy.getByTestId('api-key-input').should('be.visible').and('be.empty').type('Cypress API Key');

    // Click the "Cancel" button and assert that the view changes correctly.
    cy.getByTestId('cancel-api-key').click().getByTestId('api-key-input').should('not.exist');

    // Click the "Create API key" button again.
    cy.getByTestId('create-api-key').click();

    // Assert that the previously entered API key name has been deleted, enter
    // a value again and submit.
    cy.getByTestId('api-key-input').should('be.empty').type('Cypress API Key').getByTestId('save-api-key').click();

    // Assert that the success message is displayed correctly.
    cy.getByTestId('success-message').should('be.visible').and('contain', 'Cypress API Key');

    // Copy the API secret to the clipboard.
    cy.getByTestId('copy-api-key-secret').click();

    // Assert that the snackbar is visible and displays the correct message.
    cy.getByTestId('snackbar').should('be.visible').and('have.text', 'The API key has been copied to your clipboard.');

    // Finish the API key setup.
    cy.getByTestId('complete-api-key').click();

    // Assert that the API key table has a new row with the created key.
    cy.getByTestId('api-key-table').find('tbody tr').should('have.length', 1).and('contain', 'Cypress API Key');
  });

  it('a user can delete api keys', function () {
    // Create an Enterprise license and an API key for the user
    // first and open the settings page.
    cy.createEnterpriseLicense(this.user).createApiKey(this.user).visit('/settings');

    // Click the "Remove key" button.
    cy.getByTestId('delete-api-key').click();

    // Assert that the confirmation modal is displayed and confirm.
    cy.contains('Deleting API key').should('be.visible').getByTestId('confirm-button').click();

    // Assert that the table is not displayed after the key has been deleted.
    cy.getByTestId('api-key-table').should('not.exist');

    // Assert that the snackbar is visible and displays the correct message.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .and('have.text', 'Your key has been deleted and can no longer be used.');
  });

  it('a user can rename api keys', function () {
    // Create an Enterprise license and an API key for the user
    // first and open the settings page.
    cy.createEnterpriseLicense(this.user).createApiKey(this.user).visit('/settings');

    // Click the "Rename key" button.
    cy.getByTestId('rename-api-key').click();

    // Assert that the view has changed and that the input has the correct
    // key as value and is focused. Clear it and enter a new name.
    cy.getByTestId('api-key-input')
      .should('be.visible')
      .and('have.focus')
      .and('have.value', 'Cypress')
      .clear()
      .type('Edited API key')
      .getByTestId('save-api-key')
      .click();

    // Assert that the table has updated.
    cy.getByTestId('api-key-table').find('tbody tr').should('have.length', 1).and('contain', 'Edited API key');
  });

  it('an organization admin can see a project list', function () {
    // Create a new project
    cy.createProject(this.user).then((project) => {
      // Open the settings page.
      cy.visit('/settings');

      // Assert that the button "View projects" is visible and click it.
      cy.getByTestId('view-projects').should('be.visible').and('have.text', 'View projects').click();

      // Assert that the proper overlay is visible.
      cy.getByTestId('dialog-title').should('be.visible').and('have.text', 'Projects in organization');

      // Assert that the Entity List contains 1 project.
      cy.getByTestId('entity-list').children().should('have.length', 1);

      // Assert that the project is the same that was created for this test.
      cy.getByTestId('entity-list').children().first().should('contain', project.name);

      // Join a new collaborator to the organization.
      cy.joinUserToOrganization(this.user).then((collaborator) => {
        // Make sure that the admin's organization is used.
        cy.window().then((win) => {
          win.localStorage.setItem('cawemo.org.last_used', this.user.organization.id);
        });

        // Log in as the collaborator.
        cy.login(collaborator);

        // Open the settings page.
        cy.visit('/settings');

        // Assert that the button "View projects" is not shown to organization members.
        cy.getByTestId('view-projects').should('not.exist');
      });
    });
  });

  it.saas('a user can leave an organization', function () {
    // "leave organization" not available for the organization owner
    cy.visit('/settings').getByTestId('leave-organization').should('not.exist');

    cy.joinUserToOrganization(this.user).then((collaborator) => {
      // make sure that the owner's organization is used and login as the collaborator
      cy.window().then((win) => {
        win.localStorage.setItem('cawemo.org.last_used', this.user.organization.id);
      });
      cy.login(collaborator);

      cy.visit('/settings').getByTestId('leave-organization').should('be.visible').click();

      cy.getByTestId('confirm-button').should('have.text', 'Leave organization').click();

      cy.getByTestId('snackbar').should('be.visible').and('have.text', 'You have left the organization.');

      cy.url().should('eq', getBaseUrl());

      cy.getByTestId('empty-state').should('be.visible');

      cy.removeUser(collaborator);
    });
  });

  it.saas('a user can create their own organization', function () {
    const user = getUser();

    // Create a new project for which an invitation can be created.
    cy.createProject(this.user).then((project) => {
      // Invite a user to the project.
      cy.createInvitation(user, project.id).as('invitation');

      // Log the organization admin out.
      cy.logout();

      // Open the invitation URL.
      cy.get('@invitation').then(cy.visit);

      // Click the "Register" button to join the project.
      cy.getByTestId('join-project-button').click();

      // Create a new user account through IAM.
      cy.getByTestId('name')
        .type(user.name)
        .getByTestId('email')
        .type(user.email)
        .getByTestId('new-password')
        .type(user.password)
        .getByTestId('submit')
        .click();

      // Open the settings page.
      cy.getByTestId('user-menu-button').click().getByTestId('settings-menu-item').click();

      // Assert that the "Create organization" card is visible and click the contained button.
      cy.getByTestId('create-organization').should('be.visible').and('have.text', 'Create organization').click();

      // Assert that the correct layover is displayed.
      cy.getByTestId('create-organization-title')
        .should('be.visible')
        .and('have.text', 'Create a Personal Organization');

      // Assert that the input has the correct placeholder.
      cy.getByTestId('organization-name')
        .should('have.focus')
        .and('have.attr', 'placeholder', `${user.name}'s Organization`);

      // Assert and click the "Create" button.
      cy.getByTestId('confirm-create-organization').should('have.text', 'Create').click();

      // Assert that the correct confirmation layover is displayed.
      cy.getByTestId('organization-created-title').should('be.visible').and('have.text', 'Organization Created!');

      // Close the layover.
      cy.getByTestId('close-layover').should('be.visible').and('have.text', 'Go to organization').click();

      // Assert that the user has been redirected to the homepage.
      cy.url().should('eq', getBaseUrl());

      // Assert that no projects are displayed.
      cy.getByTestId('empty-state').should('be.visible');

      // Open the user menu.
      cy.getByTestId('user-menu-button').click();

      // Assert that the new organization is displayed in the user menu and open the settings page.
      cy.getByTestId('user-organization')
        .should('be.visible')
        .and('contain', `${user.name}'s Organization`)
        .getByTestId('settings-menu-item')
        .click();

      // Assert that the new organization has been created and that the user can edit it.
      cy.getByTestId('organization-name').should('be.visible').and('have.value', `${user.name}'s Organization`);

      // Assert that the "Create organization" card is no longer visible.
      cy.getByTestId('create-organization').should('not.exist');

      // Open the homepage.
      cy.visit('/');

      // Assert that the organization switch is visible and open it.
      cy.getByTestId('organization-switch')
        .should('be.visible')
        .and('have.text', `${user.name}'s Organization`)
        .click();

      // Select the other organization.
      cy.getByTestId(`switch-${this.user.name}\'s Organization`).should('be.visible').click();

      // Assert that the related project is displayed.
      cy.getByTestId(`entity-${project.name}`).should('be.visible');
    });
  });
});
