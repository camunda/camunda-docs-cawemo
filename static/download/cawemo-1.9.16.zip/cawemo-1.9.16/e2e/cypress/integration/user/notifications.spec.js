import { getBaseUrl } from '../../helpers';

describe('Notifications', function () {
  beforeEach(function () {
    cy.prepareCollaboration().as('data');
    cy.deleteAllEmails();
  });

  afterEach(function () {
    cy.removeCollaboration(this.data);
  });

  it('a user receives notifications when mentioned', function () {
    // Visit the diagram page.
    cy.visit(`/diagrams/${this.data.diagram.id}`);

    // Open the sidebar and mention a user in a comment.
    cy.getByTestId('specification-toggle')
      .click()
      .getByTestId('comment-input')
      .find('textarea')
      .first()
      .type('@')
      .getByTestId('user-suggestions')
      .should('be.visible')
      .getByTestId(`collaborator-${this.data.user.name}`)
      .should('be.visible')
      .and('contain', this.data.user.name)
      .click()
      .getByTestId('comment-submit')
      .click();

    // Assert that the email has been sent.
    cy.getLinkFromEmail(this.data.user.email, 'mention').then((url) => {
      expect(url).to.contain(`diagrams/${this.data.diagram.id}`);
    });
  });

  it('a user can toggle notifications per project', function () {
    // Open the settings page.
    cy.visit('/settings');

    // Scroll to the notifications section.
    cy.getByTestId('manage-notifications').scrollIntoView();

    // Assert that the notifications section is visible.
    cy.contains('Notifications').should('be.visible');

    // Assert that the "Manage notifications" button is visible and click it.
    cy.getByTestId('manage-notifications').should('be.visible').and('have.text', 'Manage notifications').click();

    // Assert that the notifications dialog is visible and has the proper title.
    cy.getByTestId('notifications-dialog').should('be.visible').and('have.text', 'Notification settings');

    // Watch the route for unsubscribing a project.
    cy.intercept({
      method: 'DELETE',
      url: getBaseUrl('internal-api/subscriptions?*')
    }).as('unsubscribe');

    // Assert that a toggle for the project is visible and click it.
    cy.getByTestId(`notification-${this.data.project.name}`)
      .should('be.visible')
      .and('contain', this.data.project.name)
      .click();

    // Assert that a request to the BE has been made to unsubscribe from the project.
    cy.wait('@unsubscribe').then(({ response }) => {
      expect(response.statusCode).to.equal(204);
    });

    // Watch the route for subscribing a project.
    cy.intercept({
      method: 'PATCH',
      url: getBaseUrl('internal-api/subscriptions?*')
    }).as('subscribe');

    // Assert that a toggle "All projects" is visible and click it.
    cy.getByTestId('all-projects').should('be.visible').and('contain', 'All projects').click();

    // Assert that a request to the BE has been made to subscribe to the project.
    cy.wait('@subscribe').then(({ response }) => {
      expect(response.statusCode).to.equal(204);
    });
  });
});
