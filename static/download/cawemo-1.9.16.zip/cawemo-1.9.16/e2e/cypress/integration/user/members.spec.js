import { getBaseUrl, getNameFor, getEmail, getUser, isEnterprise } from '../../helpers';
import { ADMIN_USER, ADMIN_ORGANIZATION } from '../../../scripts/prepare/fixtures';

describe('Organization members', function () {
  beforeEach(function () {
    if (isEnterprise()) {
      cy.removeAllUsers();

      const admin = ADMIN_USER;
      admin.organization = ADMIN_ORGANIZATION;

      cy.login(admin)
        .createProject(admin)
        .then((project) => {
          cy.createUser().then((user) => {
            cy.task('db.createProjectPermission', { project, user });
            this.data = {
              owner: admin,
              project,
              user
            };
          });
        });

      cy.deleteAllEmails();
    } else {
      cy.prepareCollaboration().as('data');
    }

    // Make sure that the owner's organization is used.
    cy.window().then((win) => {
      win.localStorage.setItem('cawemo.org.last_used', this.data.owner.organization.id);
    });
  });

  afterEach(function () {
    if (isEnterprise()) {
      cy.removeUser(this.data.user);
      cy.removeAllProjects();
      cy.task('db.removeSignUpTokens');

      // recreate admin due to permission downgrade
      cy.removeUser(this.data.owner);
      cy.createAdminUserEnterprise(ADMIN_ORGANIZATION, ADMIN_USER);
    } else {
      cy.removeCollaboration(this.data);
    }
  });

  it('only the organization admin can access the members page', function () {
    // Open the settings page.
    cy.visit('/settings');

    // Assert that the button "Manage members" is visible and click it.
    cy.getByTestId('manage-members').should('be.visible').and('have.text', 'Manage members').click();

    // Assert that the correct URL is loaded.
    cy.url().should('contain', '/settings/members');

    // Assert that the Entity List has the correct title.
    cy.getByTestId('entity-title').should('be.visible').and('have.text', 'Organization members');

    // Assert that the first entry in the entity list is the admin.
    cy.getByTestId('entity-list')
      .children()
      .first()
      .should('contain', 'You')
      .and('contain', this.data.owner.email)
      .and('contain', '1 project')
      .click();

    // Assert that the admin can't be opened.
    cy.get('[role="dialog"]').should('not.exist');

    // Assert that the last entry in the entity list is the collaborator.
    cy.getByTestId(`entity-${this.data.user.name}`)
      .should('contain', this.data.user.name)
      .and('contain', this.data.user.email)
      .and('contain', '1 project')
      .click();

    // Assert that the member can be opened.
    cy.get('[role="dialog"]').should('be.visible');

    // Log in as the collaborator.
    cy.login(this.data.user).visit('/settings');

    // Assert that the button "Manage members" is not visible.
    cy.getByTestId('manage-members').should('not.exist');

    // Manually open the member management.
    cy.visit('/settings/members');

    // Assert that the user has been redirected to the settings page.
    cy.url().should('eq', getBaseUrl('settings'));

    // Assert that the Entity List title is not visible.
    cy.getByTestId('entity-title').should('not.exist');
  });

  it('a member can be removed from an organization', function () {
    // Open the members page.
    cy.visit('/settings/members');

    // Open the only member.
    cy.getByTestId('entity-list').children().last().click();

    // Assert that the button "Manage collaborator" is visible and click it.
    cy.getByTestId('manage-collaborator').should('be.visible').and('have.text', 'Manage collaborator').click();

    // Assert that the button "Remove from organization" is visible and click it.
    cy.getByTestId('remove-from-organization')
      .should('be.visible')
      .and('have.text', 'Remove from organization')
      .click();

    // Assert that the confirmation dialog has the correct title.
    cy.getByTestId('dialog-title').should('be.visible').and('have.text', 'Remove collaborator from your organization');

    // Click the confirm button.
    cy.getByTestId('confirm-button').should('be.visible').click();

    // Assert that the proper snackbar is visible.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .and('have.text', `${this.data.user.name} has been removed from your organization.`);

    // Assert that the member has been removed from the Entity List.
    cy.getByTestId('entity-list').children().should('have.length', 1);

    // Only on SaaS will a new organization be created for the user.
    if (!isEnterprise()) {
      // Log in as the collaborator.
      cy.login(this.data.user).visit('settings');

      // Assert that the collaborator is within its own organization.
      cy.getByTestId('organization-name').should('have.value', `${this.data.user.name}'s Organization`);

      // Assert that the button "Manage members" is visible.
      cy.getByTestId('manage-members').should('be.visible');
    }
  });

  it('a member can be removed from a project', function () {
    const project = getNameFor('project');

    // Log in as the collaborator.
    cy.login(this.data.user).visit('/');

    cy.intercept({
      method: 'PATCH',
      url: getBaseUrl(`internal-api/projects/**/*`)
    }).as('saving');

    // Since On-Premise always has both options, we need to open the dropdown first.
    if (isEnterprise()) {
      cy.getByTestId('project-dropdown').click();
    }

    cy.getByTestId('create-project')
      .click()
      .getByTestId('editable-input')
      .wait(100)
      .type(project + '{enter}');

    // Wait for the project to be saved.
    cy.wait('@saving');

    // Log in as the admin and open the settings page.
    cy.login(this.data.owner).visit('/settings/members');

    // Open the only member.
    cy.getByTestId(`entity-${this.data.user.name}`).click();

    // Assert that the admin can't open the dropdown of the member's own project.
    cy.getByTestId(`entity-${project}`)
      .should('be.visible')
      .find('[data-test="entity-context-dropdown"]')
      .should('not.exist');

    // Assert that the admin can open the dropdown of its own project.
    cy.getByTestId(`entity-${this.data.project.name}`)
      .should('be.visible')
      .find('[data-test="entity-context-dropdown"]')
      .should('exist')
      .click({ force: true });

    // Assert that the option "Remove from project" is visible and click it.
    cy.getByTestId('remove-from-project').should('be.visible').and('have.text', 'Remove from project').click();

    // Assert that the confirmation dialog is visible and confirm.
    cy.getByTestId('dialog-title').should('be.visible').getByTestId('confirm-button').click();

    // Assert that the proper snackbar is visible.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .and('have.text', `${this.data.user.name} has been removed from this project.`);

    // Assert that the project is no longer part of the list.
    cy.getByTestId(`entity-${this.data.project.name}`).should('not.exist');

    // Log in as the collaborator.
    cy.login(this.data.user).visit('/');

    // Assert that the member only sees its own project.
    cy.getByTestId('entity-list')
      .children()
      .should('have.length', 1)
      .getByTestId(`entity-${this.data.project.name}`)
      .should('not.exist');
  });

  it("a member's permission can be changed", function () {
    // Increase the viewport.
    cy.viewport(1280, 720);

    // Open the members page.
    cy.visit('/settings/members');

    // Open the only member.
    cy.getByTestId(`entity-${this.data.user.name}`).click();

    // Open the "Manage collaborator" dropdown.
    cy.getByTestId('manage-collaborator').click();

    // Change the collaborator's permission to admin.
    cy.getByTestId('change-permission-admin').should('have.text', 'Organization Admin').click({ force: true });

    // Assert that the proper snackbar is visible.
    cy.getByTestId('snackbar').should('be.visible').and('have.text', 'Collaborator permissions have been updated.');

    // Close the layover.
    cy.get('body').trigger('keydown', { key: 'Escape' });

    // Assert that collaborator's the permission has been updated in the Entity List.
    cy.getByTestId(`entity-${this.data.user.name}`).should('contain', 'Organization Admin');

    // Log in as the collaborator and open the members page.
    cy.login(this.data.user).visit('/settings/members');

    // Assert that the collaborator could open the page.
    cy.url().should('include', '/settings/members');

    // Assert that all collaborator data has been loaded.
    cy.getByTestId('entity-list').children().should('have.length', 2);

    // Open the original organization admin.
    cy.getByTestId(`entity-${this.data.owner.name}`).click();

    // Open the "Manage collaborator" dropdown.
    cy.getByTestId('manage-collaborator').should('be.visible').click();

    // Change the original admin's permission to user.
    cy.getByTestId('change-permission-user').should('have.text', 'Collaborator').click({ force: true });

    // Assert that the proper snackbar is visible.
    cy.getByTestId('snackbar').should('be.visible').and('have.text', 'Collaborator permissions have been updated.');
  });

  it("a member's project permission can be changed", function () {
    // Open the members page.
    cy.visit('/settings/members');

    // Open the only member.
    cy.getByTestId(`entity-${this.data.user.name}`).click();

    // Assert that the admin can open the dropdown of its own project.
    cy.getByTestId(`entity-${this.data.project.name}`)
      .should('be.visible')
      .find('[data-test="entity-context-dropdown"]')
      .should('exist')
      .click({ force: true });

    // Assert that the option "Remove from project" is visible and click it.
    cy.getByTestId('READ-permission').should('exist').and('have.text', 'Viewer').click({ force: true });

    // Assert that the proper snackbar is visible.
    cy.getByTestId('snackbar').should('be.visible').and('have.text', 'Collaborator permissions have been updated.');

    // Assert that the permission has been updated in the Entity List.
    cy.getByTestId(`entity-${this.data.project.name}`).should('contain', 'Viewer');

    // Log in as the collaborator.
    cy.login(this.data.user).visit('/');

    // Open the project
    cy.getByTestId(`entity-${this.data.project.name}`).click();

    // Assert that the collaborator has read-only permissions.
    cy.getByTestId('diagram-dropdown').should('not.exist').getByTestId('collaborator-toggle').should('not.exist');
  });

  it('a member can be chosen as a project admin', function () {
    // Open the members page.
    cy.visit('/settings/members');

    // Open the only member.
    cy.getByTestId(`entity-${this.data.user.name}`).click();

    // Open the project's dropdown menu.
    cy.getByTestId(`entity-${this.data.project.name}`)
      .find('[data-test="entity-context-dropdown"]')
      .click({ force: true });

    // Assert that the "Admin" entry is present in the roles dropdown and click it.
    cy.getByTestId('OWNER-permission').should('exist').and('have.text', 'Project Admin').click({ force: true });

    // Assert that the proper snackbar is visible.
    cy.getByTestId('snackbar').should('be.visible').and('have.text', 'Collaborator permissions have been updated.');

    // Assert that the permission has been updated in the Entity List.
    cy.getByTestId(`entity-${this.data.project.name}`).should('contain', 'Project Admin');

    // Log in as the collaborator.
    cy.login(this.data.user).visit('/');

    // Open the project
    cy.getByTestId(`entity-${this.data.project.name}`).click();

    // Assert that the collaborator has admin permissions.
    cy.getByTestId('diagram-dropdown')
      .should('be.visible')
      .getByTestId('collaborator-toggle')
      .should('be.visible')
      .getByTestId('add-collaborator')
      .should('be.visible')
      .getByTestId('breadcrumb-project-menu')
      .click()
      .getByTestId('rename-project')
      .should('be.visible')
      .getByTestId('delete-project')
      .should('be.visible');
  });

  it.enterprise.ldap.saas('a project invitation can be removed from an organization', function () {
    const newUser = getUser();
    cy.createInvitation(newUser, this.data.project.id);

    // Open the members page.
    cy.visit('/settings/members');

    // Open the only member.
    cy.getByTestId(`entity-${newUser.email}`).click();

    // Assert that the button "Remove from organization" is visible and click it.
    cy.getByTestId('remove-from-organization').should('be.visible').and('have.text', 'Remove collaborator').click();

    // Assert that the confirmation dialog has the correct title.
    cy.getByTestId('dialog-title').should('be.visible').and('have.text', 'Remove collaborator from your organization');

    // Click the confirm button.
    cy.getByTestId('confirm-button').should('be.visible').click();

    // Assert that the proper snackbar is visible.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .and('have.text', `${newUser.email} has been removed from your organization.`);

    // Assert that the project invitation has been removed from the Entity List.
    cy.getByTestId('entity-list').children().should('have.length', 2);
  });

  it.enterprise.ldap.saas('an invitation to only one project is removed from the organization', function () {
    const newUser = getUser();
    cy.createInvitation(newUser, this.data.project.id);

    // Open the members page.
    cy.visit('/settings/members');

    cy.getByTestId(`entity-${newUser.email}`).click();

    // Assert that the admin can open the dropdown of its own project.
    cy.getByTestId(`entity-${this.data.project.name}`)
      .should('be.visible')
      .find('[data-test="entity-context-dropdown"]')
      .should('exist')
      .click({ force: true });

    // Assert that the option "Remove from project" is visible and click it.
    cy.getByTestId('remove-from-project').should('be.visible').and('have.text', 'Remove from project').click();

    // Assert that the confirmation dialog is visible and confirm.
    cy.getByTestId('dialog-title')
      .should('be.visible')
      .and('have.text', 'Remove invitation')
      .getByTestId('confirm-button')
      .click();

    // Assert that the proper snackbar is visible.
    cy.getByTestId('snackbar')
      .should('be.visible')
      .and('have.text', `${newUser.email} has been removed from your organization.`);

    // Assert that the project is no longer part of the list.
    cy.getByTestId(`entity-${this.data.project.name}`).should('not.exist');
  });

  it.enterprise.ldap.saas('an invitation can be removed from a project', function () {
    cy.createProject(this.data.owner).then((project) => {
      const newUser = getUser();
      cy.createInvitation(newUser, this.data.project.id);
      cy.createInvitation(newUser, project.id);

      // Open the members page.
      cy.visit('/settings/members');

      cy.getByTestId(`entity-${newUser.email}`).click();

      // Assert that the admin can open the dropdown of its own project.
      cy.getByTestId(`entity-${this.data.project.name}`)
        .should('be.visible')
        .find('[data-test="entity-context-dropdown"]')
        .should('exist')
        .click({ force: true });

      // Assert that the option "Remove from project" is visible and click it.
      cy.getByTestId('remove-from-project').should('be.visible').and('have.text', 'Remove from project').click();

      // Assert that the confirmation dialog is visible and confirm.
      cy.getByTestId('dialog-title')
        .should('be.visible')
        .and('have.text', 'Remove invitation')
        .getByTestId('confirm-button')
        .click();

      // Assert that the proper snackbar is visible.
      cy.getByTestId('snackbar')
        .should('be.visible')
        .and('have.text', `${newUser.email} has been removed from this project.`);

      // Assert that the project is no longer part of the list.
      cy.getByTestId(`entity-${this.data.project.name}`).should('not.exist');
    });
  });

  it.enterprise.ldap.saas("an invitation's permission can be changed", function () {
    const newUser = getUser();
    cy.createInvitation(newUser, this.data.project.id);

    // Open the members page.
    cy.visit('/settings/members');

    // Open the project invitation.
    cy.getByTestId(`entity-${newUser.email}`).click();

    // Assert that the admin can open the dropdown of their own project.
    cy.getByTestId(`entity-${this.data.project.name}`)
      .should('be.visible')
      .find('[data-test="entity-context-dropdown"]')
      .should('exist')
      .click({ force: true });

    // Assert that the option "Remove from project" is visible and click it.
    cy.getByTestId('READ-permission').should('exist').and('have.text', 'Viewer').click({ force: true });

    // Assert that the proper snackbar is visible.
    cy.getByTestId('snackbar').should('be.visible').and('have.text', 'Collaborator permissions have been updated.');

    // Assert that the permission has been updated in the Entity List.
    cy.getByTestId(`entity-${this.data.project.name}`).should('contain', 'Viewer');
  });

  it.enterprise.default('a new member can be invited via email', function () {
    const user = getUser();

    // Open the members page.
    cy.visit('/settings/members');

    // Assert that the button "Invite members" is visible and click it.
    cy.getByTestId('invite-members').should('be.visible').and('have.text', 'Invite members').click();

    // Assert that the proper dialog is visible.
    cy.getByTestId('invite-title')
      .should('be.visible')
      .and('have.text', `Invite members to "${this.data.owner.name}'s Organization"`);

    // Assert that the submit button is disabled and has the proper text.
    cy.getByTestId('send-invites').should('be.disabled').and('have.text', 'Send invites');

    // Write the first email into the input.
    cy.getByTestId('email-input').type(user.email + '{enter}');

    // Assert that 2 chips are visible.
    cy.getByTestId('chip').should('have.length', 1);

    // Assert that the submit button has updated.
    cy.getByTestId('send-invites').should('not.be.disabled').and('have.text', 'Send invite').click();

    // Assert that the proper snackbar is visible.
    cy.getByTestId('snackbar').should('be.visible').and('have.text', 'Invitation has successfully been sent.');

    // Await the invitation email.
    cy.getLinkFromEmail(user.email, 'signup-invite').as('invitation');

    // Assert that the invitation email has arrived and visit its URL.
    cy.get('@invitation')
      .should('include', 'signup?token=')
      .then((url) => {
        cy.request({ url }).its('status').should('eq', 200);
      });
  });

  it.enterprise.default('an invitation can be cancelled', function () {
    const email = getEmail();

    // Open the members page.
    cy.visit('/settings/members');

    // Assert that the button "Invite members" is visible and click it.
    cy.getByTestId('invite-members').click();

    // Write the first email into the input.
    cy.getByTestId('email-input').type(email + '{enter}');

    cy.getByTestId('send-invites').click();

    cy.getLinkFromEmail(email, 'signup-invite').as('invitation');

    cy.getByTestId('entity-list').children().last().click();

    cy.getByTestId('cancel-invitation').should('be.visible').and('have.text', 'Cancel invitation').click();

    cy.getByTestId('dialog-title').should('be.visible').and('have.text', 'Cancel Invitation');

    cy.getByTestId('confirm-button').click();

    cy.getByTestId('snackbar').should('be.visible').and('have.text', 'Invitation has been canceled.');

    cy.get('@invitation')
      .should('include', 'signup?token=')
      .then((url) => {
        cy.request({ url, failOnStatusCode: false }).its('status').should('eq', 404);
      });
  });

  it.enterprise.default('an invitation can be resent', function () {
    const email = getEmail();

    // Open the members page.
    cy.visit('/settings/members');

    // Assert that the button "Invite members" is visible and click it.
    cy.getByTestId('invite-members').click();

    // Write the first email into the input.
    cy.getByTestId('email-input')
      .type(email + '{enter}')
      .getByTestId('send-invites')
      .click()
      .wait(500);

    cy.getByTestId('entity-list').children().last().click();

    cy.getByTestId('resend-invitation').should('be.visible').and('have.text', 'Resend invitation').click();

    cy.getByTestId('snackbar').should('be.visible').and('have.text', 'Invitation has successfully been resent.');

    cy.getLinkFromEmail(email, 'signup-invite').as('invitation');

    cy.get('@invitation')
      .should('include', 'signup?token=')
      .then((url) => {
        cy.request({ url }).its('status').should('eq', 200);
      });
  });
});
