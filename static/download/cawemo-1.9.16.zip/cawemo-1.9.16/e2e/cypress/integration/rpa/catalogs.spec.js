import { getNameFor, getBaseUrl, isEnterprise } from '../../helpers';

describe('RPA catalogs', function () {
  context('Catalogs - General', function () {
    beforeEach(function () {
      cy.createUserAndLogin().as('user');
    });

    afterEach(function () {
      cy.removeUser(this.user);
      cy.removeAllProjectsIfEnterprise();
    });

    it('a user with a valid license can create a new catalog', function () {
      const name = getNameFor('catalog');

      cy.visit('/');

      if (!isEnterprise()) {
        // Assert that without a license, the user can only create BPMN projects.
        cy.getByTestId('create-project').should('be.visible').getByTestId('project-dropdown').should('not.exist');

        // Create an enterprise license for the user to enable RPA.
        cy.createEnterpriseLicense(this.user).reload();
      }

      // Create a new template catalog using the dropdown.
      cy.getByTestId('project-dropdown')
        .should('be.visible')
        .click()
        .getByTestId('create-project')
        .should('be.visible')
        .and('have.text', 'New project')
        .next()
        .should('have.text', 'New catalog')
        .click();

      // Assert that the user has been redirected to the catalog page.
      cy.url().should('include', 'projects');

      // Provide a new catalog name.
      cy.getByTestId('editable-input')
        .should('have.value', 'New Catalog')
        .wait(100)
        .type(name + '{enter}')
        .getByTestId('breadcrumb-project-menu')
        .should('have.text', name);

      // Assert that the page title is "Templates".
      cy.getByTestId('project-name').should('be.visible').and('have.text', name);
    });

    it("a catalog doesn't contain the sidebar and appropriate buttons", function () {
      cy.createEnterpriseLicense(this.user);

      // Create a new catalog and open it.
      cy.createProject(this.user, 'CATALOG').then((catalog) => {
        cy.visit(`/projects/${catalog.id}`);

        // Assert that the action buttons are visible and contain the correct text.
        cy.getByTestId('diagram-dropdown').should('be.visible').and('have.text', 'New').click();

        // Assert that the button label is correct.
        cy.getByTestId('create-service-task-template').should('be.visible').and('have.text', 'Service Task Template');

        cy.getByTestId('create-generic-template')
          .should('have.text', 'Generic JSON Template')
          .next()
          .should('have.text', 'Upload files');

        // Assert that the collaborator sidebar doesn't exist.
        cy.getByTestId('collaborator-toggle').should('not.exist');
      });
    });
  });

  context('Catalogs - Owner/Admin', function () {
    beforeEach(function () {
      cy.createUserAndLogin().as('user');
    });

    afterEach(function () {
      cy.removeUser(this.user);
      cy.removeAllProjectsIfEnterprise();
    });

    it('a user with a valid license can rename a catalog he created', function () {
      cy.createProject(this.user, 'CATALOG').then((catalog) => {
        cy.visit(`/projects/${catalog.id}`);

        if (!isEnterprise()) {
          // Assert that the user cannot rename a catalog without a valid license
          cy.openBreadcrumbMenu(catalog.name);
          cy.assertNoRenameOptionInMenu();

          cy.createEnterpriseLicense(this.user).reload();
        }
        cy.openBreadcrumbMenu(catalog.name);
        const newName = getNameFor('catalog');
        cy.assertRenamingProjectIsPossibleUsingBreadcrumbMenu(catalog.name, newName);
      });
    });

    it('a user can delete a catalog he created using breadcrumb menu', function () {
      cy.createProject(this.user, 'CATALOG').then((catalog) => {
        cy.visit(`/projects/${catalog.id}`);

        cy.openBreadcrumbMenu(catalog.name);
        cy.assertDeletingCatalogIsPossible(catalog.name);
      });
    });

    it('a user can delete a catalog he created using entity menu', function () {
      cy.createProject(this.user, 'CATALOG').then((catalog) => {
        cy.visit('/');

        cy.openEntityMenu(catalog.name);
        cy.assertDeletingProjectIsPossible(catalog.name); // In the home page, the button is 'Delete Project' instead of 'Delete Catalog'
      });
    });

    it('a user can delete from home page multiple catalogs he created', function () {
      cy.createEnterpriseLicense(this.user);
      cy.joinUserToOrganization(this.user).then((collaborator) => {
        // Create a new catalog (from the admin user).
        cy.createProject(this.user, 'CATALOG').then((catalog) => {
          // Login as the collaborator.
          cy.login(collaborator);

          cy.window().then((win) => {
            win.localStorage.setItem('cawemo.org.last_used', this.user.organization.id);
          });

          // Create multiple catalogs (from the collaborator).
          cy.createProject(collaborator, 'CATALOG').then((catalog2) => {
            cy.createProject(collaborator, 'CATALOG').then((catalog3) => {
              cy.visit('/');

              // Select the catalog not created by the collaborator.
              cy.toggleEntitySelection(catalog.name);

              // Assert that Delete option is disabled.
              cy.findByRole('button', { name: /1 item selected/i }).click();
              cy.findByRole('menuitem', { name: /delete/i }).should('exist');
              cy.findByRole('menuitem', { name: /delete/i }).should('have.css', 'pointer-events', 'none');
              cy.reload();

              if (!isEnterprise()) {
                // Switch to collaborator's organization.
                cy.findByText(`${this.user.name}'s Organization`).click();
                cy.findByText(`${collaborator.name}'s Organization`).click();
              }

              // Select the catalogs created by the collaborator.
              cy.toggleEntitySelection(catalog2.name);
              cy.toggleEntitySelection(catalog3.name);

              // Assert that Delete is possible.
              cy.findByRole('button', { name: /2 items selected/i }).click({ force: true });
              cy.findByRole('menuitem', { name: /delete/i }).click();
              cy.findByRole('button', { name: /delete projects/i }).click();
              cy.findByText(/projects have been deleted/i).should('exist');
            });
          });
        });

        cy.removeUser(collaborator);
      });
    });
  });

  context('Catalogs - Non-Owner/Non-Admin', function () {
    beforeEach(function () {
      cy.createUserAndLogin().as('user');
    });

    afterEach(function () {
      cy.removeUser(this.user);
      cy.removeAllProjectsIfEnterprise();
    });

    it('a user in the same organization has read-only access', function () {
      cy.createEnterpriseLicense(this.user);

      // Join a new user to the existing user's organization.
      cy.joinUserToOrganization(this.user).then((collaborator) => {
        // Create a new project (from the admin user).
        cy.createProject(this.user, 'CATALOG').then((catalog) => {
          // Login as the collaborator.
          cy.login(collaborator);

          cy.window().then((win) => {
            win.localStorage.setItem('cawemo.org.last_used', this.user.organization.id);
          });

          cy.visit('/');
          cy.assertEntityPresent(catalog.name, 'CATALOG');
          cy.assertNoEntityMenuPresent(catalog.name);
          cy.getByTestId(`entity-${catalog.name}`).click();
          cy.assertNoBreadcrumbMenuPresent(catalog.name);
          cy.assertNoActionButtonPresentInProjectPage();

          cy.removeUser(collaborator);
        });
      });
    });
  });
});
