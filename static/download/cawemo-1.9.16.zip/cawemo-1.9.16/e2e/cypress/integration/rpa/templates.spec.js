import { getBaseUrl, getNameFor, isEnterprise } from '../../helpers';
import downloadDiagram from '../../utils/download-diagram';

const TEMPLATES_EMPTY_STATE_TEXT = "This catalog doesn't have any templates yet.";
const REPLACE_CONFIRM_TEXT = `Uploading this file will replace the current template and you won't be able to restore it. Do you want to continue?`;
const REPLACE_CONFIRM_BUTTON = `Yes, replace this template`;
const REPLACE_SUCCESS_TEXT = `"generic-template.json" is being uploaded to replace this template.`;
const UPLOADED_TEMPLATE_NAME = 'Generic Template';
const INVALID_UPLOAD_TYPE_MESSAGE = /the following 1 file is invalid/i;

describe('RPA templates', function () {
  beforeEach(function () {
    // Create a new user and catalog.
    cy.createUserAndLogin()
      .as('user')
      .then((user) => {
        cy.createProject(user, 'CATALOG').as('catalog');
      });

    cy.window().then((win) => {
      win.localStorage.setItem('cawemo.collaborator_sidebar_visible', 'false');
    });
  });

  afterEach(function () {
    cy.removeUser(this.user);
    cy.removeAllProjectsIfEnterprise();
  });

  it('a user with a valid license can create a new service task template', function () {
    cy.visit(`/projects/${this.catalog.id}`);

    if (!isEnterprise()) {
      // Assert that, without a license, a user can't create any new templates.
      cy.getByTestId('diagram-dropdown').should('not.exist');

      cy.createEnterpriseLicense(this.user).reload();
    }

    // Open the project and click the "Create template" button
    cy.getByTestId('diagram-dropdown').should('be.visible').and('have.text', 'New').click();

    // Create a new service task label.
    cy.getByTestId('create-service-task-template').click();

    // Assert that the template has been loaded and that the form instead
    // of the code editor is visible.
    cy.url()
      .should('include', 'templates')
      .getByTestId('json-editor')
      .should('not.exist')
      .getByTestId('form-editor')
      .should('be.visible');

    // Wait for the template to load.
    cy.getByTestId('autosave').should('contain', 'Autosaved');

    // Assert that the catalog exists in the breadcrumbs and click it.
    cy.getByTestId('breadcrumb-project').should('exist').click();

    // Assert that the template is listed as a tile.
    cy.getByTestId('entity-New Service Task Template')
      .should('exist')
      .and('have.length', 1)
      .and('contain', 'New Service Task Template');
  });

  it('a user can create a new generic template', function () {
    cy.createEnterpriseLicense(this.user);

    cy.visit(`/projects/${this.catalog.id}`);

    // Open the project and click the "New generic JSON template" button
    cy.getByTestId('diagram-dropdown').should('be.visible').click().getByTestId('create-generic-template').click();

    // Assert that the template has been loaded and that the code editor instead
    // of the form is visible.
    cy.url()
      .should('include', 'templates')
      .getByTestId('form-editor')
      .should('not.exist')
      .getByTestId('json-editor')
      .should('be.visible');

    // Wait for the editor to load.
    cy.waitForEditor();

    // Go back to the catalog page.
    cy.go('back');

    // Assert that the template is listed as a tile.
    cy.getByTestId('entity-New Generic Template')
      .should('exist')
      .and('have.length', 1)
      .and('contain', 'New Generic Template')
      .and('contain', 'Generic JSON');
  });

  it('a user (with right permissions) can upload templates', function () {
    cy.createEnterpriseLicense(this.user);
    cy.visit(`/projects/${this.catalog.id}`);
    cy.findByText(TEMPLATES_EMPTY_STATE_TEXT).should('exist');

    /**
     * Admin */
    // Can upload using button
    assertUploadIsPossibleUsingButton();

    // Can upload using drag'n'drop
    cy.removeAllFiles(this.catalog.id);
    cy.visit(`/projects/${this.catalog.id}`);
    cy.findByText(TEMPLATES_EMPTY_STATE_TEXT).should('exist');
    assertUploadIsPossibleUsingDragNDrop();

    /**
     * Other members */
    // Cannot upload using drag'n'drop
    cy.removeAllFiles(this.catalog.id);
    changeUserPermissionAndVisitCatalogPage(this.user, this.catalog, 'READ');
    cy.findByText(TEMPLATES_EMPTY_STATE_TEXT).should('exist');
    cy.assertUploadIsNotPossibleUsingDragNDrop();

    // Cannot upload using button
    cy.removeAllFiles(this.catalog.id);
    changeUserPermissionAndVisitCatalogPage(this.user, this.catalog, 'READ');
    cy.findByText(TEMPLATES_EMPTY_STATE_TEXT).should('exist'); // Wait till page load
    cy.assertNoActionButtonPresentInProjectPage();
  });

  it('a user (with right permissions) can replace a template', function () {
    cy.createEnterpriseLicense(this.user);
    cy.createTemplate(this.catalog).then((template) => {
      cy.visit(`/templates/${template.id}`);
      waitForTemplateToLoad(template.name);

      // Admin
      assertReplaceIsPossibleUsingDragNDrop();
      assertReplaceIsPossibleUsingBreadcrumb(UPLOADED_TEMPLATE_NAME);

      // Other members
      changeUserPermissionAndVisitTemplatePage(this.user, this.catalog, template, 'READ');
      waitForTemplateToLoad(UPLOADED_TEMPLATE_NAME);
      cy.assertUploadIsNotPossibleUsingDragNDrop();
      cy.assertNoBreadcrumbMenuPresent(UPLOADED_TEMPLATE_NAME);
    });
  });

  it('template uploads are validated', function () {
    cy.createEnterpriseLicense(this.user);
    cy.visit(`/projects/${this.catalog.id}`);
    cy.findByText(TEMPLATES_EMPTY_STATE_TEXT).should('exist');

    cy.getByTestId('drop-target').attachFile('diagrams/process-id-one.bpmn', { subjectType: 'drag-n-drop' });
    cy.findByText(INVALID_UPLOAD_TYPE_MESSAGE).should('exist');
    cy.reload();

    cy.getByTestId('drop-target').attachFile('diagrams/process-id-one.png', { subjectType: 'drag-n-drop' });
    cy.findByText(INVALID_UPLOAD_TYPE_MESSAGE).should('exist');
    cy.reload();

    cy.getByTestId('drop-target').attachFile('diagrams/process-id-one.svg', { subjectType: 'drag-n-drop' });
    cy.findByText(INVALID_UPLOAD_TYPE_MESSAGE).should('exist');
  });

  it('a user with a valid license can rename a template', function () {
    const name = getNameFor('template');

    // Create a new template and open it.
    cy.createTemplate(this.catalog).then((template) => {
      cy.visit(`/templates/${template.id}`);

      if (!isEnterprise()) {
        // Assert that, without a license, the user can't edit the name.
        cy.getByTestId('breadcrumb-template')
          .should('have.prop', 'tagName', 'BUTTON')
          .click()
          .getByTestId('rename-template')
          .should('not.exist');

        cy.createEnterpriseLicense(this.user).reload();
      }

      // Open the template menu in the breadcrumbs, find the "Edit name"
      // option and click it.
      cy.getByTestId('breadcrumb-template')
        .should('have.prop', 'tagName', 'BUTTON')
        .click()
        .getByTestId('rename-template')
        .should('be.visible')
        .and('have.text', 'Edit name')
        .click();

      cy.intercept({
        url: getBaseUrl(`internal-api/files/${template.id}**`),
        method: 'PATCH'
      }).as('renameTemplate');

      // Type the new name in the input and confirm.
      cy.getByTestId('editable-input').type(name + '{enter}');

      cy.wait('@renameTemplate');

      // Assert that the new name has been set in the breadcrumbs.
      cy.getByTestId('breadcrumb-template').should('have.text', name);

      // Reload the page and assert that the new name still perists.
      cy.reload().getByTestId('breadcrumb-template').should('have.text', name);

      // Wait for the editor to load.
      cy.waitForEditor();
    });
  });

  it('a user can delete a template from the template page', function () {
    // Create a new template and open it.
    cy.createTemplate(this.catalog).then((template) => {
      cy.visit(`/templates/${template.id}`);

      // Wait for the editor to load.
      cy.waitForEditor();

      // Open the template menu in the breadcrumbs, find the "Delete"
      // option and click it.
      cy.getByTestId('breadcrumb-template')
        .should('have.prop', 'tagName', 'BUTTON')
        .click()
        .getByTestId('delete-template')
        .should('have.text', 'Delete')
        .click();

      // Assert that the confirmation modal is displayed and confirm.
      cy.contains('Deleting template')
        .should('be.visible')
        .getByTestId('confirm-button')
        .should('have.text', 'Delete template')
        .click();

      // Assert that the user has been redirected to the project page
      // and that the template is no longer visible.
      cy.url()
        .should('include', 'projects')
        .and('include', this.catalog.id)
        .getByTestId('empty-state')
        .should('be.visible');

      // Assert that the snackbar is visible.
      cy.getByTestId('snackbar').should('be.visible').and('have.text', 'Your template has been deleted.');
    });
  });

  it('a user can delete a template from the catalog page', function () {
    // Create a new template and open it.
    cy.createTemplate(this.catalog).then(() => {
      cy.visit(`/projects/${this.catalog.id}`);

      cy.getByTestId('entity-context-dropdown')
        .click({ force: true })
        .getByTestId('delete-diagram')
        .should('be.visible')
        .click();

      // Assert that the confirmation modal is displayed and confirm.
      cy.contains('Deleting 1 file')
        .should('be.visible')
        .getByTestId('confirm-button')
        .should('have.text', 'Delete')
        .click();

      // Assert that the snackbar is visible.
      cy.getByTestId('snackbar').should('be.visible').and('contain', 'Your data has been deleted.');

      // Assert that the template has been deleted.
      cy.getByTestId('entity-list').should('not.exist').getByTestId('empty-state').should('be.visible');
    });
  });

  it('a user with a valid license can duplicate a template from the template page', function () {
    // Create a new template and open it.
    cy.createTemplate(this.catalog).then((template) => {
      cy.visit(`/templates/${template.id}`);

      // Wait for the editor to load.
      cy.waitForEditor();

      if (!isEnterprise()) {
        // Assert that the user can't duplicate without a valid license.
        cy.getByTestId('breadcrumb-template')
          .should('have.prop', 'tagName', 'BUTTON')
          .click()
          .getByTestId('duplicate-template')
          .should('not.exist');

        cy.createEnterpriseLicense(this.user).reload();

        // Wait for the editor to load.
        cy.waitForEditor();
      }

      // Open the diagram menu in the breadcrumbs, find the "Duplicate"
      // option and click it.
      cy.getByTestId('breadcrumb-template')
        .should('have.prop', 'tagName', 'BUTTON')
        .click()
        .getByTestId('duplicate-template')
        .should('have.text', 'Duplicate')
        .click();

      // Assert that the new diagram has a "- Copy" appendix.
      cy.getByTestId('breadcrumb-template').should('have.text', template.name + ' - Copy');

      // Assert that the snackbar is visible.
      cy.getByTestId('snackbar').should('be.visible').and('contain', 'Your template has been duplicated.');

      cy.location().then((location) => {
        const duplicatedId = location.pathname.slice(11).split('--')[0];

        // When a template is duplicated, we expect that the ID and name
        // have been updated in the JSON and that the changes are saved.
        cy.contains(`"id": "${template.id}"`).should('not.exist');
        cy.contains(`"id": "${duplicatedId}"`).should('exist');
        cy.contains(`"name": "${template.name}"`).should('not.exist');
        cy.contains(`"name": "${template.name} - Copy"`).should('exist');
        cy.getByTestId('autosave').should('be.visible');
      });
    });
  });

  it('a user with a valid license can duplicate a template from the catalog page', function () {
    // Create a new template and open it.
    cy.createTemplate(this.catalog).then(() => {
      cy.visit(`/projects/${this.catalog.id}`);

      if (!isEnterprise()) {
        // Assert that, without a license, templates can't be duplicated.
        cy.getByTestId('entity-context-dropdown')
          .click({ force: true })
          .getByTestId('duplicate-diagram')
          .should('not.exist');

        cy.createEnterpriseLicense(this.user).reload();
      }

      // Duplicate a template.
      cy.getByTestId('entity-context-dropdown')
        .click({ force: true })
        .getByTestId('duplicate-diagram')
        .should('be.visible')
        .click();

      // Assert that the new diagram has a "- Copy" appendix.
      cy.getByTestId('entity-list').children().should('have.length', 2);
    });
  });

  it('the correct template controls and dropdown options are displayed', function () {
    // Create a new diagram and open it.
    cy.createTemplate(this.catalog).then((template) => {
      // Assert that the specification sidebar is not visible.
      cy.visit(`/templates/${template.id}`)
        .getByTestId('json-editor')
        .should('be.visible')
        .getByTestId('specification-toggle')
        .should('not.exist');

      // Wait for the editor to load.
      cy.waitForEditor();

      if (!isEnterprise()) {
        // Assert that only diagram deletion is possible without a license.
        cy.getByTestId('breadcrumb-template')
          .should('have.prop', 'tagName', 'BUTTON')
          .click()
          .getByTestId('delete-template')
          .should('be.visible')
          .get('[role="menu"]')
          .children()
          .should('have.length', 1);

        cy.createEnterpriseLicense(this.user).reload();

        // Wait for the editor to load.
        cy.waitForEditor();
      }

      // Assert that the all menu entries are displayed.
      cy.getByTestId('breadcrumb-template')
        .should('have.prop', 'tagName', 'BUTTON')
        .click()
        .get('[role="menu"]')
        .children()
        .should('have.length', 6);

      // Assert that the diagram help menu doesn't exist.
      cy.getByTestId('diagram-help-menu').should('not.exist');

      // Assert that only the diagram export menu doesn't exist.
      cy.getByTestId('export-menu').should('not.exist');

      // Assert that the JSON export and Guide button are visible.
      cy.getByTestId('export-json').should('be.visible').getByTestId('guide').should('be.visible');
    });
  });

  it('a user can export a template', function () {
    cy.prepareDownload();

    // Create a new template and open it.
    cy.createTemplate(this.catalog).then((template) => {
      cy.visit(`/templates/${template.id}`);

      // Wait for the editor to load.
      cy.waitForEditor();

      // Assert that only the JSON export is visible.
      cy.getByTestId('export-menu')
        .should('not.exist')
        .getByTestId('export-json')
        .should('be.visible')
        .and('have.attr', 'title', 'Download JSON')
        .click();

      // Download the JSON and expect it to contain a property value
      // of the actual template.
      cy.get('a[download]')
        .then(downloadDiagram)
        .then((json) => {
          expect(json).to.contain(`"name": "${template.name}"`);
        });
    });
  });

  it('a user can export multiple templates from the catalog page', function () {
    cy.prepareDownload();

    // Create a new template and open it.
    cy.createTemplate(this.catalog)
      .createTemplate(this.catalog)
      .then(() => {
        cy.visit(`/projects/${this.catalog.id}`);

        // Check both diagram's checkboxes.
        cy.getByTestId('entity-checkbox').click({ multiple: true, force: true });

        cy.getByTestId('entity-head-dropdown')
          .click()
          .getByTestId('download-files')
          .should('have.text', 'Download')
          .click();

        // Assert that the snackbar announcing the download preparation is visible.
        cy.getByTestId('snackbar').should('be.visible').and('contain', 'We are zipping your files. The download starts soon.');
      });
  });

  it('a user with a valid license can move a template into a new catalog', function () {
    const newTargetCatalog = getNameFor('catalog');

    // Create a new template and open it.
    cy.createTemplate(this.catalog).then((template) => {
      cy.visit(`/projects/${this.catalog.id}`);

      if (!isEnterprise()) {
        // Assert that, without a license, templates can't be moved.
        cy.getByTestId('entity-context-dropdown')
          .click({ force: true })
          .getByTestId('move-diagram-new-project')
          .should('not.exist');

        cy.createEnterpriseLicense(this.user).reload();
      }

      // Open the context menu of the template.
      cy.getByTestId('entity-context-dropdown').click({ force: true });

      // Assert that the "Move" entry exists and click it.
      cy.getByTestId('move-diagram').should('have.text', 'Move').click();

      cy.getByTestId('create-new-target').should('not.exist');

      // Go one level up to the organization root.
      cy.getByTestId('move-level-up').click();

      // Click the "Create new" button.
      cy.getByTestId('create-new-target').should('be.visible').and('have.attr', 'title', 'Create new').click();

      // Enter a new catalog name into the input.
      cy.getByTestId('target-name')
        .should('be.visible')
        .and('have.value', 'New Catalog')
        .type(newTargetCatalog)
        .getByTestId('submit')
        .click();

      // Click the "Confirm" button.
      cy.getByTestId('confirm-move').should('not.be.disabled').click();

      // Assert that the confirmation dialog is displayed and confirm.
      cy.getByTestId('dialog-title').should('have.text', 'Moving 1 file').getByTestId('confirm-button').click();

      // Assert that the snackbar is shown.
      cy.getByTestId('snackbar').should('be.visible').should('have.text', 'Your data has been moved.');

      // Assert that the moved template is inside the correct catalog.
      cy.getByTestId('breadcrumb-project-menu')
        .should('have.text', newTargetCatalog)
        .getByTestId('entity-list')
        .first()
        .find('li')
        .should('have.length', 1)
        .getByTestId(`entity-${template.name}`)
        .should('exist');
    });
  });

  it('a user with a valid license can move a template into an existing catalog', function () {
    cy.createEnterpriseLicense(this.user);

    cy.createProject(this.user).then((targetProject) => {
      cy.createProject(this.user, 'CATALOG').then((targetCatalog) => {
        // Create a new template and open it.
        cy.createTemplate(this.catalog).then((template) => {
          cy.visit(`/projects/${this.catalog.id}`);

          // Open the context menu of the template.
          cy.getByTestId('entity-context-dropdown').click({ force: true });

          // Assert that the "Move" entry exists and click it.
          cy.getByTestId('move-diagram').should('have.text', 'Move').click();

          // Assert that the move component has the correct title and body.
          cy.getByTestId('move-component-title')
            .should('have.text', this.catalog.name)
            .getByTestId('empty-message')
            .should('be.visible');

          // Go one level up to the organization root.
          cy.getByTestId('move-level-up').click();

          // Assert that the "Move" button is disabled.
          cy.getByTestId('confirm-move').should('be.disabled');

          // Assert that the target catalog exists and select it.
          cy.getByTestId(`item-${targetProject.name}`)
            .should('not.exist')
            .getByTestId(`item-${targetCatalog.name}`)
            .should('have.text', targetCatalog.name)
            .click();

          // Assert that the "Move" button is enabled and click it.
          cy.getByTestId('confirm-move').should('not.be.disabled').click();

          // Assert that the confirmation dialog is displayed and confirm.
          cy.getByTestId('dialog-title').should('have.text', 'Moving 1 file').getByTestId('confirm-button').click();

          // Assert that the snackbar is shown.
          cy.getByTestId('snackbar').should('be.visible').should('have.text', 'Your data has been moved.');

          // Assert that the template is shown inside the target catalog.
          cy.getByTestId('breadcrumb-project-menu')
            .should('have.text', targetCatalog.name)
            .getByTestId('entity-list')
            .first()
            .find('li')
            .should('have.length', 1)
            .getByTestId(`entity-${template.name}`)
            .should('exist');
        });
      });
    });
  });
});

const changeUserPermissionAndVisitCatalogPage = (user, project, permission) => {
  cy.updatePermissionAccess({ user, project, permission });
  cy.visit(`/projects/${project.id}`);
};

const changeUserPermissionAndVisitTemplatePage = (user, project, template, permission) => {
  cy.updatePermissionAccess({ user, project, permission });
  cy.visit(`/templates/${template.id}`);
};

const assertUploadIsPossibleUsingButton = () => {
  assertUploadIsPossible('button');
};

const assertUploadIsPossibleUsingDragNDrop = () => {
  assertUploadIsPossible('dragndrop');
};

const assertUploadIsPossible = (type = 'button') => {
  if (type === 'dragndrop') {
    cy.getByTestId('drop-target').attachFile('templates/generic-template.json', { subjectType: 'drag-n-drop' });
  } else if (type === 'button') {
    cy.findByText(/new/i).click();
    cy.get('[id="raised-button-file"]').attachFile('templates/generic-template.json');
  }
  cy.findByText(/"generic-template.json" is being uploaded to cawemo/i).should('exist');
  cy.assertEntityPresent('generic-template.json', 'TEMPLATE');
};

const waitForTemplateToLoad = (name) => {
  cy.get('.monaco-editor textarea')
    .should('exist')
    .get('.view-lines')
    .within(() => {
      cy.findByText(`"name"`).should('exist');
      cy.findByText(`"${name}"`).should('exist');
    });
};

const assertReplaceIsPossibleUsingDragNDrop = () => {
  assertReplaceIsPossible('dragndrop');
};

const assertReplaceIsPossibleUsingBreadcrumb = (diagramName) => {
  assertReplaceIsPossible('breadcrumb', diagramName);
};

const assertReplaceIsPossible = (type = 'breadcrumb', templateName) => {
  if (type === 'breadcrumb') {
    cy.openBreadcrumbMenu(templateName);
    cy.get('[id="raised-button-file"]').attachFile('templates/generic-template.json');
  } else if (type === 'dragndrop') {
    cy.getByTestId('drop-target').attachFile('templates/generic-template.json', { subjectType: 'drag-n-drop' });
  }
  cy.findByText(REPLACE_CONFIRM_TEXT).should('exist');
  cy.findByRole('button', { name: REPLACE_CONFIRM_BUTTON }).click();
  cy.findByText(REPLACE_SUCCESS_TEXT).should('exist');
  cy.findByText('Saving...').should('exist');
  cy.findByText(/autosaved at/i).should('exist');
};
