import { getBaseUrl, getNameFor } from '../../helpers';

describe('Milestones', function () {
  beforeEach(function () {
    // Create a new user, project and diagram.
    cy.createUserAndLogin().as('user').then(cy.createProject).as('project').then(cy.createDiagram).as('diagram');
  });

  afterEach(function () {
    cy.removeUser(this.user);
    cy.removeAllProjectsIfEnterprise();
  });

  it('a user can create milestones', function () {
    cy.visit(`/diagrams/${this.diagram.id}`);

    // Create a new task.
    cy.append('StartEvent_1', 'append-task', 'Task #1');

    // Create the first milestone.
    cy.getByTestId('breadcrumb-diagram')
      .click()
      .getByTestId('diagram-menu-item-create-milestone')
      .should('have.text', 'Create milestone')
      .click();

    // Assert that the publish dialog is visible.
    cy.getByTestId('dialog-title').should('be.visible').and('have.text', 'Create a new milestone');

    // Assert that the input has the right placeholder.
    cy.getByTestId('milestone-name').should('have.attr', 'placeholder', 'Untitled milestone 1');

    // Assert that the confirm button has the right text and click it.
    cy.getByTestId('confirm').should('have.text', 'Create').click();

    // Assert that the snackbar is visible.
    cy.getByTestId('snackbar').should('be.visible').and('have.text', 'New milestone added to history.');

    // Create another task.
    cy.append(null, 'append-task', 'Task #2');

    // Create the second milestone using the shortcut.
    cy.get('body').type('{shift}M');

    // Assert that the publish dialog is visible.
    cy.getByTestId('dialog-title').should('be.visible');

    // Assert that the input placeholder has the right text and update it's value.
    cy.getByTestId('milestone-name')
      .should('have.attr', 'placeholder', 'Untitled milestone 2')
      .type('Milestone 2{enter}');

    // Assert that the snackbar is visible.
    cy.getByTestId('snackbar').should('be.visible');

    // Create the end event.
    cy.append(null, 'end-event');

    // Open the milestone page.
    cy.getByTestId('breadcrumb-diagram')
      .click()
      .getByTestId('diagram-menu-item-show-history')
      .should('have.text', 'Show milestone history')
      .click()
      .url()
      .should('include', 'milestones');

    // Check the existing milestones.
    cy.getByTestId('milestone-list')
      .should('exist')
      .find('[data-test="milestone"]')
      .should('have.length', 3)
      .first()
      .should('contain', 'Latest version');

    // Check the latest version.
    cy.getBPMN('Event_').should('exist');

    // Check the second milestone.
    cy.getByTestId('milestone-list')
      .find('[data-test="milestone"]')
      .eq(1)
      .should('contain', 'Milestone 2')
      .click()
      .getBPMN('Event_')
      .should('not.exist')
      .getBPMN('Activity_')
      .should('have.length', 2);

    // Check the first milestone.
    cy.getByTestId('milestone-list')
      .find('[data-test="milestone"]')
      .last()
      .should('contain', 'Untitled milestone 1')
      .click()
      .getBPMN('Activity_')
      .should('have.length', 1);
  });

  it('a user can rename a milestone', function () {
    cy.createMilestone(this.diagram.id).visit(`/milestones/${this.diagram.id}`);

    // Open the milestone's menu.
    cy.getByTestId('milestone-menu-button')
      .click({ force: true })
      .getByTestId('milestone-menu-item-rename')
      .should('have.text', 'Edit name')
      .click();

    // Enter the new name.
    cy.getByTestId('editable-input').should('exist').type('Renamed milestone{enter}');

    // Check if renaming succeeded.
    cy.getByTestId('editable-text').should('have.text', 'Renamed milestone');
  });

  it('a user can delete a milestone', function () {
    cy.createMilestone(this.diagram.id).visit(`/milestones/${this.diagram.id}`);

    // Delete the first milestone.
    cy.getByTestId('milestone-list')
      .find('[data-test="milestone"]')
      .find('[data-test="milestone-menu-button"]')
      .click({ force: true })
      .getByTestId('milestone-menu-item-delete')
      .should('have.text', 'Delete')
      .click();

    // Assert that the confirmation modal is displayed.
    cy.contains('Delete milestone').should('be.visible').getByTestId('confirm-button').click();

    // Assert that the snackbar is displayed.
    cy.getByTestId('snackbar').should('be.visible').should('have.text', 'Milestone has been deleted.');

    cy.contains('Latest version').should('be.visible');
  });

  it('a user can restore a milestone', function () {
    cy.createMilestone(this.diagram.id, 'Milestone 1').visit(`/diagrams/${this.diagram.id}`);

    // Create a new task.
    cy.append('StartEvent_1', 'append-task', 'Task #1');

    // Create the second milestone and open the milestone page.
    cy.createMilestone(this.diagram.id, 'Milestone 2');

    // Create the end event and visit the milestone page.
    cy.append(null, 'end-event')
      .getByTestId('autosave')
      .should('be.visible')
      .and('contain', 'Autosaved')
      .visit(`/milestones/${this.diagram.id}`);

    // Restore the first milestone.
    cy.getByTestId('milestone')
      .last()
      .find('[data-test="milestone-menu-button"]')
      .click({ force: true })
      .getByTestId('milestone-menu-item-restore')
      .should('have.text', 'Restore as latest')
      .click();

    // Assert that the restoration succeeded.
    cy.getBPMN('StartEvent_').should('exist').getBPMN('Activity_').should('not.exist');

    // Assert that the `Restored` milestone has been created.
    cy.getByTestId('milestone').first().should('contain', '(restored)').getBPMN('Activity_').should('not.exist');

    // Assert that there are 4 milestones now.
    cy.getByTestId('milestone').should('have.length', 4);

    // Assert that the `Autosaved` milestone has been created.
    cy.getByTestId('milestone')
      .eq(1)
      .should('contain', 'Autosaved during restore')
      .click()
      .getBPMN('Activity_')
      .should('exist')
      .getBPMN('Event_')
      .should('exist');

    // Restore another milestone and assert that this time, no new
    // autosaved milestone has been created.
    cy.getByTestId('milestone')
      .eq(2)
      .find('[data-test="milestone-menu-button"]')
      .click({ force: true })
      .getByTestId('milestone-menu-item-restore')
      .click();

    // Assert that there are 5 milestones now.
    cy.getByTestId('milestone').should('have.length', 5);
  });

  it('a user can copy a milestone to a new project', function () {
    const newTargetProject = getNameFor('project');

    // Hide the collaborator sidebar on the project page.
    cy.window().then((win) => {
      win.localStorage.setItem('cawemo.collaborator_sidebar_visible', 'false');
    });

    // Open the diagram.
    cy.visit(`/diagrams/${this.diagram.id}`);

    // Create a new task.
    cy.append('StartEvent_1', 'append-task', 'Task #1');

    // Create a milestone and open the milestone page.
    cy.createMilestone(this.diagram.id).visit(`/milestones/${this.diagram.id}`);

    // Assert that the "Copy to..." entry is visible and click it.
    cy.getByTestId('milestone-menu-button')
      .click({ force: true })
      .getByTestId('milestone-menu-item-copy')
      .should('have.text', 'Copy to...')
      .click();

    // Move one level up to the organization root.
    cy.getByTestId('move-level-up').click();

    // Wait until the organization root is displayed.
    cy.getByTestId('move-component-title').should('contain', 'Organization');

    // Click the "Create new" button.
    cy.getByTestId('create-new-target').should('be.visible').and('have.attr', 'title', 'Create new').click();

    // Enter a new project name into the input.
    cy.getByTestId('target-name')
      .should('be.visible')
      .and('have.value', 'New Project')
      .type(newTargetProject)
      .getByTestId('submit')
      .click();

    // Click the "Confirm" button.
    cy.getByTestId('confirm-move').should('not.be.disabled').click();

    // Assert that the project page is opened.
    cy.url().should('include', '/projects/').getByTestId('project-name').should('have.text', newTargetProject);

    // Assert that the copied diagram is visible and open it.
    cy.getByTestId('entity-list')
      .children()
      .should('have.length', 1)
      .first()
      .should('contain', `${this.diagram.name} - Copy of Milestone`)
      .click();

    // Assert that the activity element exists.
    cy.getBPMN('Activity_').should('exist');
  });

  it("a user can't copy a milestone into a catalog or read-only project", function () {
    cy.createDiagram(this.project).then(() => {
      cy.visit(`/diagrams/${this.diagram.id}`);

      // Create a new task.
      cy.append('StartEvent_1', 'append-task', 'Task #1')
        .wait(200)
        .getByTestId('autosave')
        .should('be.visible')
        .and('contain', 'Autosaved');

      // Join a user to the organization (with a different project)
      // and create a new catalog
      cy.joinUserToOrganization(this.user).then((collaborator) => {
        cy.createProject(collaborator).then((differentProject) => {
          cy.createProject(this.user, 'CATALOG').then((catalog) => {
            // Create the milestone and open the milestone page.
            cy.createMilestone(this.diagram.id).visit(`/milestones/${this.diagram.id}`);

            // Assert that the catalog and other project isn't part of the list.
            cy.getByTestId('milestone-menu-button')
              .click({ force: true })
              .getByTestId('milestone-menu-item-copy')
              .click();

            cy.getByTestId('move-level-up').click();

            cy.getByTestId(`item-${catalog.name}`)
              .should('not.exist')
              .getByTestId(`item-${differentProject.name}`)
              .should('not.exist');
          });
        });
      });
    });
  });

  it('a user can copy a milestone to an existing project', function () {
    // Create the required license.
    cy.createEnterpriseLicense(this.user);

    // Create another diagram as call activity target.
    cy.createDiagram(this.project).then((diagram) => {
      // Open the diagram.
      cy.visit(`/diagrams/${this.diagram.id}`);

      // Create a new task and convert it to a Call Link Activity.
      cy.append('StartEvent_1', 'append-task', 'Task #1')
        .get('[data-action="replace"]')
        .click()
        .get('[data-id="replace-with-call-activity"]')
        .click();

      // Select the created diagram as call link.
      cy.getByTestId('call-activity-link-button')
        .click()
        .getByTestId(`item-${diagram.name}`)
        .should('have.text', diagram.name)
        .click();

      // Confirm the linking.
      cy.getByTestId('confirm-move').should('not.be.disabled').and('have.text', 'Link').click();

      // Wait for the diagram to save.
      cy.wait(200).getByTestId('autosave').should('be.visible').and('contain', 'Autosaved');

      // Create a milestone and open the milestone page.
      cy.createMilestone(this.diagram.id).visit(`/milestones/${this.diagram.id}`);

      // Click the "Copy to..." entry.
      cy.getByTestId('milestone-menu-button').click({ force: true }).getByTestId('milestone-menu-item-copy').click();

      // Assert that the user is currently on the project level.
      cy.getByTestId('move-component-title').should('have.text', this.project.name);

      // Click the "Copy" button.
      cy.getByTestId('confirm-move').should('have.text', 'Copy here').and('not.be.disabled').click();

      // Assert that the new diagram is inside the correct project.
      cy.url()
        .should('include', `/projects/${this.project.id}`)
        .getByTestId('breadcrumb-project-menu')
        .should('have.text', this.project.name);

      // Open the copied diagram.
      cy.getByTestId('entity-list').children().first().click();

      // Select the first Activity.
      cy.getBPMN('Activity_').first().click();

      // Assert that the Call Link is still there and open the diagram.
      cy.getByTestId('call-activity-link-button')
        .should('be.visible')
        .click()
        .getByTestId(`linked-diagram-${diagram.name}`)
        .click();

      // Open the sidebar and assert that 2 processes are still linked.
      cy.getByTestId('specification-toggle')
        .click()
        .getByTestId('call-activity-link-button')
        .next()
        .should('contain', 'This process is called by...');
    });
  });

  it('a user can copy a milestone into a folder', function () {
    // Create a new project and folder.
    cy.createProject(this.user).then((targetProject) => {
      cy.createFolder(targetProject).then((targetFolder) => {
        // Open the diagram.
        cy.visit(`/diagrams/${this.diagram.id}`);

        // Create a new task.
        cy.append('StartEvent_1', 'append-task', 'Task #1');

        // Create a milestone and open the milestone page.
        cy.createMilestone(this.diagram.id).visit(`/milestones/${this.diagram.id}`);

        // Assert that the "Copy to..." entry is visible and click it.
        cy.getByTestId('milestone-menu-button')
          .click({ force: true })
          .getByTestId('milestone-menu-item-copy')
          .should('have.text', 'Copy to...')
          .click();

        // Move one level up to the organization root.
        cy.getByTestId('move-level-up').click();

        // Open the target project.
        cy.getByTestId(`select-item-${targetProject.name}`).click({ force: true });

        // Select the target folder.
        cy.getByTestId(`item-${targetFolder.name}`).should('be.visible').click();

        // Click the "Copy" button.
        cy.getByTestId('confirm-move').should('not.be.disabled').click();

        // Assert that the new diagram is inside the correct project.
        cy.url().should('include', `/folders/${targetFolder.id}`);

        // Assert that the copied diagram is visible and open it.
        cy.getByTestId('entity-list')
          .children()
          .should('have.length', 1)
          .first()
          .should('contain', `${this.diagram.name} - Copy of Milestone`)
          .click();

        // Assert that the activity element exists.
        cy.getBPMN('Activity_').should('exist');
      });
    });
  });

  it('a user can duplicate a diagram and see related versions', function () {
    // Open the diagram.
    cy.visit(`/diagrams/${this.diagram.id}`);

    // Create a new task.
    cy.append('StartEvent_1', 'append-task', 'Task #1');

    // Wait for the diagram to update.
    cy.wait(200).getByTestId('autosave').should('be.visible').and('contain', 'Autosaved');

    // Duplicate the diagram.
    cy.getByTestId('breadcrumb-diagram').click({ force: true }).getByTestId('diagram-menu-duplicate').click();

    // Assert that the duplicated diagram is open.
    cy.getByTestId('breadcrumb-diagram').should('have.text', `${this.diagram.name} - Copy`);

    // Open the milestone page.
    cy.getByTestId('breadcrumb-diagram').click({ force: true }).getByTestId('diagram-menu-item-show-history').click();

    // Assert that the related versions section is visible.
    cy.contains('Related diagrams').should('be.visible').getByTestId('version-list').should('be.visible');

    // Assert that the related diagram is visible.
    cy.getByTestId('version').should('contain', this.diagram.name).and('contain', this.project.name);
  });

  it('a user can open a related version', function () {
    // Create a related diagram.
    cy.createDiagram(this.project, { relationId: this.diagram.relationId }).then((relatedDiagram) => {
      // Open the diagram's milestones.
      cy.visit(`/milestones/${this.diagram.id}`);

      // Open the related diagram.
      cy.getByTestId('version-menu').click().getByTestId('open-version').should('have.text', 'Open diagram').click();

      // Assert that the URL contains the related diagram's id.
      cy.url().should('include', relatedDiagram.id);

      // Assert that the related diagram is visible.
      cy.getByTestId('version').should('contain', this.diagram.name).and('contain', this.project.name);

      // Assert that the duplicated diagram's name appears in
      // the breadcrumb.
      cy.getByTestId('breadcrumb-diagram').should('have.text', relatedDiagram.name);
    });
  });

  it('a user can create a milestone from a related version', function () {
    cy.createEnterpriseLicense(this.user);

    // Create a related diagram without processId
    cy.createDiagram(this.project, { relationId: this.diagram.relationId, ommitProcessId: true }).then(
      (primaryRelatedDiagram) => {
        cy.intercept(getBaseUrl(`internal-api/files/${primaryRelatedDiagram.id}*`)).as('getDiagram');

        cy.visit(`/diagrams/${primaryRelatedDiagram.id}`);

        cy.wait('@getDiagram').then(({ response }) => {
          expect(response.body.data.file.processId).to.be.undefined;
        });

        // Create a new milestone.
        cy.createMilestone(primaryRelatedDiagram.id);

        // Append a task to the start event.
        cy.append('StartEvent_1', 'append-task', 'Task #1');

        // Open the milestone page.
        cy.visit(`/milestones/${primaryRelatedDiagram.id}`);

        // Open the related diagram.
        cy.getByTestId('version-menu')
          .click()
          .getByTestId('use-version-as-milestone')
          .should('have.text', 'Use as new milestone')
          .click();

        // Assert that the snackbar is visible.
        cy.getByTestId('snackbar')
          .should('be.visible')
          .and('have.text', 'The selected diagram has been restored as milestone.');

        // Assert that a new milestone has been created.
        cy.getByTestId('milestone')
          .should('have.length', 3)
          .first()
          .should('contain', `Copied from ${this.project.name}`)
          .next()
          .should('contain', 'Autosaved during restore')
          .next()
          .should('contain', 'Untitled milestone');

        // Assert that the the Task element is no longer existing.
        cy.getBPMN('StartEvent_').should('exist').getBPMN('Activity_').should('not.exist');

        // Register a route we want to catch to expect a processId now to be set

        cy.getByTestId('breadcrumb-diagram').click();

        // This is a workaround for the following issue:
        // https://github.com/cypress-io/cypress/issues/7663
        cy.wait('@getDiagram')
          .wait('@getDiagram')
          .wait('@getDiagram')
          .wait('@getDiagram')
          .then(({ response }) => {
            expect(response.body.data.file.processId).to.equal(this.diagram.processId);
          });
      }
    );
  });
});
