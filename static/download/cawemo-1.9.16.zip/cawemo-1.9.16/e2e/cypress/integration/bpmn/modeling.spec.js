import { getBaseUrl } from '../../helpers';

describe('Basic modeling', function () {
  beforeEach(function () {
    cy.prepareCollaboration().as('data');
  });

  afterEach(function () {
    cy.removeCollaboration(this.data);
  });

  it('a user can do basic modeling', function () {
    cy.visit(`/diagrams/${this.data.diagram.id}`);

    // Get the StartEvent and append a Task and EndEvent.
    cy.append('StartEvent_1', 'append-task', 'Task #1')
      .getByTestId('autosave')
      .should('contain', 'Autosaved')
      .append(null, 'end-event')
      .wait(500)
      .getByTestId('autosave')
      .should('contain', 'Autosaved');

    cy.reload();

    // After reload, assert that all elements are still there.
    cy.get('g.djs-group').should('have.length', 5);
  });

  it.saas('a user can participate in real-time modeling', function () {
    cy.login(this.data.owner);

    cy.visit(`/diagrams/${this.data.diagram.id}`);

    // Open Puppeteer and log the collaborator in.
    cy.task('puppeteer.open').task('puppeteer.login', {
      url: getBaseUrl(`diagrams/${this.data.diagram.id}`),
      user: this.data.user
    });

    // Assert that the snackbar is visible once Puppeteer joins the same diagram.
    cy.getByTestId('snackbar').should('be.visible').and('have.text', `${this.data.user.name} joined the diagram!`);

    // Assert that the avatar of the collaborator is visible.
    cy.getByTestId(`avatar-${this.data.user.name}`).should('be.visible');

    // Create some BPMN elements in Puppeteer.
    cy.task('puppeteer.createElements');

    // Assert that the snackbar is visible once Puppeteer modifies the diagram.
    cy.getByTestId('snackbar').should('be.visible').and('have.text', `${this.data.user.name} modified the diagram!`);

    // Assert that BPMN elements added by Puppeteer are appearing in the canvas.
    cy.get('g.djs-group').should('have.length', 5);
    cy.contains('Task #1 by Puppeteer').should('exist');

    cy.task('puppeteer.close');

    // Assert that the snackbar is visible once Puppeteer left the diagram.
    // TODO enable when #8310 is fixed
    // cy.getByTestId('snackbar').should('be.visible').and('have.text', `${this.data.user.name} left the diagram!`);
  });

  it.saas('a user can use and see the attention grabber', function () {
    cy.visit(`/diagrams/${this.data.diagram.id}`);

    // Open Puppeteer and log the collaborator in.
    cy.task('puppeteer.open').task('puppeteer.login', {
      url: getBaseUrl(`diagrams/${this.data.diagram.id}`),
      user: this.data.user
    });

    cy.task('puppeteer.toggleAttentionGrabber');
    assertAttentionGrabberIsVisible();

    cy.task('puppeteer.toggleAttentionGrabber');
    assertAttentionGrabberIsNotVisible();

    cy.task('puppeteer.close');
  });

  it.saas('a user leaves the diagram and attention grabbers created by him get removed for others', function () {
    cy.visit(`/diagrams/${this.data.diagram.id}`);

    // Open Puppeteer and log the collaborator in.
    cy.task('puppeteer.open').task('puppeteer.login', {
      url: getBaseUrl(`diagrams/${this.data.diagram.id}`),
      user: this.data.user
    });

    cy.task('puppeteer.toggleAttentionGrabber');
    assertAttentionGrabberIsVisible();

    cy.task('puppeteer.close'); // Leave the diagram as the attention grabber creator
    assertAttentionGrabberIsNotVisible();
  });

  // TODO include other browsers again by removing {browser: 'chrome'}
  //  after fixing the viewport assertions
  it('a user can use the diagram controls', { browser: 'chrome' }, function () {
    cy.visit(`/diagrams/${this.data.diagram.id}`);

    let rect = {};

    // Get the current position and dimension from StartEvent_1.
    cy.getBPMN('StartEvent_1').then(($el) => (rect = $el[0].getBoundingClientRect()));

    // Click the zoom-in control and assert that the StartEvent_1
    // is bigger than before.
    cy.getByTestId('zoom-in')
      .click()
      .getBPMN('StartEvent_1')
      .then(($el) => {
        const { width, height } = $el[0].getBoundingClientRect();

        expect(rect.width).to.be.lessThan(width);
        expect(rect.height).to.be.lessThan(height);
      });

    // Click the zoom-out control and assert that the StartEvent_1
    // is bigger than before.
    cy.getByTestId('zoom-out')
      .click()
      .getBPMN('StartEvent_1')
      .then(($el) => {
        const { width, height } = $el[0].getBoundingClientRect();

        expect(rect.width).to.equal(Math.ceil(width));
        expect(rect.height).to.equal(Math.ceil(height));
      });

    // Open the minimap and assert that it is visible.
    cy.getByTestId('toggle-minimap').click().get('.viewport-dom').should('be.visible');

    // Get the current position and dimension from StartEvent_1.
    cy.getBPMN('StartEvent_1').then(($el) => (rect = $el[0].getBoundingClientRect()));

    // Move the minimap canvas by dragging it.
    cy.get('.viewport-dom')
      .trigger('mousedown', { which: 1 })
      .trigger('mousemove', { clientX: 5, clientY: 5 })
      .trigger('mouseup', { force: true });

    // Assert that the StartEvent_1 has changed its position due
    // to dragging the minimap.
    cy.getBPMN('StartEvent_1').then(($el) => {
      const { x, y } = $el[0].getBoundingClientRect();

      expect(rect.x).to.not.equal(x);
      expect(rect.y).to.not.equal(y);
    });

    // Get the current position and dimension from StartEvent_1.
    cy.getBPMN('StartEvent_1')
      .should('not.be.visible')
      .then(($el) => (rect = $el[0].getBoundingClientRect()));

    // Click the viewport reset control and assert that the
    // StartEvent_1 is back in the viewport area.
    cy.getByTestId('viewport-reset')
      .click()
      .getBPMN('StartEvent_1')
      .should('be.visible')
      .then(($el) => {
        const { x, y } = $el[0].getBoundingClientRect();

        expect(rect.x).to.be.greaterThan(x);
        expect(rect.y).to.be.greaterThan(y);
      });
  });

  it('a user can create and delete call activity links', function () {
    // Give this user the enterprise license
    cy.createEnterpriseLicense(this.data.owner);

    // Create a second diagram, which is going to be the Call Activity link.
    cy.createDiagram(this.data.project).then((targetDiagram) => {
      cy.visit(`/diagrams/${this.data.diagram.id}`);

      // Append a new task to the start event.
      cy.append('StartEvent_1', 'append-task', 'Task #1');

      // Click the wrench icon and find and click the "Call Activity"
      // entry in the dropdown.
      cy.get('[data-action="replace"]')
        .click()
        .get('[data-id="replace-with-call-activity"]')
        .should('be.visible')
        .and('have.text', 'Call Activity')
        .click();

      // Assert that the call activity button has appeared below
      // the element and click it.
      cy.getByTestId('call-activity-link-button').should('be.visible').click();

      // Assert that the confirm button is disabled.
      cy.getByTestId('confirm-move').should('be.disabled');

      // Assert that the project name is displayed and that the user
      // can't go to the organization root.
      cy.getByTestId('move-component-title')
        .should('have.text', this.data.project.name)
        .getByTestId('move-level-up')
        .should('not.exist');

      // Assert that the created diagram is available in the list of linkable
      // diagrams and select it.
      cy.getByTestId(`item-${targetDiagram.name}`).should('be.visible').and('have.text', targetDiagram.name).click();

      // Assert that the confirm button is enabled and click it.
      cy.getByTestId('confirm-move').should('not.be.disabled').click();

      // Assert that the snackbar is visible and confirming that the link
      // has been established.
      cy.getByTestId('snackbar').should('be.visible').and('have.text', 'Call activity has been successfully linked.');

      // Click away onto a different BPMN element.
      cy.getBPMN('StartEvent_').click();

      // Click the call activitiy button again and assert that the linked diagram
      // is visible. Click and open it.
      cy.getByTestId('call-activity-link-button')
        .should('exist')
        .click()
        .getByTestId(`linked-diagram-${targetDiagram.name}`)
        .should('exist')
        .click();

      // Assert that the correct diagram has been linked by comparing the URL.
      cy.url().should('contain', targetDiagram.id);

      // Open the sidebar.
      cy.getByTestId('specification-toggle').click();

      // Assert that this child diagram has a parents section shown and it is possible to navigate back to the parent
      cy.getByTestId('call-activity-link-button')
        .should('exist')
        .click()
        .getByTestId(`call-activity-${this.data.diagram.id}`)
        .should('exist')
        .click();

      // Click the call activity button again and unlink the linked diagram.
      cy.getByTestId('call-activity-link-button')
        .should('exist')
        .click()
        .getByTestId('unlink-button')
        .should('exist')
        .click();

      // Assert that the snackbar is visible and confirming that the link
      // has been destroyed.
      cy.getByTestId('snackbar').should('be.visible').and('have.text', 'Call activity has been unlinked.');

      // Assert that the call activity button is no longer visible.
      cy.getByTestId('call-activity-link-button').should('not.exist');
    });
  });

  it('a user can link to a diagram with a shared process ID inside a folder', function () {
    // Give this user the enterprise license
    cy.createEnterpriseLicense(this.data.owner);

    cy.createFolder(this.data.project).then((folder) => {
      // Create a couple of folders and diagrams.
      cy.createDiagram(this.data.project, { parentId: folder.id, name: 'Target Diagram' });

      // Open the folder.
      cy.visit(`/folders/${folder.id}`);

      // Duplicate the diagram.
      cy.getByTestId('entity-context-dropdown')
        .click({ force: true })
        .getByTestId('duplicate-diagram')
        .click()
        .getByTestId('entity-list')
        .children()
        .should('have.length', 2);

      // Open the original diagram outside the folder.
      cy.visit(`/diagrams/${this.data.diagram.id}`);

      // Append a new task to the start event.
      cy.append('StartEvent_1', 'append-task', 'Task #1');

      // Click the wrench icon and find and click the "Call Activity"
      // entry in the dropdown.
      cy.get('[data-action="replace"]').click().get('[data-id="replace-with-call-activity"]').click();

      // Assert that the call activity button has appeared below
      // the element and click it.
      cy.getByTestId('call-activity-link-button').click();

      // Assert that the created folder is visible and select it.
      cy.getByTestId(`item-${folder.name}`).should('be.visible').and('have.text', folder.name).click();

      // Assert that the confirm button is disabled.
      cy.getByTestId('confirm-move').should('be.disabled');

      // Navigate into the folder.
      cy.getByTestId(`select-item-${folder.name}`).click();

      // Assert that the confirm button is disabled.
      cy.getByTestId('confirm-move').should('be.disabled');

      // Assert that the target diagram is visible and select it.
      cy.getByTestId('item-Target Diagram').should('be.visible').click();

      // Assert that the confirm button is enabled and click it.
      cy.getByTestId('confirm-move').should('not.be.disabled').click();

      // Assert that the confirmation screen with the duplicated diagram is visible.
      cy.getByTestId('move-component-title')
        .should('have.text', 'Multiple diagrams linked')
        .getByTestId('item-Target Diagram - Copy')
        .should('be.visible');

      // Assert that the confirm button is enabled and click it.
      cy.getByTestId('confirm-move').should('not.be.disabled').click();

      // Open the Call Link Menu again.
      cy.getByTestId('call-activity-link-button').click();

      // Assert that both diagrams are now linked.
      cy.getByTestId('linked-diagram-Target Diagram')
        .should('be.visible')
        .getByTestId('linked-diagram-Target Diagram - Copy')
        .should('be.visible');
    });
  });

  it('a user can copy & paste BPMN elements between diagrams', function () {
    cy.createDiagram(this.data.project).then((diagram) => {
      // Open the diagram.
      cy.visit(`/diagrams/${this.data.diagram.id}`);

      // Append two tasks and one end event to the start event and colorize
      // one task blue.
      cy.append('StartEvent_', 'append-task', 'Task #1')
        .append(null, 'append-task', 'Task #2')
        .get('[data-action="colorize"]')
        .click()
        .get('[data-id="colorize-blue"]')
        .click()
        .append(null, 'end-event')
        .get('[data-action="replace"]')
        .click()
        .get('[data-id="replace-with-escalation-end"]')
        .click();

      // Assert that the diagram has two tasks.
      cy.getBPMN('Activity_').should('have.length', 2);

      // Copy and paste all elements on the canvas.
      cy.get('body').type('{ctrl}a').type('{ctrl}c').trigger('mousemove', 'center').type('{ctrl}v').click();

      // Assert that the number of elements have doubled and that all
      // properties are considered.
      cy.getBPMN('Activity_')
        .should('have.length', 4)
        .eq(2)
        .should('have.text', 'Task #1')
        .getBPMN('Activity_')
        .eq(3)
        .should('have.text', 'Task #2')
        .find('.djs-visual rect')
        .should('have.css', 'stroke', 'rgb(30, 136, 229)');

      // Assert that 3 events are visible. We need to assert 3 instead of 4, because the initial
      // start event (when the diagram was created) has the type of "StartEvent" and not "Event".
      cy.getBPMN('Event_').should('have.length', 3);

      // Open the project page and open the other diagram.
      cy.getByTestId('breadcrumb-project').click().getByTestId(`entity-${diagram.name}`).click();

      // Paste the previously copied content into this empty diagram.
      cy.getBPMN('StartEvent_').click().get('body').type('{ctrl}v').trigger('mousemove', 'center').click();

      // Assert that all copied elements with their properties
      // have been transferred.
      cy.getBPMN('Activity_')
        .should('have.length', 2)
        .first()
        .should('have.text', 'Task #1')
        .getBPMN('Activity_')
        .last()
        .should('have.text', 'Task #2')
        .find('.djs-visual rect')
        .should('have.css', 'stroke', 'rgb(30, 136, 229)')
        .getBPMN('Event_')
        .should('have.length', 2);
    });
  });
});

const assertAttentionGrabberIsVisible = () => {
  cy.getByTestId('attention-grabber-item').should('exist').and('have.length', 1).and('be.visible');
};

const assertAttentionGrabberIsNotVisible = () => {
  cy.getByTestId('attention-grabber-item').should('have.length', 0);
};
