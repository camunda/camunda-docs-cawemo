describe('Milestone diffing', function () {
  beforeEach(function () {
    // Create a new user, project and diagram.
    cy.createUserAndLogin()
      .as('user')
      .then(cy.createEnterpriseLicense)
      .get('@user')
      .then(cy.createProject)
      .as('project')
      .then(cy.createDiagram)
      .as('diagram')
      .then((diagram) => {
        cy.visit(`/diagrams/${diagram.id}`);
      });
  });

  afterEach(function () {
    cy.removeUser(this.user);
  });

  it('diffing can be toggled', function () {
    // Create the first milestone.
    cy.createMilestone(this.diagram.id);

    // Create a new task.
    cy.append('StartEvent_1', 'append-task', 'Task #1');

    // Create another task.
    cy.append(null, 'append-task', 'Task #2');

    // Open the milestone page.
    cy.visit(`/milestones/${this.diagram.id}`);

    // Assert that all tasks have the diffing property displayed.
    cy.getBPMN('Activity_').each(($el) => {
      cy.wrap($el).should('be.visible').and('have.class', 'diff-added');

      cy.get(`[data-container-id="${$el.attr('data-element-id')}"]`).should('exist');
    });

    // Assert that the diffing toggle is checked by default.
    cy.getByTestId('diffing-toggle')
      .should('be.checked')
      .uncheck({ force: true })
      .then(() => {
        expect(localStorage.getItem('cawemo.diffing')).to.eq('false');
      });

    // Assert that none of the tasks have the diffing property.
    cy.getBPMN('Activity_').each(($el) => {
      cy.wrap($el).should('not.have.class', 'diff-added');

      cy.get(`[data-container-id="${$el.attr('data-element-id')}"]`).should('not.exist');
    });

    // Wait until all tasks have loaded.
    cy.getBPMN('Activity_').should('be.visible');

    // Check the diffing toggle.
    cy.getByTestId('diffing-toggle').should('not.be.checked').check({ force: true });

    // Assert that all tasks have the diffing property displayed.
    cy.getBPMN('Activity_').each(($el) => {
      cy.wrap($el).should('be.visible').and('have.class', 'diff-added');

      cy.get(`[data-container-id="${$el.attr('data-element-id')}"]`).should('exist');
    });

    // Assert that the diffing toggle is still checked.
    cy.getByTestId('diffing-toggle')
      .should('be.checked')
      .then(() => {
        expect(localStorage.getItem('cawemo.diffing')).to.eq('true');
      });
  });

  it('added elements are highlighted', function () {
    // Create the first milestone.
    cy.createMilestone(this.diagram.id);

    // Create a new task.
    cy.append('StartEvent_1', 'append-task', 'Task #1');

    // Create the end event.
    cy.append(null, 'end-event');

    // Create the second milestone using the shortcut.
    cy.createMilestone(this.diagram.id).visit(`/milestones/${this.diagram.id}`);

    // Get the task and assert that it has added diffing properties
    // and that the overlay is displayed with the correct text.
    cy.getBPMN('Activity_')
      .last()
      .should('have.class', 'diff-added')
      .then(($el) => {
        cy.get(`[data-container-id="${$el.attr('data-element-id')}"]`)
          .should('exist')
          .should('have.class', 'diff-added')
          .find('[data-test="diffing-container"]')
          .should('have.class', 'added')
          .click()
          .getByTestId('list-of-changes')
          .should('be.visible')
          .and('have.text', 'Task was added');
      });

    // Get the end event and assert that it has added diffing properties
    // and that the overlay is displayed with the correct text.
    cy.getBPMN('Event_')
      .should('have.class', 'diff-added')
      .then(($el) => {
        cy.get(`[data-container-id="${$el.attr('data-element-id')}"]`)
          .should('exist')
          .should('have.class', 'diff-added')
          .find('[data-test="diffing-container"]')
          .should('have.class', 'added')
          .click()
          .getByTestId('list-of-changes')
          .should('be.visible')
          .and('have.text', 'EndEvent was added');
      });
  });

  it('changed elements are highlighted', function () {
    // Create a new task.
    cy.append('StartEvent_1', 'append-task', 'Task #1');

    // Create the end event.
    cy.append(null, 'end-event');

    // Create the first milestone.
    cy.createMilestone(this.diagram.id);

    // Rename the task.
    cy.getBPMN('Activity_').last().dblclick().get('[contenteditable]').clear().type('Task #2{enter}');

    // Change the EndEvent type.
    cy.getBPMN('Event_')
      .last()
      .click()
      .get('[data-action="replace"]')
      .click()
      .get('[data-id="replace-with-error-end"]')
      .click();

    // Wait for the diagram to update.
    cy.wait(200).getByTestId('autosave').should('be.visible').and('contain', 'Autosaved');

    // Create the second milestone using the shortcut.
    cy.createMilestone(this.diagram.id).visit(`/milestones/${this.diagram.id}`);

    // Get the task and assert that it has added diffing properties
    // and that the overlay is displayed with the correct text.
    cy.getBPMN('Activity_')
      .last()
      .should('have.class', 'diff-changed')
      .then(($el) => {
        cy.get(`[data-container-id="${$el.attr('data-element-id')}"]`)
          .should('exist')
          .should('have.class', 'diff-changed')
          .find('[data-test="diffing-container"]')
          .should('have.class', 'changed')
          .click()
          .getByTestId('list-of-changes')
          .should('be.visible')
          .and('have.text', 'Label changed from Task #1 to Task #2 ');
      });

    // Get the end event and assert that it has added diffing properties
    // and that the overlay is displayed with the correct text.
    cy.getBPMN('Event_')
      .should('have.class', 'diff-changed')
      .then(($el) => {
        cy.get(`[data-container-id="${$el.attr('data-element-id')}"]`)
          .should('exist')
          .should('have.class', 'diff-changed')
          .find('[data-test="diffing-container"]')
          .should('have.class', 'changed')
          .click()
          .getByTestId('list-of-changes')
          .should('be.visible')
          .and('have.text', 'ErrorEventDefinition was set ');
      });
  });

  it('removed elements are highlighted', function () {
    // Create a new task.
    cy.append('StartEvent_1', 'append-task', 'Task #1');

    // Create the end event.
    cy.append(null, 'end-event');

    // Create the first milestone.
    cy.createMilestone(this.diagram.id, 'Milestone 1');

    // Remove the task.
    cy.getBPMN('Activity_').last().click().get('[data-action="delete"]').click();

    // Wait for the diagram to update.
    cy.wait(200).getByTestId('autosave').should('be.visible').and('contain', 'Autosaved');

    // Create the second milestone using the shortcut.
    cy.createMilestone(this.diagram.id, 'Milestone 2').visit(`/milestones/${this.diagram.id}`);

    // Get the task and assert that it has added diffing properties
    // and that the overlay is displayed with the correct text.
    cy.getBPMN('Activity_').should('not.exist');

    // Get the end event and assert that it has added diffing properties
    // and that the overlay is displayed with the correct text.
    cy.getBPMN('Flow_')
      .should('have.class', 'diff-removed')
      .then(($el) => {
        cy.get(`[data-container-id="${$el.attr('data-element-id')}"]`)
          .should('exist')
          .should('have.class', 'diff-removed')
          .find('[data-test="diffing-container"]')
          .should('have.class', 'removed')
          .click()
          .getByTestId('list-of-changes')
          .should('be.visible')
          .and('contain', 'Target changed from')
          .and('contain', '(got removed)');
      });
  });

  it('related diagrams can be diffed', function () {
    // Create a related diagram.
    cy.createDiagram(this.project, { relationId: this.diagram.relationId });

    // Create a new task.
    cy.append('StartEvent_1', 'append-task', 'Task #1');

    // Create the end event.
    cy.append(null, 'end-event');

    // Create the first milestone.
    cy.createMilestone(this.diagram.id).visit(`/milestones/${this.diagram.id}`);

    // Assert that there's one related diagram.
    cy.getByTestId('version').should('have.length', 1).click();

    // Assert that both diagrams can be diffed.
    cy.getBPMN('Activity_').should('have.class', 'diff-added').getBPMN('Event_').should('have.class', 'diff-added');
  });
});
