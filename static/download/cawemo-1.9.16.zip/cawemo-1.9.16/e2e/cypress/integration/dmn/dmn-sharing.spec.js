describe('DMN diagram sharing', function () {
  beforeEach(function () {
    // Create a new user, project, and DMN diagram.
    cy.createUserAndLogin()
      .as('user')
      .then(cy.createProject)
      .as('project')
      .then(cy.createDmnDiagram)
      .as('diagram')
      .then((diagram) => cy.visit(`/diagrams/${diagram.id}`));
  });

  afterEach(function () {
    cy.removeUser(this.user);
  });

  it('a DMN diagram can be shared', function () {
    // Wait until the diagram has been loaded completely.
    cy.get('[data-element-id^="Decision_"]').should('be.visible');

    // Assert that the share button has the proper title and click it.
    cy.getByTestId('share').should('be.visible').and('have.attr', 'title', 'Share').click();

    // Create a new share.
    cy.getByTestId('create-share-cta').should('be.visible').click();

    // Get the share URL from the input and open it.
    cy.getByTestId('share-link-container').invoke('val').then(cy.visit);

    // Assert that the share route is shown.
    cy.url().should('include', '/share/');

    // Assert that the proper decision table is visible.
    cy.get('[data-element-id^="Decision"').should('be.visible').and('have.text', 'Decision 1').click();

    // Assert that the context pad isn't rendered.
    cy.get('.djs-context-pad').should('not.exist');

    // Assert that the command palette isn't rendered.
    cy.get('.djs-palette').should('not.exist');

    // Assert that the correct diagram name is shown in the breadcrumb.
    cy.getByTestId('breadcrumb-diagram').should('be.visible').and('have.text', this.diagram.name);

    // Assert that the user menu is visible and contains the right user.
    cy.getByTestId('user-menu-button').should('be.visible').and('have.text', this.user.name);

    // Assert that diagram controls are visible.
    cy.getByTestId('toggle-fullscreen').should('be.visible');
  });

  it('a DMN diagram can be embedded', function () {
    // Create a new share.
    cy.createShare(this.diagram.id).then((shareId) => {
      // Navigate to the embed.
      cy.visit(`/embed/${shareId}`);

      // Assert that the share route is shown.
      cy.url().should('include', '/embed/');

      // Assert that the proper decision table is visible.
      cy.get('[data-element-id^="Decision"').should('be.visible').and('have.text', 'Decision 1').click();

      // Assert that the context pad isn't rendered.
      cy.get('.djs-context-pad').should('not.exist');

      // Assert that the command palette isn't rendered.
      cy.get('.djs-palette').should('not.exist');

      // Assert that the correct diagram name is shown in the breadcrumb.
      cy.getByTestId('breadcrumb-diagram').should('not.exist');

      // Assert that the "Powered by Cawemo" label is visible.
      cy.getByTestId('powered-by').should('be.visible').and('have.attr', 'title', 'Powered by Cawemo');

      // Assert that diagram controls are visible.
      cy.getByTestId('toggle-fullscreen').should('be.visible');
    });
  });
});
