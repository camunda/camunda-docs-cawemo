const { ADMIN_USER, ADMIN_ORGANIZATION } = require('../../scripts/prepare/fixtures');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');

const DUMMY_USER_ID = '99999999-9999-9999-9999-999999999999';

let pool;
let iamPool;

const queries = {
  insert_user:
    'INSERT INTO users (id, name, email, created, updated, username, verified, type, iam_id) VALUES ($1, $2, $3, NOW(), NOW(), $4, $5, $6, $7) ON CONFLICT DO NOTHING;',
  insert_user_saas:
    'INSERT INTO users (id, name, email, created, updated, username, verified, type, iam_id, segment) VALUES ($1, $2, $3, NOW(), NOW(), $4, $5, $6, $7, $8) ON CONFLICT DO NOTHING;',
  set_comments_created_by_to_dummy_user: `UPDATE comments SET created_by = '${DUMMY_USER_ID}' WHERE created_by = $1;`,
  set_files_created_by_to_dummy_user: `UPDATE files SET created_by = '${DUMMY_USER_ID}' WHERE created_by = $1;`,
  set_files_updated_by_to_dummy_user: `UPDATE files SET updated_by = '${DUMMY_USER_ID}' WHERE updated_by = $1;`,
  set_file_links_created_by_to_dummy_user: `UPDATE file_links SET created_by = '${DUMMY_USER_ID}' WHERE created_by = $1;`,
  set_file_links_updated_by_to_dummy_user: `UPDATE file_links SET updated_by = '${DUMMY_USER_ID}' WHERE updated_by = $1;`,
  set_folders_created_by_to_dummy_user: `UPDATE folders SET created_by = '${DUMMY_USER_ID}' WHERE created_by = $1;`,
  set_folders_updated_by_to_dummy_user: `UPDATE folders SET updated_by = '${DUMMY_USER_ID}' WHERE updated_by = $1;`,
  set_milestones_created_by_to_dummy_user: `UPDATE milestones SET created_by = '${DUMMY_USER_ID}' WHERE created_by = $1;`,
  set_milestones_updated_by_to_dummy_user: `UPDATE milestones SET updated_by = '${DUMMY_USER_ID}' WHERE updated_by = $1;`,
  set_organizations_created_by_to_dummy_user: `UPDATE organizations SET created_by = '${DUMMY_USER_ID}' WHERE created_by = $1;`,
  set_organizations_updated_by_to_dummy_user: `UPDATE organizations SET updated_by = '${DUMMY_USER_ID}' WHERE updated_by = $1;`,
  set_organization_permissions_created_by_to_dummy_user: `UPDATE organization_permissions SET created_by = '${DUMMY_USER_ID}' WHERE created_by = $1;`,
  set_organization_permissions_updated_by_to_dummy_user: `UPDATE organization_permissions SET updated_by = '${DUMMY_USER_ID}' WHERE updated_by = $1;`,
  set_projects_created_by_to_dummy_user: `UPDATE projects SET created_by = '${DUMMY_USER_ID}' WHERE created_by = $1;`,
  set_projects_updated_by_to_dummy_user: `UPDATE projects SET updated_by = '${DUMMY_USER_ID}' WHERE updated_by = $1;`,
  set_project_permissions_created_by_to_dummy_user: `UPDATE project_permissions SET created_by = '${DUMMY_USER_ID}' WHERE created_by = $1;`,
  set_project_permissions_updated_by_to_dummy_user: `UPDATE project_permissions SET updated_by = '${DUMMY_USER_ID}' WHERE updated_by = $1;`,
  set_tokens_updated_by_to_dummy_user: `UPDATE tokens SET updated_by = '${DUMMY_USER_ID}' WHERE updated_by = $1;`,
  delete_user: 'DELETE FROM users WHERE id = $1;',
  delete_all_users: `DELETE FROM users WHERE id NOT IN ('${ADMIN_USER.id}', '${DUMMY_USER_ID}');`,
  insert_organization: 'INSERT INTO organizations (id, name, created, created_by, updated, updated_by) VALUES ($1, $2, NOW(), $3, NOW(), $3);',
  delete_organization: 'DELETE FROM organizations WHERE id = $1;',
  insert_preference: 'INSERT INTO preferences(user_id, key, value, created, updated) VALUES ($1, $2, $3, NOW(), NOW());',
  insert_organization_permission:
    'INSERT INTO organization_permissions(user_id, organization_id, access, created, created_by, updated, updated_by) VALUES ($1, $2, $3, NOW(), $1, NOW(), $1);',
  insert_project: 'INSERT INTO projects(id, name, organization_id, type, created, created_by, updated, updated_by) VALUES ($1, $2, $3, $4, NOW(), $5, NOW(), $5);',
  insert_folder:
    'INSERT INTO folders(id, name, project_id, created, created_by, updated, updated_by, parent_id) VALUES ($1, $2, $3, NOW(), $4, NOW(), $5, $6);',
  insert_projects_permission:
    'INSERT INTO project_permissions(user_id, project_id, access, created, created_by, updated, updated_by) VALUES ($1, $2, $3, NOW(), $1, NOW(), $1);',
  update_projects_permission: 'UPDATE project_permissions SET access = $1 WHERE user_id = $2 AND project_id = $3',
  insert_file:
    'INSERT INTO files(name, id, project_id, content, relation_id, process_id, created, created_by, updated, updated_by, type, folder_id, revision) VALUES ($1, $2, $3, $4, $5, $6, NOW(), $7, NOW(), $7, $8, $9, 1);',
  delete_all_files: 'DELETE FROM files WHERE project_id = $1',
  insert_signup_invitation: 'INSERT INTO signup_invitations(id, invited_email, token_id, created, created_by) VALUES ($1, $2, $1, NOW(), $3)',
  insert_token: 'INSERT INTO tokens(id, type, created, created_by, updated, updated_by) VALUES ($1, $2, NOW(), $3, NOW(), $3);',
  insert_api_key:
    'INSERT INTO api_keys(id, secret, organization_id, description, created, user_id, updated) VALUES ($1, $2, $3, $4, NOW(), $5, NOW());',
  insert_license_log_entry: 'INSERT INTO license_log_entries(id, license_model, organization_id, created) VALUES ($1, $2, $3, NOW());',
  insert_link:
    'INSERT INTO file_links(id, source_file_id, target_file_id, source_element_id, created, created_by, updated, updated_by) VALUES ($1, $2, $3, $4, NOW(), $5, NOW(), $5);',
  select_user_details: 'SELECT name, email FROM users WHERE iam_id = $1;',
  update_user_type: "UPDATE users SET type = 'ADMIN' WHERE id = $1;",
  delete_organization_permission: 'DELETE FROM organization_permissions WHERE organization_id = $1;',
  delete_tokens_by_type: 'DELETE FROM tokens WHERE type = $1',
  delete_all_projects: 'DELETE FROM projects'
};

const iamQueries = {
  iam_insert_user:
    'INSERT INTO iam_user' +
    '(uuid, ldap_uuid, email, full_name, password, verified, version, google_id, linked_in_id, created_at, modified_at) ' +
    'VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) ON CONFLICT DO NOTHING RETURNING *',
  iam_delete_user: 'DELETE FROM iam_user WHERE email = $1'
};

/**
 * Runs an array of database queries in order.
 *
 * @param {Array} queries The queries to execute.
 * @returns {null}
 */
async function run(queries) {
  const client = await pool.connect();

  try {
    const queryExecutions = queries.map((query) => client.query(query[0], query[1]));
    await Promise.all(queryExecutions);
  } catch (ex) {
    console.error(ex.stack);
  } finally {
    client.release();
  }

  return null;
}

async function runWithResult(query, parameters) {
  const client = await pool.connect();

  try {
    return await client.query(query, parameters);
  } catch (ex) {
    console.error(ex.stack);
  } finally {
    client.release();
  }

  return null;
}

async function iamRunWithResult(query, parameters) {
  const client = await iamPool.connect();
  try {
    return await client.query(query, parameters);
  } catch (ex) {
    console.error(ex.stack);
  } finally {
    client.release();
  }

  return null;
}

function createUserIAM({ iamId, email, name, password }) {
  return iamRunWithResult(iamQueries.iam_insert_user, [
    iamId,
    null,
    email,
    name,
    cryptPassword(password),
    false,
    1,
    '',
    '',
    new Date(),
    new Date()
  ]);
}

function createLdapUserIAM({ iamId, username, email, name }) {
  return iamRunWithResult(iamQueries.iam_insert_user, [
    iamId,
    username,
    email,
    name,
    null,
    true,
    0,
    '',
    '',
    new Date(),
    new Date()
  ]);
}

function initDB(config) {
  const dbUser = config.env.DB_USER;
  const dbHost = config.env.DB_HOST;
  const dbPassword = config.env.DB_PASSWORD;
  const dbName = config.env.DB_NAME;
  const dbPort = config.env.DB_PORT;
  pool = new Pool({
    user: dbUser ? dbUser : 'master',
    host: dbHost ? dbHost : 'localhost',
    password: dbPassword ? dbPassword : 'master',
    database: dbName ? dbName : 'app',
    port: dbPort ? dbPort : '5432'
  });
}

function initIAMDB(config) {
  iamPool = new Pool({
    user: config.env.IAM_DB_USER,
    host: config.env.IAM_DB_HOST,
    password: config.env.IAM_DB_PASSWORD,
    database: config.env.IAM_DB_NAME,
    port: config.env.IAM_DB_PORT
  });
}

function init(config) {
  initDB(config);
  initIAMDB(config);
}

const cryptPassword = (password) => {
  const salt = bcrypt.genSaltSync(12);
  return `{bcrypt12}${bcrypt.hashSync(password, salt)}`;
};

module.exports = {
  init,
  /**
   * Gets a user by their iamId
   *
   * @param {String} iamId The iamId of the user we want to get from the database
   */
  async getUserDetailsByIamId(iamId) {
    const { rows } = await runWithResult(queries.select_user_details, [iamId]);
    return rows[0];
  },

  /**
   * Creates a new user for SaaS with appropriate organization permissions and preferences.
   *
   * @param {Object} user The user to create.
   * @returns {null}
   */
  async createUserSaaS({ id, name, email, username, iamId, verified, organization, segment }) {
    const userQueries = [
      [queries.insert_user_saas, [id, name, email, username, verified, 'USER', iamId, segment]],
      [queries.insert_preference, [id, 'showNewsletterConsentRequest', false]]
    ];
    await run(userQueries);
    return module.exports.createOrganizationForUser(organization, { id });
  },

  /**
   * Creates a new user for enterprise. The user will be added to the only existing organization created in scripts/prepare/index.js.
   *
   * @param {Object} user The user to create.
   * @returns {null}
   */
  async createUserEnterprise({ id, name, email, username, iamId }) {
    const userQueries = [
      [queries.insert_user, [id, name, email, username, 'true', 'USER', iamId]],
      [queries.insert_organization_permission, [id, ADMIN_ORGANIZATION.id, 'USER']]
    ];
    return run(userQueries);
  },

  /**
   * Creates a new admin user for enterprise.
   *
   * @param {Object} user The admin user to create.
   * @returns {null}
   */
  async createAdminUserEnterprise({ id, name, email, username, iamId }) {
    return run([[queries.insert_user, [id, name, email, username, 'true', 'ADMIN', iamId]]]);
  },

  async createUserIAM({ iamId, email, name, password }) {
    return await createUserIAM({ iamId, email, name, password });
  },

  async createLdapUserIAM({ iamId, username, email, name, password }) {
    return await createLdapUserIAM({ iamId, username, email, name, password });
  },

  removeUserIAM({ email }) {
    return iamRunWithResult(iamQueries.iam_delete_user, [email]);
  },

  /**
   * Removes an existing user and his organization in saas. Setting the dummy user like in {@link removeUserEnterprise}
   * is not necessary as the organization deletion cascades to all dependent tables.
   *
   * @param {Object} user The user to remove.
   * @returns {null}
   */
  removeUserSaaS({ id, organization }) {
    return run([
      [queries.delete_organization, [organization.id]],
      [queries.delete_user, [id]]
    ]);
  },

  /**
   * Removes an existing user in enterprise.
   *
   * @param {Object} user The user to remove.
   * @returns {null}
   */
  removeUserEnterprise({ id }) {
    return run([
      [queries.set_comments_created_by_to_dummy_user, [id]],
      [queries.set_files_created_by_to_dummy_user, [id]],
      [queries.set_files_updated_by_to_dummy_user, [id]],
      [queries.set_file_links_created_by_to_dummy_user, [id]],
      [queries.set_file_links_updated_by_to_dummy_user, [id]],
      [queries.set_folders_created_by_to_dummy_user, [id]],
      [queries.set_folders_updated_by_to_dummy_user, [id]],
      [queries.set_milestones_created_by_to_dummy_user, [id]],
      [queries.set_milestones_updated_by_to_dummy_user, [id]],
      [queries.set_organizations_created_by_to_dummy_user, [id]],
      [queries.set_organizations_updated_by_to_dummy_user, [id]],
      [queries.set_organization_permissions_created_by_to_dummy_user, [id]],
      [queries.set_organization_permissions_updated_by_to_dummy_user, [id]],
      [queries.set_projects_created_by_to_dummy_user, [id]],
      [queries.set_projects_updated_by_to_dummy_user, [id]],
      [queries.set_project_permissions_created_by_to_dummy_user, [id]],
      [queries.set_project_permissions_updated_by_to_dummy_user, [id]],
      [queries.set_tokens_updated_by_to_dummy_user, [id]],
      [queries.delete_user, [id]]
    ]);
  },

  removeAllUsers() {
    return run([[queries.delete_all_users, []]]);
  },

  createOrganizationForUser(organization, user) {
    const organizationQueries = [
      [queries.insert_organization, [organization.id, organization.name, user.id]],
      [queries.insert_organization_permission, [user.id, organization.id, 'ADMIN']]
    ];
    return run(organizationQueries);
  },

  createOrganizationPermission({ organization, user, permission = 'USER' }) {
    return run([[queries.insert_organization_permission, [user.id, organization.id, permission]]]);
  },

  /**
   * Removes an existing organization.
   *
   * @param {Object} organization The organization to remove.
   * @returns {null}
   */
  removeOrganization(organization) {
    return run([[queries.delete_organization, [organization.id]]]);
  },

  removeOrganizationPermission(organization) {
    return run([[queries.delete_organization_permission, [organization.id]]]);
  },

  removeAllProjects() {
    return run([[queries.delete_all_projects, []]]);
  },

  removeAdminSetupToken() {
    return run([[queries.delete_tokens_by_type, ['ADMIN_SETUP']]]);
  },

  removeSignUpTokens() {
    return run([[queries.delete_tokens_by_type, ['SIGNUP_INVITE']]]);
  },

  joinUserToOrganization({ user, collaborator }) {
    return run([[queries.insert_organization_permission, [collaborator.id, user.organization.id, 'USER']]]);
  },

  /**
   * Creates a new project with appropriate user permissions.
   *
   * @param {Object} project The project to create, containing the user.
   * @returns {null}
   */
  createProject({ id, name, user, type }) {
    return run([
      [queries.insert_project, [id, name, user.organization.id, type, user.id]],
      [queries.insert_projects_permission, [user.id, id, 'OWNER']]
    ]);
  },

  /**
   * Creates a new folder within a project.
   *
   * @param {Object} project The project to create, containing the user.
   * @returns {null}
   */
  createFolder({ id, name, project, parentId }) {
    return run([[queries.insert_folder, [id, name, project.id, project.user.id, project.user.id, parentId]]]);
  },

  /**
   * Creates a new legacy diagram without a process id for version <= 1.2
   *
   * @param {Object} diagram The diagram to create, containing the project.
   * @returns {null}
   */
  createLegacyDiagram({ name, id, project, content, relationId }) {
    return run([[queries.insert_file, [name, id, project.id, content, relationId, null, project.user.id, 'BPMN']]]);
  },

  /**
   * Creates a new file.
   *
   * @param {Object} file The file to create, containing the project.
   * @returns {null}
   */
  createDiagram({ name, id, project, content, relationId, processId, type, folderId }) {
    return run([
      [queries.insert_file, [name, id, project.id, content, relationId, processId, project.user.id, type, folderId]]
    ]);
  },

  removeAllFiles(project_id) {
    return run([[queries.delete_all_files, [project_id]]]);
  },

  /**
   * Creates a link between an element of one file and another file
   * @param {Object} link The link to create, has source and target details
   */
  createLink({ id, source_file_id, target_file_id, source_element_id, author_id }) {
    return run([[queries.insert_link, [id, source_file_id, target_file_id, source_element_id, author_id]]]);
  },

  /**
   * Creates a new signup invitation with a corresponding token.
   *
   * @param {String} tokenId Id for the token to create.
   * @param {String} invitedEmail The email to invite.
   * @param {Object} inviter The user who created the invitation.
   * @returns {null}
   */
  createSignupInvitation({ tokenId, invitedEmail, inviter }) {
    return run([
      [queries.insert_token, [tokenId, 'SIGNUP_INVITE', inviter.id]],
      [queries.insert_signup_invitation, [tokenId, invitedEmail, inviter.id]]
    ]);
  },

  /**
   * Creates a new API key.
   *
   * @param {Object} key The API key to create.
   * @returns {null}
   */
  createApiKey({ keyId, licenseId, apiKeySecret, name = 'Cypress Integration Tests', organizationId, userId }) {
    return run([
      [queries.insert_api_key, [keyId, apiKeySecret, organizationId, name, userId]],
      [queries.insert_license_log_entry, [licenseId, 'enterprise', organizationId]]
    ]);
  },

  /**
   * Creates a new enterprise license.
   *
   * @param {Object} license The license to create.
   * @returns {null}
   */
  createLicense({ licenseId, licenseType, organizationId }) {
    return run([[queries.insert_license_log_entry, [licenseId, licenseType, organizationId]]]);
  },

  /**
   * Creates a new project permission for collaborators.
   *
   * @param {Object} project The project to add the permission to.
   * @returns {null}
   */
  createProjectPermission({ project, user, permission = 'WRITE' }) {
    return run([[queries.insert_projects_permission, [user.id, project.id, permission]]]);
  },

  /**
   * Updates an existing permission
   */
  updatePermissionAccess({ project, user, permission }) {
    return run([[queries.update_projects_permission, [permission, user.id, project.id]]]);
  }
};
