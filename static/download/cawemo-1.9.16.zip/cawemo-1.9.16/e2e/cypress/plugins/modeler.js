const fs = require('fs');

const generateConfig = (endpoint, userId, apiKey) => `{
  "plugins": {
    "camunda:cloud-connect": {
      "configuration": {
        "endpoint": "${endpoint}",
        "userId": "${userId}",
        "apiKey": "${apiKey}",
        "syncCatalogProjects": true,
        "syncDiagrams": true
      }
    }
  },
  "editor.privacyPreferences": "{}"
}`;

module.exports = {
  prepare(store) {
    fs.writeFileSync(
      `${process.cwd()}/cypress/fixtures/modeler/user-data/config.json`,
      generateConfig(process.env.CYPRESS_BASE_URL || 'http://localhost:8088', store.user.id, store.apiKey)
    );

    return null;
  }
};
