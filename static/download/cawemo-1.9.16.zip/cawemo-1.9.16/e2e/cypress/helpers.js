import { faker } from '@faker-js/faker';
import { v4 } from 'uuid';
import { ADMIN_ORGANIZATION } from '../scripts/prepare/fixtures';

export const getUser = (config = {}) => {
  const user = {
    id: config.id || getUuid(),
    iamId: getUuid(),
    name: config.name || `${faker.name.firstName()} ${faker.name.lastName()}`,
    // IAM expects emails to be lowercase before inserted in the DB, otherwise login will fail
    email:
      config && config.email
        ? config.email.toLowerCase()
        : faker.internet.email(faker.name.firstName(), faker.name.lastName(), 'example.com').toLowerCase(),
    password: config && config.password ? config.password : faker.internet.password(),
    verified: false
  };

  user.organization = isEnterprise()
    ? {
        // Users in enterprise don't have their own organization; we just store here the reference to the single
        // existing organization (created in scripts/prepare/index.js) so it can be used to create projects or diagrams.
        id: ADMIN_ORGANIZATION.id
      }
    : {
        id: config.organizationId ? config.organizationId : getUuid(),
        name: `${user.name}'s Organization`
      };

  if (config && config.withUsername) {
    user.username = faker.internet.userName();
  }

  user.segment = config?.segment;

  return user;
};

export const getUuid = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (char) => {
    const random = (Math.random() * 16) | 0;
    const result = char == 'x' ? random : (random & 0x3) | 0x8;

    return result.toString(16);
  });
};

export const getNameFor = (prefix) => `[${prefix}] ${faker.lorem.words()}`;

export const getEmail = () => getUser().email;

export const getUserName = () => faker.internet.userName();

export const getPassword = () => faker.internet.password();

export const getComment = () => faker.lorem.sentence();

export const getURL = () => faker.internet.url();

export const getMention = () => `@${faker.internet.userName()}`;

export const isEnterprise = () => Cypress.env('PRODUCT_CONTEXT') === 'enterprise';

export const isSaaS = () => Cypress.env('PRODUCT_CONTEXT') === 'saas' || !isEnterprise();

export const isLdapEnabled = () => Cypress.env('FEATURE_LDAP_ENABLED');

export const getBaseUrl = (path = '') => `${Cypress.config('baseUrl')}/${path}`;

export const getIamBaseUrl = (path = '') => `${Cypress.env('IAM_BASE_URL')}/${path}`;

export const getRandomDiagram = (
  relationId = v4(),
  processId = `Process_${v4()}`,
  generateXMLWithoutProcessId = false
) => {
  const processIdNode = generateXMLWithoutProcessId
    ? `<bpmn:collaboration id="Collaboration_0qoogmv">
      <bpmn:participant id="Participant_1qtw8tk" />
    </bpmn:collaboration>`
    : `<bpmn:process id="${processId}" isExecutable="true">
      <bpmn:startEvent id="StartEvent_1" />
    </bpmn:process>`;

  return `<?xml version="1.0" encoding="UTF-8"?>
<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" id="Definitions_1" targetNamespace="http://bpmn.io/schema/bpmn" xmlns:camunda="http://camunda.org/schema/1.0/bpmn" camunda:diagramRelationId="${relationId}">
  ${processIdNode}
  <bpmndi:BPMNDiagram id="BPMNDiagram_1">
    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_1">
      <bpmndi:BPMNShape id="_BPMNShape_StartEvent_2" bpmnElement="StartEvent_1">
        <dc:Bounds x="150" y="100" width="36" height="36" />
      </bpmndi:BPMNShape>
    </bpmndi:BPMNPlane>
  </bpmndi:BPMNDiagram>
</bpmn:definitions>
  `;
};

export const getDmnDiagram = () => {
  return `<?xml version="1.0" encoding="UTF-8"?>
<definitions xmlns="https://www.omg.org/spec/DMN/20191111/MODEL/" xmlns:dmndi="https://www.omg.org/spec/DMN/20191111/DMNDI/" xmlns:dc="http://www.omg.org/spec/DMN/20180521/DC/" id="Definitions_${v4()}" name="DRD" namespace="http://camunda.org/schema/1.0/dmn" camunda:diagramRelationId="${v4()}">
  <decision id="Decision_0vslh6y" name="Decision 1">
    <decisionTable id="DecisionTable_0azx1hv">
      <input id="Input_1">
        <inputExpression id="InputExpression_1" typeRef="string">
          <text></text>
        </inputExpression>
      </input>
      <output id="Output_1" typeRef="string" />
    </decisionTable>
  </decision>
  <dmndi:DMNDI>
    <dmndi:DMNDiagram>
      <dmndi:DMNShape dmnElementRef="Decision_0vslh6y">
        <dc:Bounds height="80" width="180" x="160" y="100" />
      </dmndi:DMNShape>
    </dmndi:DMNDiagram>
  </dmndi:DMNDI>
</definitions>
`;
};

export const getRandomRpaTemplate = (type) => {
  if (type === 'TEMPLATE_GENERIC') {
    return `{
    "$schema": "https://unpkg.com/@camunda/element-templates-json-schema@0.3.0/resources/schema.json",
    "name":"New Generic template",
    "description": "",
    "id":"<Cawemo UID>",
    "appliesTo":[
      "bpmn:ServiceTask"
    ],
    "properties":[]
  }`;
  } else {
    return `{
    "$schema": "https://unpkg.com/@camunda/element-templates-json-schema@0.3.0/resources/schema.json",
    "name":"New UiPath template",
    "description": "",
    "id":"",
    "appliesTo":[
      "bpmn:ServiceTask"
    ],
    "properties":[
      {
        "label": "UiPath Package Name",
        "type": "String",
        "value": "",
        "editable": false,
        "binding": {
          "type": "camunda:property",
          "name": "bot"
        }
      }, {
        "type":"Hidden",
        "value":"external",
        "binding":{
          "type":"property",
          "name":"camunda:type"
        }
      }, {
        "type": "Hidden",
        "value": "uipath",
        "binding": {
          "type": "property",
          "name": "camunda:topic"
        }
      }, {
        "type":"Hidden",
        "value":"true",
        "binding":{
          "type":"property",
          "name":"camunda:asyncAfter"
        }
      }
    ]
  }`;
  }
};

export const getProcessIdFromXML = (xml) => {
  const processIdNode = xml.split('<bpmn:process id="')[1];

  if (!processIdNode) {
    return;
  }

  return processIdNode.split('"')[0];
};

export const getProcessRefsFromXML = (xml) => {
  const processRefNode = xml.split('processRef="')[1];

  if (!processRefNode) {
    return;
  }

  return processRefNode.split('"')[0];
};

export const sanitizeName = (name = '') => {
  const invalidChars = /[\/?<>\\:*|"']/g; // Invalid characters in filenames
  return name.replace(invalidChars, '_');
};
