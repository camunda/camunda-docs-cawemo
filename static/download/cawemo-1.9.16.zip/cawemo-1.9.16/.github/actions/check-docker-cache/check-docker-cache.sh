#!/usr/bin/env bash

set -euo pipefail

# Usage: exportVariable NAME
#   export NAME along with its value to GITHUB_ENV
function exportVariable() {
    echo "${1}=${!1}" >> "${GITHUB_ENV:-/dev/stdout}"
}

REGISTRY_PATH=registry.camunda.cloud/cawemo-saas
SUFFIXED_IMAGE_NAME=${IMAGE_NAME}
if [ "$IMAGE_NAME" == "restapi" ]; then
    SUFFIXED_IMAGE_NAME="$IMAGE_NAME-$PRODUCT_CONTEXT"
fi
DOCKER_IMAGE=${REGISTRY_PATH}/${SUFFIXED_IMAGE_NAME}

# shellcheck disable=SC2086 disable=SC2207
SOURCES_HASH=($(git ls-files ${DETECT_CHANGES_IN} | xargs -r -n1 sha256sum | sha256sum))
# shellcheck disable=SC2128
DOCKER_CACHE_TAG=${DOCKER_IMAGE}:ci-cache-${SOURCES_HASH}
DOCKER_TAG=${DOCKER_IMAGE}:ci-${GITHUB_SHA}

exportVariable DOCKER_IMAGE
exportVariable DOCKER_CACHE_TAG
exportVariable DOCKER_TAG

if [ "${GITHUB_REF}" = "refs/heads/master" ]; then
    echo ::notice::skipping caching for master builds
    exit 1
elif [[ "$IMAGE_NAME" == "restapi" ]]; then
    echo ::notice::skipping caching for restapi image
    exit 1
elif [[ "${IMAGE_NAME}" == "webapp" ]]; then
    echo ::notice::skipping caching for webapp image
    exit 1
fi

function buildCacheImage() {
    mkdir build-cache-image
    pushd build-cache-image
    echo git.commit.id="${GITHUB_SHA}" > git.properties
    echo ::notice::updating Commit in Docker image
    printf "FROM %s\nCOPY git.properties .\n" "${DOCKER_CACHE_TAG}" > Dockerfile.cache-image
    docker build -t "${DOCKER_TAG}" -f Dockerfile.cache-image .
    popd
}

echo ::debug::trying to find cache image "${DOCKER_CACHE_TAG}"
if docker pull "${DOCKER_CACHE_TAG}" &> /dev/null; then
    echo ::notice::found cache image, pushing as "${DOCKER_TAG}"
    buildCacheImage
    docker push "${DOCKER_TAG}"
    exit 0
else
    echo ::notice::cache not found
    exit 1
fi
