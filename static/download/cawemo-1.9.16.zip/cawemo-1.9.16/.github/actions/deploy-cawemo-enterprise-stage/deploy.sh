#!/bin/bash

set -euxo pipefail

source "$(dirname "${BASH_SOURCE[0]}")/helpers.sh"

cat <<EOF > "${KUBECONFIG}"
---
apiVersion: v1
kind: Config
preferences: {}

clusters:
- cluster:
    certificate-authority-data: LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSURLakNDQWhLZ0F3SUJBZ0lRRG9TcDloUlpaQVJ6d1BSeDVWUDJkVEFOQmdrcWhraUc5dzBCQVFzRkFEQXYKTVMwd0t3WURWUVFERXlSbE5UTm1aRE5tTnkwMVlqQTJMVFJsT0RndFltTTFOQzAwTURZNVpUazNOamszWVRZdwpIaGNOTWpFd05qQTVNRFV5TlRNeVdoY05Nall3TmpBNE1EWXlOVE15V2pBdk1TMHdLd1lEVlFRREV5UmxOVE5tClpETm1OeTAxWWpBMkxUUmxPRGd0WW1NMU5DMDBNRFk1WlRrM05qazNZVFl3Z2dFaU1BMEdDU3FHU0liM0RRRUIKQVFVQUE0SUJEd0F3Z2dFS0FvSUJBUUNJN0tMNHdhbU9ud0psWXRtak9jRStzTGNHejlVNmJvOUhCMWJ2UWZZeQo2VWdqOUtGcG5KUFQyVnVOak9CTk1wTmZrVisvckd2bitKaFFYaHorU3dTNElkZW9vcXdlQTgxSllydGxqckMyCituRytWK1p6cHQ4YUJINzB2MDBOemw4VW1nVkxzem8wTTk1c1NuREV0bnVjb1RuUlA4bmVScXBNL2taN3F2SUMKQTZsQXhteWRsM3pnODg4dkM2b2RqT3hXUUVITzlEVmdTTVYwOUMzOVM5VjArZkl0Z3ZxNDkzZlpKdHdPRUNxQwpJNFMxOTFZSVhxUkp5Nmc0MTd5T1ZNN202UXFucDB5c2pacDZGbExDWFcyaUVXRXVLMGM0anBVL09nR3JYaUYrCi9qRStkdk5FMVd2b1ZPeVNJRFpqS0hUSGFPeE1qVmdtZUl0L0I1TjRoOU10QWdNQkFBR2pRakJBTUE0R0ExVWQKRHdFQi93UUVBd0lDQkRBUEJnTlZIUk1CQWY4RUJUQURBUUgvTUIwR0ExVWREZ1FXQkJSbGl1akZCRnRIWDhRNwpaajF2R040WnpzRzQxekFOQmdrcWhraUc5dzBCQVFzRkFBT0NBUUVBVVY1cXhVSlVHaHpyL1RFSXR6NEloNEx1Ci84MmMyNWIzZmZFbEpYMi9zWU5SK1U0S2tiMGE5bXVwN3I3blF1cGZUM2JQTmFCSjlBeXBVcU9VK3dCN01PZlMKaTNkVGF3a3BvaHo3Q0xTTHhvc3VmVUMvdEZyZTFSV2hCM1p0d05vVGtLR0dFb0Nob1FTVnYwU1RzWWQ5T24vQgpCeWZMZzk1cGJKQ0M3bTFpcGVzdDljdDl5TGZOSjdHNjRHYnBrL1JuVXgzNGV4TUc0T25PTkFwS3lucVp6U3RSCnE1SkJrWmZMcFBRUklEM2pFSUJiMFRoUkNua05HNTZ5MkU3V05wbGM3Y1RleVllS2pVLzJTbTJPS1lxOXBFTmMKMzJ5b0FDRm81RVBMK3QvVDNDK3dLa2FoekxQbmxFalpUM3A2QUFlZ1NkRys2Rlo4a1U2MmdBYTFjWlR2UGc9PQotLS0tLUVORCBDRVJUSUZJQ0FURS0tLS0tCg==
    server: https://34.78.105.125
  name: camunda-ci

contexts:
- context:
    cluster: camunda-ci
    namespace: cawemo
    user: camunda-ci
  name: camunda-ci

current-context: camunda-ci

# Source: https://jeremievallee.com/2018/05/28/kubernetes-rbac-namespace-user.html
# Get credetials via:
#   kubectl describe sa cawemo -n cawemo
#   kubectl get secret cawemo-token-XXXXX -n cawemo -o "jsonpath={.data.token}" | base64 -d
users:
- name: camunda-ci
  user:
    as-user-extra: {}
    client-key-data: LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSURLakNDQWhLZ0F3SUJBZ0lRRG9TcDloUlpaQVJ6d1BSeDVWUDJkVEFOQmdrcWhraUc5dzBCQVFzRkFEQXYKTVMwd0t3WURWUVFERXlSbE5UTm1aRE5tTnkwMVlqQTJMVFJsT0RndFltTTFOQzAwTURZNVpUazNOamszWVRZdwpIaGNOTWpFd05qQTVNRFV5TlRNeVdoY05Nall3TmpBNE1EWXlOVE15V2pBdk1TMHdLd1lEVlFRREV5UmxOVE5tClpETm1OeTAxWWpBMkxUUmxPRGd0WW1NMU5DMDBNRFk1WlRrM05qazNZVFl3Z2dFaU1BMEdDU3FHU0liM0RRRUIKQVFVQUE0SUJEd0F3Z2dFS0FvSUJBUUNJN0tMNHdhbU9ud0psWXRtak9jRStzTGNHejlVNmJvOUhCMWJ2UWZZeQo2VWdqOUtGcG5KUFQyVnVOak9CTk1wTmZrVisvckd2bitKaFFYaHorU3dTNElkZW9vcXdlQTgxSllydGxqckMyCituRytWK1p6cHQ4YUJINzB2MDBOemw4VW1nVkxzem8wTTk1c1NuREV0bnVjb1RuUlA4bmVScXBNL2taN3F2SUMKQTZsQXhteWRsM3pnODg4dkM2b2RqT3hXUUVITzlEVmdTTVYwOUMzOVM5VjArZkl0Z3ZxNDkzZlpKdHdPRUNxQwpJNFMxOTFZSVhxUkp5Nmc0MTd5T1ZNN202UXFucDB5c2pacDZGbExDWFcyaUVXRXVLMGM0anBVL09nR3JYaUYrCi9qRStkdk5FMVd2b1ZPeVNJRFpqS0hUSGFPeE1qVmdtZUl0L0I1TjRoOU10QWdNQkFBR2pRakJBTUE0R0ExVWQKRHdFQi93UUVBd0lDQkRBUEJnTlZIUk1CQWY4RUJUQURBUUgvTUIwR0ExVWREZ1FXQkJSbGl1akZCRnRIWDhRNwpaajF2R040WnpzRzQxekFOQmdrcWhraUc5dzBCQVFzRkFBT0NBUUVBVVY1cXhVSlVHaHpyL1RFSXR6NEloNEx1Ci84MmMyNWIzZmZFbEpYMi9zWU5SK1U0S2tiMGE5bXVwN3I3blF1cGZUM2JQTmFCSjlBeXBVcU9VK3dCN01PZlMKaTNkVGF3a3BvaHo3Q0xTTHhvc3VmVUMvdEZyZTFSV2hCM1p0d05vVGtLR0dFb0Nob1FTVnYwU1RzWWQ5T24vQgpCeWZMZzk1cGJKQ0M3bTFpcGVzdDljdDl5TGZOSjdHNjRHYnBrL1JuVXgzNGV4TUc0T25PTkFwS3lucVp6U3RSCnE1SkJrWmZMcFBRUklEM2pFSUJiMFRoUkNua05HNTZ5MkU3V05wbGM3Y1RleVllS2pVLzJTbTJPS1lxOXBFTmMKMzJ5b0FDRm81RVBMK3QvVDNDK3dLa2FoekxQbmxFalpUM3A2QUFlZ1NkRys2Rlo4a1U2MmdBYTFjWlR2UGc9PQotLS0tLUVORCBDRVJUSUZJQ0FURS0tLS0tCg==
    token: @TOKEN@
EOF

sed -i "s/@TOKEN@/${TOKEN}/g" "${KUBECONFIG}"

kubectl version

###############################################################################
# Deployment
###############################################################################

if [ "${FEATURE_LDAP}" == "true" ]; then
  TEMPLATE_LOCATION="infrastructure/camunda-ci/stage-ldap.cawemo.camunda.cloud"

  applyDeployment ${TEMPLATE_LOCATION}/deployment-ldap-template.yml
  applyDeployment ${TEMPLATE_LOCATION}/deployment-phpldapadmin-template.yml
else
  TEMPLATE_LOCATION="infrastructure/camunda-ci/stage.cawemo.camunda.cloud"
fi

applyResource ${TEMPLATE_LOCATION}/certificate-template.yml
applyResource ${TEMPLATE_LOCATION}/configmap-template.yml
applyResource ${TEMPLATE_LOCATION}/ingress-template.yml
applyResource ${TEMPLATE_LOCATION}/sa-template.yml
applyResource ${TEMPLATE_LOCATION}/secrets-template.yml
applyResource ${TEMPLATE_LOCATION}/services-template.yml

applyDeployment ${TEMPLATE_LOCATION}/deployment-iam-template.yml
applyDeployment ${TEMPLATE_LOCATION}/deployment-pusher-template.yml
applyDeployment ${TEMPLATE_LOCATION}/deployment-restapi-template.yml
applyDeployment ${TEMPLATE_LOCATION}/deployment-webapp-template.yml
