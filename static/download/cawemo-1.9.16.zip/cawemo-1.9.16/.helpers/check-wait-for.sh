#!/bin/sh

: ${SLEEP_LENGTH:=2}
: ${TIMEOUT_LENGTH:=300}

for var in "$@"
do
  HOST=${var%:*}
  PORT=${var#*:}
  timeout ${TIMEOUT_LENGTH} sh -c "until nc -zv $HOST $PORT; do echo '$HOST $PORT not online yet' >/dev/stderr; sleep $SLEEP_LENGTH; done"
done
