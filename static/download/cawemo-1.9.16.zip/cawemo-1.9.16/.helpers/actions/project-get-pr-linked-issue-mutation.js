#!/usr/bin/env node

let fs = require('fs');
let args = process.argv.slice(2);

if (!args || args.length === 0) {
  console.error("Please provide args: $projectId $fieldId $fieldValue $linkedIssuesData");
  process.exit(1);
} else if (!args[0]) {
  console.error("Please provide a projectId");
  process.exit(1);
} else if (!args[1]) {
  console.error("Please provide a fieldId");
  process.exit(1);
} else if (!args[2]) {
  console.error("Please provide a field value");
  process.exit(1);
} else if (!args[3]) {
  console.error("Please provide linked issue data");
  process.exit(1);
}

let projectId = args[0];
let fieldId = args[1];
let fieldStatus = args[2]
let fileName = args[3];

// Check that the file exists locally
if (!fs.existsSync(fileName)) {
  console.info("There are no cards to mutate.")
  process.exit(0);
}

let fileContent = JSON.parse(fs.readFileSync(fileName, 'utf8'));

if (!fileContent || Object.keys(fileContent).length === 0) {
  console.info("There are no linked issues to mutate.")
  process.exit(0);
}

const issueProjectNodeIds = fileContent?.data?.repository?.pullRequest?.closingIssuesReferences?.nodes
    // filter only issue node ids that contain a project item matching our project id
    .map(issueNode => issueNode.projectItems?.nodes?.find(projectItemNode => projectItemNode?.project?.id === projectId).id)
    .filter(projectItem => projectItem);

let projectMutation = "";
issueProjectNodeIds.forEach(issue => {
  projectMutation += `item${issue}: updateProjectV2ItemFieldValue(
    input: {
      projectId: \"${projectId}\",
      itemId: \"${issue}\",
      fieldId: \"${fieldId}\",
      value: {
        singleSelectOptionId: \"${fieldStatus}\"
        }
    }) { 
      projectV2Item {
        id
      }
    }`;
});

if (projectMutation === "") {
  console.info("There are no linked issues.")
}

console.log(projectMutation);
