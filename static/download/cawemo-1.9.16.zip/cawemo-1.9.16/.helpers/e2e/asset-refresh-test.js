#!/bin/env node
/**
 * This script implements the asset-refresh test workflow:
 * 1. start docker-compose with VERSION_FROM
 * 2. start the Cypress test and wait for it to be ready
 * 3. start docker-compose with VERSION_TO
 * 4. wait for Cypress test to return with success, or a timeout occurs.
 */

const STATUS = { ERROR_USAGE: 251, CYPRESS_NOT_READY: 252, YARN_EARLY_EXIT: 253, YARN_TIMEOUT: 254, ERROR_OTHER: 255 };

const CYPRESS_GRACE_TIME = 90 * 1000,
  CYPRESS_EARLY_EXIT = 60 * 1000,
  CYPRESS_TIMEOUT = 180 * 1000;


const {versionFrom, versionTo, productContext} = parseArguments(process.argv);
testMigration(versionFrom, versionTo, productContext)

/**
 * Main business logic:
 *    * deploy {versionFrom}
 *    * start the Cypress test
 *    * once it signals readiness, deploy {versionTo}
 * @param {string} versionFrom
 * @param {string} versionTo
 * @param {string} productContext
 */
async function testMigration(versionFrom, versionTo, productContext) {
  log(`Testing migration from ${versionFrom} to ${versionTo}...`);
  await deployVersion(versionFrom, productContext);
  await runCypressTest(() => deployVersion(versionTo, productContext));
  log(`Migration from ${versionFrom} to ${versionTo} successful!`);
}

/**
 * The heart of the test.
 * After spawning yarn, it will wait for Cypress to become ready and call {deployCallback} to trigger the next deployment.
 * Possible reasons to throw:
 *   * Cypress doesn't become ready within {graceTime}
 *   * General error running yarn
 *   * Cypress test fails or runs longer than {timeout}
 * @param {CallableFunction} deployCallback should return a Promise
 * @returns
 */
async function runCypressTest(deployCallback) {
  const { exec } = require("child_process");

  yarn = exec("npx yarn test-asset-refresh", { cwd: "e2e", timeout: CYPRESS_TIMEOUT , env: process.env});
  yarn.stderr.pipe(process.stderr);
  yarn.stdout.pipe(process.stdout);

  try {
    await whileYarnIsRunning(yarn, async () => {
      await waitForCypressReadiness(CYPRESS_GRACE_TIME);
      await deployCallback();
    });
  } catch (error) {
    console.error(error);
    return process.exit(STATUS.ERROR_OTHER);
  }
}
/**
 * Deploy {version} using a well-known make target for {productContext}
 * @param {string} version
 * @param {string} productContext
 */
async function deployVersion(version, productContext) {
  const { exec } = require("child_process");

  const makeTarget = `docker-compose-asset-refresh-${productContext}`;
  make = exec("make -C e2e " + makeTarget, {
    env: {
      ...process.env,
      COMMIT_SHA: version,
    },
  });
  make.stderr.pipe(process.stderr);
  make.stdout.pipe(process.stdout);

  const exitCode = await new Promise((resolve, _reject) => {
    make.on("exit", resolve);
  });
  if (exitCode != 0) {
    console.error("make failed with status", exitCode);
    process.exit(exitCode);
  }
}

/**
 * @param {string} path to watch
 * @param {Number} timeout in milliseconds
 * @throws Error when timeout expired
 **/
async function waitUntilFileCreated(path, timeout) {
  const { watch } = require("fs");
  const { dirname, basename } = require("path");

  return await new Promise((resolve, reject) => {
    const watcher = watch(dirname(path));
    const watchdog = setTimeout(() => {
      watcher.close();
      reject(new Error(`Timeout expired (${timeout}ms)`));
    }, timeout);
    watcher.on("error", (err) => {
      clearTimeout(watchdog);
      reject(err);
    });
    watcher.on("change", (eventType, filename) => {
      if (filename == basename(path)) {
        log(`FS event "${eventType}": ${filename}`);
        clearTimeout(watchdog);
        watcher.close();
        resolve(eventType);
      }
    });
  });
}

/**
 * Wait for Cypress to become ready, using a signaling file (hardcoded for now).
 * Returns when file is created or changed in any way.
 * @param {Number} timeout in milliseconds
 */
async function waitForCypressReadiness(timeout) {
  const signalingFile = "/tmp/asset-refresh.json";
  try {
    await waitUntilFileCreated(signalingFile, timeout);
  } catch (err) {
    console.error("Cypress did not get ready in time", err);
    process.exit(STATUS.CYPRESS_NOT_READY);
  }
}

/**
 * Handles the logic of waiting for yarn's result and running other things meanwhile, by calling {subtasksCallback}.
 * Any errors thrown by subtasksCallback are not caught, so they will bubble up.
 * It will as well detect an "early exit" of yarn, which might happen in case of syntax errors and the like.
 * @param {ChildProcess} yarn a previously spawned ChildProcess.
 * @param {CallableFunction} subtasksCallback - should return a promise.
 */
async function whileYarnIsRunning(yarn, subtasksCallback) {
  const t0 = new Date();
  const yarnResult = new Promise((resolve, reject) => {
    yarn.on("error", reject);
    yarn.on("exit", (statusCode, signal) => {
      const dT = new Date() - t0;
      if (dT < CYPRESS_EARLY_EXIT) {
        console.error("yarn exited early after", `${dT} ms`);
        return reject(STATUS.YARN_EARLY_EXIT);
      }
      if (signal) {
        console.error("yarn terminated by", signal);
        return resolve(STATUS.YARN_TIMEOUT);
      }
      resolve(statusCode);
    });
  });

  await subtasksCallback();
  const statusCode = await yarnResult;
  if (statusCode !== 0) {
    console.error("yarn failed with status", statusCode);
    process.nextTick(() => process.exit(statusCode));
  }
}
/**
 * @param {string[]} argv Argument list to parse. Expecting first two elements to be interpreter and program.
 * @returns {{versionFrom: string, versionTo: string, productContext: string}} arguments parsed into an Object
 */
function parseArguments(argv) {
  const {basename}= require('path');
  const program = basename(argv[1]);
  const params = argv.slice(2);
  if (params.length != 3) {
    console.error(`Error: invalid number of arguments (${params.length}).`);
    log(`Usage:\n${program} VERSION_FROM VERSION_TO PRODUCT_CONTEXT`);
    return process.exit(STATUS.ERROR_USAGE);
  }
  return {
    versionFrom: params[0],
    versionTo: params[1],
    productContext: params[2],
  }
}

function log(...args) {
  console.info("[asset-refresh]", ...args)
}


