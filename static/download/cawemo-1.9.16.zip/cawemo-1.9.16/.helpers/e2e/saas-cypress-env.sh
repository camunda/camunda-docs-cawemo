#!/bin/bash

source "$(dirname $0)/common-cypress-env.sh"

export CYPRESS_PRODUCT_CONTEXT=saas

exec "$@"
