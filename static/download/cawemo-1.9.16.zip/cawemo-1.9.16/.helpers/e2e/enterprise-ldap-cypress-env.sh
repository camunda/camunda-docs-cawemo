#!/bin/bash

source "$(dirname $0)/common-cypress-env.sh"

export CYPRESS_PRODUCT_CONTEXT=enterprise
export CYPRESS_FEATURE_LDAP_ENABLED=true

export CYPRESS_LDAP_SERVER_URL=${CYPRESS_LDAP_SERVER_URL:-"ldap://localhost"}
export CYPRESS_LDAP_MANAGER_DN=${CYPRESS_LDAP_MANAGER_DN:-"cn=admin,dc=example,dc=com"}
export CYPRESS_MANAGER_PASSWORD=${CYPRESS_MANAGER_PASSWORD:-"camunda123"}

exec "$@"
