#!/bin/bash

# This script checks whether a Github Pull Request exists for the current branch.
# If this is the case this script prints "true" and otherwise "false". It should
# always exit with exit code 0.

REPO="camunda/cawemo"

current_branch=$(git rev-parse --abbrev-ref HEAD)

# filtering for PRs from current branch to any should yield a non-empty array
curl -sS -X GET "https://api.github.com/repos/${REPO}/pulls?state=all&head=${REPO}:${current_branch}" \
    -H 'Accept: application/vnd.github.ant-man-preview+json' \
    -u "${GITHUB_ACCESS_TOKEN}:" | jq '.[0] != null'
