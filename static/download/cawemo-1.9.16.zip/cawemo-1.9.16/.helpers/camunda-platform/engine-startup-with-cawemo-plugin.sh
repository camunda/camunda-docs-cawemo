#!/bin/bash
wget https://releases.jfrog.io/artifactory/jfrog-cli/v2/[RELEASE]/jfrog-cli-linux-amd64/jfrog
chmod +x jfrog
./jfrog rt dl camunda-bpm-ee/org/camunda/bpm/cawemo-engine-plugin/${ENGINE_PLUGIN_VERSION}/cawemo-engine-plugin-${ENGINE_PLUGIN_VERSION}.jar --url=https://artifacts.camunda.com/artifactory --user="${NEXUS_USER}" --password="${NEXUS_PASSWORD}" --quiet --flat
mv cawemo-engine-plugin-${ENGINE_PLUGIN_VERSION}.jar lib/
rm -rf conf/bpm-platform.xml
cp bpm-platform-with-cawemo-plugin.xml conf/bpm-platform.xml
/camunda/camunda.sh
