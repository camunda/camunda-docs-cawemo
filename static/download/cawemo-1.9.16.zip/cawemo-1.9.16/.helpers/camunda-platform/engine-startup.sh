#!/bin/bash
rm -rf conf/bpm-platform.xml
cp bpm-platform.xml conf/bpm-platform.xml
/camunda/camunda.sh
