/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.base;

import com.cawemo.data.dto.base.response.TokenDto;
import com.cawemo.data.entity.Token;
import com.cawemo.service.token.TokenMapper;
import com.cawemo.util.swagger.SwaggerUuidParameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Token")
@RestController
@RequiredArgsConstructor
public class TokenController implements InternalApiController {

  private final TokenMapper tokenMapper;

  // not proxied - no authorization required
  @GetMapping(value = "/tokens/{tokenId}", produces = MediaType.APPLICATION_JSON_VALUE)
  public TokenDto getToken(@SwaggerUuidParameter @PathVariable("tokenId") Token token) {
    return tokenMapper.asDtoWithTypeOnly(token);
  }
}
