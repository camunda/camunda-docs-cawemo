/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.data.dto.base.request.AttentionGrabberDto;
import com.cawemo.data.dto.base.request.DiagramMigrateDto;
import com.cawemo.data.dto.base.request.FileCreateDto;
import com.cawemo.data.dto.base.request.FileCreateFromMilestoneDto;
import com.cawemo.data.dto.base.request.FileUpdateDto;
import com.cawemo.data.dto.base.request.FilesMoveDto;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.FileLink;
import com.cawemo.data.entity.Folder;
import com.cawemo.data.entity.Milestone;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.User;
import com.cawemo.data.projection.FileWithoutContent;
import com.cawemo.data.repository.FileLinkRepository;
import com.cawemo.data.repository.FileRepository;
import com.cawemo.data.repository.FolderRepository;
import com.cawemo.data.repository.ProjectRepository;
import com.cawemo.data.validation.ValidJsonTemplateValidator;
import com.cawemo.service.pusher.PusherService;
import com.cawemo.util.Constants;
import com.cawemo.util.api.ApiError;
import com.cawemo.util.api.ApiWarning;
import com.cawemo.util.api.BadRequestException;
import com.cawemo.util.api.CrossOrganizationOperationForbiddenException;
import com.cawemo.util.api.ForbiddenException;
import com.cawemo.util.api.NoSuchObjectException;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;

@Service
@RequiredArgsConstructor
public class FileService {

  private static final String FILE_COPY_SUFFIX = " - Copy";
  private static final String NAMED_MILESTONE_COPY_SUFFIX = " - Copy of %s '%s'";
  private static final String UNNAMED_MILESTONE_COPY_SUFFIX = " - Copy of unnamed %s";

  private final ApplicationEventPublisher applicationEventPublisher;
  private final FileLinkMapper fileLinkMapper;
  private final FileLinkRepository fileLinkRepository;
  private final FileMapper fileMapper;
  private final FileRepository fileRepository;
  private final FolderRepository folderRepository;
  private final ProjectRepository projectRepository;
  private final PusherService pusherService;
  private final TransactionTemplate transactionTemplate;

  private final Map<FileType, Function<String, Boolean>> contentValidators = Map.of(
    FileType.BPMN, bpmn -> true, // ValidBpmnValidator::isValid TODO #6541 BPMN validation temporarily disabled
    FileType.DMN, dmn -> true, // currently no content validation for DMN
    FileType.TEMPLATE_GENERIC, ValidJsonTemplateValidator::isValid,
    FileType.TEMPLATE_SERVICE_TASK, ValidJsonTemplateValidator::isValid
  );

  private final Map<FileType, FileType> allowedTypeChanges = Map.of(
    FileType.TEMPLATE_SERVICE_TASK, FileType.TEMPLATE_GENERIC
  );

  public File getFile(String fileId) {
    return fileRepository.findById(fileId).orElseThrow(NoSuchObjectException::new);
  }

  public File createFile(File file) {
    return fileRepository.save(file);
  }

  public File createFile(FileCreateDto dto) {
    var folder = getFolder(dto.getFolderId(), dto.getProjectId());
    var project = getProject(folder, dto.getProjectId());

    var file = fileMapper.asFile(dto, project, folder);
    return createFile(file);
  }

  public void deleteFile(File file) {
    fileRepository.delete(file);
  }

  public void batchDeleteFiles(List<String> fileIds) {
    var files = fileRepository.findAllById(fileIds);
    fileRepository.deleteAll(files);
  }

  public Set<ApiWarning> getDeleteFilesSideEffectWarnings(Collection<File> files) {
    var warnings = new HashSet<>(getMoveFilesSideEffectWarnings(files));
    files.forEach(file -> {
      if (!file.getComments().isEmpty()) {
        warnings.add(ApiWarning.COMMENTS);
      }

      if (file.getShare() != null) {
        warnings.add(ApiWarning.SHARED_LINK);
      }
    });

    return warnings;
  }

  public List<File> duplicateFiles(List<String> duplicateList) {
    var files = fileRepository.findAllById(duplicateList);
    return files
      .stream()
      .map(this::duplicateFile)
      .toList();
  }

  public File updateFile(File file, User user, String originAppInstanceId) {
    try {
      var updatedFile = fileRepository.save(file);
      // publish an application event where a file update pusher message is sent to avoid passing an outdated
      // revision in case this method runs within a transaction
      applicationEventPublisher.publishEvent(new FileUpdateEvent(updatedFile, user, originAppInstanceId));
      return updatedFile;
    } catch (ObjectOptimisticLockingFailureException e) {
      throw new FileConflictException();
    }
  }

  public File updateFile(File file, User user, FileUpdateDto fileUpdateDto) {
    validateFileUpdateContent(file.getType(), fileUpdateDto.getContent());
    validateFileUpdateType(file.getType(), fileUpdateDto.getType());

    // an attached entity cannot be manipulated with optimistic lock, thus a clone with a new revision is created
    var fileClone = fileMapper.asClone(file);
    var updateFromDto = fileMapper.updateFromDto(fileClone, fileUpdateDto);

    return updateFile(updateFromDto, user, fileUpdateDto.getOriginAppInstanceId());
  }

  public void updateFile(File file, String content) {
    fileRepository.save(file.setContent(content));
  }

  public File createFromMilestone(Milestone milestone, FileCreateFromMilestoneDto dto) {
    var file = milestone.getFile();
    if (file.getType() == FileType.BPMN && StringUtils.isBlank(dto.getProcessId())) {
      throw new BadRequestException(ApiError.INVALID_INPUT);
    }

    var targetFolder = (dto.getTargetFolderId() == null) ? null :
      folderRepository
        .findById(dto.getTargetFolderId())
        .orElseThrow(NoSuchObjectException::new);
    var targetProject = getProject(dto, file, targetFolder);

    ensureNoCrossOrganizationOperation(targetProject, file);

    var copyFile = fileMapper.asFile(dto, generateFileName(milestone), milestone, targetProject, targetFolder);
    return createFile(copyFile);
  }

  public void moveFiles(FilesMoveDto dto) {
    var targetFolder = getFolder(dto.getTargetFolderId(), dto.getTargetProjectId());
    var targetProject = getProject(targetFolder, dto.getTargetProjectId());
    var files = fileRepository.findFilesToBeMoved(dto.getFileIds(), targetProject, targetFolder);
    files.forEach(file -> {
      ensureNoCrossOrganizationOperation(targetProject, file);
      file.setProject(targetProject);
      file.setFolder(targetFolder);
    });
    fileRepository.saveAll(files);
  }

  public Set<ApiWarning> getMoveFilesSideEffectWarnings(Collection<File> files) {
    var filesByProject = files
      .stream()
      // we only want to check for call activity links and can strip out all other file types
      .filter(file -> file.getType() == FileType.BPMN)
      .collect(Collectors.groupingBy(File::getProject));

    return filesByProject
      .entrySet()
      .stream()
      .filter(entry -> areLinkTargetsNotIncludedInMoveOperation(entry.getValue(), entry.getKey()) ||
        areLinkSourcesNotIncludedInMoveOperation(entry.getValue(), entry.getKey()))
      .findAny()
      .map(e -> Set.of(ApiWarning.LINKED_DIAGRAM))
      .orElseGet(Collections::emptySet);
  }

  public void createAttentionGrabber(User user, File file, AttentionGrabberDto dto) {
    pusherService.attentionGrabberCreationNotification(user, file.getId(), dto);
  }

  public void deleteAttentionGrabber(User user, File file) {
    pusherService.attentionGrabberDeletionNotification(user, file.getId());
  }

  public List<File> patchDiagramsWithoutProcessId(List<DiagramMigrateDto> dtoList) {
    return dtoList
      .stream()
      .map(this::patchDiagramWithoutProcessId)
      .filter(Optional::isPresent)
      .map(Optional::get)
      .toList();
  }

  public List<FileLink> findLegacyFileLinksBySourceFile(File file) {
    return fileLinkRepository.findBySourceFileAndTargetFileNotNull(file);
  }

  public void deleteLegacyFileLink(FileLink fileLink) {
    if (fileLink.getTargetProcessId() != null) {
      throw new ForbiddenException(ApiError.INVALID_OPERATION, "Only legacy diagram links can be deleted");
    }
    fileLinkRepository.delete(fileLink);
  }

  public List<FileWithoutContent> findByFolder(Folder folder) {
    return fileRepository.findByFolder(folder);
  }

  private Optional<File> patchDiagramWithoutProcessId(DiagramMigrateDto dto) {
    return transactionTemplate.execute(status -> {
      // custom query so that the file's "updated" date is not touched by the AuditingEntityListener
      var updated = fileRepository.updateContentProcessIdRevisionIfProcessIdNullAndTypeBPMN(
        dto.getContent(), dto.getProcessId(), dto.getId());
      if (updated > 0) {
        var optionalDiagram = fileRepository.findById(dto.getId());
        optionalDiagram.map(diagram -> fileLinkMapper.asFileLinkList(dto.getCallActivityLinks(), diagram))
          .ifPresent(fileLinkRepository::saveAll);
        return optionalDiagram;
      }
      return Optional.empty();
    });
  }

  private File duplicateFile(File file) {
    var truncatedName = StringUtils.truncate(file.getName(), Constants.VARCHAR_MAX - FILE_COPY_SUFFIX.length());

    var copyFile = fileMapper.asDuplicate(file)
      .setName(truncatedName + FILE_COPY_SUFFIX)
      .setRelationId(Objects.requireNonNullElse(file.getRelationId(), file.getId()));

    return createFile(copyFile);
  }

  private void ensureNoCrossOrganizationOperation(Project project, File file) {
    if (!file.getProject().getOrganization().getId().equals(project.getOrganization().getId())) {
      throw new CrossOrganizationOperationForbiddenException();
    }
  }

  private Project getProject(Folder folder, String projectId) {
    return (folder != null) ? folder.getProject() :
      projectRepository
        .findById(projectId)
        .orElseThrow(NoSuchObjectException::new);
  }

  private Project getProject(FileCreateFromMilestoneDto dto, File file, Folder targetFolder) {
    Project targetProject;
    if (targetFolder != null) {
      targetProject = targetFolder.getProject();
    } else {
      if (dto.getTargetProjectId() != null) {
        targetProject = projectRepository
          .findById(dto.getTargetProjectId())
          .orElseThrow(NoSuchObjectException::new);
      } else {
        targetProject = file.getProject();
      }
    }
    return targetProject;
  }

  private Folder getFolder(String folderId, String projectId) {
    return (folderId == null) ? null :
      folderRepository
        .findByIdAndProjectId(folderId, projectId)
        .orElseThrow(NoSuchObjectException::new);
  }

  private String generateFileName(Milestone milestone) {
    var file = milestone.getFile();
    var typeName = (file.getType().getCategory() == FileTypeCategory.DIAGRAM) ? "Milestone" : "Version";
    var sourceFileName = file.getName();
    var milestoneName = milestone.getName();

    String suffix;
    if (StringUtils.isNotBlank(milestoneName)) {
      suffix = String.format(NAMED_MILESTONE_COPY_SUFFIX, typeName, milestoneName);

      // edge-case: milestoneName is so long that we cannot even include sourceFileName
      if (suffix.length() > Constants.VARCHAR_MAX) {
        var truncatedMilestoneName =
          StringUtils.truncate(milestoneName, milestoneName.length() - (suffix.length() - Constants.VARCHAR_MAX));
        return String.format(NAMED_MILESTONE_COPY_SUFFIX, typeName, truncatedMilestoneName);
      }
    } else {
      suffix = String.format(UNNAMED_MILESTONE_COPY_SUFFIX, typeName);
    }
    return StringUtils.truncate(sourceFileName, Constants.VARCHAR_MAX - suffix.length()) + suffix;
  }

  private boolean areLinkTargetsNotIncludedInMoveOperation(List<File> files, Project project) {
    var movedFileIds = files
      .stream()
      .map(File::getId)
      .collect(Collectors.toSet());

    return fileRepository.findTargetFileIdsByFileLinkSourceFilesAndProject(files, project)
      .stream()
      .anyMatch(targetFileId -> !movedFileIds.contains(targetFileId));
  }

  private boolean areLinkSourcesNotIncludedInMoveOperation(List<File> files, Project project) {
    var movedProcessIds = files
      .stream()
      .map(File::getProcessId)
      .collect(Collectors.toSet());
    var movedFileIds = files
      .stream()
      .map(File::getId)
      .collect(Collectors.toSet());

    return fileRepository.findSourceFileIdByTargetProcessIdsAndProject(movedProcessIds, project)
      .stream()
      .anyMatch(sourceFileId -> !movedFileIds.contains(sourceFileId));
  }

  private void validateFileUpdateContent(FileType type, String content) {
    // null content allowed on update (PATCH)
    if (content != null && !contentValidators.getOrDefault(type, s -> false).apply(content)) {
      throw new BadRequestException(ApiError.INVALID_INPUT, "invalid content for type " + type);
    }
  }

  private void validateFileUpdateType(FileType currentType, FileType newType) {
    if (newType != null && newType != allowedTypeChanges.get(currentType)) {
      throw new BadRequestException(ApiError.INVALID_INPUT,
        String.format("invalid type change from %s to %s", currentType, newType));
    }
  }
}
