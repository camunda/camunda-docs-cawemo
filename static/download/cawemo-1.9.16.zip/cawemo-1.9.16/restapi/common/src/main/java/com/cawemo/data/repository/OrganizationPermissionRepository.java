/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.OrganizationPermission;
import com.cawemo.data.entity.OrganizationPermissionId;
import com.cawemo.data.entity.User;
import com.cawemo.service.organization.OrganizationPermissionLevel;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrganizationPermissionRepository
  extends JpaRepository<OrganizationPermission, OrganizationPermissionId> {

  int countByIdOrganization(Organization organization);

  List<OrganizationPermission> findByIdUser(User user);

  List<OrganizationPermission> findByIdOrganizationAndAccess(Organization organization,
                                                             OrganizationPermissionLevel access);

  Optional<OrganizationPermission> findFirstByIdOrganizationAndIdUserNotAndAccessOrderByCreated(
    Organization organization, User user, OrganizationPermissionLevel access);

  Optional<OrganizationPermission> findByIdOrganizationAndIdUserEmailIgnoreCase(Organization organization,
                                                                                String email);

  boolean existsByIdOrganizationAndIdUserEmailIgnoreCase(Organization organization, String email);

  boolean existsByIdOrganizationAndIdUserNotAndAccess(Organization organization,
                                                      User user,
                                                      OrganizationPermissionLevel access);
}
