/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.organization;

import com.cawemo.data.entity.OrganizationPermission;
import com.cawemo.data.entity.User;

public interface OrganizationPermissionUpdater {

  void updatePermissionAccess(OrganizationPermission permission, OrganizationPermissionLevel newAccess,
                              User authenticatedUser);
}
