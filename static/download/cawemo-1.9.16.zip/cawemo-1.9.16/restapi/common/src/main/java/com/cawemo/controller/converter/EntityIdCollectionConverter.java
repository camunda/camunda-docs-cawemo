/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.converter;

import java.util.Collection;

public interface EntityIdCollectionConverter<T> {

  Class<T> getEntityType();

  Collection<T> convert(Collection<String> entityIds);
}
