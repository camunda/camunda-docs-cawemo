/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.base;

import com.cawemo.data.dto.base.response.UserSessionDto;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.authentication.AuthenticationService;
import com.cawemo.service.authentication.SessionMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class SessionController implements InternalApiController {

  private final AuthenticationService authenticationService;
  private final SessionMapper sessionMapper;

  /**
   * Authentication is already done by {@link com.cawemo.security.authentication.PreAuthenticatedLoginFilter}, that's
   * why the authentication principal is available here.
   */
  @PostMapping(path = "/login", produces = MediaType.APPLICATION_JSON_VALUE)
  public UserSessionDto createSession(@AuthenticationPrincipal UserAwareUserDetails userDetails) {
    var user = userDetails.getUser();
    return sessionMapper.asUserSessionDto(authenticationService.createSession(user));
  }

  /**
   * This is a dummy endpoint only used by the webapp to check whether a session is (still) valid. Incoming requests are
   * processed by {@link com.cawemo.security.authentication.cookie.SessionCookieRememberMeService} that would throw an
   * {@link org.springframework.security.web.authentication.rememberme.InvalidCookieException} in case of an invalid
   * or expired session cookie – resulting in a <code>401 Unauthorized</code> response code. If the session cookie is
   * valid <code>204 No Content</code> will be returned.
   */
  @PostMapping(path = "/sessions/validate")
  public void validateSession() {
  }
}
