/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.comment;

import com.cawemo.data.dto.base.request.CommentCreateDto;
import com.cawemo.data.dto.base.request.CommentUpdateDto;
import com.cawemo.data.dto.base.response.CommentDto;
import com.cawemo.data.entity.Comment;
import com.cawemo.data.entity.File;
import java.util.List;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueMappingStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring")
public interface CommentMapper {

  @Mapping(source = "createdBy", target = "author")
  @Mapping(source = "file.id", target = "fileId")
  @Mapping(source = "updated", target = "lastChanged")
  CommentDto asCommentDto(Comment comment);

  List<CommentDto> asCommentDtoList(List<Comment> comments);

  @Mapping(source = "dto.content", target = "content")
  @Mapping(source = "dto.reference", target = "reference")
  @Mapping(target = "created", ignore = true)
  @Mapping(target = "createdBy", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "updated", ignore = true)
  Comment asComment(File file, CommentCreateDto dto);

  @Mapping(source = "content", target = "content")
  @BeanMapping(
    ignoreByDefault = true,
    nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
  )
  Comment updateFromDto(@MappingTarget Comment comment, CommentUpdateDto dto);
}
