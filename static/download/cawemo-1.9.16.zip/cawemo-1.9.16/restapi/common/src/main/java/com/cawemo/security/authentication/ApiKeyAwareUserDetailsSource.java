/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.authentication;

import com.cawemo.data.entity.ApiKey;
import org.springframework.security.authentication.AuthenticationDetailsSource;
import org.springframework.stereotype.Component;

@Component
public class ApiKeyAwareUserDetailsSource implements AuthenticationDetailsSource<ApiKey, ApiKeyAwareUserDetails> {

  @Override
  public ApiKeyAwareUserDetails buildDetails(ApiKey apiKey) {
    return new ApiKeyAwareUserDetails(apiKey);
  }
}
