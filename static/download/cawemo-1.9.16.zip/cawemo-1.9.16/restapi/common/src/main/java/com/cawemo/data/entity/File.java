/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity;

import com.cawemo.data.entity.listener.FileEntityListener;
import com.cawemo.service.file.FileType;
import com.cawemo.util.Constants;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.Where;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(
  name = "files",
  indexes = {
    @Index(columnList = "created_by"),
    @Index(columnList = "folder_id"),
    @Index(columnList = "project_id"),
    @Index(columnList = "updated_by")
  }
)
@EntityListeners({AuditingEntityListener.class, FileEntityListener.class})
@Data
@Accessors(chain = true)
public class File implements Serializable {

  @Id
  private String id;

  @Column(nullable = false)
  private String name;

  @ManyToOne
  @JoinColumn(name = "project_id", nullable = false)
  @OnDelete(action = OnDeleteAction.CASCADE)
  private Project project;

  @ManyToOne
  @JoinColumn(name = "folder_id")
  @OnDelete(action = OnDeleteAction.CASCADE)
  private Folder folder;

  @Type(type = "org.hibernate.type.TextType")
  private String content;

  @Version
  @Column(nullable = false)
  private Integer revision;

  @Column(nullable = false)
  private String relationId;

  private String processId;

  @Column(nullable = false)
  @Enumerated(EnumType.STRING)
  private FileType type;

  @CreatedDate
  @Column(updatable = false, nullable = false)
  private ZonedDateTime created;

  @CreatedBy
  @ManyToOne
  @JoinColumn(name = "created_by", nullable = false)
  private User createdBy;

  @LastModifiedDate
  @Column(nullable = false)
  private ZonedDateTime updated;

  @LastModifiedBy
  @ManyToOne
  @JoinColumn(name = "updated_by", nullable = false)
  private User updatedBy;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "file", fetch = FetchType.LAZY)
  private List<Comment> comments;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "sourceFile", fetch = FetchType.LAZY, orphanRemoval = true)
  @Where(clause = "source_element_id IS NULL")
  private List<FileLink> linksOutgoing;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "targetFile", fetch = FetchType.LAZY)
  private List<FileLink> legacyLinksIncoming;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "file", fetch = FetchType.LAZY)
  private List<Milestone> milestones;

  @ToString.Exclude
  @OneToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "file", fetch = FetchType.LAZY)
  private FileShare share;

  @Override
  public boolean equals(Object object) {
    if (object == null) {
      return false;
    } else if (object == this) {
      return true;
    } else if (!(object instanceof File)) {
      return false;
    } else {
      return Objects.equals(this.id, ((File) object).getId());
    }
  }

  @Override
  public int hashCode() {
    return Constants.ENTITY_HASHCODE;
  }
}
