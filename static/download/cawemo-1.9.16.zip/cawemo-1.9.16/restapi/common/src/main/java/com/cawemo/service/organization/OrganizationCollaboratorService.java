/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.organization;

import com.cawemo.data.entity.Organization;
import com.cawemo.service.project.ProjectInvitationService;
import com.cawemo.service.project.ProjectInvitationWithAdmins;
import com.cawemo.service.project.ProjectPermissionService;
import com.cawemo.service.project.ProjectPermissionWithAdmins;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class OrganizationCollaboratorService {

  private final ProjectPermissionService projectPermissionService;
  private final ProjectInvitationService projectInvitationService;

  public Stream<OrganizationCollaborator> getUsersWithOrganizationPermission(Organization organization) {
    return organization
      .getOrganizationPermissions()
      .stream()
      .map(permission -> new OrganizationCollaborator(permission.getId().getUser(), permission.getAccess()));
  }

  public List<ProjectPermissionWithAdmins> findProjectPermissions(Organization organization,
                                                                  OrganizationCollaborator collaborator) {
    return Optional.ofNullable(collaborator.getId())
      .map(userId ->
        projectPermissionService.getPermissionsWithProjectAdminsForOrganizationAndUser(organization, userId))
      .orElse(Collections.emptyList());
  }

  public Stream<OrganizationCollaboratorWithStatus> getInvitedUsersWithoutOrganizationPermission(
    Organization organization) {
    return projectInvitationService.getInvitedUsersWithoutOrganizationPermission(organization)
      .stream()
      .map(OrganizationCollaboratorWithStatus::new);
  }

  public List<ProjectInvitationWithAdmins> findProjectInvitations(Organization organization,
                                                                  OrganizationCollaboratorWithStatus collaborator) {
    return projectInvitationService.getInvitationsWithProjectAdminsForOrganizationAndInvitedEmail(organization,
      collaborator.getEmail());
  }
}
