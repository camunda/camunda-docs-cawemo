/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.authentication;

import com.cawemo.data.dto.base.request.UserLoginDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LoginRequestDeserializer {

  private final ObjectMapper objectMapper;

  UserLoginDto deserializeBody(HttpServletRequest request) {
    return deserializeBody(request, UserLoginDto.class);
  }

  protected <T extends UserLoginDto> T deserializeBody(HttpServletRequest request, Class<T> dtoClass) {
    try (var reader = request.getReader()) {
      return objectMapper.readValue(reader, dtoClass);
    } catch (IOException e) {
      throw new HttpMessageNotReadableException("Failed to deserialize login request", e, null);
    }
  }
}
