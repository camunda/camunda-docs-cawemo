/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.mail.template.view;

import com.cawemo.data.entity.User;
import lombok.Getter;

@Getter
public class MentionMail extends View {

  private final String comment;
  private final String diagramLink;
  private final String settingsLink;

  public MentionMail(User user, String comment, String diagramLink, String settingsLink) {
    super("mention", user);
    this.comment = comment;
    this.diagramLink = diagramLink;
    this.settingsLink = settingsLink;
  }
}
