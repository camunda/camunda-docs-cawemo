/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller;

import java.util.EnumSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

@Component
public class ResponseStatusCodeInterceptor implements HandlerInterceptor {

  @Override
  public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
                         ModelAndView modelAndView) {
    if (isNotGetRequest(request) && isContentTypeEmpty(response) && isDefaultOKStatusCode(response)) {
      response.setStatus(HttpServletResponse.SC_NO_CONTENT);
    }
  }

  private boolean isNotGetRequest(HttpServletRequest request) {
    return EnumSet.of(HttpMethod.PATCH, HttpMethod.POST, HttpMethod.PUT, HttpMethod.DELETE)
      .contains(HttpMethod.valueOf(request.getMethod()));
  }

  private boolean isContentTypeEmpty(HttpServletResponse response) {
    return response.getContentType() == null;
  }

  private boolean isDefaultOKStatusCode(HttpServletResponse response) {
    return response.getStatus() == HttpStatus.OK.value();
  }
}
