/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.converter;

import com.cawemo.util.api.NoSuchObjectException;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.core.CollectionFactory;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.core.convert.converter.GenericConverter;
import org.springframework.stereotype.Component;

/**
 * Custom implementation of Spring's CollectionToCollection converter. Mostly does the same as the original but directly
 * calls a CollectionConverter for batch converting instead of the ConversionService. If no EntityIdCollectionConverter
 * exists for the pair to be converted an empty collection is returned.
 */
@Component
public class BatchIdCollectionToEntityCollectionConverter implements GenericConverter {

  private final Map<ConvertiblePair, EntityIdCollectionConverter<?>> convertersByPair;

  public BatchIdCollectionToEntityCollectionConverter(List<EntityIdCollectionConverter<?>> collectionConverters) {
    convertersByPair = collectionConverters
      .stream()
      .collect(Collectors.toUnmodifiableMap(converter -> new ConvertiblePair(String.class, converter.getEntityType()),
      Function.identity()));
  }

  @Override
  public Set<ConvertiblePair> getConvertibleTypes() {
    return Collections.singleton(new ConvertiblePair(Collection.class, Collection.class));
  }

  @Override
  @SuppressWarnings("unchecked")
  public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
    if (source == null) {
      return null;
    }
    var sourceCollection = (Collection<?>) source;

    // Shortcut if possible...
    var copyRequired = !targetType.getType().isInstance(source);
    if (!copyRequired && sourceCollection.isEmpty()) {
      return source;
    }

    var targetElementDesc = targetType.getElementTypeDescriptor();
    if (targetElementDesc == null && !copyRequired) {
      return source;
    }

    var sourceElementDesc = sourceType.getElementTypeDescriptor();

    // At this point, we need a collection copy in any case, even if just for finding out about element copies...
    var target = CollectionFactory.createCollection(targetType.getType(),
      (targetElementDesc != null ? targetElementDesc.getType() : null), sourceCollection.size());

    if (sourceElementDesc == null || targetElementDesc == null) {
      target.addAll(sourceCollection);
    } else {
      var pair = new ConvertiblePair(sourceElementDesc.getType(), targetElementDesc.getType());
      if (convertersByPair.containsKey(pair)) {
        var converter = convertersByPair.get(pair);
        var convertedCollection = converter.convert((Collection<String>) sourceCollection);
        if (countDistinct(sourceCollection) != convertedCollection.size()) {
          // at least one ID could not be found
          throw new NoSuchObjectException();
        }
        target.addAll(convertedCollection);
      }
    }

    return target;
  }

  private int countDistinct(Collection<?> collection) {
    return (int) collection.stream().distinct().count();
  }
}
