/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.mail;

import com.cawemo.configuration.executor.ExecutorConfiguration;
import com.cawemo.service.mail.template.view.View;
import com.cawemo.util.Constants;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.Date;
import java.util.Map;
import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.mail.MailAuthenticationException;
import org.springframework.mail.MailSendException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class CawemoMailSender {

  private static final String TEXT_PLAIN_UTF_8 = new MediaType(MediaType.TEXT_PLAIN, StandardCharsets.UTF_8).toString();
  private static final String TEXT_HTML_UTF_8 = new MediaType(MediaType.TEXT_HTML, StandardCharsets.UTF_8).toString();

  private final MailFactory mailFactory;
  private final JavaMailSender mailSender;

  @Retryable(value = {MailSendException.class, MailAuthenticationException.class},
    maxAttemptsExpression = "${mail.retry.max-attempts}",
    backoff = @Backoff(delayExpression = "${mail.retry.delay}",
      maxDelayExpression = "${mail.retry.max-delay}",
      multiplierExpression = "${mail.retry.multiplier}"))
  @Async(value = ExecutorConfiguration.MAIL_EXECUTOR)
  public void sendMail(String recipientName, String recipientEmail, View view) {
    var mail = mailFactory.createMail(recipientName, recipientEmail, view);
    sendMail(mail);
  }

  @Retryable(value = {MailSendException.class, MailAuthenticationException.class},
    maxAttemptsExpression = "${mail.retry.max-attempts}",
    backoff = @Backoff(delayExpression = "${mail.retry.delay}",
      maxDelayExpression = "${mail.retry.max-delay}",
      multiplierExpression = "${mail.retry.multiplier}"))
  @Async(value = ExecutorConfiguration.MAIL_EXECUTOR)
  public void sendMail(Collection<String> recipientEmails, View view) {
    recipientEmails.forEach(email -> sendMail(null, email, view));
  }

  private void sendMail(Mail mail) {
    log.info("Sending e-mail: {}", mail);

    mailSender.send(mimeMessage -> {

      mimeMessage.setReplyTo(new Address[]{mail.getFrom()});
      mimeMessage.setFrom(mail.getFrom());
      mimeMessage.setRecipient(Message.RecipientType.TO, mail.getTo());
      mimeMessage.setSentDate(new Date());
      mimeMessage.setSubject(mail.getSubject(), Constants.CHARSET_UTF_8);
      mimeMessage.setContent(createMultipart(mail));

      for (Map.Entry<String, String> header : mail.getHeaders().entrySet()) {
        mimeMessage.setHeader(header.getKey(), header.getValue());
      }
    });
  }

  private MimeMultipart createMultipart(Mail mail) throws MessagingException {
    var multipart = new MimeMultipart("alternative");

    // The order of the parts matters!
    // Email clients will usually display the last version they are capable of showing.
    // This means "text/plain" followed by "text/html" in multipart/alternative emails.

    // text/plain
    var textBodyPart = new MimeBodyPart();
    textBodyPart.setContent(mail.getPlainTextBody(), TEXT_PLAIN_UTF_8);
    multipart.addBodyPart(textBodyPart);

    // text/html
    var htmlBodyPart = new MimeBodyPart();
    htmlBodyPart.setContent(mail.getHtmlBody(), TEXT_HTML_UTF_8);
    multipart.addBodyPart(htmlBodyPart);

    return multipart;
  }
}
