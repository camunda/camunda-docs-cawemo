/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.authentication;

import com.cawemo.data.dto.base.response.UserSessionDto;
import com.cawemo.data.entity.Session;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface SessionMapper {

  @Mapping(source = "id", target = "sessionToken")
  @Mapping(source = "validUntil", target = "validUntil")
  UserSessionDto asUserSessionDto(Session session);
}
