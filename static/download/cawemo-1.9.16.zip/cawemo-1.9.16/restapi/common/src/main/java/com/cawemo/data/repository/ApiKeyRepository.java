/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.ApiKey;
import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.User;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface ApiKeyRepository extends JpaRepository<ApiKey, String> {

  List<ApiKey> findByUserId(String userId);

  List<ApiKey> findByOrganizationId(String organizationId);

  List<ApiKey> findByOrganizationAndUser(Organization organization, User user);

  @Transactional
  void deleteByOrganizationAndUser(Organization organization, User user);
}
