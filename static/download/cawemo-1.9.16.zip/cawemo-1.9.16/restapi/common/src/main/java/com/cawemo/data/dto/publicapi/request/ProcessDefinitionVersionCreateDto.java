/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.publicapi.request;

import com.cawemo.data.validation.constraint.ValidBpmnWithExecutableProcess;
import java.time.ZonedDateTime;
import javax.validation.constraints.Positive;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class ProcessDefinitionVersionCreateDto {

  @ValidBpmnWithExecutableProcess
  private String content;

  private ZonedDateTime created;

  @Positive
  private int version;
}
