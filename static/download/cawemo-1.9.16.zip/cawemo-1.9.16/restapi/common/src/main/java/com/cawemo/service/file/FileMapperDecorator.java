/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.data.dto.base.request.FileCreateDto;
import com.cawemo.data.dto.base.request.FileCreateFromMilestoneDto;
import com.cawemo.data.dto.base.request.FileUpdateDto;
import com.cawemo.data.dto.base.request.MilestoneAddRelatedDiagramDto;
import com.cawemo.data.dto.base.request.MilestoneRestoreDto;
import com.cawemo.data.dto.base.response.FileWrapperDto;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.FileLink;
import com.cawemo.data.entity.Folder;
import com.cawemo.data.entity.Milestone;
import com.cawemo.data.entity.Project;
import com.cawemo.data.repository.FileRepository;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public abstract class FileMapperDecorator implements FileMapper {

  // Autowired as constructor injection is not possible yet: https://github.com/mapstruct/mapstruct/issues/1683
  @Autowired
  @Qualifier("delegate")
  private FileMapper delegate;

  @Autowired
  private FileLinkMapper fileLinkMapper;

  // Autowired as constructor injection is not possible yet: https://github.com/mapstruct/mapstruct/issues/1683
  @Autowired
  private FileRepository fileRepository;

  @Override
  public File asDuplicate(File file) {
    var result = delegate.asDuplicate(file);

    var links = fileLinkMapper.asFileLinkListDuplicate(file.getLinksOutgoing(), result);
    return addLinksToFile(result, links);
  }

  @Override
  public File asFile(FileCreateDto dto, Project project, Folder folder) {
    var file = delegate.asFile(dto, project, folder);

    var links = fileLinkMapper.asFileLinkList(dto.getCallActivityLinks(), file);
    return addLinksToFile(file, links);
  }

  @Override
  public File asFile(FileCreateFromMilestoneDto dto, String name, Milestone milestone, Project project, Folder folder) {
    var file = delegate.asFile(dto, name, milestone, project, folder);

    var links = fileLinkMapper.asFileLinkList(dto.getCallActivityLinks(), file);
    return addLinksToFile(file, links);
  }

  @Override
  public FileWrapperDto asFileWrapperDto(File file) {
    var result = delegate.asFileWrapperDto(file);
    var processIds = Optional
      .ofNullable(file.getLinksOutgoing())
      .stream()
      .flatMap(Collection::stream)
      .map(FileLink::getTargetProcessId)
      .collect(Collectors.toList());

    var children = fileRepository.findByProcessIdInAndProject(processIds, file.getProject());
    var parents = fileRepository
      .findByLinksOutgoingTargetProcessIdNotNullAndLinksOutgoingTargetProcessIdAndProject(file.getProcessId(),
        file.getProject());

    result
      .getFile()
      .setChildren(delegate.asLinkedFileDtoList(children))
      .setParents(delegate.asLinkedFileDtoList(parents));
    return result;
  }

  @Override
  public File updateFromDto(File file, MilestoneRestoreDto dto, String restoredContent) {
    var result = delegate.updateFromDto(file, dto, restoredContent);

    var links = fileLinkMapper.asFileLinkList(dto.getCallActivityLinks(), file);
    return addLinksToFile(result, links);
  }

  @Override
  public File updateFromDto(File file, FileUpdateDto dto) {
    var result = delegate.updateFromDto(file, dto);

    var links = fileLinkMapper.asFileLinkList(dto.getCallActivityLinks(), file);
    return addLinksToFile(result, links);
  }

  @Override
  public File updateFromDto(File file, MilestoneAddRelatedDiagramDto dto, File sourceFile) {
    var result = delegate.updateFromDto(file, dto, sourceFile);

    var links = fileLinkMapper.asFileLinkList(dto.getCallActivityLinks(), result);
    return addLinksToFile(result, links);
  }

  private File addLinksToFile(File file, List<FileLink> links) {
    if (links != null) {
      if (file.getLinksOutgoing() == null) {
        file.setLinksOutgoing(links);
      } else {
        file.getLinksOutgoing().clear();
        file.getLinksOutgoing().addAll(links);
      }
    }

    return file;
  }
}
