/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.configuration.data.ZonedDateTimeProvider;
import com.cawemo.data.dto.publicapi.request.ProcessDefinitionVersionCreateDto;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.Milestone;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.User;
import com.cawemo.data.repository.FileRepository;
import com.cawemo.data.repository.MilestoneRepository;
import com.cawemo.service.milestone.MilestoneService;
import com.cawemo.util.BpmnUtil;
import com.cawemo.util.api.ServerException;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PublicApiFileService {

  private final FileMapper fileMapper;
  private final FileRepository fileRepository;
  private final FileService fileService;
  private final MilestoneRepository milestoneRepository;
  private final MilestoneService milestoneService;
  private final ZonedDateTimeProvider zonedDateTimeProvider;

  @Transactional
  public Milestone createProcessDefinitionVersion(ProcessDefinitionVersionCreateDto dto, Project project, User user) {
    var file = createOrUpdateFile(dto, project, user);
    var versionName = MilestoneService.ENGINE_VERSION_PREFIX + dto.getVersion();
    return milestoneService.createMilestone(file, versionName, dto.getContent(), dto.getCreated());
  }

  private File createOrUpdateFile(ProcessDefinitionVersionCreateDto dto, Project project, User user) {
    var model = BpmnUtil.getBpmnModelInstance(dto.getContent());

    var process = BpmnUtil.getFirstExecutableProcess(model)
      // this should not happen as the BPMN is already validated within the dto
      .orElseThrow(() -> new ServerException("No executable process found"));
    var processId = process.getId();
    var processName = StringUtils.defaultIfBlank(process.getName(), processId);
    var relationId = BpmnUtil.getRelationId(model).orElse(null);

    return fileRepository.findFirstByProcessIdAndProjectOrderByUpdatedDesc(processId, project)
      .map(file -> updateOrReturnFile(dto, user, processName, relationId, file))
      .orElseGet(() -> fileService.createFile(fileMapper.asFile(dto, processName, processId, relationId, project)));
  }

  private File updateOrReturnFile(ProcessDefinitionVersionCreateDto dto, User user, String processName,
                                  String relationId, File file) {
    var latestVersion = milestoneRepository.findFirstByFileOrderByCreatedDesc(file);
    var created = Objects.requireNonNullElse(dto.getCreated(), zonedDateTimeProvider.now());
    if (latestVersion.isPresent() && latestVersion.get().getCreated().isBefore(created)) {
      var updatedFile = fileMapper.updateFromDto(file, dto, processName, relationId);
      return fileService.updateFile(updatedFile, user, "");
    } else {
      return file;
    }
  }
}
