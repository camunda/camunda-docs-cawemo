/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity;

import com.cawemo.util.Constants;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.hibernate.annotations.Type;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(
  name = "comments",
  indexes = {
    @Index(columnList = "created_by"),
    @Index(columnList = "file_id")
  }
)
@EntityListeners(AuditingEntityListener.class)
@Data
@Accessors(chain = true)
public class Comment implements Serializable {

  @Id
  @GeneratedValue(generator = "uuid")
  @GenericGenerator(name = "uuid", strategy = "uuid2")
  private String id;

  @ManyToOne
  @JoinColumn(name = "file_id", nullable = false)
  @OnDelete(action = OnDeleteAction.CASCADE)
  private File file;

  @Type(type = "org.hibernate.type.TextType")
  @Column(nullable = false)
  private String content;

  @Type(type = "org.hibernate.type.TextType")
  private String reference;

  @CreatedDate
  @Column(nullable = false, updatable = false)
  private ZonedDateTime created;

  @CreatedBy
  @ManyToOne
  @JoinColumn(name = "created_by", nullable = false)
  private User createdBy;

  @LastModifiedDate
  @Column(nullable = false)
  private ZonedDateTime updated;

  @Override
  public boolean equals(Object object) {
    if (object == null) {
      return false;
    } else if (object == this) {
      return true;
    } else if (!(object instanceof Comment)) {
      return false;
    } else {
      return Objects.equals(this.id, ((Comment) object).getId());
    }
  }

  @Override
  public int hashCode() {
    return Constants.ENTITY_HASHCODE;
  }
}
