/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.configuration.executor;

import java.util.Optional;
import org.slf4j.MDC;
import org.springframework.boot.task.TaskExecutorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.core.task.TaskDecorator;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.security.core.context.SecurityContextHolder;

@EnableAsync
@Configuration
public class ExecutorConfiguration {

  public static final String FILE_DOWNLOAD_EXECUTOR = "fileDownloadExecutor";
  public static final String MAIL_EXECUTOR = "mailExecutor";

  @Bean(name = FILE_DOWNLOAD_EXECUTOR)
  public AsyncTaskExecutor asyncFileDownloadExecutor(TaskExecutorBuilder builder, TaskDecorator taskDecorator,
                                                     FileDownloadExecutorProperties properties) {
    return builder.threadNamePrefix(FILE_DOWNLOAD_EXECUTOR)
      .taskDecorator(taskDecorator)
      .corePoolSize(properties.corePoolSize())
      .maxPoolSize(properties.maxPoolSize())
      .queueCapacity(properties.queueCapacity())
      .build();
  }

  @Bean(name = MAIL_EXECUTOR)
  public AsyncTaskExecutor asyncMailExecutor(TaskExecutorBuilder builder, TaskDecorator taskDecorator) {
    return buildExecutor(builder, MAIL_EXECUTOR, taskDecorator);
  }

  @Bean
  public TaskDecorator authenticationTaskDecorator() {
    return task -> {
      var authentication = SecurityContextHolder.getContext().getAuthentication();
      var contextMap = MDC.getCopyOfContextMap();
      return () -> {
        try {
          SecurityContextHolder.getContext().setAuthentication(authentication);
          Optional.ofNullable(contextMap).ifPresent(MDC::setContextMap);
          task.run();
        } finally {
          SecurityContextHolder.clearContext();
          MDC.clear();
        }
      };
    };
  }

  public static ThreadPoolTaskExecutor buildExecutor(TaskExecutorBuilder builder, String threadNamePrefix,
                                                     TaskDecorator decorator) {
    return builder
      .threadNamePrefix(threadNamePrefix)
      .taskDecorator(decorator)
      .build();
  }
}
