/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.mail;

import java.util.HashMap;
import java.util.Map;
import javax.mail.internet.InternetAddress;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Getter
@ToString(exclude = {"plainTextBody", "htmlBody"})
@RequiredArgsConstructor(access = AccessLevel.PACKAGE)
class Mail {

  private final InternetAddress from;
  private final InternetAddress to;
  private final String subject;
  private final String plainTextBody;
  private final String htmlBody;
  private final Map<String, String> headers = new HashMap<>();

  void addHeader(String name, String value) {
    headers.put(name, value);
  }
}
