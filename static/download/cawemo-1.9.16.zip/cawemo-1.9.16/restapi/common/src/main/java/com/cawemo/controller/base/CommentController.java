/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.base;

import com.cawemo.data.dto.base.request.CommentCreateDto;
import com.cawemo.data.dto.base.request.CommentDeleteDto;
import com.cawemo.data.dto.base.request.CommentUpdateDto;
import com.cawemo.data.dto.base.request.NodeRemoveDto;
import com.cawemo.data.dto.base.response.CommentDto;
import com.cawemo.data.entity.Comment;
import com.cawemo.data.entity.File;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.comment.CommentMapper;
import com.cawemo.service.comment.CommentService;
import com.cawemo.util.swagger.SwaggerUuidParameter;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Comments")
@RequiredArgsConstructor
@RestController
public class CommentController implements InternalApiController {

  private final CommentMapper commentMapper;
  private final CommentService commentService;

  @PreAuthorize("hasPermission(#file, T(ProjectOperation).COMMENT_AND_MENTION)")
  @GetMapping(value = "/files/{fileId}/comments", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<CommentDto> getComments(@SwaggerUuidParameter @PathVariable("fileId") File file) {
    var comments = file.getComments()
      .stream()
      .sorted(Comparator.comparing(Comment::getCreated))
      .collect(Collectors.toList());
    return commentMapper.asCommentDtoList(comments);
  }

  @PreAuthorize("hasPermission(#dto.fileId, 'com.cawemo.data.entity.File', T(ProjectOperation).COMMENT_AND_MENTION)")
  @PostMapping(value = "/comments", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public CommentDto createComment(@AuthenticationPrincipal UserAwareUserDetails userDetails,
                                  @Valid @RequestBody @Parameter(required = true) CommentCreateDto dto) {
    return commentMapper.asCommentDto(commentService.createComment(userDetails.getUser(), dto));
  }

  @PreAuthorize("hasPermission(#comment.file, T(ProjectOperation).COMMENT_AND_MENTION) && " +
    "#comment.createdBy.id == authentication.principal.user.id")
  @PatchMapping(value = "/comments/{commentId}", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public CommentDto updateComment(@AuthenticationPrincipal UserAwareUserDetails userDetails,
                                  @SwaggerUuidParameter @PathVariable("commentId") Comment comment,
                                  @Valid @RequestBody @Parameter(required = true) CommentUpdateDto dto) {
    return commentMapper.asCommentDto(commentService.updateComment(userDetails.getUser(), comment, dto));
  }

  @PreAuthorize("hasPermission(#comment.file, T(ProjectOperation).COMMENT_AND_MENTION) && " +
    "#comment.createdBy.id == authentication.principal.user.id")
  @DeleteMapping(value = "/comments/{commentId}", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void deleteComment(@SwaggerUuidParameter @PathVariable("commentId") Comment comment,
                            @Valid @RequestBody @Parameter(required = true) CommentDeleteDto dto) {
    commentService.deleteComment(comment, dto);
  }

  @PreAuthorize("hasPermission(#file.project, T(ProjectOperation).MODIFY_FILE)")
  @DeleteMapping(value = "/files/{fileId}/node/{nodeId}", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void deleteNode(@SwaggerUuidParameter @PathVariable("fileId") File file,
                         @SwaggerUuidParameter @PathVariable String nodeId,
                         @Valid @RequestBody @Parameter(required = true) NodeRemoveDto nodeRemoveDto) {
    commentService.deleteDiagramNodeComments(file, nodeRemoveDto, nodeId);
  }
}
