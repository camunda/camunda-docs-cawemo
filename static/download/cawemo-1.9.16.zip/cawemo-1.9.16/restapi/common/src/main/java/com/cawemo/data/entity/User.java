/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity;

import com.cawemo.data.entity.listener.UserEntityListener;
import com.cawemo.service.user.UserSegment;
import com.cawemo.service.user.UserType;
import com.cawemo.util.Constants;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "users")
@EntityListeners({AuditingEntityListener.class, UserEntityListener.class})
@Data
@Accessors(chain = true)
public class User implements Serializable {

  @Id
  @GeneratedValue(generator = "uuid")
  @GenericGenerator(name = "uuid", strategy = "uuid2")
  private String id;

  @Column(nullable = false, updatable = false, unique = true)
  private String iamId;

  @Column(nullable = false)
  private String name;

  // length attribute is not considered when Flyway creates the schema on Postgres (there, "citext" is used as type with
  // basically unlimited length), but only when running tests on H2 or MySQL (in this case Hibernate creates the schema)
  @Column(unique = true, length = Constants.EMAIL_MAX_LENGTH)
  private String email;

  @CreatedDate
  @Column(nullable = false, updatable = false)
  private ZonedDateTime created;

  @Column(unique = true)
  private String username;

  @Column(nullable = false)
  private boolean verified;

  @LastModifiedDate
  @Column(nullable = false)
  private ZonedDateTime updated;

  @Enumerated(EnumType.STRING)
  @Column(nullable = false)
  private UserType type;

  @Enumerated(EnumType.STRING)
  private UserSegment segment;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "user", fetch = FetchType.LAZY)
  private List<ApiKey> apiKeys;

  @ToString.Exclude
  // don't cascade deletion; createdBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "createdBy", fetch = FetchType.LAZY)
  private List<Comment> commentsCreated;

  @ToString.Exclude
  // don't cascade deletion; createdBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "createdBy", fetch = FetchType.LAZY)
  private List<FileLink> fileLinksCreated;

  @ToString.Exclude
  // don't cascade deletion; updatedBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "updatedBy", fetch = FetchType.LAZY)
  private List<FileLink> fileLinksUpdated;

  @ToString.Exclude
  // don't cascade deletion; createdBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "createdBy", fetch = FetchType.LAZY)
  private List<File> filesCreated;

  @ToString.Exclude
  // don't cascade deletion; updatedBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "updatedBy", fetch = FetchType.LAZY)
  private List<File> filesUpdated;

  @ToString.Exclude
  // don't cascade deletion; createdBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "createdBy", fetch = FetchType.LAZY)
  private List<FileShare> fileSharesCreated;

  @ToString.Exclude
  // don't cascade deletion; updatedBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "updatedBy", fetch = FetchType.LAZY)
  private List<FileShare> fileSharesUpdated;

  @ToString.Exclude
  // don't cascade deletion; createdBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "createdBy", fetch = FetchType.LAZY)
  private List<Folder> foldersCreated;

  @ToString.Exclude
  // don't cascade deletion; updatedBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "updatedBy", fetch = FetchType.LAZY)
  private List<Folder> foldersUpdated;

  @ToString.Exclude
  // don't cascade deletion; createdBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "createdBy", fetch = FetchType.LAZY)
  private List<Milestone> milestonesCreated;

  @ToString.Exclude
  // don't cascade deletion; updatedBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "updatedBy", fetch = FetchType.LAZY)
  private List<Milestone> milestonesUpdated;

  @ToString.Exclude
  // don't cascade deletion; createdBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "createdBy", fetch = FetchType.LAZY)
  private List<Organization> organizationsCreated;

  @ToString.Exclude
  // don't cascade deletion; updatedBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "updatedBy", fetch = FetchType.LAZY)
  private List<Organization> organizationsUpdated;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "id.user", fetch = FetchType.LAZY)
  private List<OrganizationPermission> organizationPermissions;

  @ToString.Exclude
  // don't cascade deletion; createdBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "createdBy", fetch = FetchType.LAZY)
  private List<OrganizationPermission> organizationPermissionsCreated;

  @ToString.Exclude
  // don't cascade deletion; updatedBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "updatedBy", fetch = FetchType.LAZY)
  private List<OrganizationPermission> organizationPermissionsUpdated;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "id.user", fetch = FetchType.LAZY)
  private List<Preference> preferences;

  @ToString.Exclude
  // don't cascade deletion; createdBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "createdBy", fetch = FetchType.LAZY)
  private List<Project> projectsCreated;

  @ToString.Exclude
  // don't cascade deletion; updatedBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "updatedBy", fetch = FetchType.LAZY)
  private List<Project> projectsUpdated;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "createdBy", fetch = FetchType.LAZY)
  private List<ProjectInvitation> projectInvitationsCreated;

  @ToString.Exclude
  // don't cascade deletion; updatedBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "updatedBy", fetch = FetchType.LAZY)
  private List<ProjectInvitation> projectInvitationsUpdated;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "id.user", fetch = FetchType.LAZY)
  private List<ProjectPermission> projectPermissions;

  @ToString.Exclude
  // don't cascade deletion; createdBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "createdBy", fetch = FetchType.LAZY)
  private List<ProjectPermission> projectPermissionsCreated;

  @ToString.Exclude
  // don't cascade deletion; updatedBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "updatedBy", fetch = FetchType.LAZY)
  private List<ProjectPermission> projectPermissionsUpdated;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "id.user", fetch = FetchType.LAZY)
  private List<ProjectSubscription> projectSubscriptions;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "user", fetch = FetchType.LAZY)
  private List<Session> sessions;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "createdBy", fetch = FetchType.LAZY)
  private List<Token> tokensCreated;

  @ToString.Exclude
  // don't cascade deletion; updatedBy will be updated to "deleted user" by UserEventListener
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "updatedBy", fetch = FetchType.LAZY)
  private List<Token> tokensUpdated;

  @Override
  public boolean equals(Object object) {
    if (object == null) {
      return false;
    } else if (object == this) {
      return true;
    } else if (!(object instanceof User)) {
      return false;
    } else {
      return Objects.equals(this.id, ((User) object).getId());
    }
  }

  @Override
  public int hashCode() {
    return Constants.ENTITY_HASHCODE;
  }
}
