/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.data.dto.publicapi.request.TemplateCreateDto;
import com.cawemo.data.dto.publicapi.request.TemplateUpdateDto;
import com.cawemo.data.dto.publicapi.response.PublicApiTemplateDto;
import com.cawemo.data.dto.publicapi.response.PublicApiTemplateMetadataDto;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.Milestone;
import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.Project;
import com.cawemo.data.repository.FileRepository;
import com.cawemo.data.repository.MilestoneRepository;
import com.cawemo.data.repository.ProjectRepository;
import com.cawemo.service.milestone.MilestoneMapper;
import com.cawemo.service.project.ProjectType;
import com.cawemo.util.DateUtil;
import com.cawemo.util.api.NoSuchObjectException;
import com.cawemo.util.api.PublicApiErrorMessages;
import com.cawemo.util.api.ServerException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.PrettyPrinter;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.core.util.DefaultIndenter;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class TemplateService {

  private static final PrettyPrinter PRETTY_PRINTER = new TemplatePrettyPrinter();
  private static final TypeReference<Map<String, Object>> MAP_TYPE_REFERENCE = new TypeReference<>() { };
  private static final Set<FileType> TEMPLATE_FILE_TYPES = FileType.forCategory(FileTypeCategory.ELEMENT_TEMPLATE);
  private static final String VERSION_DEFAULT_NAME_PREFIX = "Untitled version ";
  private static final String TEMPLATE_JSON_CONTENT_NOT_PARSEABLE = "Could not parse template content as JSON.";

  private final FileRepository fileRepository;
  private final FileMapper fileMapper;
  private final MilestoneMapper milestoneMapper;
  private final MilestoneRepository milestoneRepository;
  private final ObjectMapper objectMapper;
  private final ProjectRepository projectRepository;

  @Transactional
  public PublicApiTemplateDto createTemplate(TemplateCreateDto dto, Organization organization) {
    var catalog = getCatalog(dto.getMetadata().getCatalogId(), organization);

    var id = UUID.randomUUID().toString();
    // strip metadata and version field and replace the id with the entity's id
    var content = convertDtoToString(dto, id);

    var persistedTemplate = createTemplate(id, dto.getName(), content, catalog);
    if (dto.getMetadata().isPublished()) {
      var persistedVersion = createInitialVersion(dto.getMetadata().getTemplateVersionName(), persistedTemplate);
      return readTemplateContentWithPublicApiMetadata(persistedVersion);
    } else {
      return readTemplateContentWithPublicApiMetadata(persistedTemplate);
    }
  }

  public PublicApiTemplateDto getTemplate(File template, boolean includeUnpublishedVersions) {
    return includeUnpublishedVersions ?
      readTemplateContentWithPublicApiMetadata(template) :
      milestoneRepository.findFirstByFileOrderByCreatedDesc(template)
        .map(this::readTemplateContentWithPublicApiMetadata)
        .orElseThrow(() -> new NoSuchObjectException(PublicApiErrorMessages.TEMPLATE_HAS_NO_PUBLISHED_VERSIONS));
  }

  public List<PublicApiTemplateDto> getTemplates(Organization organization, Project catalog,
                                                 boolean includeUnpublishedVersions) {
    return includeUnpublishedVersions ?
      getTemplatesIncludingUnpublishedVersions(organization, catalog) :
      getTemplatesExcludingUnpublishedVersions(organization, catalog);
  }

  @Transactional
  public PublicApiTemplateDto updateTemplate(TemplateUpdateDto dto, File template) {
    var catalogId = dto.getMetadata() != null ? dto.getMetadata().getCatalogId() : null;
    var catalog = StringUtils.isBlank(catalogId) ?
      template.getProject() :
      getCatalog(catalogId, template.getProject().getOrganization());

    var persistedTemplate = fileRepository.save(updateFromDto(template, dto, catalog));
    if (dto.getMetadata() != null && dto.getMetadata().isPublished()) {
      var persistedVersion = createVersion(dto.getMetadata().getTemplateVersionName(), persistedTemplate);
      return readTemplateContentWithPublicApiMetadata(persistedVersion);
    } else {
      return readTemplateContentWithPublicApiMetadata(persistedTemplate);
    }
  }

  private Project getCatalog(String catalogId, Organization organization) {
    return projectRepository
      .findByIdAndOrganizationAndType(catalogId, organization, ProjectType.CATALOG)
      .orElseThrow(NoSuchObjectException::new);
  }

  private Milestone createInitialVersion(String name, File file) {
    var versionName = Objects.requireNonNullElse(name, VERSION_DEFAULT_NAME_PREFIX + 1);

    return createVersion(file, versionName);
  }

  private Milestone createVersion(String name, File file) {
    var versionName = name != null ? name :
      VERSION_DEFAULT_NAME_PREFIX + (milestoneRepository.countByFile(file) + 1);

    return createVersion(file, versionName);
  }

  private Milestone createVersion(File file, String versionName) {
    var milestone = new Milestone()
      .setName(versionName)
      .setContent(file.getContent())
      .setFile(file);

    return milestoneRepository.save(milestone);
  }

  private File createTemplate(String id, String name, String content, Project catalog) {
    var file = new File()
      .setId(id)
      .setName(name)
      .setContent(content)
      .setProject(catalog)
      .setType(FileType.TEMPLATE_GENERIC);
    return fileRepository.save(file);
  }

  private String convertDtoToString(TemplateCreateDto dto, String id) {
    try {
      var content = fileMapper.asTemplateContentView(dto, id);
      return objectMapper.writer(PRETTY_PRINTER).writeValueAsString(content);
    } catch (JsonProcessingException e) {
      throw new ServerException(TEMPLATE_JSON_CONTENT_NOT_PARSEABLE, e);
    }
  }

  private List<PublicApiTemplateDto> getTemplatesExcludingUnpublishedVersions(Organization organization,
                                                                              Project catalog) {
    var templates = catalog == null ?
      milestoneRepository.findLatestPerFileByOrganizationAndFileTypeIn(organization, TEMPLATE_FILE_TYPES) :
      milestoneRepository
        .findLatestPerFileByOrganizationAndProjectAndFileTypeIn(organization, catalog, TEMPLATE_FILE_TYPES);

    return templates
      .stream()
      .map(this::readTemplateContentWithPublicApiMetadata)
      .collect(Collectors.toList());
  }

  private List<PublicApiTemplateDto> getTemplatesIncludingUnpublishedVersions(Organization organization,
                                                                              Project catalog) {
    var templates = catalog == null ?
      fileRepository.findByProjectOrganizationAndTypeIn(organization, TEMPLATE_FILE_TYPES) :
      fileRepository.findByProjectOrganizationAndProjectAndTypeIn(organization, catalog, TEMPLATE_FILE_TYPES);

    return templates
      .stream()
      .map(this::readTemplateContentWithPublicApiMetadata)
      .collect(Collectors.toList());
  }

  private PublicApiTemplateDto readTemplateContentWithPublicApiMetadata(File template) {
    return getPublicApiTemplateDto(template.getContent(), template.getUpdated(),
      milestoneMapper.asPublicApiTemplateMetadataDto(template));
  }

  private PublicApiTemplateDto readTemplateContentWithPublicApiMetadata(Milestone templateVersion) {
    return getPublicApiTemplateDto(templateVersion.getContent(), templateVersion.getCreated(),
      milestoneMapper.asPublicApiTemplateMetadataDto(templateVersion));
  }

  private PublicApiTemplateDto getPublicApiTemplateDto(String content, ZonedDateTime created,
                                                       PublicApiTemplateMetadataDto dto) {
    try {
      return objectMapper.readValue(content, PublicApiTemplateDto.class)
        .setVersion(DateUtil.asTimestamp(created))
        .setMetadata(dto);
    } catch (JsonProcessingException e) {
      throw new ServerException(TEMPLATE_JSON_CONTENT_NOT_PARSEABLE, e);
    }
  }

  private File updateFromDto(File template, TemplateUpdateDto dto, Project targetCatalog) {
    var content = updateTemplateContentFromDto(template, dto);
    var result = template
      .setContent(content)
      .setProject(targetCatalog)
      .setType(FileType.TEMPLATE_GENERIC);

    var name = dto.getName();
    if (StringUtils.isNotBlank(name)) {
      result.setName(name);
    }

    return result;
  }

  private String updateTemplateContentFromDto(File template, TemplateUpdateDto dto) {
    try {
      var currentProperties = convertToMap(template.getContent());
      // strip metadata and version field and replace the id with the entity's id
      var updatedProperties = convertToMap(dto, template.getId());

      var mergedProperties = new LinkedHashMap<>(currentProperties);
      mergedProperties.putAll(updatedProperties);
      return objectMapper.writer(PRETTY_PRINTER).writeValueAsString(mergedProperties);
    } catch (JsonProcessingException e) {
      throw new ServerException(TEMPLATE_JSON_CONTENT_NOT_PARSEABLE, e);
    }
  }

  private Map<String, Object> convertToMap(String content) throws JsonProcessingException {
    return objectMapper.readValue(content, MAP_TYPE_REFERENCE);
  }

  private Map<String, Object> convertToMap(TemplateUpdateDto dto, String id) {
    var content = fileMapper.asTemplateContentView(dto, id);
    return objectMapper.convertValue(content, MAP_TYPE_REFERENCE);
  }

  private static class TemplatePrettyPrinter extends DefaultPrettyPrinter {

    private TemplatePrettyPrinter() {
      super();
      // white space only between separator and value but not between field and separator, e.g. "field": "value"
      this._objectFieldValueSeparatorWithSpaces = DEFAULT_SEPARATORS.getObjectFieldValueSeparator() + " ";
      // add new lines before/after array values
      this._arrayIndenter = DefaultIndenter.SYSTEM_LINEFEED_INSTANCE;
    }

    private TemplatePrettyPrinter(DefaultPrettyPrinter base) {
      super(base);
    }

    @Override
    public DefaultPrettyPrinter createInstance() {
      return new TemplatePrettyPrinter(this);
    }

    /**
     * Does the same as {@link DefaultPrettyPrinter#writeEndArray(JsonGenerator, int)} but doesn't add a whitespace in
     * case of an empty array.
     */
    @Override
    public void writeEndArray(JsonGenerator g, int nrOfValues) throws IOException {
      if (!_arrayIndenter.isInline()) {
        --_nesting;
      }
      if (nrOfValues > 0) {
        _arrayIndenter.writeIndentation(g, _nesting);
      }
      g.writeRaw(']');
    }
  }
}
