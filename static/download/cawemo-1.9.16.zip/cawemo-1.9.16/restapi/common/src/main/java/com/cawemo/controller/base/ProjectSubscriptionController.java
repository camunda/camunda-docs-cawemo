/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.base;

import com.cawemo.data.dto.base.request.ProjectSubscriptionChangeDto;
import com.cawemo.data.dto.base.response.ProjectSubscriptionDto;
import com.cawemo.data.entity.Organization;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.project.ProjectSubscriptionMapper;
import com.cawemo.service.project.ProjectSubscriptionService;
import com.cawemo.util.swagger.SwaggerUuidParameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Project Subscriptions")
@RestController
@RequiredArgsConstructor
public class ProjectSubscriptionController implements InternalApiController {

  private final ProjectSubscriptionService subscriptionService;
  private final ProjectSubscriptionMapper subscriptionMapper;

  @PreAuthorize("hasPermission(#dto.projectId, 'com.cawemo.data.entity.Project', " +
    "T(ProjectOperation).COMMENT_AND_MENTION)")
  @PatchMapping(value = "/subscriptions", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void subscribeToProject(@Valid @RequestBody ProjectSubscriptionChangeDto dto,
                                 @AuthenticationPrincipal UserAwareUserDetails userDetails) {
    subscriptionService.createSubscription(dto.getProjectId(), userDetails.getUser());
  }

  @PreAuthorize("hasPermission(#organization, T(OrganizationOperation).VIEW_PROJECTS)")
  @GetMapping(value = "/organizations/{organizationId}/subscriptions", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<ProjectSubscriptionDto> getSubscriptions(@SwaggerUuidParameter
                                                         @PathVariable("organizationId") Organization organization,
                                                       @AuthenticationPrincipal UserAwareUserDetails userDetails) {
    var subscriptions = subscriptionService.getSubscriptions(organization, userDetails.getUser());
    return subscriptionMapper.asSubscriptionDtoList(subscriptions);
  }

  @PreAuthorize("hasPermission(#dto.projectId, 'com.cawemo.data.entity.Project', " +
    "T(ProjectOperation).COMMENT_AND_MENTION)")
  @DeleteMapping("/subscriptions")
  public void unsubscribeFromProject(@Valid @RequestBody ProjectSubscriptionChangeDto dto,
                                     @AuthenticationPrincipal UserAwareUserDetails userDetails) {
    subscriptionService.deleteSubscription(dto.getProjectId(), userDetails.getUser());
  }
}
