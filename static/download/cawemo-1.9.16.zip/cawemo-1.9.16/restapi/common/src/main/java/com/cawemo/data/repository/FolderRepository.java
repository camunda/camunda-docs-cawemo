/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.Folder;
import com.cawemo.data.entity.Project;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface FolderRepository extends JpaRepository<Folder, String> {

  Optional<Folder> findByIdAndProjectId(String folderId, String projectId);

  List<Folder> findByParentIsNullAndProject(Project project);

  @Query("SELECT f.id FROM Folder f WHERE f.parent = :parent")
  List<String> findFolderIdsByParent(@Param("parent") Folder parent);

  /**
   * Returns only folders that are not already in the target location.
   **/
  @Query("SELECT f FROM Folder f WHERE f.id IN :folderIds AND (" +
    "(:targetFolder IS NOT NULL AND (f.parent IS NULL OR f.parent <> :targetFolder)) OR " +
    "(:targetFolder IS NULL AND (f.parent IS NOT NULL OR f.project <> :targetProject)))")
  List<Folder> findFoldersToBeMoved(@Param("folderIds") List<String> folderIds,
                                    @Param("targetProject") Project targetProject,
                                    @Param("targetFolder") Folder targetFolder);
}
