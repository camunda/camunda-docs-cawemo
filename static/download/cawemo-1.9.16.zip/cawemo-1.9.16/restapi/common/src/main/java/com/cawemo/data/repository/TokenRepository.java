/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.Token;
import com.cawemo.service.token.TokenType;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface TokenRepository extends JpaRepository<Token, String> {

  Optional<Token> findByIdAndTypeIn(String tokenId, TokenType... types);

  List<Token> findByType(TokenType type);

  @Transactional
  @Modifying
  @Query("DELETE FROM Token t WHERE t.id IN (SELECT pi.token FROM ProjectInvitation pi " +
    "WHERE pi.project = :project AND lower(pi.invitedEmail) = lower(:email))")
  int deleteByProjectInvitationProjectAndEmail(@Param("project") Project project, @Param("email") String email);
}
