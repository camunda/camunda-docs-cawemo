/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.configuration.mail;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSenderImpl;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class MailConfiguration implements InitializingBean {

  private final JavaMailSenderImpl mailSender;

  @Override
  public void afterPropertiesSet() {
    if (log.isDebugEnabled()) {
      mailSender.getJavaMailProperties().put("mail.debug", "true");
      mailSender.getJavaMailProperties().put("mail.debug.auth", "true");
    }
  }
}
