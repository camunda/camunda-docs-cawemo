/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.organization;

import com.cawemo.data.dto.base.response.OrganizationCollaboratorDto;
import com.cawemo.data.dto.base.response.ProjectAccessWithStatusDto;
import java.util.List;
import org.mapstruct.MapperConfig;
import org.mapstruct.Mapping;

@MapperConfig
public interface OrganizationCollaboratorMapper {

  @Mapping(target = "id", source = "project.id")
  @Mapping(target = "name", source = "project.name")
  @Mapping(target = "slug", source = "project", qualifiedByName = "projectSlug") // uses ProjectMapper
  @Mapping(target = "admins", source = "admins", qualifiedByName = "idsAsUserDtoList") // uses UserMapper
  ProjectAccessWithStatusDto asDto(OrganizationCollaboratorWithStatus.ProjectAccessWithStatus access);

  @Mapping(target = "permissionAccess", source = "access")
  OrganizationCollaboratorDto asDto(OrganizationCollaboratorWithStatus collaborator);

  List<OrganizationCollaboratorDto> asOrganizationCollaboratorDtoList(
    List<? extends OrganizationCollaborator> collaborators);
}
