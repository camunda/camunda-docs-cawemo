/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.File;
import com.cawemo.data.entity.FileLink;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FileLinkRepository extends JpaRepository<FileLink, String> {

  // targetFileNotNull is used to identify legacy links (new links use targetProcessId instead)
  List<FileLink> findBySourceFileAndTargetFileNotNull(File file);
}
