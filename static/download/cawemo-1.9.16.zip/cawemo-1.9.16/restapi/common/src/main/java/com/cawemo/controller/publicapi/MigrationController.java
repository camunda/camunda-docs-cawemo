/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.publicapi;

import com.cawemo.data.dto.publicapi.request.PublicApiMilestoneCreateDto;
import com.cawemo.data.dto.publicapi.response.PublicApiFileDto;
import com.cawemo.data.dto.publicapi.response.PublicApiFileMetadataDto;
import com.cawemo.data.dto.publicapi.response.PublicApiMilestoneDto;
import com.cawemo.data.dto.publicapi.response.PublicApiMilestoneMetadataDto;
import com.cawemo.data.dto.publicapi.response.PublicApiProjectMetadataDto;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.Milestone;
import com.cawemo.data.entity.Project;
import com.cawemo.data.repository.FileRepository;
import com.cawemo.data.repository.MilestoneRepository;
import com.cawemo.data.repository.ProjectRepository;
import com.cawemo.security.authentication.ApiKeyAwareUserDetails;
import com.cawemo.service.file.FileMapper;
import com.cawemo.service.milestone.MilestoneMapper;
import com.cawemo.service.project.ProjectMapper;
import com.cawemo.util.api.NoSuchObjectException;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Public API: C8 Migration Endpoints")
@RequiredArgsConstructor
@RestController
public class MigrationController implements PublicApiController {

  private final FileMapper fileMapper;
  private final FileRepository fileRepository;
  private final MilestoneMapper milestoneMapper;
  private final MilestoneRepository milestoneRepository;
  private final ProjectMapper projectMapper;
  private final ProjectRepository projectRepository;

  @PreAuthorize("""
    hasPermission(#userDetails.apiKey.organization, T(OrganizationOperation).VIEW_ORGANIZATION_DATA)
      """)
  @GetMapping(path = "/projects", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<PublicApiProjectMetadataDto> getProjects(
    @AuthenticationPrincipal ApiKeyAwareUserDetails userDetails) {
    var projects = projectRepository.findByOrganization(userDetails.getApiKey().getOrganization());
    return projectMapper.asPublicApiProjectDtoList(projects);
  }

  @PreAuthorize("""
    #project.organization == #userDetails.apiKey.organization &&
    hasPermission(#userDetails.apiKey.organization, T(OrganizationOperation).VIEW_ORGANIZATION_DATA)
    """)
  @GetMapping(path = "/projects/{projectId}/files", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<PublicApiFileMetadataDto> getFiles(
    @AuthenticationPrincipal ApiKeyAwareUserDetails userDetails, @PathVariable("projectId") Project project) {
    var projects = fileRepository.findByProject(project);
    return fileMapper.asPublicApiFileMetadataDtoList(projects);
  }

  @PreAuthorize("""
    #file.project.organization == #userDetails.apiKey.organization &&
    hasPermission(#userDetails.apiKey.organization, T(OrganizationOperation).VIEW_ORGANIZATION_DATA)
    """)
  @GetMapping(path = "/files/{fileId}", produces = MediaType.APPLICATION_JSON_VALUE)
  public PublicApiFileDto getFile(
    @AuthenticationPrincipal ApiKeyAwareUserDetails userDetails, @PathVariable("fileId") File file) {
    var metadata = fileMapper.asPublicApiFileMetadataDto(file);
    return fileMapper.asPublicApiFileDto(file, metadata);
  }

  @PreAuthorize("""
    hasPermission(#dto.fileId, 'com.cawemo.data.entity.File', T(ProjectOperation).MODIFY_MILESTONE)
    """)
  @PostMapping(path = "/milestones", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public PublicApiMilestoneMetadataDto createMilestone(
    @SuppressWarnings("unused") @AuthenticationPrincipal ApiKeyAwareUserDetails userDetails,
    @Valid @RequestBody PublicApiMilestoneCreateDto dto) {
    var file = fileRepository.findById(dto.fileId()).orElseThrow(NoSuchObjectException::new);

    var milestone = milestoneMapper.asMilestone(file, dto);

    return milestoneMapper.asPublicApiMilestoneMetadataDto(milestoneRepository.save(milestone));
  }

  @PreAuthorize("""
    #file.project.organization == #userDetails.apiKey.organization &&
    hasPermission(#userDetails.apiKey.organization, T(OrganizationOperation).VIEW_ORGANIZATION_DATA)
    """)
  @GetMapping(path = "/files/{fileId}/milestones", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<PublicApiMilestoneMetadataDto> getMilestones(
    @SuppressWarnings("unused") @AuthenticationPrincipal ApiKeyAwareUserDetails userDetails,
    @PathVariable("fileId") File file) {
    var milestones = milestoneRepository.findByFile(file);
    return milestoneMapper.asPublicApiMilestoneMetadataDtoList(milestones);
  }

  @PreAuthorize("""
    #milestone.file.project.organization == #userDetails.apiKey.organization &&
    hasPermission(#userDetails.apiKey.organization, T(OrganizationOperation).VIEW_ORGANIZATION_DATA)
    """)
  @GetMapping(path = "/milestones/{milestoneId}", produces = MediaType.APPLICATION_JSON_VALUE)
  public PublicApiMilestoneDto getMilestone(
    @SuppressWarnings("unused") @AuthenticationPrincipal ApiKeyAwareUserDetails userDetails,
    @PathVariable("milestoneId") Milestone milestone) {
    var metadata = milestoneMapper.asPublicApiMilestoneMetadataDto(milestone);
    return milestoneMapper.asPublicApiMilestoneDto(milestone, metadata);
  }
}
