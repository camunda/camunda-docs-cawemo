/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.validation;

import com.cawemo.data.validation.constraint.Utf8ByteLength;
import java.nio.charset.StandardCharsets;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class Utf8ByteLengthValidator implements ConstraintValidator<Utf8ByteLength, String> {

  private int max;

  @Override
  public void initialize(Utf8ByteLength byteLength) {
    max = byteLength.max();
  }

  @Override
  public boolean isValid(String value, ConstraintValidatorContext context) {
    return value == null || value.getBytes(StandardCharsets.UTF_8).length <= max;
  }
}
