/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.publicapi;

import com.cawemo.data.dto.publicapi.request.ProcessDefinitionVersionCreateDto;
import com.cawemo.data.dto.publicapi.response.PublicApiProcessDefinitionVersionDto;
import com.cawemo.data.entity.Project;
import com.cawemo.data.repository.MilestoneRepository;
import com.cawemo.security.authentication.ApiKeyAwareUserDetails;
import com.cawemo.service.file.PublicApiFileService;
import com.cawemo.service.milestone.MilestoneMapper;
import com.cawemo.service.project.ProjectType;
import com.cawemo.util.api.NoSuchObjectException;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Public API: Process Definitions")
@RequiredArgsConstructor
@RestController
public class ProcessDefinitionController implements PublicApiController {

  private final PublicApiFileService fileService;
  private final MilestoneRepository milestoneRepository;
  private final MilestoneMapper milestoneMapper;

  @PreAuthorize("""
    #project.organization == #userDetails.apiKey.organization
    """)
  @PostMapping(path = "/engine-projects/{projectId}/process-definitions/versions",
    consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public PublicApiProcessDefinitionVersionDto createProcessDefinitionVersion(@PathVariable("projectId") Project project,
                                                                             @Valid @RequestBody
                                                                               ProcessDefinitionVersionCreateDto dto,
                                                                             @AuthenticationPrincipal
                                                                               ApiKeyAwareUserDetails userDetails) {
    ensureEngineProject(project);

    var version = fileService.createProcessDefinitionVersion(dto, project, userDetails.getUser());
    return milestoneMapper.asPublicApiProcessDefinitionDto(version);
  }

  @PreAuthorize("""
    hasPermission(#project, T(ProjectOperation).VIEW_MILESTONE) &&
    #project.organization == #userDetails.apiKey.organization
    """)
  @GetMapping(path = "/engine-projects/{projectId}/process-definitions/{processDefinitionKey}/versions",
    produces = MediaType.APPLICATION_JSON_VALUE)
  public List<PublicApiProcessDefinitionVersionDto> getProcessDefinitions(@PathVariable("projectId") Project project,
                                                                          @PathVariable String processDefinitionKey,
                                                                          @AuthenticationPrincipal
                                                                       ApiKeyAwareUserDetails userDetails) {
    ensureEngineProject(project);

    var processDefinitions = milestoneRepository
      .findByFileProjectOrganizationAndFileProjectAndFileProcessIdOrderByCreatedDesc(
        userDetails.getApiKey().getOrganization(), project, processDefinitionKey);
    return milestoneMapper.asPublicApiProcessDefinitionDtoList(processDefinitions);
  }

  private void ensureEngineProject(Project project) {
    if (project.getType() != ProjectType.ENGINE) {
      throw new NoSuchObjectException();
    }
  }
}
