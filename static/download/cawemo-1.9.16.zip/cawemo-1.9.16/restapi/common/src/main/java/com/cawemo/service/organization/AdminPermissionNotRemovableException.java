/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.organization;

import com.cawemo.data.entity.OrganizationPermission;
import com.cawemo.util.api.ApiError;
import com.cawemo.util.api.ForbiddenException;

public class AdminPermissionNotRemovableException extends ForbiddenException {

  AdminPermissionNotRemovableException(OrganizationPermission permission) {
    super(ApiError.INVALID_OPERATION, "Admin permission for organization " + getOrganizationId(permission) +
      " and user " + getUserId(permission) + " cannot be removed");
  }

  private static String getOrganizationId(OrganizationPermission permission) {
    return permission.getId().getOrganization().getId();
  }

  private static String getUserId(OrganizationPermission permission) {
    return permission.getId().getUser().getId();
  }
}
