/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.data.entity.ApiKey;
import com.cawemo.data.entity.File;

public interface PluginDiagramPostSyncHandler {

  void handleAfterPluginDiagramSynced(ApiKey apiKey, PluginDiagramOrigin diagramOrigin, File file);
}
