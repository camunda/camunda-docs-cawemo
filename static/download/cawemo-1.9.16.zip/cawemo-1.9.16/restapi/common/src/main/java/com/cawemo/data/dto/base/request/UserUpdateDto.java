/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import com.cawemo.util.Constants;
import com.fasterxml.jackson.annotation.JsonAlias;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class UserUpdateDto {

  @NotBlank
  @Size(max = Constants.EMAIL_MAX_LENGTH)
  private String email;

  @JsonAlias("fullName")
  @NotBlank
  @Size(max = Constants.VARCHAR_MAX)
  private String name;

  @NotNull
  private Boolean verified;
}
