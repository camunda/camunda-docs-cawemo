/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.authentication;

import java.security.SecureRandom;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.security.crypto.keygen.StringKeyGenerator;

class AlphanumericStringKeyGenerator implements StringKeyGenerator {

  private final SecureRandom secureRandom = new SecureRandom();
  private final int keyLength;

  AlphanumericStringKeyGenerator(int keyLength) {
    this.keyLength = keyLength;
  }

  @Override
  public String generateKey() {
    // same as RandomStringUtils.randomAlphanumeric, but with SecureRandom instead of Random
    return RandomStringUtils.random(keyLength, 0, 0, true, true, null, secureRandom);
  }
}
