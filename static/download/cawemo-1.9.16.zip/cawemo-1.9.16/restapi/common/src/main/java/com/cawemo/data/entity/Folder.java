/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity;

import com.cawemo.util.Constants;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Data;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(
  name = "folders",
  indexes = {
    @Index(columnList = "created_by"),
    @Index(columnList = "parent_id"),
    @Index(columnList = "project_id"),
    @Index(columnList = "updated_by")
  }
)
@EntityListeners(AuditingEntityListener.class)
@Data
@Accessors(chain = true)
public class Folder implements Serializable {

  @Id
  @GeneratedValue(generator = "uuid")
  @GenericGenerator(name = "uuid", strategy = "uuid2")
  private String id;

  @Column(nullable = false)
  private String name;

  @ManyToOne
  @JoinColumn(name = "project_id", nullable = false)
  @OnDelete(action = OnDeleteAction.CASCADE)
  private Project project;

  @ManyToOne
  @JoinColumn(name = "parent_id")
  @OnDelete(action = OnDeleteAction.CASCADE)
  private Folder parent;

  @CreatedDate
  @Column(nullable = false, updatable = false)
  private ZonedDateTime created;

  @CreatedBy
  @ManyToOne
  @JoinColumn(name = "created_by", nullable = false)
  private User createdBy;

  @LastModifiedDate
  @Column(nullable = false)
  private ZonedDateTime updated;

  @LastModifiedBy
  @ManyToOne
  @JoinColumn(name = "updated_by", nullable = false)
  private User updatedBy;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "parent", fetch = FetchType.LAZY)
  private List<Folder> children;

  @ToString.Exclude
  @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH},
    mappedBy = "folder", fetch = FetchType.LAZY)
  private List<File> files;

  @Override
  public boolean equals(Object object) {
    if (object == null) {
      return false;
    } else if (object == this) {
      return true;
    } else if (!(object instanceof Folder)) {
      return false;
    } else {
      return Objects.equals(this.id, ((Folder) object).getId());
    }
  }

  @Override
  public int hashCode() {
    return Constants.ENTITY_HASHCODE;
  }
}
