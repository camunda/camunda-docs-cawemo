/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.File;
import com.cawemo.data.entity.Milestone;
import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.User;
import com.cawemo.data.projection.MilestoneWithoutContent;
import com.cawemo.service.file.FileType;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface MilestoneRepository extends JpaRepository<Milestone, String> {

  long countByFile(File file);

  List<MilestoneWithoutContent> findByFile(File file);

  List<MilestoneWithoutContent> findByFileOrderByCreatedDesc(File file);

  @SuppressWarnings("checkstyle:linelength")
  List<MilestoneWithoutContent> findByFileProcessIdAndFileProjectNameAndFileProjectOrganizationOrganizationPermissionsIdUser(
    String processId, String projectName, User user);

  Optional<Milestone> findFirstByNameAndFileAndCreated(String name, File file, ZonedDateTime deploymentTime);

  Optional<Milestone> findFirstByFileOrderByCreatedDesc(File file);

  List<Milestone> findTop2ByFileOrderByCreatedDesc(File file);

  List<Milestone> findByFileProjectOrganizationAndFileTypeIn(Organization organization, Iterable<FileType> type);

  @Query("""
    SELECT m FROM Milestone m INNER JOIN m.file f INNER JOIN f.project p
    WHERE p.organization = :organization AND f.type IN :types
    AND (m.file.id, m.created) IN (SELECT m.file.id, MAX(m.created) FROM Milestone m GROUP BY m.file.id)
    """)
  List<Milestone> findLatestPerFileByOrganizationAndFileTypeIn(@Param("organization") Organization organization,
                                                               @Param("types") Iterable<FileType> types);

  @Query("""
    SELECT m FROM Milestone m INNER JOIN m.file f INNER JOIN f.project p
    WHERE p = :project AND p.organization = :organization AND f.type IN :types
    AND (m.file.id, m.created) IN (SELECT m.file.id, MAX(m.created) FROM Milestone m GROUP BY m.file.id)
    """)
  List<Milestone> findLatestPerFileByOrganizationAndProjectAndFileTypeIn(
    @Param("organization") Organization organization, @Param("project") Project project,
    @Param("types") Iterable<FileType> types);

  List<MilestoneWithoutContent> findByFileProjectOrganizationAndFileProjectAndFileProcessIdOrderByCreatedDesc(
    Organization organization, Project project, String processId);
}
