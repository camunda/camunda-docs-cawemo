/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.mail.template;

import com.cawemo.util.api.ServerException;

public class TemplateRenderingFailedException extends ServerException {

  TemplateRenderingFailedException(Throwable cause) {
    super(cause);
  }
}
