/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.validation;

import com.cawemo.data.dto.base.request.FoldersMoveDto;
import com.cawemo.data.entity.Folder;
import com.cawemo.data.validation.constraint.ValidFoldersMoveData;
import com.cawemo.service.folder.FolderService;
import java.util.List;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class ValidFoldersMoveDataValidator implements ConstraintValidator<ValidFoldersMoveData, FoldersMoveDto> {

  private final FolderService folderService;

  @Override
  public boolean isValid(FoldersMoveDto dto, ConstraintValidatorContext context) {
    var parentId = dto.getParentId();
    var folderIds = dto.getFolderIds();
    return parentId == null || folderIds == null || !folderIdsContainsParent(parentId, folderIds);
  }

  private boolean folderIdsContainsParent(String parentId, List<String> folderIds) {
    return folderIds.contains(parentId) || folderService.getChildrenRecursively(folderIds)
      .stream()
      .map(Folder::getId)
      .anyMatch(id -> id.equals(parentId));
  }
}
