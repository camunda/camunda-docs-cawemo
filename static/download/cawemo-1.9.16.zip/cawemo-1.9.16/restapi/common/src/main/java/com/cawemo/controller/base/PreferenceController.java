/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.base;

import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.preference.PreferenceKey;
import com.cawemo.service.preference.PreferenceService;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Preferences")
@RestController
@RequiredArgsConstructor
@Validated
public class PreferenceController implements InternalApiController {

  private final PreferenceService preferenceService;

  @GetMapping(value = "/preferences", produces = MediaType.APPLICATION_JSON_VALUE)
  public Map<PreferenceKey, Boolean> getPreferences(@AuthenticationPrincipal UserAwareUserDetails userDetails) {
    return preferenceService.getUserPreferences(userDetails.getUser());
  }

  @PostMapping(value = "/preferences", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void updatePreferences(@AuthenticationPrincipal UserAwareUserDetails userDetails,
                                @RequestBody Map<PreferenceKey, Boolean> newPreferences) {
    preferenceService.updateUserPreferences(userDetails.getUser(), newPreferences);
  }
}
