/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.ProjectSubscription;
import com.cawemo.data.entity.ProjectSubscriptionId;
import com.cawemo.data.entity.User;
import com.cawemo.data.entity.view.ProjectSubscriptionView;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ProjectSubscriptionRepository extends JpaRepository<ProjectSubscription, ProjectSubscriptionId> {

  @Query("""
    SELECT new com.cawemo.data.entity.view.ProjectSubscriptionView(pp,
    CASE WHEN s.active IS NULL THEN true ELSE s.active END) FROM ProjectPermission pp
    LEFT OUTER JOIN ProjectSubscription s ON pp.id.user = s.id.user AND s.id.project = pp.id.project
    WHERE pp.id.user = :user AND pp.id.project.organization = :organization
    """)
  List<ProjectSubscriptionView> findByIdProjectOrganizationAndIdUser(@Param("organization") Organization organization,
                                                                     @Param("user") User user);
}
