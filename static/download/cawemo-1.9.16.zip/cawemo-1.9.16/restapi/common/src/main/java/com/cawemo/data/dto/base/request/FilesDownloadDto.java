/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import com.cawemo.data.validation.constraint.FileDownloadLimit;
import com.cawemo.data.validation.constraint.FolderDownloadLimit;
import com.cawemo.data.validation.constraint.ValidFilesDownloadData;
import com.cawemo.util.Constants;
import java.util.List;
import java.util.Objects;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@ValidFilesDownloadData
public record FilesDownloadDto(
  @FileDownloadLimit List<@NotBlank @Size(min = 1, max = Constants.VARCHAR_MAX) String> fileIds,
  @FolderDownloadLimit List<@NotBlank @Size(min = 1, max = Constants.VARCHAR_MAX) String> folderIds) {

  public FilesDownloadDto(List<String> fileIds, List<String> folderIds) {
    this.fileIds = Objects.requireNonNullElse(fileIds, List.of());
    this.folderIds = Objects.requireNonNullElse(folderIds, List.of());
  }
}
