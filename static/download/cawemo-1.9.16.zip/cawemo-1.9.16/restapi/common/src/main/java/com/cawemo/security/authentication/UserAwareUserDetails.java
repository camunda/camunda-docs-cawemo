/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.authentication;

import com.cawemo.data.entity.User;
import com.cawemo.util.Constants;
import java.time.Clock;
import java.time.ZonedDateTime;
import java.util.Collection;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;

@RequiredArgsConstructor
public class UserAwareUserDetails implements UserDetails {

  @Getter
  private final User user;

  @Override
  public Collection<? extends GrantedAuthority> getAuthorities() {
    return AuthorityUtils.createAuthorityList("ROLE_USER");
  }

  @Override
  public String getPassword() {
    return null;
  }

  @Override
  public String getUsername() {
    return user.getUsername();
  }

  @Override
  public boolean isAccountNonExpired() {
    return true;
  }

  @Override
  public boolean isAccountNonLocked() {
    return true;
  }

  @Override
  public boolean isCredentialsNonExpired() {
    return true;
  }

  @Override
  public boolean isEnabled() {
    return user.isVerified() || isNonVerifiedAllowed();
  }

  private boolean isNonVerifiedAllowed() {
    var earliestAllowedCreationDate = ZonedDateTime.now(Clock.systemUTC())
      .minusHours(Constants.NON_VERIFIED_ALLOWED_PERIOD_IN_HOURS);
    return user.getCreated().isAfter(earliestAllowedCreationDate);
  }
}
