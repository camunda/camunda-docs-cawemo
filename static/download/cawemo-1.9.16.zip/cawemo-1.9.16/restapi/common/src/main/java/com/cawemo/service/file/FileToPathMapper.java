/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.data.dto.publicapi.response.PathElementDto;
import com.cawemo.data.entity.Folder;
import com.cawemo.data.projection.FileWithoutContent;
import java.util.ArrayList;
import java.util.List;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface FileToPathMapper {

  default String asSimplePath(FileWithoutContent file) {
    var folder = file.getFolder();

    return asSimplePath(folder, getFilename(file));
  }

  default String asSimplePath(Folder folder, String path) {
    if (folder == null) {
      return path;
    }

    var prependedPath = folder.getName() + "/" + path;

    return asSimplePath(folder.getParent(), prependedPath);
  }

  default List<PathElementDto> asCanonicalPath(FileWithoutContent file) {
    var folder = file.getFolder();

    var canonicalPath = new ArrayList<PathElementDto>();

    return asCanonicalPath(folder, canonicalPath);
  }

  default List<PathElementDto> asCanonicalPath(Folder folder, List<PathElementDto> path) {
    if (folder == null) {
      return path;
    }

    path.add(0, new PathElementDto(folder.getId(), folder.getName()));

    return asCanonicalPath(folder.getParent(), path);
  }

  private String getFilename(FileWithoutContent file) {
    return file.getName() + file.getType().getFileExtension();
  }
}
