/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity.listener;

import com.cawemo.data.entity.Session;
import com.cawemo.util.Constants;
import javax.persistence.PrePersist;

public class SessionEntityListener {

  @PrePersist
  public void setValidUntil(Session session) {
    var user = session.getUser();
    var validUntil = user.isVerified() ?
      // session.created has already been set by the AuditingEntityListener
      session.getCreated().plusDays(Constants.SESSION_EXPIRATION_TIME_IN_DAYS) :
      user.getCreated().plusHours(Constants.NON_VERIFIED_ALLOWED_PERIOD_IN_HOURS);
    session.setValidUntil(validUntil);
  }
}
