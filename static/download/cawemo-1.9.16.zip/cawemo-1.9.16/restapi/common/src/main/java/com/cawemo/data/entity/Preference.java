/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity;

import com.cawemo.util.Constants;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Table;
import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "preferences")
@EntityListeners(AuditingEntityListener.class)
@Data
@Accessors(chain = true)
public class Preference implements Serializable {

  @EmbeddedId
  private PreferenceId id;

  @Column(nullable = false)
  private boolean value;

  @CreatedDate
  @Column(updatable = false, nullable = false)
  private ZonedDateTime created;

  @LastModifiedDate
  @Column(nullable = false)
  private ZonedDateTime updated;

  @Override
  public boolean equals(Object object) {
    if (object == null) {
      return false;
    } else if (object == this) {
      return true;
    } else if (!(object instanceof Preference)) {
      return false;
    } else {
      return Objects.equals(this.id, ((Preference) object).getId());
    }
  }

  @Override
  public int hashCode() {
    return Constants.ENTITY_HASHCODE;
  }
}
