/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity.view;

import com.cawemo.data.entity.Project;
import com.cawemo.service.project.ProjectPermissionLevel;
import com.cawemo.service.project.ProjectType;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class ProjectPermissionView {

  private final Project project;
  private final ProjectPermissionLevel projectPermission;

  public ProjectType getProjectType() {
    return project.getType();
  }
}
