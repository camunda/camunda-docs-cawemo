/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.authentication;

import com.cawemo.data.repository.SessionRepository;
import com.cawemo.security.authentication.cookie.SessionCookieRememberMeService;
import java.io.IOException;
import java.util.Optional;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.stereotype.Component;
import org.springframework.web.util.WebUtils;

@Slf4j
@Component
public class LogOutSuccessHandler implements LogoutSuccessHandler {

  private final SessionRepository sessionRepository;

  public LogOutSuccessHandler(SessionRepository sessionRepository) {
    this.sessionRepository = sessionRepository;
  }

  @Override
  public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
    throws IOException {
    Optional.ofNullable(WebUtils.getCookie(request, SessionCookieRememberMeService.SESSION_COOKIE_NAME))
      .map(Cookie::getValue)
      .ifPresent(value -> {
        try {
          sessionRepository.deleteById(value);
          log.info("Log out successful, session '{}' deleted", value);
        } catch (EmptyResultDataAccessException e) {
          log.info("User tried to log out with invalid session id");
        }
      });

    response.setStatus(HttpStatus.NO_CONTENT.value());
    response.getWriter().flush();
  }
}
