/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.folder;

import com.cawemo.data.dto.base.request.FolderCreateDto;
import com.cawemo.data.dto.base.request.FolderUpdateDto;
import com.cawemo.data.dto.base.response.DryRunDeleteWarningsDto;
import com.cawemo.data.dto.base.response.FolderChildDto;
import com.cawemo.data.dto.base.response.FolderDto;
import com.cawemo.data.entity.Folder;
import com.cawemo.data.entity.Project;
import com.cawemo.data.projection.FileWithoutContent;
import com.cawemo.service.file.FileMapper;
import com.cawemo.service.user.UserMapper;
import com.cawemo.util.UrlSlug;
import com.cawemo.util.api.ApiWarning;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.NullValueMappingStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring", uses = {FileMapper.class, UserMapper.class})
public interface FolderMapper {

  @Mapping(source = "folder.project.id", target = "projectId")
  @Mapping(source = "folder.parent.id", target = "parentId")
  @Mapping(source = "folder", target = "slug", qualifiedByName = "folderSlug")
  @Mapping(source = "files", target = "files")
  FolderDto asFolderDto(Folder folder, List<FileWithoutContent> files);

  @Mapping(source = "folder", target = "slug", qualifiedByName = "folderSlug")
  FolderChildDto asFolderChildDto(Folder folder);

  default List<FolderChildDto> asFolderChildDtoList(List<Folder> folders) {
    return (folders != null) ? folders
      .stream()
      .map(this::asFolderChildDto)
      .sorted(Comparator.comparing(FolderChildDto::getName))
      .collect(Collectors.toList()) : null;
  }

  @Mapping(source = "dto.name", target = "name")
  @Mapping(source = "parent", target = "parent")
  @Mapping(source = "project", target = "project")
  @Mapping(target = "created", ignore = true)
  @Mapping(target = "createdBy", ignore = true)
  @Mapping(target = "files", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "updated", ignore = true)
  @Mapping(target = "updatedBy", ignore = true)
  Folder asFolder(FolderCreateDto dto, Project project, Folder parent);

  @Mapping(target = "name", source = "dto.name")
  @BeanMapping(
    ignoreByDefault = true,
    nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
  )
  Folder updateFromDto(@MappingTarget Folder folder, FolderUpdateDto dto);

  DryRunDeleteWarningsDto asDryRunDeleteWarningsDto(Integer folderCount, Integer fileCount, Set<ApiWarning> warnings);

  @Named("folderSlug")
  default String folderSlug(Folder folder) {
    return UrlSlug.buildSlug(folder.getId(), folder.getName());
  }
}
