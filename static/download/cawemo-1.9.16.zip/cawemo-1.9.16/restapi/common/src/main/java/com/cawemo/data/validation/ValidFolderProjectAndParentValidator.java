/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.validation;

import com.cawemo.data.dto.base.request.AbstractFolderDto;
import com.cawemo.data.validation.constraint.ValidFolderProjectAndParent;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidFolderProjectAndParentValidator
  implements ConstraintValidator<ValidFolderProjectAndParent, AbstractFolderDto> {

  @Override
  public boolean isValid(AbstractFolderDto dto, ConstraintValidatorContext context) {
    return dto.getProjectId() != null || dto.getParentId() != null;
  }
}
