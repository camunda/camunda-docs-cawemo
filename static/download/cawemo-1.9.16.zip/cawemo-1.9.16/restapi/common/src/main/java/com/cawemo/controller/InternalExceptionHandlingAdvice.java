/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller;

import com.cawemo.controller.admin.AdminApiController;
import com.cawemo.controller.base.InternalApiController;
import com.cawemo.controller.plugin.PluginApiController;
import com.cawemo.data.dto.base.response.ApiResponseWrapperDto;
import com.cawemo.data.validation.constraint.CustomApiErrorResponse;
import com.cawemo.util.api.ApiError;
import com.cawemo.util.api.ApiResponseUtil;
import com.cawemo.util.api.BadRequestException;
import com.cawemo.util.api.ClientException;
import com.cawemo.util.api.ConflictException;
import com.cawemo.util.api.ForbiddenException;
import com.cawemo.util.api.NotFoundException;
import com.cawemo.util.api.ServerException;
import com.cawemo.util.api.UnauthorizedException;
import com.cawemo.util.api.UnprocessableEntityException;
import java.util.Arrays;
import java.util.Optional;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.convert.ConversionFailedException;
import org.springframework.core.task.TaskRejectedException;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@Slf4j
@Order(InternalExceptionHandlingAdvice.ADVICE_ORDER)
@ControllerAdvice(assignableTypes = {AdminApiController.class, InternalApiController.class, PluginApiController.class})
public class InternalExceptionHandlingAdvice {

  public static final int ADVICE_ORDER = Ordered.HIGHEST_PRECEDENCE;

  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler({
    ConstraintViolationException.class,
    HttpMessageNotReadableException.class,
    IllegalArgumentException.class,
    MissingServletRequestParameterException.class
  })
  public @ResponseBody ApiResponseWrapperDto returnBadRequest() {
    return createInvalidInputErrorResponse();
  }

  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler
  public @ResponseBody ApiResponseWrapperDto returnBadRequest(MethodArgumentNotValidException e) {
    return createErrorResponse(e);
  }

  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler
  public @ResponseBody ApiResponseWrapperDto returnBadRequest(BadRequestException e) {
    return createErrorResponse(e);
  }

  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  @ExceptionHandler
  public @ResponseBody ApiResponseWrapperDto returnUnauthorized(UnauthorizedException e) {
    return createErrorResponse(e);
  }

  @ResponseStatus(HttpStatus.FORBIDDEN)
  @ExceptionHandler
  public @ResponseBody ApiResponseWrapperDto returnForbidden(ForbiddenException e) {
    return createErrorResponse(e);
  }

  @ResponseStatus(HttpStatus.NOT_FOUND)
  @ExceptionHandler({AccessDeniedException.class, ConversionFailedException.class, MissingPathVariableException.class})
  public void returnNotFound() {
  }

  @ResponseStatus(HttpStatus.NOT_FOUND)
  @ExceptionHandler
  public @ResponseBody ApiResponseWrapperDto returnNotFound(NotFoundException e) {
    return createErrorResponse(e);
  }

  @ResponseStatus(HttpStatus.CONFLICT)
  @ExceptionHandler
  public @ResponseBody ApiResponseWrapperDto returnConflict(ConflictException e) {
    return createErrorResponse(e);
  }

  @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
  @ExceptionHandler(UnprocessableEntityException.class)
  public void returnUnprocessableEntity() {
  }

  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  @ExceptionHandler(ServerException.class)
  public void returnInternalServerError(ServerException e) {
    log.error("Request failed unexpectedly", e);
  }

  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  @ExceptionHandler
  public void internalServerError(TaskRejectedException e) {
    log.error("Request failed since async task was rejected", e);
  }

  private ApiResponseWrapperDto createInvalidInputErrorResponse() {
    return ApiResponseUtil.createErrorResponse(ApiError.INVALID_INPUT);
  }

  private ApiResponseWrapperDto createErrorResponse(ClientException e) {
    return ApiResponseUtil.createErrorResponse(e.getApiError());
  }

  private ApiResponseWrapperDto createErrorResponse(MethodArgumentNotValidException e) {
    return e.getFieldErrors().stream()
      .map(fieldError -> fieldError.unwrap(ConstraintViolation.class))
      .map(violation -> findCustomApiErrorResponseAnnotation(violation)
        .map(error -> {
          log.warn("Request failed with the following error code: {}", error.reason());
          return ApiResponseUtil.createErrorResponse(
            error.reason(), error.useMessageAsDetail() ? violation.getMessage() : null);
        }))
      .filter(Optional::isPresent)
      .map(Optional::get)
      .findFirst()
      .orElseGet(this::createInvalidInputErrorResponse);
  }

  private Optional<CustomApiErrorResponse> findCustomApiErrorResponseAnnotation(
    ConstraintViolation<?> violation) {
    return Arrays.stream(violation
        .getConstraintDescriptor()
        .getAnnotation()
        .annotationType()
        .getAnnotations())
      .filter(annotation -> annotation.annotationType() == CustomApiErrorResponse.class)
      .findFirst()
      .map(CustomApiErrorResponse.class::cast);
  }
}
