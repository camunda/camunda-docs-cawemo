/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.organization;

import com.cawemo.data.entity.Organization;
import com.cawemo.util.api.ApiError;
import com.cawemo.util.api.ForbiddenException;

public class OrganizationPermissionNotChangeableException extends ForbiddenException {

  OrganizationPermissionNotChangeableException(Organization organization) {
    super(ApiError.INVALID_OPERATION, "Permission for organization " + organization.getId() + " cannot be changed");
  }
}
