/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.data.entity.File;
import com.cawemo.data.repository.FileRepository;
import com.cawemo.data.repository.FolderRepository;
import com.cawemo.util.api.ServerException;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.attribute.FileTime;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.IntStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class FileDownloadService {

  private final FileRepository fileRepository;
  private final FolderRepository folderRepository;

  public void copyFileContentToOutputStream(File file, OutputStream outputStream) {
    try {
      log.info("Downloading file {}", file.getId());
      StreamUtils.copy(file.getContent(), StandardCharsets.UTF_8, outputStream);
    } catch (IOException e) {
      throw new ServerException("Failed to copy content of file " + file.getId() + " to OutputStream", e);
    }
  }

  public void copyFilesToZipOutputStream(
    List<String> fileIds, List<String> folderIds, ZipOutputStream zipOutputStream) {
    copyFilesToZipOutputStream("", fileIds, zipOutputStream);
    copyFoldersToZipOutputStream(folderIds, zipOutputStream);
  }

  private void copyFoldersToZipOutputStream(List<String> folderIds, ZipOutputStream zipOutputStream) {
    if (folderIds.isEmpty()) {
      return;
    }
    var folderPathCount = new HashMap<String, Integer>();
    var folderEntries =
      folderIds.stream().map(id -> new FolderQueueEntry("", id)).toList();
    var folderQueue = new LinkedList<>(folderEntries);
    while (!folderQueue.isEmpty()) {
      var current = folderQueue.poll();
      folderRepository.findById(current.folderId).ifPresent(folder -> {
        log.info("Downloading files in folder {}", folder.getId());

        var folderPath = prependPathIfNotEmpty(current.parentPath, sanitizeName(folder.getName()));
        var count = folderPathCount.merge(folderPath, 1, Integer::sum);
        var zipFolderPath = (count == 1) ? folderPath : (folderPath + " (" + count + ")");

        var fileIds = fileRepository.findFileIdsByFolder(folder);
        var childFolderIds = folderRepository.findFolderIdsByParent(folder);

        if (fileIds.isEmpty() && childFolderIds.isEmpty()) {
          addZipEntryForEmptyFolder(zipOutputStream, zipFolderPath);
        } else {
          copyFilesToZipOutputStream(zipFolderPath, fileIds, zipOutputStream);
          IntStream.range(0, childFolderIds.size())
            .forEach(i ->
              folderQueue.add(i, new FolderQueueEntry(zipFolderPath, childFolderIds.get(i))));
        }
      });
    }
  }

  private void copyFilesToZipOutputStream(String folderPath, List<String> fileIds, ZipOutputStream zipOutputStream) {
    if (fileIds.isEmpty()) {
      return;
    }
    var fileNameCount = new HashMap<String, Integer>();
    fileIds.forEach(id -> fileRepository.findById(id).ifPresent(file -> {
      var fileName = prependPathIfNotEmpty(folderPath, sanitizeName(file.getName())) + getFileExtension(file);
      var count = fileNameCount.merge(fileName, 1, Integer::sum);
      var zipEntryName = (count == 1)
        ? fileName
        // ensure unique file names inside ZIP archive
        : (StringUtils.substringBeforeLast(fileName, ".") + " (" + count + ")" + getFileExtension(file));
      addZipEntryFromFile(zipOutputStream, zipEntryName, file);
    }));
  }

  /**
   * Replaces "/" and "\" characters in the name (as they would be used as path separators inside the ZIP archive and
   * create sub folders).
   */
  private static String sanitizeName(String name) {
    return name.replaceAll("([/\\\\])", "_");
  }

  private static String getFileExtension(File file) {
    return file.getType().getFileExtension();
  }

  private static String prependPathIfNotEmpty(String path, String name) {
    return path.isEmpty() ? name : (path + "/" + name);
  }

  private static void addZipEntryForEmptyFolder(ZipOutputStream zip, String name) {
    try {
      var entry = new ZipEntry(name + "/"); // trailing slash creates a folder instead of a file
      zip.putNextEntry(entry);
      zip.closeEntry();
    } catch (IOException e) {
      throw new ServerException("Failed to create ZIP entry for empty folder", e);
    }
  }

  private void addZipEntryFromFile(ZipOutputStream zip, String name, File file) {
    try {
      var entry = new ZipEntry(name);
      entry.setSize(file.getContent().length());
      entry.setCreationTime(FileTime.from(file.getCreated().toInstant()));
      entry.setLastModifiedTime(FileTime.from(file.getUpdated().toInstant()));
      zip.putNextEntry(entry);
      copyFileContentToOutputStream(file, zip);
      zip.closeEntry();
    } catch (IOException e) {
      throw new ServerException("Failed to create ZIP entry for file " + file.getId(), e);
    }
  }

  private record FolderQueueEntry(String parentPath, String folderId) {
  }
}
