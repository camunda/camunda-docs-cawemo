/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity.listener;

import com.cawemo.data.entity.File;
import com.cawemo.data.entity.event.PrePersistFileEvent;
import javax.persistence.PrePersist;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class FileEntityListener {

  private final ApplicationEventPublisher publisher;

  @PrePersist
  public void prePersist(File file) {
    publisher.publishEvent(new PrePersistFileEvent(file));
  }
}
