/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.access.permission;

import com.cawemo.data.entity.File;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.project.ProjectOperation;
import java.util.Collection;
import java.util.stream.Collectors;
import org.springframework.stereotype.Component;

@Component
public class FilePermissionEvaluator implements EntityPermissionEvaluator<File, ProjectOperation>,
                                                EntityCollectionPermissionEvaluator<File, ProjectOperation> {

  private final ProjectPermissionEvaluator projectPermissionEvaluator;

  public FilePermissionEvaluator(ProjectPermissionEvaluator projectPermissionEvaluator) {
    this.projectPermissionEvaluator = projectPermissionEvaluator;
  }

  @Override
  public boolean hasPermission(UserAwareUserDetails userDetails, File file, ProjectOperation projectOperation) {
    return projectPermissionEvaluator.hasPermission(userDetails, file.getProject(), projectOperation);
  }

  @Override
  public boolean hasPermission(UserAwareUserDetails userDetails, Collection<File> files,
                               ProjectOperation projectOperation) {
    var projects = files.stream().map(File::getProject).collect(Collectors.toList());
    return projectPermissionEvaluator.hasPermission(userDetails, projects, projectOperation);
  }
}
