/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.base;

import com.cawemo.data.dto.base.response.ApiWarningsDto;
import com.cawemo.data.dto.base.response.DryRunDeleteWarningsDto;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.Folder;
import com.cawemo.service.file.FileService;
import com.cawemo.service.folder.FolderMapper;
import com.cawemo.service.folder.FolderService;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Dry Run")
@RestController
@RequiredArgsConstructor
public class DryRunController implements InternalApiController {

  private final FileService fileService;
  private final FolderService folderService;
  private final FolderMapper folderMapper;

  @PreAuthorize(
    "(#deletedFiles == null || " +
      "hasPermissionToCollection(#deletedFiles, 'com.cawemo.data.entity.File', T(ProjectOperation).DELETE_FILE)) && " +
    "(#deletedFolders == null || " +
      "hasPermissionToCollection(#deletedFolders, 'com.cawemo.data.entity.Folder', T(ProjectOperation).DELETE_FOLDER))"
  )
  @GetMapping(value = "/dry-run/delete", produces = MediaType.APPLICATION_JSON_VALUE)
  public DryRunDeleteWarningsDto dryRunDelete(@RequestParam(value = "fileId", required = false) List<File> deletedFiles,
                                              @RequestParam(value = "folderId", required = false)
                                                List<Folder> deletedFolders) {
    deletedFiles = Objects.requireNonNullElse(deletedFiles, List.of());
    deletedFolders = Objects.requireNonNullElse(deletedFolders, List.of());

    var filesByFolders = folderService.getFilesRecursively(deletedFolders);

    var files = flatMapFiles(filesByFolders);
    files.addAll(deletedFiles);
    var warnings = fileService.getDeleteFilesSideEffectWarnings(files);
    return folderMapper.asDryRunDeleteWarningsDto(filesByFolders.keySet().size(), files.size(), warnings);
  }

  @PreAuthorize(
    "(#movedFiles == null || " +
      "hasPermissionToCollection(#movedFiles, 'com.cawemo.data.entity.File', T(ProjectOperation).MODIFY_FILE)) && " +
    "(#movedFolders == null || " +
      "hasPermissionToCollection(#movedFolders, 'com.cawemo.data.entity.Folder', T(ProjectOperation).MODIFY_FOLDER))"
  )
  @GetMapping(value = "/dry-run/move", produces = MediaType.APPLICATION_JSON_VALUE)
  public ApiWarningsDto dryRunMove(@RequestParam(value = "fileId", required = false) List<File> movedFiles,
                                   @RequestParam(value = "folderId", required = false) List<Folder> movedFolders) {
    movedFiles = Objects.requireNonNullElse(movedFiles, List.of());
    movedFolders = Objects.requireNonNullElse(movedFolders, List.of());

    var files = flatMapFiles(folderService.getFilesRecursively(movedFolders));
    files.addAll(movedFiles);
    var warnings = fileService.getMoveFilesSideEffectWarnings(files);
    return new ApiWarningsDto().setWarnings(warnings);
  }

  private static Collection<File> flatMapFiles(Map<Folder, Collection<File>> filesPerFolder) {
    return filesPerFolder
      .values()
      .stream()
      .flatMap(Collection::stream)
      .collect(Collectors.toList());
  }
}
