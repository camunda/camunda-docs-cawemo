/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.mail.template.view;

import com.cawemo.data.entity.User;
import com.cawemo.service.mail.ThemeProperties;
import java.util.Collections;
import java.util.Map;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class View {

  private final String templatePath;
  private final User user;

  // are set in TemplateService before rendering
  private String hostUrl;
  private ThemeProperties theme;

  public Map<String, View> toModel() {
    return Collections.singletonMap("view", this);
  }
}
