/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.base;

import com.cawemo.data.dto.base.request.ApiKeyCreateDto;
import com.cawemo.data.dto.base.request.ApiKeyUpdateDto;
import com.cawemo.data.dto.base.response.ApiKeyDto;
import com.cawemo.data.dto.base.response.ApiKeyWithSecretDto;
import com.cawemo.data.entity.ApiKey;
import com.cawemo.data.entity.Organization;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.authentication.ApiKeyMapper;
import com.cawemo.service.authentication.ApiKeyService;
import com.cawemo.util.swagger.SwaggerUuidParameter;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Api Keys")
@RequiredArgsConstructor
@RestController
public class ApiKeyController implements InternalApiController {

  private final ApiKeyService apiKeyService;
  private final ApiKeyMapper apiKeyMapper;

  @PreAuthorize("hasPermission(#organization, T(OrganizationOperation).VIEW_API_KEYS)")
  @GetMapping(value = "/organizations/{organizationId}/keys", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<ApiKeyDto> getApiKeys(@SwaggerUuidParameter @PathVariable("organizationId") Organization organization,
                                    @AuthenticationPrincipal UserAwareUserDetails userDetails) {
    var keys = apiKeyService.getApiKeysForUser(organization, userDetails.getUser());
    return apiKeyMapper.asApiKeyDtoList(keys);
  }

  @PreAuthorize("hasPermission(#dto.organizationId, 'com.cawemo.data.entity.Organization', " +
    "T(OrganizationOperation).MODIFY_API_KEY)")
  @PostMapping(value = "/keys",
    consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ApiKeyWithSecretDto createApiKey(@Valid @RequestBody @Parameter(required = true) ApiKeyCreateDto dto) {
    return apiKeyMapper.asApiKeyWithSecretDto(apiKeyService.createApiKey(dto));
  }

  @PreAuthorize("hasPermission(#key.organization, T(OrganizationOperation).MODIFY_API_KEY) && " +
    "authentication.principal.user.id == #key.user.id")
  @DeleteMapping(value = "/keys/{keyId}")
  public void deleteApiKey(@SwaggerUuidParameter @PathVariable("keyId") ApiKey key) {
    apiKeyService.deleteApiKey(key);
  }

  @PreAuthorize("hasPermission(#key.organization, T(OrganizationOperation).MODIFY_API_KEY) && " +
    "authentication.principal.user.id == #key.user.id")
  @PatchMapping(value = "/keys/{keyId}",
    consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ApiKeyDto patchApiKey(@SwaggerUuidParameter @PathVariable("keyId") ApiKey key,
                               @Valid @RequestBody @Parameter(required = true) ApiKeyUpdateDto dto) {
    return apiKeyMapper.asApiKeyDto(apiKeyService.updateApiKey(key, dto));
  }
}
