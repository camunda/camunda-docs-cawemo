/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.base;

import com.cawemo.data.dto.base.request.ProjectInvitationDto;
import com.cawemo.data.dto.base.response.ProjectInvitationResultListWrapperDto;
import com.cawemo.data.entity.Project;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.project.ProjectInvitationHandler;
import com.cawemo.service.project.ProjectInvitationMapper;
import io.swagger.v3.oas.annotations.tags.Tag;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Project Invitations")
@RestController
@RequiredArgsConstructor
public class ProjectInvitationController implements InternalApiController {

  private final ProjectInvitationHandler projectInvitationHandler;
  private final ProjectInvitationMapper projectInvitationMapper;

  @PreAuthorize("hasPermission(#project, T(ProjectOperation).INVITE_COLLABORATOR)")
  @PostMapping(path = "/projects/{projectId}/invite", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public ProjectInvitationResultListWrapperDto inviteCollaborators(
    @AuthenticationPrincipal UserAwareUserDetails userDetails, @PathVariable("projectId") Project project,
    @Valid @RequestBody ProjectInvitationDto dto) {
    var results = projectInvitationHandler.inviteCollaborators(userDetails.getUser(), project, dto);
    return projectInvitationMapper.asListWrapperDto(results);
  }
}
