/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.authentication;

import com.cawemo.util.api.ApiError;
import com.cawemo.util.api.ApiResponseUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class LoginFailureHandler implements AuthenticationFailureHandler {

  private final ObjectMapper objectMapper;

  @Override
  public void onAuthenticationFailure(HttpServletRequest request,
                                      HttpServletResponse response,
                                      AuthenticationException e) throws IOException {
    response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

    if (e instanceof DisabledException) {
      response.setContentType(MediaType.APPLICATION_JSON_VALUE);
      response.getWriter().print(createNotVerifiedResponse());
      response.getWriter().flush();
    }
  }

  private String createNotVerifiedResponse() throws JsonProcessingException {
    var response = ApiResponseUtil.createErrorResponse(ApiError.NOT_VERIFIED);
    return objectMapper.writeValueAsString(response);
  }
}
