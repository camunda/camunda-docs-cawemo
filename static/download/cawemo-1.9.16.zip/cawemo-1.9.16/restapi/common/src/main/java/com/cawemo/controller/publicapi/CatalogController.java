/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.publicapi;

import com.cawemo.data.dto.publicapi.response.CatalogDto;
import com.cawemo.data.repository.ProjectRepository;
import com.cawemo.security.authentication.ApiKeyAwareUserDetails;
import com.cawemo.service.project.ProjectMapper;
import com.cawemo.service.project.ProjectType;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Public API: Catalogs")
@RequiredArgsConstructor
@RestController
public class CatalogController implements PublicApiController {

  private final ProjectRepository projectRepository;
  private final ProjectMapper projectMapper;

  @PreAuthorize(
    "hasPermission(#userDetails.apiKey.organization, T(OrganizationOperation).VIEW_PROJECTS)"
  )
  @GetMapping(path = "/catalogs", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<CatalogDto> getCatalogs(@AuthenticationPrincipal ApiKeyAwareUserDetails userDetails) {
    var catalogs = projectRepository
      .findByOrganizationAndType(userDetails.getApiKey().getOrganization(), ProjectType.CATALOG);
    return projectMapper.asCatalogDtoList(catalogs);
  }
}
