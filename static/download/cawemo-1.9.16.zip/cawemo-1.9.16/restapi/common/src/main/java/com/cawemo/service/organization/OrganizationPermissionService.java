/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.organization;

import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.OrganizationPermission;
import com.cawemo.data.entity.OrganizationPermissionId;
import com.cawemo.data.entity.User;
import com.cawemo.data.entity.event.PreRemoveOrganizationPermissionEvent;
import com.cawemo.data.repository.OrganizationPermissionRepository;
import com.cawemo.service.mail.MailService;
import com.cawemo.util.api.NoSuchObjectException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class OrganizationPermissionService {

  private final ApplicationEventPublisher publisher;
  private final OrganizationPermissionRepository organizationPermissionRepository;
  private final MailService mailService;

  public List<User> getOrganizationAdmins(Organization organization) {
    return organizationPermissionRepository
      .findByIdOrganizationAndAccess(organization, OrganizationPermissionLevel.ADMIN)
      .stream()
      .map(permission -> permission.getId().getUser())
      .collect(Collectors.toList());
  }

  public User getMostSeniorOrganizationAdminExcludingUser(Organization organization, User user) {
    return organizationPermissionRepository
      .findFirstByIdOrganizationAndIdUserNotAndAccessOrderByCreated(
        organization, user, OrganizationPermissionLevel.ADMIN)
      .map(permission -> permission.getId().getUser())
      .orElseThrow(() -> new OrganizationAdminNotFoundException(organization.getId()));
  }

  @Transactional
  public OrganizationPermission createOwnerOrganizationPermission(Organization organization, User user) {
    var id = createOrganizationPermissionId(organization, user);
    var organizationPermission = new OrganizationPermission()
      .setId(id)
      .setAccess(OrganizationPermissionLevel.ADMIN)
      .setCreatedBy(user)
      .setUpdatedBy(user);
    return organizationPermissionRepository.save(organizationPermission);
  }

  @Transactional
  public OrganizationPermission getOrCreateCollaboratorPermission(Organization organization, User user,
                                                                  User createdBy) {
    var id = createOrganizationPermissionId(organization, user);
    return organizationPermissionRepository.findById(id).orElseGet(() -> {
      var organizationPermission = new OrganizationPermission()
        .setId(id)
        .setAccess(OrganizationPermissionLevel.USER)
        .setCreatedBy(createdBy)
        .setUpdatedBy(createdBy);
      return organizationPermissionRepository.save(organizationPermission);
    });
  }

  public Optional<OrganizationPermission> findByOrganizationAndUser(Organization organization, User user) {
    var id = createOrganizationPermissionId(organization, user);
    return organizationPermissionRepository.findById(id);
  }

  public boolean organizationPermissionExists(Organization organization, String userEmail) {
    return organizationPermissionRepository.existsByIdOrganizationAndIdUserEmailIgnoreCase(organization, userEmail);
  }

  public int countOrganizationPermissions(Organization organization) {
    return organizationPermissionRepository.countByIdOrganization(organization);
  }

  public boolean otherPermissionExists(Organization organization, User excludedUser,
                                       OrganizationPermissionLevel access) {
    return organizationPermissionRepository
      .existsByIdOrganizationAndIdUserNotAndAccess(organization, excludedUser, access);
  }

  public void deleteOrganizationPermission(OrganizationPermission permission) {
    // TODO #5425: event is published manually (and not in an entity listener) so that it does not get triggered when an
    //  organization is deleted and this deletion is cascaded automatically to organization permissions
    publisher.publishEvent(new PreRemoveOrganizationPermissionEvent(permission));
    organizationPermissionRepository.delete(permission);
  }

  public OrganizationPermission getByOrganizationAndUserEmail(Organization organization, String userEmail) {
    return organizationPermissionRepository.findByIdOrganizationAndIdUserEmailIgnoreCase(organization, userEmail)
      .orElseThrow(NoSuchObjectException::new);
  }

  public void sendOrganizationPermissionChangedMail(OrganizationPermission permission, User authenticatedUser) {
    var permissionUser = permission.getId().getUser();
    if (!permissionUser.equals(authenticatedUser)) {
      var organization = permission.getId().getOrganization();
      if (permission.getAccess() == OrganizationPermissionLevel.ADMIN) {
        mailService.sendOrganizationAdminPermissionGrantedMail(authenticatedUser, permissionUser, organization);
      } else {
        mailService.sendOrganizationAdminPermissionRevokedMail(authenticatedUser, permissionUser, organization);
      }
    }
  }

  public List<OrganizationPermission> findByUser(User user) {
    return organizationPermissionRepository.findByIdUser(user);
  }

  private OrganizationPermissionId createOrganizationPermissionId(Organization organization, User user) {
    return new OrganizationPermissionId()
      .setOrganization(organization)
      .setUser(user);
  }
}
