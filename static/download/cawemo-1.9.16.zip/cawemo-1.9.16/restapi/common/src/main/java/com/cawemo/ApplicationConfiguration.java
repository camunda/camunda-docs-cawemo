/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo;

import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.context.annotation.Configuration;

/**
 * As we don't have a {@link org.springframework.boot.SpringApplication} in this module, we need a {@link Configuration}
 * in the root of our package structure for global settings.
 */
@ConfigurationPropertiesScan
@Configuration
public class ApplicationConfiguration {
}
