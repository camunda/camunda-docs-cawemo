/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.publicapi.request;

import com.cawemo.data.validation.constraint.NullOrNotBlank;
import com.cawemo.data.validation.constraint.NullOrNotEmpty;
import com.cawemo.util.Constants;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class TemplateUpdateDto {

  @JsonProperty("$schema")
  private String schema;

  @Size(max = Constants.VARCHAR_MAX)
  @NullOrNotBlank
  private String name;

  private String description;

  private String id;

  @NullOrNotEmpty
  private List<@NotBlank String> appliesTo;

  private List<Object> properties;

  private Long version;

  @Valid
  private Metadata metadata;

  @JsonAnySetter
  @JsonAnyGetter
  @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
  private Map<String, Object> additionalProperties = new HashMap<>();

  @Data
  @Accessors(chain = true)
  public static class Metadata {

    @Size(max = Constants.VARCHAR_MAX)
    @NullOrNotBlank
    private String catalogId;

    @Size(max = Constants.VARCHAR_MAX)
    @NullOrNotBlank
    private String templateVersionName;

    private boolean published;
  }
}
