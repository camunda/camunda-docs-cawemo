/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.publicapi.response;

import java.util.List;

public record PublicApiFileMetadataDto(
  String id,
  String name,
  String projectId,
  String folderId,
  String simplePath,
  List<PathElementDto> canonicalPath,
  int revision,
  String type,
  String created,
  PublicApiUserDto createdBy,
  String updated,
  PublicApiUserDto updatedBy) { }
