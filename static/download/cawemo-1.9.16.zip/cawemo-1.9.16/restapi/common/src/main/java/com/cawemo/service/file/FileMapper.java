/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.data.dto.base.request.DiagramEnginePluginDto;
import com.cawemo.data.dto.base.request.DiagramModelerPluginDto;
import com.cawemo.data.dto.base.request.FileCreateDto;
import com.cawemo.data.dto.base.request.FileCreateFromMilestoneDto;
import com.cawemo.data.dto.base.request.FileUpdateDto;
import com.cawemo.data.dto.base.request.MilestoneAddRelatedDiagramDto;
import com.cawemo.data.dto.base.request.MilestoneRestoreDto;
import com.cawemo.data.dto.base.response.FileDto;
import com.cawemo.data.dto.base.response.FileWithoutContentDto;
import com.cawemo.data.dto.base.response.FileWrapperDto;
import com.cawemo.data.dto.base.response.LinkedFileDto;
import com.cawemo.data.dto.base.response.RelatedFileDto;
import com.cawemo.data.dto.publicapi.request.ProcessDefinitionVersionCreateDto;
import com.cawemo.data.dto.publicapi.request.TemplateCreateDto;
import com.cawemo.data.dto.publicapi.request.TemplateUpdateDto;
import com.cawemo.data.dto.publicapi.response.PublicApiFileDto;
import com.cawemo.data.dto.publicapi.response.PublicApiFileMetadataDto;
import com.cawemo.data.dto.view.TemplateContentView;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.FileShare;
import com.cawemo.data.entity.Folder;
import com.cawemo.data.entity.Milestone;
import com.cawemo.data.entity.Project;
import com.cawemo.data.projection.FileWithProcessIdOnly;
import com.cawemo.data.projection.FileWithoutContent;
import com.cawemo.service.folder.FolderMapper;
import com.cawemo.service.user.UserMapper;
import com.cawemo.util.UrlSlug;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import org.mapstruct.BeanMapping;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.NullValueMappingStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring", uses = {
  FileLinkMapper.class,
  FileToPathMapper.class,
  FolderMapper.class,
  UserMapper.class
})
@DecoratedWith(FileMapperDecorator.class)
public interface FileMapper {

  @Mapping(target = "comments", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "linksOutgoing", ignore = true) // added by FileMapperDecorator
  @Mapping(target = "legacyLinksIncoming", ignore = true)
  @Mapping(target = "milestones", ignore = true)
  @Mapping(target = "share", ignore = true)
  File asDuplicate(File file);

  @Mapping(source = "createdBy", target = "author")
  @Mapping(source = "file.share", target = "passwordProtected", qualifiedByName = "isFileSharePasswordProtected")
  @Mapping(source = "file", target = "slug", qualifiedByName = "fileSlug")
  @Mapping(source = "folder.id", target = "folderId")
  @Mapping(source = "project.id", target = "projectId")
  @Mapping(source = "project.organization.id", target = "organizationId")
  @Mapping(source = "share.id", target = "shareId")
  @Mapping(source = "updated", target = "changed")
  @Mapping(target = "children", ignore = true)
  @Mapping(target = "parents", ignore = true)
  FileDto asFileDto(File file);

  @Mapping(source = "createdBy", target = "author")
  @Mapping(source = "file.share", target = "passwordProtected", qualifiedByName = "isFileSharePasswordProtected")
  @Mapping(source = "file", target = "slug", qualifiedByName = "fileWithoutContentSlug")
  @Mapping(source = "folder.id", target = "folderId")
  @Mapping(source = "project.id", target = "projectId")
  @Mapping(source = "project.organization.id", target = "organizationId")
  @Mapping(source = "share.id", target = "shareId")
  @Mapping(source = "updated", target = "changed")
  @Mapping(target = "children", ignore = true)
  @Mapping(target = "parents", ignore = true)
  FileWithoutContentDto asFileWithoutContentDto(FileWithoutContent file);

  FileWithoutContent asFileWithoutContent(File file);

  List<FileDto> asFileDtoList(List<File> files);

  List<FileWithoutContentDto> asFileWithoutContentDtoList(List<FileWithoutContent> files);

  List<FileWithoutContentDto> asFileWithoutContentDtoListFromFileList(List<File> files);

  FileWrapperDto asFileWrapperDto(File file);

  List<LinkedFileDto> asLinkedFileDtoList(List<FileWithProcessIdOnly> files);

  LinkedFileDto asLinkedFileDto(FileWithProcessIdOnly file);

  List<RelatedFileDto> asRelatedFileDtoList(List<FileWithoutContent> files);

  @Mapping(source = "file", target = "slug", qualifiedByName = "fileWithoutContentSlug")
  RelatedFileDto asRelatedFileDto(FileWithoutContent file);

  @Mapping(source = "dto.name", target = "name")
  @Mapping(source = "dto.type", target = "type")
  @Mapping(source = "folder", target = "folder")
  @Mapping(source = "project", target = "project")
  @Mapping(target = "comments", ignore = true)
  @Mapping(target = "created", ignore = true)
  @Mapping(target = "createdBy", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "legacyLinksIncoming", ignore = true)
  @Mapping(target = "linksOutgoing", ignore = true) // added by FileMapperDecorator
  @Mapping(target = "milestones", ignore = true)
  @Mapping(target = "revision", ignore = true)
  @Mapping(target = "share", ignore = true)
  @Mapping(target = "updated", ignore = true)
  @Mapping(target = "updatedBy", ignore = true)
  File asFile(FileCreateDto dto, Project project, Folder folder);

  File asClone(File source);

  @Mapping(target = "comments", ignore = true)
  @Mapping(target = "created", ignore = true)
  @Mapping(target = "createdBy", ignore = true)
  @Mapping(target = "folder", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "legacyLinksIncoming", ignore = true)
  @Mapping(target = "linksOutgoing", ignore = true) // added by FileMapperDecorator
  @Mapping(target = "milestones", ignore = true)
  @Mapping(target = "project", ignore = true)
  @Mapping(target = "share", ignore = true)
  @Mapping(target = "updated", ignore = true)
  @Mapping(target = "updatedBy", ignore = true)
  @BeanMapping(nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
  File updateFromDto(@MappingTarget File file, FileUpdateDto dto);

  @Mapping(source = "processDefinition.name", target = "name", defaultExpression = "java( file.getProcessId() )")
  @Mapping(source = "relationId", target = "relationId")
  @Mapping(source = "processDefinition.content", target = "content")
  @BeanMapping(
    ignoreByDefault = true,
    nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
  )
  File updateFromDto(@MappingTarget File file, DiagramEnginePluginDto dto);

  @Mapping(source = "content", target = "content")
  @Mapping(source = "name", target = "name")
  @Mapping(source = "relationId", target = "relationId")
  @BeanMapping(
    ignoreByDefault = true,
    nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
  )
  File updateFromDto(@MappingTarget File file, DiagramModelerPluginDto dto);

  @Mapping(source = "dto.content", target = "content")
  @Mapping(source = "name", target = "name")
  @Mapping(source = "relationId", target = "relationId")
  @BeanMapping(
    ignoreByDefault = true,
    nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.SET_TO_NULL
  )
  File updateFromDto(@MappingTarget File file, ProcessDefinitionVersionCreateDto dto, String name, String relationId);

  @Mapping(source = "dto.processId", target = "processId")
  @Mapping(source = "restoredContent", target = "content")
  @BeanMapping(
    ignoreByDefault = true,
    nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
  )
  File updateFromDto(@MappingTarget File file, MilestoneRestoreDto dto, String restoredContent);

  @Mapping(source = "sourceFile.content", target = "content")
  @Mapping(source = "dto.processId", target = "processId")
  @BeanMapping(
    ignoreByDefault = true,
    nullValueMappingStrategy = NullValueMappingStrategy.RETURN_DEFAULT,
    nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE
  )
  File updateFromDto(@MappingTarget File file, MilestoneAddRelatedDiagramDto dto, File sourceFile);

  @Mapping(source = "dto.processId", target = "processId")
  @Mapping(source = "folder", target = "folder")
  @Mapping(source = "milestone.content", target = "content")
  @Mapping(source = "milestone.file.relationId", target = "relationId")
  @Mapping(source = "milestone.file.type", target = "type")
  @Mapping(source = "name", target = "name")
  @Mapping(source = "project", target = "project")
  @Mapping(target = "comments", ignore = true)
  @Mapping(target = "created", ignore = true)
  @Mapping(target = "createdBy", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "legacyLinksIncoming", ignore = true)
  @Mapping(target = "linksOutgoing", ignore = true) // added by FileMapperDecorator
  @Mapping(target = "milestones", ignore = true)
  @Mapping(target = "revision", ignore = true)
  @Mapping(target = "share", ignore = true)
  @Mapping(target = "updated", ignore = true)
  @Mapping(target = "updatedBy", ignore = true)
  File asFile(FileCreateFromMilestoneDto dto, String name, Milestone milestone, Project project, Folder folder);

  @Mapping(source = "dto.created", target = "created")
  @Mapping(source = "name", target = "name")
  @Mapping(source = "project", target = "project")
  @Mapping(target = "type", expression = "java( FileType.BPMN )")
  @Mapping(target = "createdBy", ignore = true)
  @Mapping(target = "comments", ignore = true)
  @Mapping(target = "folder", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "legacyLinksIncoming", ignore = true)
  @Mapping(target = "linksOutgoing", ignore = true)
  @Mapping(target = "milestones", ignore = true)
  @Mapping(target = "revision", ignore = true)
  @Mapping(target = "share", ignore = true)
  @Mapping(target = "updated", ignore = true)
  @Mapping(target = "updatedBy", ignore = true)
  File asFile(ProcessDefinitionVersionCreateDto dto, String name, String processId, String relationId, Project project);

  @Mapping(source = "dto.deploymentTime", target = "created")
  @Mapping(source = "dto.processDefinition.content", target = "content")
  @Mapping(source = "dto.processDefinition.name", target = "name", defaultExpression = "java( processId )")
  @Mapping(source = "processId", target = "processId")
  @Mapping(source = "project", target = "project")
  @Mapping(target = "type", expression = "java( FileType.BPMN )")
  @Mapping(target = "comments", ignore = true)
  @Mapping(target = "createdBy", ignore = true)
  @Mapping(target = "folder", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "legacyLinksIncoming", ignore = true)
  @Mapping(target = "linksOutgoing", ignore = true)
  @Mapping(target = "milestones", ignore = true)
  @Mapping(target = "revision", ignore = true)
  @Mapping(target = "share", ignore = true)
  @Mapping(target = "updated", ignore = true)
  @Mapping(target = "updatedBy", ignore = true)
  File asFile(DiagramEnginePluginDto dto, String processId, Project project);

  @Mapping(source = "dto.name", target = "name")
  @Mapping(source = "project", target = "project")
  @Mapping(target = "type", expression = "java( FileType.BPMN )")
  @Mapping(target = "comments", ignore = true)
  @Mapping(target = "created", ignore = true)
  @Mapping(target = "createdBy", ignore = true)
  @Mapping(target = "folder", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "legacyLinksIncoming", ignore = true)
  @Mapping(target = "linksOutgoing", ignore = true)
  @Mapping(target = "milestones", ignore = true)
  @Mapping(target = "processId", ignore = true)
  @Mapping(target = "revision", ignore = true)
  @Mapping(target = "share", ignore = true)
  @Mapping(target = "updated", ignore = true)
  @Mapping(target = "updatedBy", ignore = true)
  File asFile(DiagramModelerPluginDto dto, Project project);

  @Mapping(target = "id", source = "id")
  TemplateContentView asTemplateContentView(TemplateCreateDto dto, String id);

  @Mapping(target = "id", source = "id")
  TemplateContentView asTemplateContentView(TemplateUpdateDto dto, String id);

  @Mapping(source = "created", target = "created", qualifiedByName = "asZuluTime")
  @Mapping(source = "folder.id", target = "folderId")
  @Mapping(source = "project.id", target = "projectId")
  @Mapping(source = "updated", target = "updated", qualifiedByName = "asZuluTime")
  @Mapping(source = "file", target = "simplePath")
  @Mapping(source = "file", target = "canonicalPath")
  PublicApiFileMetadataDto asPublicApiFileMetadataDto(FileWithoutContent file);

  @Mapping(source = "created", target = "created", qualifiedByName = "asZuluTime")
  @Mapping(source = "folder.id", target = "folderId")
  @Mapping(source = "project.id", target = "projectId")
  @Mapping(source = "updated", target = "updated", qualifiedByName = "asZuluTime")
  @Mapping(source = "file", target = "simplePath")
  @Mapping(source = "file", target = "canonicalPath")
  PublicApiFileMetadataDto asPublicApiFileMetadataDto(File file);

  List<PublicApiFileMetadataDto> asPublicApiFileMetadataDtoList(List<FileWithoutContent> files);

  PublicApiFileDto asPublicApiFileDto(File file, PublicApiFileMetadataDto metadata);

  @Named("isFileSharePasswordProtected")
  default boolean isFileSharePasswordProtected(FileShare share) {
    return share != null && share.getPassword() != null;
  }

  @Named("fileSlug")
  default String fileSlug(File file) {
    return UrlSlug.buildSlug(file.getId(), file.getName());
  }

  @Named("fileWithoutContentSlug")
  default String fileSlug(FileWithoutContent file) {
    return UrlSlug.buildSlug(file.getId(), file.getName());
  }

  default ZonedDateTime toZonedDateTime(LocalDateTime time) {
    return time.atZone(ZoneOffset.UTC);
  }

  @Named("asZuluTime")
  default String asZuluTime(ZonedDateTime zonedDateTime) {
    return zonedDateTime.withZoneSameInstant(ZoneOffset.UTC).format(DateTimeFormatter.ISO_ZONED_DATE_TIME);
  }
}
