/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.data.entity.event.PrePersistFileEvent;
import com.cawemo.service.pusher.PusherService;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

@Component
@RequiredArgsConstructor
public class FileEventListener {

  private final PusherService pusherService;

  @EventListener
  public void onPrePersistFileEvent(PrePersistFileEvent event) {
    var file = event.getSource();
    if (file.getId() == null) {
      // TODO use Hibernate UUID generator?
      file.setId(UUID.randomUUID().toString());
    }

    if (file.getRelationId() == null) {
      file.setRelationId(file.getId());
    }

    if (file.getRevision() == null) {
      file.setRevision(1);
    }
  }

  @TransactionalEventListener(fallbackExecution = true)
  public void onFileUpdateEvent(FileUpdateEvent event) {
    pusherService.updateFileNotification(event.getSource(), event.getUser(), event.getOriginAppInstanceId());
  }
}
