/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import com.cawemo.data.validation.constraint.NullOrNotBlank;
import com.cawemo.service.file.FileType;
import com.cawemo.util.Constants;
import java.util.Set;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class FileUpdateDto {

  @Size(max = Constants.VARCHAR_MAX)
  @NullOrNotBlank
  private String name;

  @NullOrNotBlank
  private String content;

  @Size(max = Constants.VARCHAR_MAX)
  @NullOrNotBlank
  private String relationId;

  @Size(max = Constants.VARCHAR_MAX)
  @NullOrNotBlank
  private String processId;

  private Set<@NotBlank @Size(max = Constants.VARCHAR_MAX) String> callActivityLinks;

  @Size(max = Constants.VARCHAR_MAX)
  @NotBlank
  private String originAppInstanceId;

  // TODO #10353: frontend should always send revision on updates
  private Integer revision;

  private FileType type;
}
