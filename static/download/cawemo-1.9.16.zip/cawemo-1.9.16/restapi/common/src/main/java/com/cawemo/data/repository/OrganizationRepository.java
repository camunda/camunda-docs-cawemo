/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.User;
import com.cawemo.data.entity.view.OrganizationAdminView;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface OrganizationRepository extends JpaRepository<Organization, String> {

  @Query("SELECT new com.cawemo.data.entity.view.OrganizationAdminView(o, adminPermission.id.user) " +
    "FROM Organization o " +
    "INNER JOIN OrganizationPermission userPermission ON userPermission.id.organization = o AND " +
    "userPermission.id.user = :user " +
    "LEFT JOIN OrganizationPermission adminPermission ON " +
    "adminPermission.id.organization = userPermission.id.organization AND " +
    "adminPermission.access = com.cawemo.service.organization.OrganizationPermissionLevel.ADMIN")
  List<OrganizationAdminView> findOrganizationsWithAdminByUser(@Param("user") User user);
}
