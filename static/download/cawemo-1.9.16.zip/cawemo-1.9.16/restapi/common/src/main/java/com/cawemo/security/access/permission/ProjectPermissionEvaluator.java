/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.access.permission;

import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.view.ProjectPermissionView;
import com.cawemo.data.repository.ProjectRepository;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.project.ProjectOperation;
import com.cawemo.service.project.ProjectPermissionMatcher;
import com.cawemo.service.project.ProjectPermissionService;
import java.util.Collection;
import java.util.List;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
public class ProjectPermissionEvaluator implements EntityPermissionEvaluator<Project, ProjectOperation>,
                                                   EntityCollectionPermissionEvaluator<Project, ProjectOperation> {

  private final ProjectRepository projectRepository;

  public ProjectPermissionEvaluator(@Lazy ProjectRepository projectRepository) {
    this.projectRepository = projectRepository;
  }

  @Override
  public boolean hasPermission(UserAwareUserDetails userDetails, Project project, ProjectOperation projectOperation) {
    return hasPermission(userDetails, List.of(project), projectOperation);
  }

  @Override
  public boolean hasPermission(UserAwareUserDetails userDetails, Collection<Project> projects,
                               ProjectOperation projectOperation) {
    var permissions = projectRepository.findPermissionsByUserAndProjects(userDetails.getUser(), projects);
    return permissions.size() == countDistinctProjectIds(projects) &&
      permissions.stream().allMatch(permission -> isAllowed(permission, projectOperation));
  }

  private long countDistinctProjectIds(Collection<Project> projects) {
    return projects.stream().map(Project::getId).distinct().count();
  }

  private boolean isAllowed(ProjectPermissionView permission, ProjectOperation projectOperation) {
    return ProjectPermissionMatcher.isAllowed(
      permission.getProjectType(),
      ProjectPermissionService.getEffectiveProjectPermissionLevel(permission),
      projectOperation);
  }
}
