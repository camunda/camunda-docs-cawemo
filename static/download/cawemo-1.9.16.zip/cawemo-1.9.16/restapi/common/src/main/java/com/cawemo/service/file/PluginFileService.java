/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.configuration.data.ZonedDateTimeProvider;
import com.cawemo.data.dto.base.request.DiagramEnginePluginDto;
import com.cawemo.data.dto.base.request.DiagramModelerPluginDto;
import com.cawemo.data.dto.base.response.FileDto;
import com.cawemo.data.dto.base.response.TemplateDto;
import com.cawemo.data.entity.ApiKey;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.Milestone;
import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.Project;
import com.cawemo.data.entity.User;
import com.cawemo.data.repository.FileRepository;
import com.cawemo.data.repository.MilestoneRepository;
import com.cawemo.service.milestone.MilestoneMapper;
import com.cawemo.service.milestone.MilestoneService;
import com.cawemo.service.project.ProjectService;
import com.cawemo.util.DateUtil;
import com.cawemo.util.api.ServerException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PluginFileService {

  private final FileMapper fileMapper;
  private final FileRepository fileRepository;
  private final FileService fileService;
  private final MilestoneMapper milestoneMapper;
  private final MilestoneRepository milestoneRepository;
  private final MilestoneService milestoneService;
  private final ObjectMapper objectMapper;
  private final ProjectService projectService;
  private final ZonedDateTimeProvider zonedDateTimeProvider;
  private final Optional<PluginDiagramPostSyncHandler> postSyncHandler;

  public int[] getMissingEngineDiagramVersions(String projectName, String processId, User user) {
    var presentVersions = milestoneService
      .getMilestones(ProjectService.engineDeploymentProjectName(projectName), processId, user)
      .stream()
      .filter(milestone -> milestone.getName() != null)
      .map(milestone -> milestone.getName().replace(MilestoneService.ENGINE_VERSION_PREFIX, ""))
      .map(Integer::valueOf)
      .collect(Collectors.toSet());

    int highestVersion = presentVersions
      .stream()
      .mapToInt(Integer::intValue)
      .max()
      .orElse(0);

    return IntStream.rangeClosed(1, highestVersion)
      .filter(x -> presentVersions
        .stream()
        .noneMatch(version -> version == x))
      .toArray();
  }

  @Transactional
  public void putEngineDiagram(String projectName, String processId, ApiKey apiKey, DiagramEnginePluginDto dto) {
    var project = projectService.getOrCreateEngineProject(apiKey.getOrganization(), apiKey.getUser(), projectName);
    var file = createOrUpdateFile(apiKey.getUser(), processId, dto, project);

    postSyncHandler.ifPresent(handler -> handler.handleAfterPluginDiagramSynced(
      apiKey, PluginDiagramOrigin.ENGINE, file));

    milestoneService.createOrUpdateMilestone(dto, file);
  }

  @Transactional
  public FileDto putModelerDiagram(ApiKey apiKey, DiagramModelerPluginDto dto) {
    var project = projectService.getOrCreateModelerProject(apiKey.getOrganization(), apiKey.getUser());

    var file = createOrUpdateFile(apiKey.getUser(), dto, project);

    postSyncHandler.ifPresent(handler -> handler.handleAfterPluginDiagramSynced(
      apiKey, PluginDiagramOrigin.MODELER, file));

    milestoneService.createMilestone(file, "", dto.getContent(), zonedDateTimeProvider.now());

    return fileMapper.asFileDto(file);
  }

  public List<TemplateDto> getCatalogTemplatesWithMetadata(ApiKey apiKey, boolean includeAllVersions) {
    return getPublishedTemplateVersions(apiKey.getOrganization(), includeAllVersions)
      .stream()
      .map(this::readTemplateContentWithMetadata)
      .collect(Collectors.toList());
  }

  private List<Milestone> getPublishedTemplateVersions(Organization organization, boolean includeAllVersions) {
    return includeAllVersions ?
      milestoneRepository.findByFileProjectOrganizationAndFileTypeIn(
        organization, FileType.forCategory(FileTypeCategory.ELEMENT_TEMPLATE))
      :
      milestoneRepository.findLatestPerFileByOrganizationAndFileTypeIn(organization,
        FileType.forCategory(FileTypeCategory.ELEMENT_TEMPLATE));
  }

  private TemplateDto readTemplateContentWithMetadata(Milestone templateVersion) {
    try {
      return objectMapper.readValue(templateVersion.getContent(), TemplateDto.class)
        .setVersion(DateUtil.asTimestamp(templateVersion.getCreated()))
        .setMetadata(milestoneMapper.asTemplateMetadataDto(templateVersion));
    } catch (JsonProcessingException e) {
      throw new ServerException("Could not parse content of milestone '" + templateVersion.getId() + "' as JSON", e);
    }
  }

  private File createOrUpdateFile(User user, String processId, DiagramEnginePluginDto dto, Project project) {
    return fileRepository.findFirstByProcessIdAndProjectOrderByUpdatedDesc(processId, project)
      .map(file -> {
        if (file.getUpdated().isBefore(dto.getDeploymentTime().atZone(ZoneOffset.UTC))) {
          return fileService.updateFile(fileMapper.updateFromDto(file, dto), user, "");
        } else {
          return file;
        }
      })
      .orElseGet(() -> fileService.createFile(fileMapper.asFile(dto, processId, project)));
  }

  private File createOrUpdateFile(User user, DiagramModelerPluginDto dto, Project project) {
    Optional<File> fileOptional = (dto.getRelationId() != null) ?
      fileRepository.findFirstByProjectAndRelationIdOrderByUpdatedDesc(project, dto.getRelationId()) :
      Optional.empty();

    return fileOptional
      .map(d -> fileService.updateFile(fileMapper.updateFromDto(d, dto), user, ""))
      .orElseGet(() -> fileService.createFile(fileMapper.asFile(dto, project)));
  }
}
