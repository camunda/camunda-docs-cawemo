/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.data.dto.base.response.FileLinkLegacyDto;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.FileLink;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import org.mapstruct.Context;
import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring")
public interface FileLinkMapper {

  @Mapping(target = "sourceFileId", source = "sourceFile.id")
  @Mapping(target = "targetFileId", source = "targetFile.id")
  FileLinkLegacyDto asLegacyDto(FileLink fileLink);

  List<FileLinkLegacyDto> asLegacyDtoList(List<FileLink> fileLinks);

  List<FileLink> asFileLinkList(Set<String> links, @Context File sourceFile);

  default FileLink asFileLink(String link, @Context File sourceFile) {
    if (link == null || sourceFile == null) {
      return null;
    }

    return Stream.ofNullable(sourceFile.getLinksOutgoing())
      .flatMap(Collection::stream)
      .filter(l -> l.getTargetProcessId().equals(link))
      .findFirst()
      .orElseGet(() -> new FileLink()
        .setTargetProcessId(link)
        .setSourceFile(sourceFile));
  }

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "sourceFile", ignore = true)
  FileLink asFileLink(FileLink fileLink);

  @Named("asFileLinkDuplicate")
  default FileLink asFileLinkDuplicate(FileLink fileLink, @Context File duplicatedDiagram) {
    return asFileLink(fileLink).setSourceFile(duplicatedDiagram);
  }

  @IterableMapping(qualifiedByName = "asFileLinkDuplicate")
  List<FileLink> asFileLinkListDuplicate(List<FileLink> links, @Context File duplicatedDiagram);
}
