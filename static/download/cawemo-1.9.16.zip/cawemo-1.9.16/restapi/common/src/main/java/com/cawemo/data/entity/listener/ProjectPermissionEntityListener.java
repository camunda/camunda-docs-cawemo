/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity.listener;

import com.cawemo.data.entity.ProjectPermission;
import com.cawemo.data.entity.event.PostPersistProjectPermissionEvent;
import com.cawemo.data.entity.event.PostRemoveProjectPermissionEvent;
import com.cawemo.data.entity.event.PostUpdateProjectPermissionEvent;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class ProjectPermissionEntityListener {

  private final ApplicationEventPublisher publisher;

  @PostRemove
  public void postRemove(ProjectPermission projectPermission) {
    publisher.publishEvent(new PostRemoveProjectPermissionEvent(projectPermission));
  }

  @PostUpdate
  public void postUpdate(ProjectPermission projectPermission) {
    publisher.publishEvent(new PostUpdateProjectPermissionEvent(projectPermission));
  }

  @PostPersist
  public void postPersist(ProjectPermission projectPermission) {
    publisher.publishEvent(new PostPersistProjectPermissionEvent(projectPermission));
  }
}
