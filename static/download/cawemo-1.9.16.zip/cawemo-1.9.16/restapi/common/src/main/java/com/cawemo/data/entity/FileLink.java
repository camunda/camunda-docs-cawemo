/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.entity;

import com.cawemo.util.Constants;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import lombok.Data;
import lombok.experimental.Accessors;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(
  name = "file_links",
  indexes = {
    @Index(columnList = "created_by"),
    @Index(columnList = "source_file_id"),
    @Index(columnList = "target_file_id"),
    @Index(columnList = "updated_by")
  },
  uniqueConstraints = {
    @UniqueConstraint(columnNames = {"source_file_id", "source_element_id"}),
    @UniqueConstraint(columnNames = {"source_file_id", "target_process_id"})
  }
)
@EntityListeners(AuditingEntityListener.class)
@Data
@Accessors(chain = true)
public class FileLink implements Serializable {

  @Id
  @GeneratedValue(generator = "uuid")
  @GenericGenerator(name = "uuid", strategy = "uuid2")
  private String id;

  @ManyToOne
  @JoinColumn(name = "source_file_id", nullable = false)
  @OnDelete(action = OnDeleteAction.CASCADE)
  private File sourceFile;

  @Column(name = "target_process_id")
  private String targetProcessId;

  @Column(name = "source_element_id")
  private String sourceElementId; // TODO #5029: This only exists for identifying "old" diagram links

  @ManyToOne
  @JoinColumn(name = "target_file_id")
  @OnDelete(action = OnDeleteAction.CASCADE)
  private File targetFile; // TODO #5029: This only exists for identifying "old" diagram links

  @CreatedDate
  @Column(updatable = false, nullable = false)
  private ZonedDateTime created;

  @CreatedBy
  @ManyToOne
  @JoinColumn(name = "created_by", nullable = false)
  private User createdBy;

  @LastModifiedDate
  @Column(nullable = false)
  private ZonedDateTime updated;

  @LastModifiedBy
  @ManyToOne
  @JoinColumn(name = "updated_by", nullable = false)
  private User updatedBy;

  @Override
  public boolean equals(Object object) {
    if (object == null) {
      return false;
    } else if (object == this) {
      return true;
    } else if (!(object instanceof FileLink)) {
      return false;
    } else {
      return Objects.equals(this.id, ((FileLink) object).getId());
    }
  }

  @Override
  public int hashCode() {
    return Constants.ENTITY_HASHCODE;
  }
}
