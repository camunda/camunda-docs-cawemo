/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.data.dto.base.response.FileShareDto;
import com.cawemo.data.dto.base.response.FileShareWrapperDto;
import com.cawemo.data.entity.File;
import com.cawemo.data.entity.FileShare;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", uses = FileMapper.class)
public interface FileShareMapper {

  @Mapping(source = "fileShare.file", target = "file")
  FileShareDto asFileShareDto(FileShare fileShare);

  FileShareWrapperDto asFileShareWrapperDto(FileShare share);

  @Mapping(source = "file", target = "fileSlug", qualifiedByName = "fileSlug")
  FileShareDto.FileShareFileDto asFileShareFileDtoWithSlug(File file);
}
