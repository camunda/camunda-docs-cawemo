/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.service.project.ProjectType;
import java.util.EnumSet;
import java.util.Set;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum FileTypeCategory {

  DIAGRAM(EnumSet.of(ProjectType.DEFAULT, ProjectType.ENGINE, ProjectType.MODELER)),
  ELEMENT_TEMPLATE(EnumSet.of(ProjectType.CATALOG));

  private final Set<ProjectType> allowedProjectTypes;

  public boolean isAllowed(ProjectType type) {
    return allowedProjectTypes.contains(type);
  }
}
