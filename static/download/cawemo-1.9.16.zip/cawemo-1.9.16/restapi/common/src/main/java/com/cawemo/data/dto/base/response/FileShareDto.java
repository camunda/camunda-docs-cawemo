/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.response;

import com.cawemo.data.dto.view.ListView;
import com.cawemo.service.file.FileType;
import com.fasterxml.jackson.annotation.JsonView;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class FileShareDto {

  private String id;
  private FileShareFileDto file;

  @Data
  @Accessors(chain = true)
  public static class FileShareFileDto {

    @JsonView({SlugView.class, WithoutSlugView.class, ListView.class})
    private String name;

    @JsonView({SlugView.class, WithoutSlugView.class})
    private String content;

    @JsonView({SlugView.class, ListView.class})
    private String fileSlug;

    @JsonView({SlugView.class, WithoutSlugView.class, ListView.class})
    private FileType type;
  }

  public static class SlugView {
  }

  public static class WithoutSlugView {
  }
}
