/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.mail.template.view;

import com.cawemo.data.entity.User;
import lombok.Getter;

@Getter
public class ShareDiagramMail extends View {

  private final String message;
  private final String shareLink;

  public ShareDiagramMail(User user, String message, String shareLink) {
    super("share_diagram", user);
    this.message = message;
    this.shareLink = shareLink;
  }
}
