/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.response;

import com.cawemo.service.file.FileType;
import io.swagger.v3.oas.annotations.media.Schema;
import java.time.ZonedDateTime;
import java.util.List;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public abstract class FileBaseDto {

  private String id;

  private String name;

  private String slug;

  // TODO use @SwaggerTimestampField if possible
  @Schema(type = "integer", format = "int64", description = "Timestamp", example = "1576238401000")
  private ZonedDateTime created;

  // TODO use @SwaggerTimestampField if possible
  @Schema(type = "integer", format = "int64", description = "Timestamp", example = "1576238401000")
  private ZonedDateTime changed;

  private String projectId;

  private String folderId;

  private String organizationId;

  private String shareId;

  private Integer revision;

  private boolean passwordProtected;

  private String relationId;

  private String processId;

  private FileType type;

  private UserDto author;

  private List<LinkedFileDto> children;

  private List<LinkedFileDto> parents;
}
