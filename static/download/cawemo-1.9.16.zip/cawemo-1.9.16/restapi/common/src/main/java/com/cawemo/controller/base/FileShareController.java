/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.controller.base;

import com.cawemo.data.dto.base.request.FileShareAuthenticateDto;
import com.cawemo.data.dto.base.request.FileShareCreateDto;
import com.cawemo.data.dto.base.request.FileShareEmailDto;
import com.cawemo.data.dto.base.request.FileSharePasswordDto;
import com.cawemo.data.dto.base.response.FileShareDto;
import com.cawemo.data.dto.base.response.FileShareWrapperDto;
import com.cawemo.data.dto.view.ListView;
import com.cawemo.data.entity.FileShare;
import com.cawemo.security.authentication.UserAwareUserDetails;
import com.cawemo.service.file.FileShareMapper;
import com.cawemo.service.file.FileShareService;
import com.cawemo.service.mail.MailService;
import com.cawemo.util.swagger.SwaggerUuidParameter;
import com.fasterxml.jackson.annotation.JsonView;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "File Shares")
@RequiredArgsConstructor
@RestController
public class FileShareController implements InternalApiController {

  private final FileShareService fileShareService;
  private final FileShareMapper fileShareMapper;
  private final MailService mailService;

  @GetMapping(value = "/shares/{shareId}", produces = MediaType.APPLICATION_JSON_VALUE)
  public MappingJacksonValue getUnprotectedShare(@SwaggerUuidParameter @PathVariable("shareId") FileShare fileShare,
                                                 @AuthenticationPrincipal UserDetails userDetails) {
    fileShareService.ensureShareUnprotected(fileShare);

    return getFileShareDto(fileShare, userDetails);
  }

  @PostMapping(value = "/shares/{shareId}/authenticate", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public MappingJacksonValue getProtectedShare(@SwaggerUuidParameter @PathVariable("shareId") FileShare fileShare,
                                               @Valid @RequestBody @Parameter(required = true)
                                                 FileShareAuthenticateDto dto,
                                               @AuthenticationPrincipal UserDetails userDetails) {
    if (fileShare.getPassword() != null) {
      fileShareService.checkPassword(fileShare, dto.getPassword());
    }

    return getFileShareDto(fileShare, userDetails);
  }

  @JsonView(ListView.class)
  @PreAuthorize("hasPermission(#dto.fileId, 'com.cawemo.data.entity.File', T(ProjectOperation).SHARE_FILE)")
  @PostMapping(value = "/shares", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public FileShareWrapperDto createShare(@Valid @RequestBody @Parameter(required = true) FileShareCreateDto dto) {
    return fileShareMapper.asFileShareWrapperDto(fileShareService.createShare(dto));
  }

  @PreAuthorize("hasPermission(#fileShare.file, T(ProjectOperation).SHARE_FILE)")
  @PostMapping(value = "/shares/{shareId}/password", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void passwordProtectShare(@SwaggerUuidParameter @PathVariable("shareId") FileShare fileShare,
                                   @Valid @RequestBody @Parameter(required = true) FileSharePasswordDto dto) {
    if (StringUtils.isBlank(dto.getPassword())) {
      fileShareService.deletePassword(fileShare);
    } else {
      fileShareService.createPassword(fileShare, dto.getPassword());
    }
  }

  @PreAuthorize("hasPermission(#fileShare.file, T(ProjectOperation).SHARE_FILE)")
  @DeleteMapping("/shares/{shareId}")
  public void deleteShare(@SwaggerUuidParameter @PathVariable("shareId") FileShare fileShare) {
    fileShareService.delete(fileShare);
  }

  @PreAuthorize("hasPermission(#fileShare.file, T(ProjectOperation).SHARE_FILE)")
  @ResponseStatus(HttpStatus.ACCEPTED)
  @PostMapping(value = "/shares/{shareId}/email", consumes = MediaType.APPLICATION_JSON_VALUE)
  public void sendShareEmail(@AuthenticationPrincipal UserAwareUserDetails userDetails,
                             @SwaggerUuidParameter @PathVariable("shareId") FileShare fileShare,
                             @Valid @RequestBody @Parameter(required = true) FileShareEmailDto dto) {
    mailService.sendDiagramShareMails(userDetails.getUser(), fileShare, dto);
  }

  private MappingJacksonValue getFileShareDto(FileShare fileShare, UserDetails userDetails) {
    var result = new MappingJacksonValue(fileShareMapper.asFileShareWrapperDto(fileShare));
    if (userDetails != null) {
      result.setSerializationView(FileShareDto.SlugView.class);
    } else {
      result.setSerializationView(FileShareDto.WithoutSlugView.class);
    }
    return result;
  }
}
