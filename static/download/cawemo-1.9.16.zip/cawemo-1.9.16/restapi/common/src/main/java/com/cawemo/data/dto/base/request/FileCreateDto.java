/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.dto.base.request;

import com.cawemo.data.validation.constraint.NullOrNotBlank;
import com.cawemo.data.validation.constraint.ValidFileCreateData;
import com.cawemo.service.file.FileType;
import com.cawemo.util.Constants;
import java.util.Set;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@ValidFileCreateData
public class FileCreateDto {

  @Size(max = Constants.VARCHAR_MAX)
  @NotBlank
  private String name;

  @NotBlank
  private String content;

  @Size(max = Constants.VARCHAR_MAX)
  @NotBlank
  private String projectId;

  @Size(max = Constants.VARCHAR_MAX)
  @NullOrNotBlank
  private String folderId;

  @Size(max = Constants.VARCHAR_MAX)
  @NotBlank
  private String relationId;

  @Size(max = Constants.VARCHAR_MAX)
  private String processId;

  @NotNull
  private FileType type;

  private Set<@NotBlank @Size(max = Constants.VARCHAR_MAX) String> callActivityLinks;
}
