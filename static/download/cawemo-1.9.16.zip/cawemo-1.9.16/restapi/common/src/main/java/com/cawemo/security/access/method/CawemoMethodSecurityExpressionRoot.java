/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.access.method;

import com.cawemo.security.access.feature.FeatureEvaluator;
import com.cawemo.security.access.permission.CawemoPermissionEvaluator;
import com.cawemo.security.access.permission.FileTypeEvaluator;
import com.cawemo.service.file.FileType;
import com.cawemo.service.file.FileTypeCategory;
import com.cawemo.service.project.ProjectType;
import com.cawemo.util.Feature;
import com.cawemo.util.Permission;
import java.util.Collection;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.access.expression.SecurityExpressionRoot;
import org.springframework.security.access.expression.method.MethodSecurityExpressionOperations;
import org.springframework.security.core.Authentication;
import org.springframework.util.Assert;

public class CawemoMethodSecurityExpressionRoot extends SecurityExpressionRoot
  implements MethodSecurityExpressionOperations {

  private CawemoPermissionEvaluator permissionEvaluator;
  private FeatureEvaluator featureEvaluator;
  private FileTypeEvaluator fileTypeEvaluator;
  private Object filterObject;
  private Object returnObject;
  private Object target;

  public CawemoMethodSecurityExpressionRoot(Authentication authentication, FeatureEvaluator featureEvaluator,
                                            FileTypeEvaluator fileTypeEvaluator) {
    super(authentication);
    setFeatureEvaluator(featureEvaluator);
    setFileTypeEvaluator(fileTypeEvaluator);
  }

  public boolean hasPermissionToCollection(Collection<?> target,
                                           String targetElementType,
                                           Permission permission) {
    return permissionEvaluator.hasPermissionToCollection(authentication, target, targetElementType, permission);
  }

  public boolean hasPermissionToCollection(Collection<?> target,
                                           String sourceElementType,
                                           String targetElementType,
                                           Permission permission) {
    return permissionEvaluator.hasPermissionToCollection(authentication, target, sourceElementType, targetElementType,
      permission);
  }

  public boolean isFeatureEnabled(Object target, Feature feature) {
    return featureEvaluator.isFeatureEnabled(target, feature);
  }

  public boolean isProjectTypeSupportedByLicense(String organizationId, ProjectType type) {
    return featureEvaluator.isProjectTypeSupportedByLicense(organizationId, type);
  }

  public boolean isFileTypeSupportedByLicense(String projectId, FileType type) {
    return featureEvaluator.isFileTypeSupportedByLicense(projectId, type);
  }

  public boolean isFileTypeSupportedByLicense(String fileId) {
    return featureEvaluator.isFileTypeSupportedByLicense(fileId);
  }

  public boolean areFileTypesSupportedByLicense(Collection<String> fileIds) {
    return featureEvaluator.areFileTypesSupportedByLicense(fileIds);
  }

  public boolean areFileTypesSupportedByLicense(String projectId, Collection<String> fileIds) {
    return featureEvaluator.areFileTypesSupportedByLicense(projectId, fileIds);
  }

  public boolean isFileTypeCategoryAllowedForFolder(String folderId, FileTypeCategory category) {
    return fileTypeEvaluator.isFileTypeCategoryAllowedForFolder(folderId, category);
  }

  public boolean isFileTypeCategoryAllowed(String projectId, FileTypeCategory category) {
    return fileTypeEvaluator.isFileTypeCategoryAllowed(projectId, category);
  }

  public boolean areFileTypeCategoriesAllowed(String projectId, Collection<String> fileIds) {
    return fileTypeEvaluator.areFileTypeCategoriesAllowed(projectId, fileIds);
  }

  @Override
  public void setPermissionEvaluator(PermissionEvaluator permissionEvaluator) {
    super.setPermissionEvaluator(permissionEvaluator);
    if (!(permissionEvaluator instanceof CawemoPermissionEvaluator)) {
      throw new IllegalArgumentException("Expected instance of CawemoPermissionEvaluator, got " +
        permissionEvaluator.getClass() + "instead");
    }
    this.permissionEvaluator = (CawemoPermissionEvaluator) permissionEvaluator;
  }

  @Override
  public void setFilterObject(Object filterObject) {
    this.filterObject = filterObject;
  }

  @Override
  public Object getFilterObject() {
    return filterObject;
  }

  @Override
  public void setReturnObject(Object returnObject) {
    this.returnObject = returnObject;
  }

  @Override
  public Object getReturnObject() {
    return returnObject;
  }

  @Override
  public Object getThis() {
    return target;
  }

  public void setThis(Object target) {
    this.target = target;
  }

  public void setFeatureEvaluator(FeatureEvaluator featureEvaluator) {
    Assert.notNull(featureEvaluator, "featureEvaluator cannot be null");
    this.featureEvaluator = featureEvaluator;
  }

  public void setFileTypeEvaluator(FileTypeEvaluator fileTypeEvaluator) {
    Assert.notNull(fileTypeEvaluator, "fileTypeEvaluator cannot be null");
    this.fileTypeEvaluator = fileTypeEvaluator;
  }
}
