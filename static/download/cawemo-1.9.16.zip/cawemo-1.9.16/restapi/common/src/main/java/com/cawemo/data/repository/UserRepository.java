/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.User;
import java.util.Optional;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, String> {

  Optional<User> findByIamId(String iamId);

  Optional<User> findByEmailIgnoreCase(String email);

  boolean existsByUsernameIgnoreCase(String username);

  @Query("SELECT u FROM User u " +
    "WHERE (lower(u.name) LIKE lower(:searchString) OR " +
    "lower(u.username) LIKE lower(:searchString) OR " +
    "lower(u.email) LIKE lower(:searchString)) " +
    "AND u.id <> :id ORDER BY u.email")
  Slice<User> findByNameLikeOrUsernameLikeOrEmailLike_AndIdNot(@Param("searchString") String searchString,
                                                               @Param("id") String id,
                                                               Pageable pageable);
}
