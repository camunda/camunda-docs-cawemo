/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.Preference;
import com.cawemo.data.entity.PreferenceId;
import com.cawemo.data.entity.User;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PreferenceRepository extends JpaRepository<Preference, PreferenceId> {

  List<Preference> findByIdUser(User user);
}
