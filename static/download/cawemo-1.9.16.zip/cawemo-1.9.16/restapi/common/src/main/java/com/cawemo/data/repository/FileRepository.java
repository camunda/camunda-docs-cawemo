/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.repository;

import com.cawemo.data.entity.File;
import com.cawemo.data.entity.Folder;
import com.cawemo.data.entity.Organization;
import com.cawemo.data.entity.Project;
import com.cawemo.data.projection.FileWithProcessIdOnly;
import com.cawemo.data.projection.FileWithoutContent;
import com.cawemo.service.file.FileType;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface FileRepository extends JpaRepository<File, String> {

  /**
   * Returns only files that are not already in the target location.
   **/
  @Query("""
    SELECT f FROM File f WHERE f.id IN :fileIds AND (
    (:targetFolder IS NOT NULL AND (f.folder IS NULL OR f.folder <> :targetFolder)) OR
    (:targetFolder IS NULL AND (f.folder IS NOT NULL OR f.project <> :targetProject)))
    """)
  List<File> findFilesToBeMoved(@Param("fileIds") List<String> fileIds,
                                @Param("targetProject") Project targetProject,
                                @Param("targetFolder") Folder targetFolder);

  List<FileWithoutContent> findByProject(Project project);

  List<FileWithoutContent> findByFolder(Folder folder);

  List<FileWithoutContent> findByProcessIdAndProjectOrderByUpdatedDesc(String processId, Project project);

  List<FileWithoutContent> findByProjectAndFolderIsNullOrderByUpdatedDesc(Project project);

  List<FileWithoutContent> findByProjectInAndRelationIdAndIdNot(List<Project> project, String relationId,
                                                                String excludedFileId);

  List<FileWithoutContent> findByIdIn(Collection<String> fileIds);

  @Query("SELECT f.id FROM File f WHERE f.folder = :folder")
  List<String> findFileIdsByFolder(@Param("folder") Folder folder);

  Optional<File> findFirstByProcessIdAndProjectOrderByUpdatedDesc(String processId, Project project);

  Optional<File> findFirstByProjectAndRelationIdOrderByUpdatedDesc(Project project, String relationId);

  /**
   * Find child files within project.
   */
  List<FileWithProcessIdOnly> findByProcessIdInAndProject(List<String> processIds, Project project);

  /**
   * Find parents files within project.
   */
  List<FileWithProcessIdOnly> findByLinksOutgoingTargetProcessIdNotNullAndLinksOutgoingTargetProcessIdAndProject(
    String processId, Project project);

  @Query("""
    SELECT fl.sourceFile.id FROM FileLink fl
    LEFT JOIN File f ON fl.targetProcessId = f.processId
    WHERE fl.targetProcessId IN :targetProcessIds AND f.project = :project AND fl.sourceFile.project = :project
    """)
  List<String> findSourceFileIdByTargetProcessIdsAndProject(
    @Param("targetProcessIds") Iterable<String> targetProcessIds, @Param("project") Project project);

  @Query("""
    SELECT targetFile.id
    FROM FileLink fl
    LEFT JOIN File sourceFile ON fl.sourceFile = sourceFile
    LEFT JOIN File targetFile ON fl.targetProcessId = targetFile.processId
    WHERE fl.sourceFile IN :sourceFiles AND sourceFile.project = :project AND targetFile.project = :project
    """)
  List<String> findTargetFileIdsByFileLinkSourceFilesAndProject(@Param("sourceFiles") Iterable<File> sourceFiles,
                                                                @Param("project") Project project);

  Slice<File> findByProjectOrganizationAndProcessIdIsNullAndType(Organization organization, Pageable pageable,
                                                                 FileType type);

  @Modifying
  @Transactional
  @Query("""
    UPDATE File SET content = CASE WHEN :content IS NOT NULL THEN :content ELSE content END,
    processId = :processId, revision = revision + 1
    WHERE id = :fileId AND processId IS NULL
    AND type = com.cawemo.service.file.FileType.BPMN
    """)
  int updateContentProcessIdRevisionIfProcessIdNullAndTypeBPMN(@Param("content") String content,
                                                               @Param("processId") String processId,
                                                               @Param("fileId") String fileId);

  List<File> findByProjectOrganizationAndTypeIn(Organization organization, Iterable<FileType> types);

  List<File> findByProjectOrganizationAndProjectAndTypeIn(Organization organization, Project project,
                                                          Iterable<FileType> types);
}
