/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.service.file;

import com.cawemo.util.api.ApiError;
import com.cawemo.util.api.ConflictException;

public class FileConflictException extends ConflictException {

  FileConflictException() {
    super(ApiError.REVISION_CONFLICT);
  }
}
