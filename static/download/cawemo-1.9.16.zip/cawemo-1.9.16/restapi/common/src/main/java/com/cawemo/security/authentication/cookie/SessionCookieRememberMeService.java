/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.security.authentication.cookie;

import com.cawemo.configuration.data.ZonedDateTimeProvider;
import com.cawemo.configuration.security.WebSecurityConfiguration;
import com.cawemo.data.entity.Session;
import com.cawemo.data.entity.User;
import com.cawemo.data.repository.SessionRepository;
import com.cawemo.security.authentication.UserAwareUserDetails;
import java.time.ZonedDateTime;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.AuthenticationDetailsSource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.rememberme.AbstractRememberMeServices;
import org.springframework.security.web.authentication.rememberme.InvalidCookieException;
import org.springframework.security.web.authentication.rememberme.RememberMeAuthenticationException;
import org.springframework.stereotype.Service;

@Service
public class SessionCookieRememberMeService extends AbstractRememberMeServices {

  public static final String SESSION_COOKIE_NAME = "cawemo_sessionid";

  private final SessionRepository sessionRepository;
  private final AuthenticationDetailsSource<User, UserAwareUserDetails> detailsSource;
  private final ZonedDateTimeProvider zonedDateTimeProvider;

  public SessionCookieRememberMeService(UserDetailsService userDetailsService,
                                        AuthenticationDetailsSource<User, UserAwareUserDetails> detailsSource,
                                        SessionRepository sessionRepository,
                                        ZonedDateTimeProvider zonedDateTimeProvider) {
    super(WebSecurityConfiguration.REMEMBER_ME_KEY, userDetailsService);
    super.setCookieName(SESSION_COOKIE_NAME);
    this.detailsSource = detailsSource;
    this.sessionRepository = sessionRepository;
    this.zonedDateTimeProvider = zonedDateTimeProvider;
  }

  /**
   * Not called as we're not offering interactive authentication and thus should do nothing.
   */
  @Override
  protected void onLoginSuccess(HttpServletRequest request, HttpServletResponse response,
                                Authentication successfulAuthentication) {
  }

  @Override
  protected UserDetails processAutoLoginCookie(String[] cookieTokens, HttpServletRequest request,
                                               HttpServletResponse response)
    throws RememberMeAuthenticationException, UsernameNotFoundException {
    var now = zonedDateTimeProvider.now();
    return sessionRepository.findByIdAndValidUntilAfter(cookieTokens[0], now)
      .map(persistedSession -> {
        var session = persistedSession.getUpdated().plusMinutes(1).isBefore(now) ?
          updateSession(persistedSession, now) : persistedSession;
        return detailsSource.buildDetails(session.getUser());
      })
      .orElseThrow(() -> new InvalidCookieException("Session not found or expired"));
  }

  @Override
  protected String[] decodeCookie(String cookieValue) throws InvalidCookieException {
    return new String[]{cookieValue};
  }

  private Session updateSession(Session session, ZonedDateTime now) {
    session.setUpdated(now);
    return sessionRepository.save(session);
  }
}
