/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements.
 *
 * Licensed under a commercial license.
 * You may not use this file except in compliance with the commercial license.
 */
package com.cawemo.data.validation;

import com.cawemo.data.validation.constraint.ValidBpmn;
import com.cawemo.util.BpmnUtil;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;
import org.camunda.bpm.model.xml.ModelException;

public class ValidBpmnValidator implements ConstraintValidator<ValidBpmn, String> {

  public static boolean isValid(String bpmn) {
    if (StringUtils.isBlank(bpmn)) {
      return false;
    }

    try {
      // validation is done within parseModelFromStream
      BpmnUtil.getBpmnModelInstance(bpmn);
    } catch (ModelException e) {
      return false;
    }

    return true;
  }

  @Override
  public boolean isValid(String value, ConstraintValidatorContext context) {
    return isValid(value);
  }
}
