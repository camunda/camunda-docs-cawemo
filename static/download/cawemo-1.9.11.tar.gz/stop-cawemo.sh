#!/bin/bash -eu

BASE_DIR=$(dirname "$0")
readonly BASE_DIR
readonly DOCKER_COMPOSE_DIR=$BASE_DIR/docker-compose

docker --log-level=error compose \
  -f "$DOCKER_COMPOSE_DIR"/docker-compose.yml \
  -f "$DOCKER_COMPOSE_DIR"/docker-compose.demo.yml \
  -f "$DOCKER_COMPOSE_DIR"/docker-compose.reverse-proxy.yml \
  down -v
