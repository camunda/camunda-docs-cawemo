This is a distribution of

       Cawemo v1.9.31

visit
       https://docs.camunda.org/cawemo

==================

### Contents:
    /
        start-cawemo-sh                     -   script to start Cawemo
        stop-cawemo-sh                      -   script to stop Cawemo

    configuration/
        .env.demo                           -   ready-to-use configuration file for the demo setup
        .env.production                     -   configuration file for the production setup
        license-key.txt                     -   Camunda license key
                                                (please replace the file contents with your personal license key)

    docker-compose/
        docker-compose.yml                  -   core components (Cawemo and Camunda Account)
        docker-compose.demo.yml             -   additional applications (PostgreSQL and MailHog) for the demo setup
        docker-compose.reverse-proxy.yml    -   additional configuration for the (optional) reverse proxy

    helpers/
        create-demo-databases.sql           -   script that creates the databases for Cawemo and Camunda Account
                                                (used in demo setup only)

### Prerequisites

- Docker with Docker Compose V2 must be installed on your machine.

- A valid Enterprise license is required to use Cawemo. Please put your license key into:
    configuration/license-key.txt
  You can sign up for a free 30-day trial license at https://camunda.com/download/enterprise.

- Log in to Camunda's Docker registry with the credentials you received from Camunda by executing:
    docker login registry.camunda.cloud


### Run Cawemo (demo setup)

This distribution includes a ready-to-use configuration for running Cawemo in a demo setup. This is useful if you'd
like to try out Cawemo on your local computer. However, it is NOT recommended for production use.

The demo setup includes:
  - a PostgreSQL database
  - MailHog as SMTP server (see https://github.com/mailhog/MailHog)
    Please note that MailHog does not relay the e-mails to the actual recipients, but simply catches them. You can
    inspect the received e-mails at: http://localhost:8025

To start Cawemo, run the startup script without any arguments:
  ./start-cawemo.sh


### Run Cawemo (production setup)

The production configuration neither includes a database nor an SMTP server, so you'd have to set them up separately.
For more details please refer to:
  https://docs.camunda.org/cawemo/1.9/technical-guide/installation/#production-setup

To start Cawemo, please follow the steps below:

1. Add the missing values – according to your own setup – in:
     configuration/.env.production

   For a description of the different settings please refer to:
     https://docs.camunda.org/cawemo/1.9/technical-guide/installation/configuration

   You can leave the following values empty since they will be generated automatically by the startup script:
     - SERVER_SESSION_COOKIE_SECRET
     - WEBSOCKET_SECRET
     - CLIENT_SECRET
     - IAM_DATABASE_ENCRYPTION_KEY
     - IAM_TOKEN_SIGNING_KEY

2. Run the startup script with the argument "--production":
     ./start-cawemo.sh --production


### Stop Cawemo

To stop Cawemo, please run:
  ./stop-cawemo.sh

The script will shut down and remove all previously started Docker containers.


### Enable LDAP Integration

You can enable the LDAP integration by setting
  LDAP_ENABLED=true
in the configuration file.

At least the following environment variables must be set:
  - IAM_LDAP_SERVER_URL
  - IAM_LDAP_UUID_ATTRIBUTE
  - IAM_LDAP_USER_NAME_ATTRIBUTES
  - IAM_LDAP_USER_EMAIL_ATTRIBUTE

Depending on your LDAP server, other settings might be required as well. For more details please refer to:
  https://docs.camunda.org/cawemo/1.9/technical-guide/installation/ldap-support


### Enable Reverse Proxy

This distribution includes a sample configuration for running Cawemo behind an NGINX reverse proxy with SSL support.

To enable the reverse proxy, please follow the steps described on:
  https://docs.camunda.org/cawemo/1.9/technical-guide/installation/reverse-proxy-configuration


=================

Cawemo version: 1.9.31
Camunda Account version: v1.1.21

=================
